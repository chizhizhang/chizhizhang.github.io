#!/usr/bin/env python3
"""Build revision evidence tables from life-test records.

This script is the reproducible bridge between reviewer comments, figures,
manuscript numbers, and the response letter. By default it reads the restricted
real CSV files under ``data/LifeTest-*-RITS*_clean.csv`` and regenerates the
reported manuscript outputs. The optional ``--data-dir`` argument can be used
with the public pseudo-data files to inspect the workflow and file formats; such
pseudo-data runs are checks only and are not the source of the manuscript
numbers.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr, ndtri_exp


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = ROOT / "data"
DEFAULT_BUILD = ROOT / "outputs"
DEFAULT_MODEL = DEFAULT_BUILD

CURRENT_BY_GROUP = {1: 3.0, 2: 3.5, 3: 4.0, 4: 4.5}
STATE_NAMES = {1: "Stable", 2: "Drift", 3: "L80 risk", 4: "Collapse"}
FEATURES = [
    "D",
    "loss_rate",
    "heat_proxy_W",
    "lambda_shift_nm",
    "bw_shift_nm",
    "spectral_instability",
    "eta",
]
ORIGIN_GRID = [100.0, 200.0, 300.0]
AGE_GRID = np.arange(0.0, 501.0, 1.0)
SURV_GRID = np.arange(0.0, 501.0, 2.0)
SCORING_GRID = np.arange(0.0, 601.0, 1.0)
RAW_RECORDS: dict[str, pd.DataFrame] = {}


def stable_seed(*parts: object) -> int:
    text = "|".join(str(part) for part in parts)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return int(digest[:16], 16) % (2**32)


@dataclass
class UnitRecord:
    file: str
    source_file: str
    current_A: float
    raw: pd.DataFrame
    grid: pd.DataFrame
    P0: float
    P_first: float
    baseline_age_h: float
    baseline_values: dict[str, float]


def current_from_record(path: Path, frame: pd.DataFrame) -> float:
    """Return the stress current from a real-data name or a public pseudo file.

    Restricted real files encode the current group in the file name. Public
    pseudo-data files use anonymized names, so the current is read from the
    measurement column after verifying that the column is internally consistent.
    """
    try:
        group = int(path.name.split("-")[1])
        if group in CURRENT_BY_GROUP:
            return CURRENT_BY_GROUP[group]
    except (IndexError, ValueError):
        pass

    values = pd.to_numeric(frame["Current_A"], errors="coerce").dropna().to_numpy(dtype=float)
    if values.size == 0:
        raise ValueError(f"{path} does not contain a usable Current_A column")
    current = float(np.median(values))
    if float(np.nanmax(np.abs(values - current))) > 1e-6:
        raise ValueError(f"{path} contains multiple current levels; expected one fixed stress")
    return current


def read_life_file(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, comment="#").sort_values("Duration_h").reset_index(drop=True)
    required = {"Duration_h", "Current_A", "Voltage_V", "P", "Lambda_nm", "BW_nm"}
    missing = sorted(required.difference(df.columns))
    if missing:
        raise ValueError(f"{path} is missing columns: {missing}")
    return df


def first_row_at_or_after(df: pd.DataFrame, age_h: float) -> pd.Series:
    after = df[df["Duration_h"] >= age_h]
    if after.empty:
        return df.iloc[-1]
    return after.iloc[0]


def rolling_std(values: np.ndarray, window: int) -> np.ndarray:
    series = pd.Series(values)
    return (
        series.rolling(window=window, min_periods=3)
        .std()
        .bfill()
        .fillna(0.0)
        .to_numpy(dtype=float)
    )


def past_slope(values: np.ndarray, window: int = 15) -> np.ndarray:
    out = np.zeros_like(values, dtype=float)
    for i in range(len(values)):
        j = max(0, i - window)
        dt = max(1.0, float(i - j))
        out[i] = (float(values[i]) - float(values[j])) / dt
    return out


def persistent_crossing(age: np.ndarray, y: np.ndarray, threshold: float, window: int = 5) -> tuple[float, int]:
    hit = y <= threshold
    for idx in range(0, len(hit) - window + 1):
        if bool(hit[idx : idx + window].all()):
            return float(age[idx]), 1
    return 500.0, 0


def assign_states(y: np.ndarray, D: np.ndarray, loss_rate: np.ndarray) -> np.ndarray:
    """Assign ordered states from observable health depth and local rate.

    The risk state is tied to the persistent L80 boundary. The drift state is
    entered before L80 when optical loss or recent loss rate becomes visible.
    """
    state = np.ones(len(y), dtype=int)
    drift = (D >= 0.080) | ((D >= 0.045) & (loss_rate >= 0.00045))
    state[drift] = 2
    state[y <= 0.800] = 3
    state[y <= 0.500] = 4
    return np.maximum.accumulate(state)


def load_units(data_dir: Path) -> list[UnitRecord]:
    records: list[UnitRecord] = []
    candidates = sorted(data_dir.glob("LifeTest-*-RITS*_clean.csv"))
    if not candidates:
        candidates = sorted(data_dir.glob("*_clean.csv"))
    for path in candidates:
        df = read_life_file(path)
        RAW_RECORDS[path.name] = df.copy()
        current = current_from_record(path, df)
        baseline = first_row_at_or_after(df, 20.0)
        P0 = float(baseline["P"])
        P_first = float(df["P"].iloc[0])
        x = df["Duration_h"].to_numpy(dtype=float)
        grid = pd.DataFrame({"t_h": AGE_GRID, "age_h": AGE_GRID})
        for col in ["Current_A", "Voltage_V", "P", "Lambda_nm", "BW_nm"]:
            grid[col] = np.interp(AGE_GRID, x, df[col].to_numpy(dtype=float))

        y = grid["P"].to_numpy(dtype=float) / P0
        D = 1.0 - y
        loss_rate = np.maximum(0.0, past_slope(D, window=15))
        input_power = grid["Current_A"].to_numpy(dtype=float) * grid["Voltage_V"].to_numpy(dtype=float)
        baseline_input_power = float(baseline["Current_A"] * baseline["Voltage_V"])
        heat_proxy = (input_power - grid["P"].to_numpy(dtype=float)) - (baseline_input_power - P0)
        lambda_shift = grid["Lambda_nm"].to_numpy(dtype=float) - float(baseline["Lambda_nm"])
        bw_shift = grid["BW_nm"].to_numpy(dtype=float) - float(baseline["BW_nm"])
        spectral_instability = np.sqrt(rolling_std(lambda_shift, 21) ** 2 + rolling_std(bw_shift, 21) ** 2)
        eta = grid["P"].to_numpy(dtype=float) / np.maximum(input_power, 1e-9)
        state = assign_states(y, D, loss_rate)

        grid["file"] = path.name
        grid["source_file"] = path.name
        grid["current_A"] = current
        grid["D"] = D
        grid["loss_rate"] = loss_rate
        grid["heat_proxy_W"] = heat_proxy
        grid["lambda_shift_nm"] = lambda_shift
        grid["bw_shift_nm"] = bw_shift
        grid["spectral_instability"] = spectral_instability
        grid["eta"] = eta
        grid["state"] = state

        records.append(
            UnitRecord(
                file=path.name,
                source_file=path.name,
                current_A=current,
                raw=df,
                grid=grid,
                P0=P0,
                P_first=P_first,
                baseline_age_h=float(baseline["Duration_h"]),
                baseline_values={
                    "Current_A": float(baseline["Current_A"]),
                    "Voltage_V": float(baseline["Voltage_V"]),
                    "P": P0,
                    "Lambda_nm": float(baseline["Lambda_nm"]),
                    "BW_nm": float(baseline["BW_nm"]),
                },
            )
        )
    if not records:
        raise FileNotFoundError(f"No life-test files found under {data_dir}")
    return records


def build_baseline_table(records: list[UnitRecord]) -> pd.DataFrame:
    rows = []
    for rec in records:
        rows.append(
            {
                "file": rec.file,
                "source_file": rec.source_file,
                "current_A": rec.current_A,
                "P0": rec.P0,
                "P_first": rec.P_first,
                "tb_group_constrained_h": 0.0,
                "baseline_reference_age_h": rec.baseline_age_h,
                "censor_age_h": 500.0,
            }
        )
    return pd.DataFrame(rows)


def build_endpoint_table(records: list[UnitRecord]) -> pd.DataFrame:
    rows = []
    for rec in records:
        y = 1.0 - rec.grid["D"].to_numpy(dtype=float)
        t90, e90 = persistent_crossing(AGE_GRID, y, 0.90, window=5)
        t80, e80 = persistent_crossing(AGE_GRID, y, 0.80, window=5)
        t50, e50 = persistent_crossing(AGE_GRID, y, 0.50, window=5)
        rows.append(
            {
                "file": rec.file,
                "source_file": rec.source_file,
                "current_A": rec.current_A,
                "T90_age_h": t90 if e90 else np.nan,
                "T90_abs_h": t90 if e90 else np.nan,
                "E90": e90,
                "T80_age_h": t80,
                "T80_abs_h": t80,
                "E80": e80,
                "T50_age_h": t50 if e50 else np.nan,
                "T50_abs_h": t50 if e50 else np.nan,
                "E50": e50,
                "censor_age_h": 500.0,
            }
        )
    return pd.DataFrame(rows)


def build_decoded(records: list[UnitRecord]) -> pd.DataFrame:
    cols = [
        "file",
        "source_file",
        "current_A",
        "t_h",
        "age_h",
        "state",
        "D",
        "loss_rate",
        "heat_proxy_W",
        "lambda_shift_nm",
        "bw_shift_nm",
        "spectral_instability",
        "eta",
    ]
    frames = []
    for rec in records:
        frame = rec.grid[cols].copy()
        y = 1.0 - frame["D"].to_numpy(dtype=float)
        age = frame["age_h"].to_numpy(dtype=float)
        threshold_time, event = persistent_crossing(age, y, 0.8)
        state = frame["state"].to_numpy(dtype=int)
        # Full-record training routes must obey the persistent endpoint, not
        # an isolated one-hour dip. This mask is never used for a held-out origin.
        before = age < threshold_time if event else np.ones(len(age), dtype=bool)
        state[before] = np.minimum(state[before], 2)
        if event:
            state[~before] = np.maximum(state[~before], 3)
        frame["state"] = state
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def causal_origin_history(decoded_unit,t0):
    file=str(decoded_unit.file.iloc[0]);raw=RAW_RECORDS[file];available=raw[raw.Duration_h<=t0].copy()
    baseline=available[available.Duration_h>=20]
    if baseline.empty:raise ValueError("Prediction origin precedes the reference")
    ref=baseline.iloc[0];age=np.arange(0.,t0+1,1.);v={c:np.interp(age,available.Duration_h,available[c]) for c in ['P','Current_A','Voltage_V','Lambda_nm','BW_nm']}
    power=v['P'];depth=1-power/ref.P;rate=np.maximum(0.,past_slope(depth,15));ip=v['Current_A']*v['Voltage_V'];lam=v['Lambda_nm']-ref.Lambda_nm;bw=v['BW_nm']-ref.BW_nm
    frame=pd.DataFrame({'file':file,'age_h':age,'D':depth,'loss_rate':rate,'heat_proxy_W':ip-power-(ref.Current_A*ref.Voltage_V-ref.P),'lambda_shift_nm':lam,'bw_shift_nm':bw,'spectral_instability':np.sqrt(rolling_std(lam,21)**2+rolling_std(bw,21)**2),'eta':power/np.maximum(ip,1e-9)})
    frame['state']=assign_states(1-depth,depth,rate)
    variant=decoded_unit.attrs.get('route_variant')
    if variant:
        frame.attrs['origin_history']=True;frame,_,_,_=derive_state_variant(frame,variant,decoded_unit.attrs.get('route_seed',0))
    return frame



def build_segments(decoded: pd.DataFrame, endpoints: pd.DataFrame) -> pd.DataFrame:
    return build_segments_for_risk(decoded, endpoints, risk_state=3)


def build_segments_for_risk(decoded: pd.DataFrame, endpoints: pd.DataFrame, risk_state: int) -> pd.DataFrame:
    endpoint_index = endpoints.set_index("file")
    rows = []
    for file, sub in decoded.sort_values(["file", "age_h"]).groupby("file", sort=False):
        sub = sub.reset_index(drop=True)
        states = sub["state"].astype(int).to_numpy()
        ages = sub["age_h"].to_numpy(dtype=float)
        starts = [0]
        for idx in range(1, len(sub)):
            if states[idx] != states[idx - 1]:
                starts.append(idx)
        starts.append(len(sub))
        for j in range(len(starts) - 1):
            a = starts[j]
            b = starts[j + 1]
            start_age = float(ages[a])
            end_age = float(ages[b - 1])
            state = int(states[a])
            completed = int(b < len(sub))
            if state < risk_state and int(endpoint_index.loc[file, "E80"]) == 0 and b == len(sub):
                completed = 0
            rows.append(
                {
                    "file": file,
                    "current_A": float(sub["current_A"].iloc[0]),
                    "state": state,
                    "start_age_h": start_age,
                    "end_age_h": end_age,
                    "duration_h": end_age - start_age + (1.0 if completed else 0.0),
                    "completed": completed,
                }
            )
    return pd.DataFrame(rows)


def robust_center_scale(values: pd.Series) -> tuple[float, float]:
    x = values.to_numpy(dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return 0.0, 1.0
    med = float(np.median(x))
    mad = float(np.median(np.abs(x - med)))
    scale = 1.4826 * mad
    if not np.isfinite(scale) or scale < 1e-9:
        scale = float(np.std(x) or 1.0)
    return med, max(scale, 1e-9)


def lognormal_logsf(log_duration: np.ndarray, mean: np.ndarray, sigma: float) -> np.ndarray:
    z = (log_duration - mean) / (sigma * math.sqrt(2.0))
    sf = np.vectorize(math.erfc)(z) / 2.0
    return np.log(np.clip(sf, 1e-300, 1.0))


def fit_alpha(frame: pd.DataFrame) -> tuple[float, float, float]:
    d = frame[frame["duration_h"] > 0].copy()
    if d.empty:
        return np.nan, np.nan, np.nan
    y = np.log(np.maximum(d["duration_h"].to_numpy(dtype=float), 1.0))
    x = np.log(d["current_A"].to_numpy(dtype=float) / 3.0)
    completed = d["completed"].fillna(1).to_numpy(dtype=int)

    if d["current_A"].nunique() < 2 or len(d) < 3:
        mu = float(np.mean(y))
        sigma = float(np.std(y, ddof=1)) if len(y) > 1 else 0.35
        return mu, max(0.25, min(1.25, sigma)), 0.0

    X = np.column_stack([np.ones_like(x), -x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    init_mu = float(beta[0])
    init_alpha = float(max(0.0, beta[1]))
    init_sigma = float(np.std(y - X @ np.array([init_mu, init_alpha]), ddof=1)) if len(y) > 2 else 0.35
    init_sigma = max(0.25, min(1.25, init_sigma))

    def nll(theta: np.ndarray) -> float:
        mu, alpha, log_sigma = theta
        sigma = float(np.exp(log_sigma))
        mean = mu - alpha * x
        ll_event = -np.log(np.maximum(d["duration_h"].to_numpy(dtype=float), 1.0)) - np.log(sigma) - 0.5 * np.log(2.0 * np.pi) - 0.5 * ((y - mean) / sigma) ** 2
        ll_censored = lognormal_logsf(y, mean, sigma)
        ll = completed * ll_event + (1 - completed) * ll_censored
        return -float(np.sum(ll))

    res = minimize(
        nll,
        np.array([init_mu, init_alpha, math.log(init_sigma)]),
        method="L-BFGS-B",
        bounds=[(math.log(1.0), math.log(2000.0)), (0.0, 8.0), (math.log(0.20), math.log(1.50))],
        options={"maxiter": 2000},
    )
    if not res.success:
        mu = init_mu
        sigma = init_sigma
        alpha = init_alpha
    else:
        mu, alpha, log_sigma = res.x
        sigma = float(np.exp(log_sigma))
    return float(mu), float(max(0.20, min(1.50, sigma))), float(max(0.0, alpha))


def build_parameters(decoded: pd.DataFrame, segments: pd.DataFrame) -> pd.DataFrame:
    return build_parameters_for_states(decoded, segments, sorted(STATE_NAMES), STATE_NAMES)


def build_parameters_for_states(decoded,segments,states,state_names,mode="full"):
    return soft_parameter_table(decoded,states,state_names,mode)



def current_stress_transform(current: np.ndarray | float, transform: str) -> np.ndarray:
    arr = np.asarray(current, dtype=float)
    if transform == "log_current_ratio":
        return np.log(arr / 3.0)
    if transform == "linear_current":
        return arr - 3.0
    raise ValueError(f"unknown current stress transform: {transform}")


def fit_weibull_aft(endpoints: pd.DataFrame, transform: str = "log_current_ratio") -> dict[str, float]:
    df = endpoints.copy()
    t = np.maximum(df["T80_age_h"].to_numpy(dtype=float), 1.0)
    e = df["E80"].to_numpy(dtype=int)
    x = current_stress_transform(df["current_A"].to_numpy(dtype=float), transform)

    def nll(theta: np.ndarray) -> float:
        beta0, beta1, log_shape = theta
        shape = math.exp(float(log_shape))
        log_lambda = beta0 + beta1 * x
        z = (t / np.exp(log_lambda)) ** shape
        ll_event = np.log(shape) - shape * log_lambda + (shape - 1.0) * np.log(t) - z
        ll_cens = -z
        ll = e * ll_event + (1 - e) * ll_cens
        return -float(np.sum(ll))

    init = np.array([np.log(np.median(t)), -2.0, np.log(2.0)])
    res = minimize(nll, init, method="Nelder-Mead", options={"maxiter": 20000})
    beta0, beta1, log_shape = res.x
    return {
        "beta0": float(beta0),
        "beta1": float(beta1),
        "shape": float(np.exp(log_shape)),
        "transform": transform,
        "reference_current_A": 3.0,
    }


def weibull_survival(age: np.ndarray, current: float, params: dict[str, float]) -> np.ndarray:
    transform = str(params.get("transform", "log_current_ratio"))
    lam = math.exp(params["beta0"] + params["beta1"] * float(current_stress_transform(current, transform)))
    shape = params["shape"]
    return np.exp(-((np.maximum(age, 0.0) / lam) ** shape))


def weibull_residual_quantiles(t0: float, current: float, params: dict[str, float], probs: list[float]) -> np.ndarray:
    transform = str(params.get("transform", "log_current_ratio"))
    lam = math.exp(params["beta0"] + params["beta1"] * float(current_stress_transform(current, transform)))
    shape = params["shape"]
    base = (t0 / lam) ** shape
    out = []
    for p in probs:
        target = base - math.log(max(1e-9, 1.0 - p))
        out.append(max(0.0, lam * (target ** (1.0 / shape)) - t0))
    return np.asarray(out, dtype=float)


def params_table_to_dict(params: pd.DataFrame) -> dict[int, dict[str, float]]:
    d = {}
    for _, row in params[params["feature"].isna()].iterrows():
        d[int(row["state"])] = {
            "mu": float(row["sojourn_mu_log_h"]),
            "sigma": float(row["sojourn_sigma_log_h"]),
            "alpha": float(row["current_accel_alpha"]),
        }
    return d






def simulate_rul_samples(origin_row,decoded,params,method,n=5000,risk_state=3):
    fit=params.attrs.get('soft_model')
    if fit is None:raise ValueError('Soft predictions require the fitted emission and duration model')
    unit=decoded[decoded.file.eq(origin_row['file'])];hist=causal_origin_history(unit,float(origin_row.t0_h));x=(hist[FEATURES].to_numpy()-fit['center'])/fit['scale'];current=float(origin_row.current_A)
    mask=endpoint_mask(len(hist),len(fit['emission'][2]),risk_state,alive=True)
    _,posterior,_,_=forward_backward(x,current,fit['theta'],fit['emission'],mask,stats=False,geometric=fit['mode']=='geometric')
    mass=posterior[:risk_state-1].copy();mass/=mass.sum();S,A=mass.shape;rng=np.random.default_rng(stable_seed(origin_row['file'],float(origin_row.t0_h),method))
    sampled=rng.choice(S*A,size=n,p=mass.ravel());state=sampled//A;age=sampled%A;total=np.zeros(n)
    for s in range(risk_state-1):
        active=state<=s;elapsed=np.where(state[active]==s,age[active],0);mu,alpha,logsigma=fit['theta'][s];loc=mu-alpha*np.log(current/3);sigma=np.exp(logsigma)
        if fit['mode']=='geometric':dur=rng.geometric(min(.999999,1/max(1.000001,np.exp(loc))),active.sum())+elapsed
        else:
            z=np.full(len(elapsed),-np.inf);nonzero=elapsed>0;z[nonzero]=(np.log(elapsed[nonzero])-loc)/sigma
            durations=np.exp(loc-sigma*ndtri_exp(log_ndtr(-z)+np.log(np.maximum(rng.random(len(elapsed)),np.finfo(float).tiny))));dur=np.ceil(durations)
        total[active]+=dur-elapsed
    key=(str(origin_row['file']),float(origin_row.t0_h),method)
    if key not in SOFT_ORIGIN_ROWS:
        nonzero=mass>0;SOFT_ORIGIN_ROWS[key]={'file':key[0],'t0_h':key[1],'method':method,'posterior_sum':float(mass.sum()),'posterior_entropy':float(-np.sum(mass[nonzero]*np.log(mass[nonzero]))),'maximum_state_age_mass':float(mass.max()),'mean_residence_age_h':float(np.sum(mass*np.arange(A))),**{f'p_state_{s+1}':float(mass[s].sum()) for s in range(S)}}
        SOFT_ORIGIN_MASS[key]=mass
    return np.clip(total,0,1200)





def fit_wiener_current_exponent(decoded: pd.DataFrame) -> float:
    rows = []
    for file, sub in decoded.sort_values(["file", "age_h"]).groupby("file"):
        pre = sub[sub["age_h"].between(0.0, 500.0)].copy()
        if len(pre) < 20:
            continue
        x = pre["age_h"].to_numpy(dtype=float)
        y = pre["D"].to_numpy(dtype=float)
        X = np.column_stack([np.ones_like(x), x - x.min()])
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        slope = max(float(beta[1]), 1e-6)
        rows.append({"current_A": float(pre["current_A"].iloc[0]), "slope": slope})
    frame = pd.DataFrame(rows)
    if frame.empty or frame["current_A"].nunique() < 2:
        return 0.0
    x = np.log(frame["current_A"].to_numpy(dtype=float) / 3.0)
    y = np.log(frame["slope"].to_numpy(dtype=float))
    X = np.column_stack([np.ones_like(x), x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    return float(np.clip(beta[1], 0.0, 5.0))


def wiener_origin_parameters(origin_row: pd.Series, decoded: pd.DataFrame) -> dict[str, float]:
    file = str(origin_row["file"])
    t0 = float(origin_row["t0_h"])
    current = float(origin_row["current_A"])
    unit = causal_origin_history(decoded[decoded["file"].eq(file)], t0)
    if unit.empty:
        return {
            "D0": 0.0,
            "recent_drift_per_h": 1e-3,
            "sigma_increment": 0.0025,
            "current_exponent_gamma": 0.0,
            "current_scale": 1.0,
        }
    D0 = float(unit["D"].iloc[-1])
    recent = unit[unit["age_h"] >= max(0.0, t0 - 60.0)]
    if len(recent) >= 5:
        x = recent["age_h"].to_numpy(dtype=float)
        y = recent["D"].to_numpy(dtype=float)
        X = np.column_stack([np.ones_like(x), x - x.min()])
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        drift = max(float(beta[1]), 1e-4)
    else:
        drift = 1e-3
    train = decoded[decoded["file"].ne(file)]
    increments = train.sort_values(["file", "age_h"]).groupby("file")["D"].diff().dropna()
    sigma = float(np.nanstd(increments.to_numpy(dtype=float)))
    sigma = max(sigma, 0.0025)
    gamma = fit_wiener_current_exponent(train)
    current_scale = max(0.25, math.exp(gamma * math.log(current / 3.0)))
    return {
        "D0": D0,
        "recent_drift_per_h": drift,
        "sigma_increment": sigma,
        "current_exponent_gamma": gamma,
        "current_scale": current_scale,
    }


def simulate_wiener_samples(
    origin_row: pd.Series,
    decoded: pd.DataFrame,
    endpoints: pd.DataFrame,
    n: int = 5000,
) -> np.ndarray:
    rng_seed = stable_seed(origin_row["file"], float(origin_row["t0_h"]), "wiener")
    rng = np.random.default_rng(rng_seed)
    pars = wiener_origin_parameters(origin_row, decoded)
    D0 = pars["D0"]
    drift = pars["recent_drift_per_h"]
    sigma = pars["sigma_increment"]
    current_scale = pars["current_scale"]
    remaining = max(0.0, 0.20 - D0)
    if remaining <= 0:
        return np.zeros(n, dtype=float)
    max_steps = 1200
    paths = np.full(n, max_steps, dtype=float)
    level = np.full(n, D0, dtype=float)
    for step in range(1, max_steps + 1):
        active = paths == max_steps
        if not active.any():
            break
        level[active] += drift * current_scale + rng.normal(0.0, sigma, int(active.sum()))
        crossed = active & (level >= 0.20)
        paths[crossed] = step
    return paths


def make_prediction_origins(endpoints: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in endpoints[endpoints["E80"].eq(1)].iterrows():
        for t0 in ORIGIN_GRID:
            if t0 < float(row["T80_age_h"]):
                rows.append(
                    {
                        "fold_id": f"LOU_{row['file']}",
                        "file": row["file"],
                        "current_A": float(row["current_A"]),
                        "t0_h": t0,
                        "T80_age_h": float(row["T80_age_h"]),
                        "true_rul_h": float(row["T80_age_h"] - t0),
                    }
                )
    return pd.DataFrame(rows)


def build_rul_predictions(
    decoded: pd.DataFrame,
    endpoints: pd.DataFrame,
    origins: pd.DataFrame,
    all_params: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, list[np.ndarray]]]:
    rows = []
    sample_store: dict[str, list[np.ndarray]] = {}
    for _, origin in origins.iterrows():
        train_endpoints = endpoints[endpoints["file"].ne(origin["file"])]
        train_decoded = decoded[decoded["file"].ne(origin["file"])]
        train_segments = build_segments(train_decoded, train_endpoints)
        train_params = build_parameters(train_decoded, train_segments)
        if train_params[train_params["feature"].isna()]["sojourn_mu_log_h"].isna().all():
            raise ValueError("Held-out fold has no estimable training residence parameters")
        weibull = fit_weibull_aft(train_endpoints)
        method_samples = {
            "NH_HSMM": simulate_rul_samples(origin, decoded, train_params, "NH_HSMM"),
            "shared_accel_HSMM_ablation": simulate_rul_samples(origin, decoded, soft_parameter_table(train_decoded,[1,2,3,4],STATE_NAMES,"shared"), "shared_accel_HSMM_ablation"),
            "homogeneous_HSMM_ablation": simulate_rul_samples(origin, decoded, soft_parameter_table(train_decoded,[1,2,3,4],STATE_NAMES,"independent"), "homogeneous_HSMM_ablation"),
            "no_explicit_duration_HMM_ablation": simulate_rul_samples(origin, decoded, soft_parameter_table(train_decoded,[1,2,3,4],STATE_NAMES,"geometric"), "no_explicit_duration_HMM_ablation"),
            "wiener_degradation_FP_baseline": simulate_wiener_samples(origin, decoded, endpoints),
        }
        q = weibull_residual_quantiles(float(origin["t0_h"]), float(origin["current_A"]), weibull, [0.10, 0.50, 0.90])
        method_samples["weibull_AFT_endpoint_baseline"] = weibull_residual_quantiles(float(origin["t0_h"]), float(origin["current_A"]), weibull, (np.arange(5000) + 0.5) / 5000)
        for method, samples in method_samples.items():
            p10, p50, p90 = np.quantile(samples, [0.10, 0.50, 0.90])
            if method == "weibull_AFT_endpoint_baseline":
                p10, p50, p90 = q
            rows.append(
                {
                    "method": method,
                    "fold_id": origin["fold_id"],
                    "file": origin["file"],
                    "current_A": float(origin["current_A"]),
                    "t0_h": float(origin["t0_h"]),
                    "true_rul_h": float(origin["true_rul_h"]),
                    "p10_h": float(p10),
                    "p50_h": float(p50),
                    "p90_h": float(p90),
                }
            )
            sample_store.setdefault(method, []).append(samples)
    return pd.DataFrame(rows), sample_store


def cluster_bootstrap_ci(pred: pd.DataFrame, seed: int = 20260704) -> tuple[float, float, float]:
    files = np.array(sorted(pred["file"].unique()))
    rng = np.random.default_rng(seed)
    point = float(np.mean(np.abs(pred["p50_h"] - pred["true_rul_h"])))
    reps = []
    for _ in range(2000):
        chosen = rng.choice(files, len(files), replace=True)
        boot = pd.concat([pred[pred["file"].eq(f)] for f in chosen], ignore_index=True)
        reps.append(float(np.mean(np.abs(boot["p50_h"] - boot["true_rul_h"]))))
    lo, hi = np.quantile(reps, [0.025, 0.975])
    return point, float(lo), float(hi)


def rul_survival_iae(pred: pd.DataFrame, samples_by_row: list[np.ndarray]) -> float:
    values = []
    for (_, row), samples in zip(pred.iterrows(), samples_by_row):
        true = float(row["true_rul_h"])
        pred_surv = (samples[:, None] > SCORING_GRID[None, :]).mean(axis=0)
        obs_surv = (true > SCORING_GRID).astype(float)
        values.append(np.trapezoid(np.abs(pred_surv - obs_surv), SCORING_GRID) / SCORING_GRID[-1])
    return float(np.mean(values)) if values else np.nan


def summarize_prediction_metrics(pred: pd.DataFrame, samples_by_row: list[np.ndarray]) -> dict[str, float]:
    mae, lo, hi = cluster_bootstrap_ci(pred)
    bias = float(np.mean(pred["p50_h"] - pred["true_rul_h"]))
    coverage = float(((pred["true_rul_h"] >= pred["p10_h"]) & (pred["true_rul_h"] <= pred["p90_h"])).mean())
    iae = rul_survival_iae(pred.reset_index(drop=True), samples_by_row)
    return {
        "rul_p50_mae_h": round(mae, 1),
        "rul_p50_mae_lo95_h": round(lo, 1),
        "rul_p50_mae_hi95_h": round(hi, 1),
        "rul_p50_bias_h": round(bias, 1),
        "rul_p10_p90_coverage": round(coverage, 3),
        "rul_survival_iae": round(iae, 3),
    }


def build_ablation_summary(predictions: pd.DataFrame, sample_store: dict[str, list[np.ndarray]]) -> pd.DataFrame:
    rows = []
    for method, pred in predictions.groupby("method", sort=False):
        metrics = summarize_prediction_metrics(pred, sample_store.get(method, []))
        rows.append({"method": method, **metrics})
    order = [
        "NH_HSMM",
        "weibull_AFT_endpoint_baseline",
        "wiener_degradation_FP_baseline",
        "no_explicit_duration_HMM_ablation",
        "homogeneous_HSMM_ablation",
        "shared_accel_HSMM_ablation",
    ]
    out = pd.DataFrame(rows)
    out["method"] = pd.Categorical(out["method"], categories=order, ordered=True)
    return out.sort_values("method").assign(method=lambda d: d["method"].astype(str)).reset_index(drop=True)


def build_weibull_transform_predictions(
    endpoints: pd.DataFrame,
    origins: pd.DataFrame,
    transform: str,
    method: str,
) -> tuple[pd.DataFrame, list[np.ndarray]]:
    rows = []
    samples_by_row = []
    for _, origin in origins.iterrows():
        train_endpoints = endpoints[endpoints["file"].ne(origin["file"])]
        params = fit_weibull_aft(train_endpoints, transform=transform)
        q = weibull_residual_quantiles(float(origin["t0_h"]), float(origin["current_A"]), params, [0.10, 0.50, 0.90])
        samples = weibull_residual_quantiles(float(origin["t0_h"]), float(origin["current_A"]), params, (np.arange(5000) + 0.5) / 5000)
        p10, p50, p90 = q
        rows.append(
            {
                "method": method,
                "fold_id": origin["fold_id"],
                "file": origin["file"],
                "current_A": float(origin["current_A"]),
                "t0_h": float(origin["t0_h"]),
                "true_rul_h": float(origin["true_rul_h"]),
                "p10_h": float(p10),
                "p50_h": float(p50),
                "p90_h": float(p90),
            }
        )
        samples_by_row.append(samples)
    return pd.DataFrame(rows), samples_by_row


def acceleration_row(
    law_family: str,
    reviewer_example: str,
    required_stress_channels: str,
    available_stress_channels: str,
    estimable: bool,
    fitted_comparator: str,
    transform_or_reason: str,
    metrics: dict[str, float] | None = None,
) -> dict[str, object]:
    row: dict[str, object] = {
        "law_family": law_family,
        "reviewer_example": reviewer_example,
        "required_stress_channels": required_stress_channels,
        "available_stress_channels": available_stress_channels,
        "estimable_from_current_dataset": estimable,
        "fitted_comparator": fitted_comparator,
        "transform_or_reason": transform_or_reason,
        "rul_p50_mae_h": np.nan,
        "rul_p50_mae_lo95_h": np.nan,
        "rul_p50_mae_hi95_h": np.nan,
        "rul_p50_bias_h": np.nan,
        "rul_p10_p90_coverage": np.nan,
        "rul_survival_iae": np.nan,
    }
    if metrics:
        row.update(metrics)
    return row


def build_acceleration_law_benchmark_summary(
    predictions: pd.DataFrame,
    sample_store: dict[str, list[np.ndarray]],
    endpoints: pd.DataFrame,
    origins: pd.DataFrame,
) -> pd.DataFrame:
    nh_pred = predictions[predictions["method"].eq("NH_HSMM")]
    aft_pred = predictions[predictions["method"].eq("weibull_AFT_endpoint_baseline")]
    linear_pred, linear_samples = build_weibull_transform_predictions(
        endpoints,
        origins,
        "linear_current",
        "weibull_AFT_current_linear_endpoint_benchmark",
    )
    rows = [
        acceleration_row(
            "State-specific current-residence NH-HSMM",
            "NH-HSMM comparison row",
            "Drive current and monitored degradation histories",
            "Drive current, voltage, optical power, wavelength, bandwidth",
            True,
            "Full NH-HSMM",
            "State-specific residence clocks with g(I)=log(I/I_ref)",
            summarize_prediction_metrics(nh_pred, sample_store.get("NH_HSMM", [])),
        ),
        acceleration_row(
            "Current inverse-power/log-current endpoint Weibull AFT",
            "Conventional current-stress acceleration benchmark",
            "Drive current and L80 endpoint or censoring time",
            "Drive current and L80 endpoint/censoring status",
            True,
            "Endpoint Weibull AFT",
            "Endpoint AFT with g(I)=log(I/I_ref)",
            summarize_prediction_metrics(aft_pred, sample_store.get("weibull_AFT_endpoint_baseline", [])),
        ),
        acceleration_row(
            "Current-linear endpoint Weibull AFT",
            "Conventional current-stress acceleration sensitivity",
            "Drive current and L80 endpoint or censoring time",
            "Drive current and L80 endpoint/censoring status",
            True,
            "Endpoint Weibull AFT",
            "Endpoint AFT with g(I)=I-I_ref",
            summarize_prediction_metrics(linear_pred, linear_samples),
        ),
        acceleration_row(
            "Thermal acceleration law",
            "Arrhenius / Eyring",
            "Controlled junction or chamber temperature, and activation-energy or interaction terms",
            "Temperature was not recorded in the restricted life-test files",
            False,
            "Not fitted",
            "Not identifiable without measured thermal stress; fitting it would introduce unsupported stress variables",
        ),
        acceleration_row(
            "Humidity-temperature acceleration law",
            "Peck",
            "Relative humidity and temperature",
            "Humidity and temperature were not recorded",
            False,
            "Not fitted",
            "Not identifiable without humidity-temperature stress channels",
        ),
        acceleration_row(
            "Thermal-cycling acceleration law",
            "Norris-Landzberg",
            "Thermal-cycle amplitude, frequency or dwell profile, and temperature",
            "Thermal cycling was not applied or recorded",
            False,
            "Not fitted",
            "Not identifiable without cycling stress variables",
        ),
        acceleration_row(
            "Fatigue acceleration law",
            "Basquin",
            "Cyclic mechanical stress or strain amplitude and cycle count",
            "Mechanical fatigue stress and cycle count were not recorded",
            False,
            "Not fitted",
            "Not identifiable without mechanical fatigue loading variables",
        ),
    ]
    return pd.DataFrame(rows)


def build_unit_level_error_summary(predictions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (method, file), sub in predictions.groupby(["method", "file"], sort=False):
        err = sub["p50_h"].to_numpy(dtype=float) - sub["true_rul_h"].to_numpy(dtype=float)
        rows.append(
            {
                "method": method,
                "file": file,
                "current_A": float(sub["current_A"].iloc[0]),
                "prediction_origins": int(len(sub)),
                "mean_abs_error_h": round(float(np.mean(np.abs(err))), 1),
                "median_abs_error_h": round(float(np.median(np.abs(err))), 1),
                "mean_bias_h": round(float(np.mean(err)), 1),
                "p10_p90_covered": int(((sub["true_rul_h"] >= sub["p10_h"]) & (sub["true_rul_h"] <= sub["p90_h"])).sum()),
            }
        )
    return pd.DataFrame(rows)


def build_wiener_benchmark_parameters(decoded: pd.DataFrame, origins: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, origin in origins.iterrows():
        pars = wiener_origin_parameters(origin, decoded)
        rows.append(
            {
                "fold_id": origin["fold_id"],
                "file": origin["file"],
                "current_A": float(origin["current_A"]),
                "t0_h": float(origin["t0_h"]),
                "D0": pars["D0"],
                "recent_drift_per_h": pars["recent_drift_per_h"],
                "sigma_increment": pars["sigma_increment"],
                "current_exponent_gamma": pars["current_exponent_gamma"],
                "current_scale": pars["current_scale"],
                "threshold_D": 0.20,
            }
        )
    return pd.DataFrame(rows)


def summarize_prediction_frame(predictions: pd.DataFrame, sample_store: dict[str, list[np.ndarray]]) -> pd.DataFrame:
    rows = []
    for method, pred in predictions.groupby("method", sort=False):
        mae, lo, hi = cluster_bootstrap_ci(pred)
        rows.append(
            {
                "method": method,
                "rul_p50_mae_h": round(mae, 1),
                "rul_p50_mae_lo95_h": round(lo, 1),
                "rul_p50_mae_hi95_h": round(hi, 1),
                "rul_p50_bias_h": round(float(np.mean(pred["p50_h"] - pred["true_rul_h"])), 1),
                "rul_p10_p90_coverage": round(float(((pred["true_rul_h"] >= pred["p10_h"]) & (pred["true_rul_h"] <= pred["p90_h"])).mean()), 3),
                "rul_survival_iae": round(rul_survival_iae(pred.reset_index(drop=True), sample_store.get(method, [])), 3),
            }
        )
    return pd.DataFrame(rows)




def build_transition_probability_grid(params: pd.DataFrame) -> pd.DataFrame:
    base = params[params["feature"].isna()].copy()
    states = sorted(base["state"].astype(int).tolist())
    max_state = max(states)
    rows = []
    for current in [3.0, 3.5, 4.0, 4.5]:
        for _, row in base.iterrows():
            state = int(row["state"])
            state_name = str(row["state_name"])
            if state >= max_state:
                rows.append(
                    {
                        "current_A": current,
                        "from_state": state,
                        "from_state_name": state_name,
                        "to_state": state,
                        "to_state_name": state_name,
                        "residence_age_h": 0.0,
                        "one_hour_transition_probability": 0.0,
                        "one_hour_stay_probability": 1.0,
                        "embedded_transition_probability": 1.0,
                    }
                )
                continue
            mu = float(row["sojourn_mu_log_h"])
            sigma = float(row["sojourn_sigma_log_h"])
            alpha = float(row["current_accel_alpha"])
            mu_eff = mu - alpha * math.log(current / 3.0)
            for residence_age in [0.0, 25.0, 50.0, 100.0, 200.0, 300.0, 500.0]:
                z0 = (math.log(residence_age) - mu_eff) / sigma if residence_age > 0 else -np.inf
                z1 = (math.log(residence_age + 1.0) - mu_eff) / sigma
                # Equivalent to the CDF formula, without cancellation when
                # both CDF values round to one in the upper tail.
                p_jump = float(np.clip(-np.expm1(log_ndtr(-z1) - log_ndtr(-z0)), 0.0, 1.0))
                to_state = min(max_state, state + 1)
                rows.append(
                    {
                        "current_A": current,
                        "from_state": state,
                        "from_state_name": state_name,
                        "to_state": to_state,
                        "to_state_name": str(base.loc[base["state"].astype(int).eq(to_state), "state_name"].iloc[0]),
                        "residence_age_h": residence_age,
                        "one_hour_transition_probability": p_jump,
                        "one_hour_stay_probability": 1.0 - p_jump,
                        "embedded_transition_probability": 1.0,
                    }
                )
    return pd.DataFrame(rows)


def build_stress_transfer_summary(
    decoded: pd.DataFrame,
    endpoints: pd.DataFrame,
    origins: pd.DataFrame,
    all_params: pd.DataFrame,
) -> pd.DataFrame:
    """Leave one current group out and score origins in the excluded group."""
    rows = []
    sample_store: dict[str, list[np.ndarray]] = {}
    for held_current in sorted(origins["current_A"].unique()):
        train_endpoints = endpoints[~np.isclose(endpoints["current_A"], held_current)]
        train_decoded = decoded[~np.isclose(decoded["current_A"], held_current)]
        if train_endpoints["E80"].sum() < 2:
            continue
        train_segments = build_segments(train_decoded, train_endpoints)
        train_params = build_parameters(train_decoded, train_segments)
        if train_params[train_params["feature"].isna()]["sojourn_mu_log_h"].isna().all():
            raise ValueError("Held-current fold has no estimable training residence parameters")
        weibull = fit_weibull_aft(train_endpoints)
        held_origins = origins[np.isclose(origins["current_A"], held_current)]
        for _, origin in held_origins.iterrows():
            method_samples = {
                "NH_HSMM": simulate_rul_samples(origin, decoded, train_params, "NH_HSMM"),
                "homogeneous_HSMM_ablation": simulate_rul_samples(origin, decoded, soft_parameter_table(train_decoded,[1,2,3,4],STATE_NAMES,"independent"), "homogeneous_HSMM_ablation"),
            }
            q = weibull_residual_quantiles(float(origin["t0_h"]), float(origin["current_A"]), weibull, [0.10, 0.50, 0.90])
            method_samples["weibull_AFT_endpoint_baseline"] = weibull_residual_quantiles(float(origin["t0_h"]), float(origin["current_A"]), weibull, (np.arange(5000) + 0.5) / 5000)
            for method, samples in method_samples.items():
                p10, p50, p90 = np.quantile(samples, [0.10, 0.50, 0.90])
                if method == "weibull_AFT_endpoint_baseline":
                    p10, p50, p90 = q
                rows.append(
                    {
                        "held_out_current_A": float(held_current),
                        "method": method,
                        "fold_id": f"LOC_{held_current:.1f}A",
                        "file": origin["file"],
                        "current_A": float(origin["current_A"]),
                        "t0_h": float(origin["t0_h"]),
                        "true_rul_h": float(origin["true_rul_h"]),
                        "p10_h": float(p10),
                        "p50_h": float(p50),
                        "p90_h": float(p90),
                    }
                )
                sample_store.setdefault(method, []).append(samples)
    if not rows:
        return pd.DataFrame(
            columns=[
                "method",
                "rul_p50_mae_h",
                "rul_p50_mae_lo95_h",
                "rul_p50_mae_hi95_h",
                "rul_p50_bias_h",
                "rul_p10_p90_coverage",
                "rul_survival_iae",
            ]
        )
    pred = pd.DataFrame(rows)
    summary = summarize_prediction_frame(pred, sample_store)
    summary.insert(0, "data_separation", "leave-one-current")
    summary.insert(1, "scored_origins", int(origins.shape[0]))
    summary.insert(2, "unique_units", int(origins["file"].nunique()))
    return summary


def sample_first_passage(params: pd.DataFrame, current: float, n: int = 40000, method: str = "NH_HSMM") -> np.ndarray:
    rng = np.random.default_rng(stable_seed(current, method))
    p = params_table_to_dict(params)
    total = np.zeros(n, dtype=float)
    for s in [1, 2]:
        row = p[s]
        mu_eff = row["mu"] - row["alpha"] * math.log(current / 3.0)
        total += np.ceil(rng.lognormal(mu_eff, row["sigma"], size=n))
    return total


def build_reliability_curves(params: pd.DataFrame, endpoints: pd.DataFrame) -> pd.DataFrame:
    rows = []
    weibull = fit_weibull_aft(endpoints)
    observed_currents = sorted(endpoints["current_A"].unique())
    methods = [
        "NH_HSMM",
        "shared_accel_HSMM_ablation",
        "homogeneous_HSMM_ablation",
        "weibull_AFT_endpoint_baseline",
    ]
    for method in methods:
        per_current_surv = []
        for current in observed_currents:
            if method == "weibull_AFT_endpoint_baseline":
                surv = weibull_survival(SURV_GRID, current, weibull)
            else:
                fp = sample_first_passage(FULL_MODEL_TABLES[method], current, method="NH_HSMM")
                surv = np.array([(fp > age).mean() for age in SURV_GRID], dtype=float)
            per_current_surv.append(surv)
            for age, s in zip(SURV_GRID, surv):
                rows.append(
                    {
                        "reliability_scope": "component_level",
                        "reliability_target": "L80_first_passage",
                        "method": method,
                        "current_A": f"{current:.1f}",
                        "age_h": float(age),
                        "survival": float(s),
                    }
                )
        pooled = np.mean(np.vstack(per_current_surv), axis=0)
        for age, s in zip(SURV_GRID, pooled):
            rows.append(
                {
                    "reliability_scope": "component_level",
                    "reliability_target": "L80_first_passage",
                    "method": method,
                    "current_A": "pooled",
                    "age_h": float(age),
                    "survival": float(s),
                }
            )
    return pd.DataFrame(rows)


def build_decoded_alignment(endpoints: pd.DataFrame, decoded: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in endpoints.iterrows():
        sub = decoded[decoded["file"].eq(row["file"])]
        hit = sub[sub["state"] >= 3]
        decoded_entry = float(hit["age_h"].iloc[0]) if len(hit) else np.nan
        out = row.to_dict()
        out["decoded_l80_entry_age_h"] = decoded_entry
        rows.append(out)
    return pd.DataFrame(rows)


def build_transition_summary(segments: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for current in sorted(segments["current_A"].unique()):
        subcur = segments[segments["current_A"].eq(current)]
        total = max(1, len(subcur))
        for state in [1, 2, 3, 4]:
            sub = subcur[subcur["state"].eq(state)]
            rows.append(
                {
                    "current_A": float(current),
                    "state": state,
                    "state_name": STATE_NAMES[state],
                    "segments": int(len(sub)),
                    "median_duration_h": float(np.median(sub["duration_h"])) if len(sub) else np.nan,
                    "segment_share": float(len(sub) / total),
                    "allowed_next_state": min(4, state + 1),
                }
            )
    return pd.DataFrame(rows)


def monotone_state_by_file(frame: pd.DataFrame, state_values: np.ndarray) -> np.ndarray:
    out = np.empty_like(state_values, dtype=int)
    offset = 0
    for _, sub in frame.groupby("file", sort=False):
        n = len(sub)
        out[offset : offset + n] = np.maximum.accumulate(state_values[offset : offset + n])
        offset += n
    return out


def derive_state_variant(decoded: pd.DataFrame, variant: str, seed: int = 0) -> tuple[pd.DataFrame, list[int], dict[int, str], int]:
    out = decoded.copy()
    y = 1.0 - out["D"].to_numpy(dtype=float)
    D = out["D"].to_numpy(dtype=float)
    loss_rate = out["loss_rate"].to_numpy(dtype=float)

    if variant == "selected_5_state":
        states = [1, 2, 3, 4]
        names = STATE_NAMES
        risk_state = 3
        raw_state = out["state"].astype(int).to_numpy()
    elif variant == "four_state_merged_pre_risk":
        states = [1, 2, 3]
        names = {1: "Pre-risk", 2: "L80 risk", 3: "Collapse"}
        risk_state = 2
        raw_state = np.ones(len(out), dtype=int)
        raw_state[y <= 0.800] = 2
        raw_state[y <= 0.500] = 3
    elif variant == "six_state_l90_warning":
        states = [1, 2, 3, 4, 5]
        names = {1: "Stable", 2: "Early drift", 3: "L90 warning", 4: "L80 risk", 5: "Collapse"}
        risk_state = 4
        raw_state = np.ones(len(out), dtype=int)
        raw_state[(D >= 0.050) | ((D >= 0.035) & (loss_rate >= 0.00035))] = 2
        raw_state[(y <= 0.900) | (D >= 0.100) | (loss_rate >= 0.00060)] = 3
        raw_state[y <= 0.800] = 4
        raw_state[y <= 0.500] = 5
    elif variant == "random_ordered":
        states = [1, 2, 3, 4]
        names = STATE_NAMES
        risk_state = 3
        rng = np.random.default_rng(seed)
        drift_depth = float(rng.uniform(0.060, 0.105))
        early_depth = float(rng.uniform(0.035, 0.060))
        slope_threshold = float(rng.uniform(0.00030, 0.00070))
        raw_state = np.ones(len(out), dtype=int)
        raw_state[(D >= drift_depth) | ((D >= early_depth) & (loss_rate >= slope_threshold))] = 2
        raw_state[y <= 0.800] = 3
        raw_state[y <= 0.500] = 4
    else:
        raise ValueError(f"Unknown sensitivity variant: {variant}")

    out["state"] = monotone_state_by_file(out, raw_state)
    # Preserve the selected route's persistent L80 boundary in training data.
    original_risk = decoded["state"].to_numpy(dtype=int) >= 3
    if not decoded.attrs.get("origin_history", False):
        revised = out["state"].to_numpy(dtype=int)
        revised[~original_risk] = np.minimum(revised[~original_risk], risk_state - 1)
        revised[original_risk] = np.maximum(revised[original_risk], risk_state)
        out["state"] = revised
    out.attrs["route_variant"] = variant
    out.attrs["route_seed"] = seed
    return out, states, names, risk_state


def build_variant_predictions(
    decoded: pd.DataFrame,
    endpoints: pd.DataFrame,
    origins: pd.DataFrame,
    states: list[int],
    state_names: dict[int, str],
    risk_state: int,
    variant_label: str,
    n_samples: int = 3000,
) -> pd.DataFrame:
    rows = []
    for _, origin in origins.iterrows():
        train_endpoints = endpoints[endpoints["file"].ne(origin["file"])]
        train_decoded = decoded[decoded["file"].ne(origin["file"])]
        train_segments = build_segments_for_risk(train_decoded, train_endpoints, risk_state=risk_state)
        train_params = build_parameters_for_states(train_decoded, train_segments, states, state_names)
        samples = simulate_rul_samples(
            origin,
            decoded,
            train_params,
            f"{variant_label}_NH_HSMM",
            n=n_samples,
            risk_state=risk_state,
        )
        p10, p50, p90 = np.quantile(samples, [0.10, 0.50, 0.90])
        rows.append(
            {
                "method": variant_label,
                "fold_id": origin["fold_id"],
                "file": origin["file"],
                "current_A": float(origin["current_A"]),
                "t0_h": float(origin["t0_h"]),
                "true_rul_h": float(origin["true_rul_h"]),
                "p10_h": float(p10),
                "p50_h": float(p50),
                "p90_h": float(p90),
            }
        )
    return pd.DataFrame(rows)


def summarize_variant_predictions(pred: pd.DataFrame, seed: int) -> dict[str, float]:
    mae, lo, hi = cluster_bootstrap_ci(pred, seed=seed)
    return {
        "rul_mae_h": round(mae, 1),
        "rul_mae_lo95_h": round(lo, 1),
        "rul_mae_hi95_h": round(hi, 1),
        "rul_bias_h": round(float(np.mean(pred["p50_h"] - pred["true_rul_h"])), 1),
        "coverage": round(float(((pred["true_rul_h"] >= pred["p10_h"]) & (pred["true_rul_h"] <= pred["p90_h"])).mean()), 3),
    }


def build_sensitivity_summary(
    decoded: pd.DataFrame,
    endpoints: pd.DataFrame,
    origins: pd.DataFrame,
    predictions: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    selected_pred = predictions[predictions["method"].eq("NH_HSMM")].copy()
    selected_summary = summarize_variant_predictions(
        selected_pred.assign(method="selected_reference_plus_4_post_burn"),
        seed=20260704,
    )
    rows.append(
        {
            "ordered_stages_including_reference": 5,
            "decoded_post_burn_states": 4,
            "reference_phase": "fixed post-burn reference phase; not decoded as a residence state",
            "risk_set": "{S3,S4}",
            "initialization": "health-ordered",
            "route_restarts": 1,
            "variant": "selected_reference_plus_4_post_burn",
            "source": "actual leave-one-unit predictions",
            **selected_summary,
            "restart_mae_min_h": np.nan,
            "restart_mae_median_h": np.nan,
            "restart_mae_max_h": np.nan,
            "interpretation": "selected",
        }
    )

    for variant, ordered_stages, post_burn_states, risk_set, initialization in [
        ("four_state_merged_pre_risk", 4, 3, "{S2,S3}", "merged-stable-drift"),
        ("six_state_l90_warning", 6, 5, "{S4,S5}", "L90-warning split"),
        ("random_ordered", 5, 4, "{S3,S4}", "random-ordered seed 20260704"),
    ]:
        v_decoded, states, names, risk_state = derive_state_variant(decoded, variant, seed=20260704)
        v_pred = build_variant_predictions(v_decoded, endpoints, origins, states, names, risk_state, variant)
        rows.append(
            {
                "ordered_stages_including_reference": ordered_stages,
                "decoded_post_burn_states": post_burn_states,
                "reference_phase": "fixed post-burn reference phase; not decoded as a residence state",
                "risk_set": risk_set,
                "initialization": initialization,
                "route_restarts": 1,
                "variant": variant,
                "source": "actual variant refit at each leave-one-unit origin",
                **summarize_variant_predictions(v_pred, seed=stable_seed(variant, "summary")),
                "restart_mae_min_h": np.nan,
                "restart_mae_median_h": np.nan,
                "restart_mae_max_h": np.nan,
                "interpretation": "sensitivity check",
            }
        )

    restart_summaries = []
    best_row = None
    for restart in range(5):
        v_decoded, states, names, risk_state = derive_state_variant(decoded, "random_ordered", seed=20260704 + restart)
        v_pred = build_variant_predictions(v_decoded, endpoints, origins, states, names, risk_state, f"restart_{restart:02d}", n_samples=2500)
        summary = summarize_variant_predictions(v_pred, seed=stable_seed("restart", restart))
        restart_summaries.append(summary["rul_mae_h"])
        candidate = {
            "ordered_stages_including_reference": 5,
            "decoded_post_burn_states": 4,
            "reference_phase": "fixed post-burn reference phase; not decoded as a residence state",
            "risk_set": "{S3,S4}",
            "initialization": "best of random-ordered restarts",
            "route_restarts": 5,
            "variant": "random_ordered_5_restarts_summary",
            "source": "actual 5 soft-EM initializations refit at each leave-one-unit origin",
            **summary,
            "restart_mae_min_h": np.nan,
            "restart_mae_median_h": np.nan,
            "restart_mae_max_h": np.nan,
            "interpretation": "descriptive restart sensitivity; no test-score-selected primary model",
        }
        if best_row is None or candidate["rul_mae_h"] < best_row["rul_mae_h"]:
            best_row = candidate
    assert best_row is not None
    best_row["restart_mae_min_h"] = round(float(np.min(restart_summaries)), 1)
    best_row["restart_mae_median_h"] = round(float(np.median(restart_summaries)), 1)
    best_row["restart_mae_max_h"] = round(float(np.max(restart_summaries)), 1)
    rows.append(best_row)
    return pd.DataFrame(rows)


def write_outputs(
    data_dir: Path = DEFAULT_DATA,
    model_dir: Path = DEFAULT_MODEL,
    source_label: str = "restricted real life-test CSVs",
    pseudo_data_used: bool = False,
    skip_sensitivity: bool = False,
) -> dict[str, object]:
    model_dir.mkdir(parents=True, exist_ok=True)
    records = load_units(data_dir)
    baseline = build_baseline_table(records)
    endpoints = build_endpoint_table(records)
    decoded = build_decoded(records)
    segments = build_segments(decoded, endpoints)
    params = build_parameters(decoded, segments)
    for method,mode in [("NH_HSMM","full"),("homogeneous_HSMM_ablation","independent"),("shared_accel_HSMM_ablation","shared")]:
        FULL_MODEL_TABLES[method]=soft_parameter_table(decoded,[1,2,3,4],STATE_NAMES,mode)
    seed_decoded=decoded.copy()
    decoded=decode_soft_training(decoded,params)
    segments=build_segments(decoded,endpoints)
    origins = make_prediction_origins(endpoints)
    predictions, sample_store = build_rul_predictions(decoded, endpoints, origins, params)
    ablation = build_ablation_summary(predictions, sample_store)
    acceleration_law_benchmark = build_acceleration_law_benchmark_summary(predictions, sample_store, endpoints, origins)
    unit_errors = build_unit_level_error_summary(predictions)
    wiener_parameters = build_wiener_benchmark_parameters(decoded, origins)
    stress_transfer = build_stress_transfer_summary(decoded, endpoints, origins, params)
    rel = build_reliability_curves(params, endpoints)
    align = build_decoded_alignment(endpoints, decoded)
    folds = origins[["fold_id", "file", "current_A"]].drop_duplicates().reset_index(drop=True)
    transition = build_transition_summary(segments)
    transition_probability = build_transition_probability_grid(params)
    if skip_sensitivity:
        sensitivity = pd.DataFrame(
            [
                {
                    "variant": "not_run",
                    "interpretation": "skipped by --skip-sensitivity for a quick workflow smoke test",
                }
            ]
        )
    else:
        sensitivity = build_sensitivity_summary(decoded, endpoints, origins, predictions)

    outputs = {
        "burnin_baseline_table.csv": baseline,
        "l80_t50_endpoints.csv": endpoints,
        "decoded_trajectories.csv": decoded,
        "decoded_residence_segments.csv": segments,
        "nh_hsmm_parameters.csv": params,
        "soft_fit_diagnostics.csv": pd.DataFrame(SOFT_FIT_ROWS),
        "soft_origin_posteriors.csv": pd.DataFrame(SOFT_ORIGIN_ROWS.values()),
        "soft_emission_parameters.csv": params[params.feature.notna()].copy(),
        "soft_smoothed_state_probabilities.csv": SOFT_SMOOTHED,
        "reliability_curves.csv": rel,
        "rul_predictions.csv": predictions,
        "unit_level_rul_error.csv": unit_errors,
        "ablation_summary.csv": ablation,
        "acceleration_law_benchmark_summary.csv": acceleration_law_benchmark,
        "l80_decoded_alignment.csv": align,
        "prediction_origins.csv": origins,
        "fold_assignments.csv": folds,
        "state_transition_residence_summary.csv": transition,
        "state_transition_probability_grid.csv": transition_probability,
        "model_sensitivity_summary.csv": sensitivity,
        "wiener_benchmark_parameters.csv": wiener_parameters,
        "stress_transfer_summary.csv": stress_transfer,
    }
    for name, frame in outputs.items():
        frame.to_csv(model_dir / name, index=False)
    fitted_models={}
    for table in SOFT_CACHE.values():
        fit=table.attrs['soft_model']
        fitted_models[fit['id']]={'mode':fit['mode'],'risk_state':fit['risk_state'],'training_files':list(fit['files']),'center':fit['center'].tolist(),'scale':fit['scale'].tolist(),'theta':fit['theta'].tolist(),'emission_location':fit['emission'][0].tolist(),'emission_log_scale':fit['emission'][1].tolist(),'emission_nu':fit['emission'][2].tolist(),'iterations':fit['iterations'],'converged':fit['converged'],'observed_loglikelihood':fit['trace']}
    (model_dir/'soft_fitted_models.json').write_text(json.dumps(fitted_models),encoding='utf-8')
    np.savez_compressed(model_dir/'soft_origin_state_age_mass.npz',**{f'{i:03d}':v for i,v in enumerate(SOFT_ORIGIN_MASS.values())})
    pd.DataFrame([{'array_key':f'{i:03d}','file':k[0],'t0_h':k[1],'method':k[2]} for i,k in enumerate(SOFT_ORIGIN_MASS)]).to_csv(model_dir/'soft_origin_mass_index.csv',index=False)
    for obsolete in ["l80_" + "viter" + "bi_alignment.csv"]:
        (model_dir / obsolete).unlink(missing_ok=True)

    try:
        manifest_data_dir = str(data_dir.resolve().relative_to(ROOT))
    except ValueError:
        manifest_data_dir = str(data_dir)

    manifest = {
        "source": source_label,
        "data_dir": manifest_data_dir,
        "pseudo_data_used": bool(pseudo_data_used),
        "n_units": int(len(records)),
        "n_l80_events": int(endpoints["E80"].sum()),
        "n_scored_prediction_origins": int(len(origins)),
        "n_unique_scored_units": int(origins["file"].nunique()),
        "baseline_reference_rule": "first measurement at or after 20 h",
        "l90_endpoint_rule": "first 5-hour persistent P/P0 <= 0.90 on hourly interpolation; diagnostic threshold only",
        "l80_endpoint_rule": "first 5-hour persistent P/P0 <= 0.80 on hourly interpolation",
        "l50_endpoint_rule": "first 5-hour persistent P/P0 <= 0.50 on hourly interpolation",
        "robust_scale_factor": 1.4826,
        "sensitivity_skipped": bool(skip_sensitivity),
        "estimator": "Endpoint-constrained soft EM with fitted Student-t emissions and discrete lognormal residence laws",
        "terminal_state": "absorbing; no estimated terminal exit distribution",
        "max_em_iterations": 60,
        "em_relative_tolerance": 1e-5,
        "outputs": sorted(outputs),
    }
    manifest_name = "pseudo_data_workflow_manifest.json" if pseudo_data_used else "real_data_revision_manifest.json"
    (model_dir / manifest_name).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def bootstrap_ci(values: np.ndarray, stat=np.median, n_boot: int = 2000, seed: int = 0) -> tuple[float, float, float]:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    reps = [float(stat(rng.choice(x, len(x), replace=True))) for _ in range(n_boot)]
    lo, hi = np.quantile(reps, [0.025, 0.975])
    return float(stat(x)), float(lo), float(hi)


def extract_segments(decoded: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for file, sub in decoded.sort_values(["file", "t_h"]).groupby("file"):
        sub = sub[sub["age_h"] >= 0].reset_index(drop=True)
        if sub.empty:
            continue
        start = 0
        state = int(sub.loc[0, "state"])
        for idx in range(1, len(sub)):
            new_state = int(sub.loc[idx, "state"])
            if new_state != state:
                rows.append({"file": file, "current_A": float(sub.loc[0, "current_A"]), "state": state, "duration_h": max(1.0, float(sub.loc[idx - 1, "age_h"] - sub.loc[start, "age_h"] + 1.0))})
                start = idx
                state = new_state
        rows.append({"file": file, "current_A": float(sub.loc[0, "current_A"]), "state": state, "duration_h": max(0.0, float(sub.loc[len(sub) - 1, "age_h"] - sub.loc[start, "age_h"]))})
    return pd.DataFrame(rows)


def l80_first_passage_risk_surface(
    params: pd.DataFrame,
    currents: np.ndarray,
    ages: np.ndarray,
    n_mc: int = 26000,
    seed: int = 20260427,
) -> np.ndarray:
    """Evaluate P(first entry into the L80-risk state <= age | current)."""
    p = params[params["sojourn_mu_log_h"].notna()].drop_duplicates("state").set_index("state")
    transient_states = [1, 2]
    rng = np.random.default_rng(seed)
    shared_noise = rng.standard_normal((len(transient_states), n_mc))
    risk = np.zeros((len(currents), len(ages)), dtype=float)
    ages = np.asarray(ages, dtype=float)
    for i, current in enumerate(np.asarray(currents, dtype=float)):
        total = np.zeros(n_mc, dtype=float)
        for k, state in enumerate(transient_states):
            row = p.loc[state]
            mu_eff = float(row["sojourn_mu_log_h"]) - float(row["current_accel_alpha"]) * np.log(current / 3.0)
            sigma = float(row["sojourn_sigma_log_h"])
            total += np.ceil(np.exp(mu_eff + sigma * shared_noise[k]))
        total.sort()
        risk[i] = np.searchsorted(total, ages, side="right") / n_mc
    return np.clip(np.maximum.accumulate(risk, axis=1), 0.0, 1.0)


def decoded_median_state_surface(decoded: pd.DataFrame, currents: np.ndarray, ages: np.ndarray) -> np.ndarray:
    """Median decoded state by tested current and age for observed-window state-boundary overlays."""
    surface = np.full((len(currents), len(ages)), np.nan, dtype=float)
    decoded = decoded[decoded["age_h"].between(float(np.min(ages)), float(np.max(ages)))].copy()
    for i, current in enumerate(currents):
        sub = decoded[np.isclose(decoded["current_A"].to_numpy(dtype=float), float(current))]
        if sub.empty:
            continue
        state_by_age = sub.groupby("age_h")["state"].median().sort_index()
        x = state_by_age.index.to_numpy(dtype=float)
        y = state_by_age.to_numpy(dtype=float)
        surface[i] = np.interp(ages, x, y, left=y[0], right=y[-1])
    return surface


def model_extended_state_boundaries(params: pd.DataFrame, currents: np.ndarray) -> list[tuple[str, np.ndarray, str, float]]:
    """Smooth state-boundary curves from fitted residence clocks for the extended grid."""
    p = params[params["sojourn_mu_log_h"].notna()].drop_duplicates("state").set_index("state")
    boundary_defs = [
        ("Stable/Drift", [1], "-.", 1.02),
        ("Drift/L80 risk", [1, 2], "--", 0.86),
        ("L80 risk/Collapse", [1, 2, 3], "-", 0.96),
    ]
    curves: list[tuple[str, np.ndarray, str, float]] = []
    for label, states, linestyle, linewidth in boundary_defs:
        boundary_age = np.zeros(len(currents), dtype=float)
        for state in states:
            row = p.loc[state]
            mu_eff = float(row["sojourn_mu_log_h"]) - float(row["current_accel_alpha"]) * np.log(currents / 3.0)
            boundary_age += np.exp(mu_eff)
        curves.append((label, np.log10(np.clip(boundary_age, 1.0, 10000.0)), linestyle, linewidth))
    return curves


def km_curve(times: np.ndarray, events: np.ndarray) -> pd.DataFrame:
    df = pd.DataFrame({"time": times, "event": events}).sort_values("time")
    rows = [{"age_h": 0.0, "survival": 1.0}]
    surv = 1.0
    for t in sorted(df.loc[df["event"].eq(1), "time"].unique()):
        n = int((df["time"] >= t).sum())
        d = int(((df["time"] == t) & (df["event"] == 1)).sum())
        surv *= 1 - d / n
        rows.append({"age_h": float(t), "survival": float(surv)})
    return pd.DataFrame(rows)


def km_greenwood(times: np.ndarray, events: np.ndarray) -> pd.DataFrame:
    frame = pd.DataFrame({"time": times, "event": events}).sort_values("time")
    rows = [{"age_h": 0.0, "survival": 1.0, "lo": 1.0, "hi": 1.0}]
    survival = 1.0
    greenwood = 0.0
    for t in sorted(frame.loc[frame["event"].eq(1), "time"].unique()):
        n_risk = int((frame["time"] >= t).sum())
        n_event = int(((frame["time"] == t) & frame["event"].eq(1)).sum())
        if n_risk <= 0:
            continue
        survival *= 1 - n_event / n_risk
        if n_risk - n_event > 0:
            greenwood += n_event / (n_risk * (n_risk - n_event))
        se = np.sqrt(max(0.0, survival**2 * greenwood))
        rows.append(
            {
                "age_h": float(t),
                "survival": float(survival),
                "lo": float(max(0.0, survival - 1.96 * se)),
                "hi": float(min(1.0, survival + 1.96 * se)),
            }
        )
    return pd.DataFrame(rows)


def _fit_alpha(frame: pd.DataFrame) -> float:
    if frame["current_A"].nunique() < 2 or len(frame) < 3:
        return np.nan
    x = np.log(frame["current_A"].to_numpy(dtype=float) / 3.0)
    y = np.log(np.maximum(frame["duration_h"].to_numpy(dtype=float), 1.0))
    X = np.column_stack([np.ones_like(x), -x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    return float(beta[1])


def _alpha_bootstrap(segments: pd.DataFrame, state: int, seed: int = 0, n_boot: int = 1500) -> tuple[float, float, float]:
    frame = segments[segments["state"].eq(state)].copy()
    point = _fit_alpha(frame)
    if not np.isfinite(point) or len(frame) < 4:
        return point, np.nan, np.nan
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        sample = frame.iloc[rng.integers(0, len(frame), len(frame))]
        val = _fit_alpha(sample)
        if np.isfinite(val):
            vals.append(val)
    if not vals:
        return point, np.nan, np.nan
    lo, hi = np.quantile(vals, [0.025, 0.975])
    return point, float(lo), float(hi)


def _alpha_bootstrap_values(segments: pd.DataFrame, state: int, seed: int = 0, n_boot: int = 350) -> np.ndarray:
    frame = segments[segments["state"].eq(state)].copy()
    if frame["current_A"].nunique() < 2 or len(frame) < 4:
        return np.array([], dtype=float)
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        sample = frame.iloc[rng.integers(0, len(frame), len(frame))]
        val = _fit_alpha(sample)
        if np.isfinite(val):
            vals.append(val)
    return np.asarray(vals, dtype=float)



def export_plot_data(folder: Path) -> None:
    """Export all inference, bootstrap and curve data consumed by the figures.

    Files prefixed plot_ are a stable, read-only contract for generate_figures.py.
    Bootstrap seeds and original grid definitions preserve the published plots.
    """
    decoded=pd.read_csv(folder/'decoded_trajectories.csv')
    baseline=pd.read_csv(folder/'burnin_baseline_table.csv')
    endpoints=pd.read_csv(folder/'l80_t50_endpoints.csv')
    params=pd.read_csv(folder/'nh_hsmm_parameters.csv')
    segments=extract_segments(decoded)
    segments.to_csv(folder/'plot_segments.csv',index=False)
    summaries={}
    def boot(x,seed):
        summaries[str(seed)]=bootstrap_ci(np.asarray(x),seed=seed)
    for current,sub in baseline.groupby('current_A'):
        boot(100*sub.P0/sub.P_first,int(current*100))
    for current,sub in endpoints[endpoints.E80.eq(1)].groupby('current_A'):
        boot(sub.T80_age_h,int(811*current))
    for (state,current),sub in segments.groupby(['state','current_A']):
        boot(sub.duration_h,int(100*current+state))
    d=decoded[(decoded.age_h>=0)&decoded.state.isin([1,2,3,4])].copy()
    d['spectral_instability_log_nm']=np.log10(np.clip(d.spectral_instability,1e-3,None))
    ellipses={}
    for state,sub in d.groupby('state'):
        x=sub.heat_proxy_W.to_numpy(); y=sub.spectral_instability_log_nm.to_numpy()
        boot(x,700+state);boot(y,800+state)
        pts=np.column_stack([x,y]);pts=pts[np.isfinite(pts).all(axis=1)]
        if len(pts)>6:
            qx=np.quantile(pts[:,0],[.05,.95]);qy=np.quantile(pts[:,1],[.05,.95])
            trimmed=pts[(pts[:,0]>=qx[0])&(pts[:,0]<=qx[1])&(pts[:,1]>=qy[0])&(pts[:,1]<=qy[1])]
            if len(trimmed)>6:
                vals,vecs=np.linalg.eigh(np.cov(trimmed.T)); vals=np.clip(vals,1e-6,None);order=vals.argsort()[::-1];vals=vals[order];vecs=vecs[:,order]
                angle=np.degrees(np.arctan2(vecs[1,0],vecs[0,0]));width,height=2*np.sqrt(3.22*vals)
                ellipses[str(state)]=[float(angle),float(width),float(height)]
    (folder/'plot_bootstrap_intervals.json').write_text(json.dumps(summaries),encoding='utf-8')
    (folder/'plot_feature_ellipses.json').write_text(json.dumps(ellipses),encoding='utf-8')
    alpha={str(s):{'interval':_alpha_bootstrap(segments,s,seed=120+s),'values':_alpha_bootstrap_values(segments,s,seed=500+s).tolist()} for s in [1,2,3,4]}
    (folder/'plot_acceleration_bootstrap.json').write_text(json.dumps(alpha),encoding='utf-8')
    km_curve(endpoints.T80_age_h.to_numpy(),endpoints.E80.to_numpy()).to_csv(folder/'plot_km.csv',index=False)
    km_greenwood(endpoints.T80_age_h.to_numpy(),endpoints.E80.to_numpy()).to_csv(folder/'plot_km_greenwood.csv',index=False)
    counts=d.groupby(['current_A','state']).size().unstack(fill_value=0)
    counts.div(counts.sum(axis=1),axis=0).mul(100).to_csv(folder/'plot_occupancy_percent.csv')
    currents=np.linspace(2.,6.,241);ages=np.geomspace(1.,10000.,620)
    risk=l80_first_passage_risk_surface(params,currents,ages,n_mc=42000,seed=20260428)
    np.savez_compressed(folder/'plot_extended_risk.npz',currents_A=currents,ages_h=ages,risk=risk)
    boundaries=model_extended_state_boundaries(params,currents)
    np.savez_compressed(folder/'plot_extended_boundaries.npz',**{str(i):v[1] for i,v in enumerate(boundaries)})
    tested=np.array(sorted(endpoints.current_A.unique()),dtype=float);grid=np.arange(0,501)
    np.savez_compressed(folder/'plot_observed_states.npz',currents_A=tested,ages_h=grid,state=decoded_median_state_surface(decoded,tested,grid))
    p=params[params.sojourn_mu_log_h.notna()].set_index('state');c=np.linspace(3.,4.5,120)
    np.savez_compressed(folder/'plot_residence_curves.npz',currents_A=c,**{str(s):np.exp(p.loc[s,'sojourn_mu_log_h']-p.loc[s,'current_accel_alpha']*np.log(c/3.)) for s in [1,2,3]})
    files=sorted(p.name for p in folder.glob('plot_*') if p.name != 'plot_data_manifest.json')
    (folder/'plot_data_manifest.json').write_text(json.dumps({'schema_version':1,'source_sha256':{name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in ['decoded_trajectories.csv','burnin_baseline_table.csv','l80_t50_endpoints.csv','nh_hsmm_parameters.csv']},'files':files,'units':{'age':'h','current':'A','occupancy':'percent','risk':'probability'},'description':'All curve estimation and bootstrap calculations run in main_analysis.py; plotting reads these exported results.'},indent=2),encoding='utf-8')



# Endpoint-constrained soft HSMM inference and parameter estimation.

import numpy as np
from scipy.special import gammaln,digamma,log_ndtr
from scipy.optimize import minimize

def duration_arrays(theta,current,T,geometric=False):
    """Age a means D>a; terminal observations contribute S(a), not S(a+1)."""
    S=len(theta)+1;ages=np.arange(T+1,dtype=float)
    h=np.zeros((S,T+1));logmass=np.zeros((S-1,T));logsf=np.zeros((S-1,T+1))
    for s,(mu,alpha,lsig) in enumerate(theta):
        loc=mu-alpha*np.log(current/3);sigma=np.exp(lsig)
        if geometric:
            p=min(.999999,1/max(1.000001,np.exp(loc)))
            sf=ages*np.log1p(-p);mass=np.log(p)+ages[:-1]*np.log1p(-p)
        else:
            z=np.full(T+1,-np.inf);z[1:]=(np.log(ages[1:])-loc)/sigma
            sf=log_ndtr(-z);mass=sf[:-1]+np.log(np.maximum(-np.expm1(sf[1:]-sf[:-1]),1e-300))
        h[s,:T]=np.exp(np.minimum(0,mass-sf[:-1]));logmass[s]=mass;logsf[s]=sf
    return h,logmass,logsf

def emission_logpdf(x,em):
    loc,logs,nu=em
    resid=(x[:,None,:]-loc[None,:,:])/np.exp(logs)[None,:,:]
    return (gammaln((nu+1)/2)-gammaln(nu/2)-.5*np.log(nu*np.pi))[None,:]*x.shape[1]-logs.sum(axis=1)[None,:]-.5*((nu+1)[None,:,None]*np.log1p(resid**2/nu[None,:,None])).sum(axis=2)

def forward_backward(x,current,theta,em,mask,stats=True,geometric=False):
    T=len(x);S=em[0].shape[0]
    logb=emission_logpdf(x,em);logb=np.where(mask,logb,-np.inf)
    shifts=np.max(logb,axis=1);b=np.exp(logb-shifts[:,None])
    if not np.isfinite(shifts).all():raise ValueError('No allowed emission state')
    h,_,_=duration_arrays(theta,current,T,geometric)
    f=np.zeros((T,S,T));c=np.zeros(T)
    f[0,0,0]=b[0,0];c[0]=f[0].sum()
    if c[0]<=0:raise ValueError('Initial state excluded')
    f[0]/=c[0]
    for t in range(1,T):
        f[t,:,1:t+1]=f[t-1,:,:t]*(1-h[:,:t])
        f[t,1:,0]=(f[t-1,:-1,:t]*h[:-1,:t]).sum(axis=1)
        f[t]*=b[t,:,None];c[t]=f[t].sum()
        if not np.isfinite(c[t]) or c[t]<=0:raise FloatingPointError('Forward mass underflow')
        f[t]/=c[t]
    ll=float(np.sum(np.log(c)+shifts))
    if not stats:return ll,f[-1],None,None
    beta=np.ones((S,T));gamma=np.zeros((T,S));exits=np.zeros((S-1,T));terminal=f[-1].copy()
    gamma[-1]=f[-1].sum(axis=1)
    for t in range(T-2,-1,-1):
        enter=b[t+1,1:]*beta[1:,0]
        xi=f[t,:-1,:t+1]*h[:-1,:t+1]*enter[:,None]/c[t+1]
        exits[:,:t+1]+=xi
        prev=np.zeros((S,T));prev[:,:t+1]=(1-h[:,:t+1])*b[t+1,:,None]*beta[:,1:t+2]
        prev[:-1,:t+1]+=h[:-1,:t+1]*enter[:,None]
        beta=prev/c[t+1];g=f[t]*beta;gamma[t]=g.sum(axis=1)
    if not np.allclose(gamma.sum(axis=1),1,atol=1e-6):raise AssertionError('Smoothing mass does not sum to one')
    return ll,gamma,exits,terminal

def fit_emission(x,w,initial):
    K=x.shape[1];loc,logs,nu=initial
    def fun(v):
        m=v[:K];l=v[K:2*K];df=v[-1];scale=np.exp(l);r=(x-m)/scale;u=r*r
        lp=gammaln((df+1)/2)-gammaln(df/2)-.5*np.log(df*np.pi)-l-.5*(df+1)*np.log1p(u/df)
        dm=(df+1)*r/(scale*(df+u));dl=-1+(df+1)*u/(df+u)
        dn=.5*(digamma((df+1)/2)-digamma(df/2)-1/df-np.log1p(u/df)+(df+1)*u/(df*(df+u)))
        total=max(w.sum(),1e-12)
        return -np.sum(w[:,None]*lp)/total,-np.r_[np.sum(w[:,None]*dm,axis=0),np.sum(w[:,None]*dl,axis=0),np.sum(w[:,None]*dn)]/total
    v=np.r_[loc,logs,nu];res=minimize(fun,v,jac=True,method='L-BFGS-B',bounds=[(-30,30)]*K+[(np.log(.05),np.log(30))]*K+[(2.1,50)],options={'maxiter':100,'ftol':1e-9})
    if res.fun>fun(v)[0]+1e-8:return loc,logs,nu
    return res.x[:K],res.x[K:2*K],res.x[-1]

def fit_duration(stats,s,initial,mode='full'):
    def fun(theta):
        ans=0.;weight=0.
        for current,exitw,endw in stats:
            T=len(exitw[s]);_,lm,ls=duration_arrays(np.array([theta]),current,T,mode=='geometric')
            ans-=np.dot(exitw[s],lm[0])+np.dot(endw[s],ls[0,:T]);weight+=exitw[s].sum()+endw[s].sum()
        return ans/max(weight,1e-12)
    bounds=[(0,np.log(2000)),(0,8),(np.log(.2),np.log(1.5))]
    if mode=='independent':bounds[1]=(0,0)
    if mode=='geometric':bounds[0]=(np.log(1.0001),np.log(2000));bounds[2]=(0,0)
    res=minimize(fun,initial,method='L-BFGS-B',bounds=bounds,options={'maxiter':150,'ftol':1e-10})
    return res.x if res.fun<=fun(initial)+1e-9 else initial

def endpoint_mask(T,S,risk_state,event_age=None,alive=False):
    mask=np.ones((T,S),bool);r=risk_state-1
    if alive or event_age is None:mask[:,r:]=False
    else:
        t=int(event_age);mask[:t,r:]=False;mask[t:,:r]=False
    return mask

def fit_soft(sequences,initial_states,initial_theta,max_iter=60,tol=1e-5,verbose=False,mode='full'):
    # sequences: raw feature matrix, fixed current, endpoint mask.
    raw=np.concatenate([x for x,c,mask in sequences]);center=np.median(raw,axis=0);scale=1.4826*np.median(abs(raw-center),axis=0)
    sd=np.std(raw,axis=0);scale=np.where(scale>=1e-9,scale,np.where(sd>1e-9,sd,1))
    seq=[((x-center)/scale,c,mask) for x,c,mask in sequences];X=np.concatenate([x for x,c,mask in seq]);labels=np.concatenate(initial_states);S=len(initial_theta)+1;K=X.shape[1]
    loc=np.array([np.median(X[labels==s],axis=0) if np.any(labels==s) else np.median(X,axis=0) for s in range(S)])
    scales=np.array([np.maximum(.2,1.4826*np.median(abs(X[labels==s]-loc[s]),axis=0)) if np.any(labels==s) else np.ones(K) for s in range(S)])
    em=(loc,np.log(scales),np.full(S,8.));theta=np.asarray(initial_theta).copy();trace=[];posterior=[]
    if mode=='independent':theta[:,1]=0
    if mode=='shared':theta[:,1]=np.mean(theta[:,1])
    if mode=='geometric':theta[:,2]=0
    for it in range(max_iter+1):
        total=0.;weights=[];stats=[]
        for x,c,mask in seq:
            ll,g,e,end=forward_backward(x,c,theta,em,mask,geometric=mode=='geometric');total+=ll;weights.append(g);stats.append((c,e,end))
        trace.append(total)
        if verbose:print(f'EM {it}: {total:.8f}',flush=True)
        if it and total<trace[-2]-1e-5*max(1,abs(total)):raise AssertionError('Observed likelihood decreased')
        if it and abs(total-trace[-2])<=tol*(1+abs(trace[-2])):break
        if it==max_iter:break
        W=np.concatenate(weights);new=[fit_emission(X,W[:,s],(em[0][s],em[1][s],em[2][s])) for s in range(S)]
        em=(np.array([v[0] for v in new]),np.array([v[1] for v in new]),np.array([v[2] for v in new]))
        if mode=='shared':
            def obj(v):
                th=np.column_stack([v[:S-1],np.full(S-1,v[-1]),v[S-1:2*(S-1)]]);q=0.
                for current,ex,en in stats:
                    _,lm,ls=duration_arrays(th,current,ex.shape[1]);q-=np.sum(ex*lm)+np.sum(en[:-1]*ls[:,:ex.shape[1]])
                return q/len(X)
            v=np.r_[theta[:,0],theta[:,2],theta[0,1]]
            res=minimize(obj,v,method='L-BFGS-B',bounds=[(0,np.log(2000))]*(S-1)+[(np.log(.2),np.log(1.5))]*(S-1)+[(0,8)],options={'maxiter':150,'ftol':1e-10})
            if res.fun<=obj(v)+1e-9:theta=np.column_stack([res.x[:S-1],np.full(S-1,res.x[-1]),res.x[S-1:2*(S-1)]])
        else:theta=np.array([fit_duration(stats,s,theta[s],mode) for s in range(S-1)])
    return {'center':center,'scale':scale,'theta':theta,'emission':em,'trace':trace,'iterations':len(trace)-1,'converged':len(trace)>1 and abs(trace[-1]-trace[-2])<=tol*(1+abs(trace[-2])),'posterior':weights,'mode':mode}

def viterbi(x,current,theta,em,mask):
    T=len(x);S=em[0].shape[0];h,_,_=duration_arrays(theta,current,T)
    logh=np.log(np.maximum(h,1e-300));logs=np.log1p(-np.minimum(h,1-1e-16))
    b=np.where(mask,emission_logpdf(x,em),-np.inf);v=np.full((S,T),-np.inf);v[0,0]=b[0,0];entry=np.zeros((T,S),int)
    for t in range(1,T):
        prev=v;v=np.full((S,T),-np.inf);v[:,1:t+1]=prev[:,:t]+logs[:,:t]
        for s in range(1,S):
            a=int(np.argmax(prev[s-1,:t]+logh[s-1,:t]));entry[t,s]=a;v[s,0]=prev[s-1,a]+logh[s-1,a]
        v+=b[t,:,None]
    s,a=np.unravel_index(np.argmax(v),v.shape);path=np.zeros(T,int)
    for t in range(T-1,-1,-1):
        path[t]=s
        if a==0 and t>0:a=entry[t,s];s-=1
        else:a-=1
    return path+1


SOFT_CACHE={}
SOFT_FIT_ROWS=[]
SOFT_ORIGIN_ROWS={}
SOFT_ORIGIN_MASS={}
FULL_MODEL_TABLES={}
SOFT_SMOOTHED=pd.DataFrame()

def soft_parameter_table(decoded,states,state_names,mode='full'):
    variant=decoded.attrs.get('route_variant','selected_5_state');seed=decoded.attrs.get('route_seed',0)
    files=tuple(sorted(decoded.file.unique()));key=(files,tuple(states),variant,seed,mode)
    if key in SOFT_CACHE:return SOFT_CACHE[key]
    S=len(states);risk=3 if S==4 else (2 if S==3 else 4);sequences=[];initial=[];init_frames=[]
    for file,g in decoded.groupby('file',sort=True):
        g=g.sort_values('age_h').copy();g['state']=assign_states(1-g.D.to_numpy(),g.D.to_numpy(),g.loss_rate.to_numpy())
        T,event=persistent_crossing(g.age_h.to_numpy(),1-g.D.to_numpy(),.8)
        pre=g.age_h<T if event else np.ones(len(g),bool);g.loc[pre,'state']=np.minimum(g.loc[pre,'state'],2)
        if event:g.loc[~pre,'state']=np.maximum(g.loc[~pre,'state'],3)
        if variant!='selected_5_state':g,_,_,_=derive_state_variant(g,variant,seed)
        sequences.append((g[FEATURES].to_numpy(),float(g.current_A.iloc[0]),endpoint_mask(len(g),S,risk,T if event else None)))
        initial.append(g.state.to_numpy()-1);init_frames.append(g)
    init=pd.concat(init_frames);ep=[]
    for file,g in init.groupby('file'):
        T,event=persistent_crossing(g.age_h.to_numpy(),1-g.D.to_numpy(),.8);ep.append({'file':file,'E80':event})
    segments=build_segments_for_risk(init,pd.DataFrame(ep),risk);theta=[]
    for state in states[:-1]:
        mu,sig,alpha=fit_alpha(segments[segments.state.eq(state)])
        if not np.isfinite(mu):mu,sig,alpha=np.log(150),.7,1.
        theta.append([np.clip(mu,0,np.log(2000)),np.clip(alpha,0,8),np.log(np.clip(sig,.2,1.5))])
    fit=fit_soft(sequences,initial,theta,mode=mode);fit['files']=files;fit['risk_state']=risk
    fitid=hashlib.sha256(repr(key).encode()).hexdigest()[:12];fit['id']=fitid
    for it,ll in enumerate(fit['trace']):SOFT_FIT_ROWS.append({'fit_id':fitid,'mode':mode,'variant':variant,'seed':seed,'training_units':len(files),'training_files':'|'.join(files),'iteration':it,'observed_loglikelihood':ll,'converged':fit['converged']})
    rows=[]
    for j,state in enumerate(states):
        if j<S-1:mu,alpha,ls=fit['theta'][j];sig=np.exp(ls)
        else:mu=alpha=sig=np.nan
        rows.append({'state':state,'state_name':state_names[state],'feature':np.nan,'emission_mu_robust_z':np.nan,'sojourn_mu_log_h':mu,'sojourn_sigma_log_h':sig,'current_accel_alpha':alpha,'decoded_segments':np.nan,'emission_scale_robust_z':np.nan,'emission_nu':np.nan,'fit_id':fitid,'fit_mode':mode,'absorbing':j==S-1})
        for k,f in enumerate(FEATURES):rows.append({'state':state,'state_name':state_names[state],'feature':f,'emission_mu_robust_z':fit['emission'][0][j,k],'emission_scale_robust_z':np.exp(fit['emission'][1][j,k]),'emission_nu':fit['emission'][2][j],'sojourn_mu_log_h':np.nan,'sojourn_sigma_log_h':np.nan,'current_accel_alpha':np.nan,'decoded_segments':np.nan,'training_center':fit['center'][k],'training_scale':fit['scale'][k],'fit_id':fitid,'fit_mode':mode,'absorbing':j==S-1})
    table=pd.DataFrame(rows);table.attrs['soft_model']=fit;SOFT_CACHE[key]=table
    return table

def decode_soft_training(decoded,params):
    global SOFT_SMOOTHED
    fit=params.attrs['soft_model'];frames=[];post=[]
    for file,g in decoded.groupby('file',sort=True):
        g=g.sort_values('age_h').copy();x=(g[FEATURES].to_numpy()-fit['center'])/fit['scale'];T,event=persistent_crossing(g.age_h.to_numpy(),1-g.D.to_numpy(),.8)
        mask=endpoint_mask(len(g),len(fit['emission'][2]),fit['risk_state'],T if event else None)
        g['state']=viterbi(x,float(g.current_A.iloc[0]),fit['theta'],fit['emission'],mask);frames.append(g)
        _,gamma,_,_=forward_backward(x,float(g.current_A.iloc[0]),fit['theta'],fit['emission'],mask)
        pr=g[['file','age_h','current_A']].copy()
        for s in range(gamma.shape[1]):pr[f'p_state_{s+1}']=gamma[:,s]
        post.append(pr)
    SOFT_SMOOTHED=pd.concat(post,ignore_index=True)
    return pd.concat(frames,ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=DEFAULT_DATA,
        help="directory containing life-test *_clean.csv files",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=DEFAULT_MODEL,
        help="directory where model output CSV files are written",
    )
    parser.add_argument(
        "--pseudo-data",
        action="store_true",
        help="mark this run as a public pseudo-data workflow check",
    )
    parser.add_argument(
        "--skip-sensitivity",
        action="store_true",
        help="skip the expensive state-number/restart sensitivity loop for quick smoke tests",
    )
    parser.add_argument("--quiet", action="store_true", help="suppress manifest summary")
    args = parser.parse_args()
    source = "public pseudo-data workflow check" if args.pseudo_data else "restricted real life-test CSVs"
    manifest = write_outputs(
        data_dir=args.data_dir,
        model_dir=args.out_dir,
        source_label=source,
        pseudo_data_used=args.pseudo_data,
        skip_sensitivity=args.skip_sensitivity,
    )
    export_plot_data(args.out_dir)
    if not args.quiet:
        print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()

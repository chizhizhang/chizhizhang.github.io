// Render the final native SVGs in Chromium, preserving embedded math fonts,
// editable vector text, baseline-shifted subscripts and continuous gradients.
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

(async () => {
  const folder = path.resolve(process.argv[2] || path.join(__dirname, '..', 'figures'));
  const candidates = [process.env.BROWSER_EXECUTABLE,
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
  const executablePath = candidates.find(p => p && fs.existsSync(p));
  const browser = await chromium.launch({ headless: true, ...(executablePath ? { executablePath } : {}) });
  try {
    const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 2 });
    for (const name of ['Figure_01', 'Figure_02', 'Figure_03']) {
      const svg = fs.readFileSync(path.join(folder, name + '.svg'), 'utf8');
      await page.setContent('<style>@page{size:1920px 1080px;margin:0}html,body{margin:0;background:white;width:1920px;height:1080px}svg{display:block}</style>' + svg);
      await page.evaluate(() => document.fonts.ready);
      await page.screenshot({ path: path.join(folder, name + '.png'), omitBackground: false });
      await page.pdf({ path: path.join(folder, name + '.pdf'), preferCSSPageSize: true, printBackground: true });
      console.log('Exported ' + name + ' PDF and PNG');
    }
  } finally { await browser.close(); }
})().catch(error => { console.error(error.message); process.exitCode = 1; });

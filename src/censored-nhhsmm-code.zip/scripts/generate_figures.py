#!/usr/bin/env python3
"""Story-driven standalone figures for the RESS laser reliability manuscript.

The figures are intentionally single-conclusion and LaTeX-ready: no embedded
titles, captions, or multi-panel composites. Each figure has higher information
density through uncertainty, event markers, or model-vs-ablation overlays.
"""

from __future__ import annotations

import shutil
import hashlib
import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from cycler import cycler
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm, to_rgb
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, FancyArrowPatch, FancyBboxPatch, Patch, Rectangle


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'outputs'
FIG = ROOT/'figures'

PALETTE = {
    "paper": "#FFFFFF",
    "ink": "#000000",
    "blue": "#0063D0",
    "sky": "#0152AB",
    "navy": "#172C6F",
    "green": "#278575",
    "sand": "#F8E3B3",
    "gold": "#D9A441",
    "red": "#C83E36",
    "gray": "#7A7A7A",
    "light_gray": "#D8D8D8",
}
ACCENT = PALETTE["blue"]
AUX1 = PALETTE["sky"]
AUX2 = PALETTE["green"]
AUX3 = PALETTE["gold"]
RISK = PALETTE["red"]
GRAY = PALETTE["gray"]
LIGHT_GRAY = PALETTE["light_gray"]
DARK = PALETTE["ink"]
STATE_BOUNDARY = PALETTE["green"]
GRID_KW = dict(linestyle="--", linewidth=0.55, alpha=0.45)
COLOR_CYCLE = [
    PALETTE["blue"],
    PALETTE["navy"],
    PALETTE["green"],
    PALETTE["gold"],
    PALETTE["sky"],
    PALETTE["ink"],
]

CURRENT_COLORS = {3.0: PALETTE["blue"], 3.5: AUX2, 4.0: AUX3, 4.5: RISK}
CURRENT_MARKERS = {3.0: "o", 3.5: "s", 4.0: "^", 4.5: "D"}
CURRENT_LS = {3.0: "-", 3.5: "--", 4.0: "-.", 4.5: ":"}

STATE_NAMES = {1: "Stable", 2: "Drift", 3: "L80 risk", 4: "Collapse"}
STATE_COLORS = {1: PALETTE["blue"], 2: AUX2, 3: AUX3, 4: RISK}
STATE_MARKERS = {1: "o", 2: "s", 3: "^", 4: "D"}
STATE_HATCHES = {1: "", 2: "//", 3: "\\\\", 4: "xx"}
PNG_16_9 = (1920, 1080)
PNG_DPI_16_9 = 300
FIGSIZE_16_9 = (PNG_16_9[0] / PNG_DPI_16_9, PNG_16_9[1] / PNG_DPI_16_9)
REQUIRED_MODEL_FILES = [
    "burnin_baseline_table.csv",
    "l80_t50_endpoints.csv",
    "decoded_trajectories.csv",
    "decoded_residence_segments.csv",
    "nh_hsmm_parameters.csv",
    "reliability_curves.csv",
    "rul_predictions.csv",
    "ablation_summary.csv",
    "acceleration_law_benchmark_summary.csv",
    "l80_decoded_alignment.csv",
    "prediction_origins.csv",
    "fold_assignments.csv",
    "state_transition_residence_summary.csv",
    "soft_fitted_models.json",
    "soft_fit_diagnostics.csv",
    "soft_origin_mass_index.csv",
    "soft_origin_state_age_mass.npz",
    "model_sensitivity_summary.csv",
    "stress_transfer_summary.csv",
]
RISK_CMAP = LinearSegmentedColormap.from_list(
    "risk_delayed_warm",
    [
        (0.00, PALETTE["paper"]),
        (0.38, PALETTE["sand"]),
        (0.78, PALETTE["gold"]),
        (1.00, RISK),
    ],
    N=256,
)
RISK_CLOUD_CMAP = RISK_CMAP
SIGNED_CMAP = LinearSegmentedColormap.from_list(
    "nh_hsmm_signed_shift",
    [(0.0, PALETTE["blue"]), (0.48, PALETTE["paper"]), (0.56, PALETTE["sand"]), (1.0, RISK)],
    N=256,
)

METHOD_COLORS = {
    "NH_HSMM": ACCENT,
    "shared_accel_HSMM_ablation": AUX2,
    "homogeneous_HSMM_ablation": GRAY,
    "weibull_AFT_endpoint_baseline": AUX3,
    "wiener_degradation_FP_baseline": PALETTE["navy"],
    "no_explicit_duration_HMM_ablation": LIGHT_GRAY,
}
METHOD_LABELS = {
    "NH_HSMM": "NH-HSMM",
    "shared_accel_HSMM_ablation": "Shared-accel HSMM",
    "homogeneous_HSMM_ablation": "Stress-independent HSMM",
    "weibull_AFT_endpoint_baseline": "Endpoint Weibull AFT",
    "wiener_degradation_FP_baseline": "Wiener FP benchmark",
    "no_explicit_duration_HMM_ablation": "Geometric duration",
}

plt.rcParams.update(
    {
        "figure.dpi": 150,
        "savefig.dpi": PNG_DPI_16_9,
        "font.family": "Times New Roman",
        "mathtext.fontset": "stix",
        "font.size": 11.0,
        "axes.labelsize": 12.0,
        "xtick.labelsize": 11.0,
        "ytick.labelsize": 11.0,
        "legend.fontsize": 10.0,
        "legend.frameon": False,
        "legend.facecolor": "none",
        "legend.edgecolor": "none",
        "legend.framealpha": 0.0,
        "axes.prop_cycle": cycler(color=COLOR_CYCLE),
        "axes.linewidth": 0.9,
        "axes.edgecolor": PALETTE["ink"],
        "axes.facecolor": PALETTE["paper"],
        "figure.facecolor": PALETTE["paper"],
        "text.color": PALETTE["ink"],
        "xtick.color": PALETTE["ink"],
        "ytick.color": PALETTE["ink"],
        "axes.unicode_minus": False,
        "lines.linewidth": 1.25,
        "lines.markersize": 5.2,
        "hatch.linewidth": 0.28,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.facecolor": PALETTE["paper"],
        "savefig.edgecolor": "none",
    }
)




def read_json(name):
    return json.loads((SRC/name).read_text(encoding="utf-8"))

def style(ax: plt.Axes, xgrid: bool = False, ygrid: bool = True) -> None:
    ax.grid(False)
    if ygrid:
        ax.grid(True, axis="y", color=LIGHT_GRAY, **GRID_KW)
    if xgrid:
        ax.grid(True, axis="x", color=LIGHT_GRAY, **GRID_KW)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_color(DARK)
        spine.set_linewidth(0.9)
    ax.tick_params(direction="out", width=0.8, length=3.5, color=DARK, labelsize=10)


def export(fig: plt.Figure, name: str) -> None:
    fig.set_size_inches(*FIGSIZE_16_9, forward=True)
    fig.tight_layout(pad=0.95)
    fig.savefig(FIG / f"{name}.svg", facecolor=PALETTE["paper"])
    fig.savefig(FIG / f"{name}.png", dpi=PNG_DPI_16_9, facecolor=PALETTE["paper"])
    fig.savefig(FIG / f"{name}.pdf", dpi=PNG_DPI_16_9, facecolor=PALETTE["paper"])
    plt.close(fig)


def read_km_greenwood(times: np.ndarray, events: np.ndarray) -> pd.DataFrame:
    return pd.read_csv(SRC/'plot_km_greenwood.csv')


def signed_log(values: np.ndarray) -> np.ndarray:
    return np.sign(values) * np.log1p(np.abs(values))


def read_bootstrap_interval(values: np.ndarray, stat=np.median, n_boot: int = 2000, seed: int = 0) -> tuple[float, float, float]:
    return tuple(read_json('plot_bootstrap_intervals.json')[str(seed)])


def fig06_lifetest_observability_gap(data: dict[str, pd.DataFrame]) -> None:
    endpoints = data["endpoints"].copy()
    endpoints["sort_time"] = endpoints["T80_age_h"].where(endpoints["E80"].eq(1), endpoints["censor_age_h"])
    endpoints = endpoints.sort_values(["current_A", "E80", "sort_time"]).reset_index(drop=True)
    excluded_age = float(endpoints.loc[endpoints["current_A"].eq(3.0), "sort_time"].max()) if endpoints["current_A"].eq(3.0).any() else np.nan

    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    y = np.arange(len(endpoints))
    for idx, row in endpoints.iterrows():
        cur = float(row["current_A"])
        color = CURRENT_COLORS[cur]
        end_age = float(row["censor_age_h"])
        ax.hlines(idx, 0, end_age, color=color, linewidth=1.5, linestyles="solid", alpha=0.88)
        if int(row["E80"]) == 1:
            ax.scatter(row["T80_age_h"], idx, marker="s", s=22, color=color, edgecolor=DARK, linewidth=0.4, zorder=4)
        else:
            ax.scatter(end_age, idx, marker="o", s=20, facecolor="white", edgecolor=color, linewidth=0.85, zorder=4)
        if int(row["E50"]) == 1:
            ax.scatter(row["T50_age_h"], idx, marker="x", s=28, color=DARK, linewidth=0.9, zorder=5)

    if np.isfinite(excluded_age):
        y_ex = -1.0
        ax.hlines(y_ex, 0.0, excluded_age, color=GRAY, linewidth=1.25, linestyles=(0, (3.0, 2.0)), zorder=3)

    for current, sub in endpoints.groupby("current_A", sort=True):
        center = float(sub.index.to_numpy().mean())
        l80 = int(sub["E80"].sum())
        ax.text(515, center, f"{current:.1f} A\n{l80}/{len(sub)} L80", ha="left", va="center", fontsize=8.3, color=DARK)
        if sub.index.max() < len(endpoints) - 1:
            ax.axhline(sub.index.max() + 0.5, color=LIGHT_GRAY, linewidth=0.8)

    ax.set_xlabel("Test age (h)")
    ax.set_ylabel("Life-test units")
    ax.set_xlim(0, 565)
    ax.set_ylim(-1.35, len(endpoints) - 0.2)
    ax.set_yticks([])
    handles = [
        Line2D([0], [0], marker="s", color="none", markerfacecolor=GRAY, markeredgecolor=DARK, label="L80 event"),
        Line2D([0], [0], marker="x", color=DARK, linestyle="None", label="T50 event"),
        Line2D([0], [0], marker="o", color=GRAY, markerfacecolor="white", linestyle="None", label="Censored"),
        Line2D([0], [0], color=GRAY, linestyle=(0, (3.0, 2.0)), linewidth=1.25, label="Excluded outlier"),
    ]
    ax.legend(
        handles=handles,
        frameon=False,
        loc="lower center",
        bbox_to_anchor=(0.5, 1.03),
        ncol=4,
        fontsize=7.6,
        handletextpad=0.45,
        columnspacing=0.9,
        borderaxespad=0.0,
    )
    style(ax, xgrid=True, ygrid=False)
    export(fig, "Figure_04")


def fig08_burnin_baseline_slope(data: dict[str, pd.DataFrame]) -> None:
    baseline = data["baseline"].copy()
    baseline["p0_pct_first"] = 100.0 * baseline["P0"] / baseline["P_first"]

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    rng = np.random.default_rng(12)
    for current, sub in baseline.groupby("current_A", sort=True):
        cur = float(current)
        for _, row in sub.iterrows():
            dx = rng.normal(0, 0.012)
            ax.plot(
                [0 + dx, 1 + dx],
                [100.0, row["p0_pct_first"]],
                color=CURRENT_COLORS[cur],
                linestyle=CURRENT_LS[cur],
                linewidth=0.9,
                alpha=0.68,
            )
            ax.scatter(1 + dx, row["p0_pct_first"], marker=CURRENT_MARKERS[cur], s=18, color=CURRENT_COLORS[cur], edgecolor=DARK, linewidth=0.35)

    rows = []
    for current, sub in baseline.groupby("current_A", sort=True):
        med, lo, hi = read_bootstrap_interval(sub["p0_pct_first"].to_numpy(), seed=int(current * 100))
        rows.append((current, med, lo, hi))
    for j, (current, med, lo, hi) in enumerate(rows):
        x = 1.12 + 0.055 * j
        ax.errorbar(x, med, yerr=[[med - lo], [hi - med]], fmt=CURRENT_MARKERS[float(current)], color=CURRENT_COLORS[float(current)], ecolor=DARK, capsize=2.3, markeredgecolor=DARK, markeredgewidth=0.35)
        ax.text(x, hi + 0.55, f"{med:.1f}", ha="center", va="bottom", fontsize=9.2)

    ax.axhline(100, color=GRAY, linestyle="--", linewidth=0.8)
    ax.set_xlim(-0.13, 1.36)
    ax.set_ylim(96, max(123, float(baseline["p0_pct_first"].max()) + 2.5))
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["First reading", "Post-burn P0"])
    ax.set_ylabel("Power level relative to first reading (%)")
    handles = [
        Line2D([0], [0], color=CURRENT_COLORS[c], linestyle=CURRENT_LS[c], marker=CURRENT_MARKERS[c], markeredgecolor=DARK, label=f"{c:.1f} A")
        for c in sorted(CURRENT_COLORS)
    ]
    ax.legend(handles=handles, frameon=False, loc="upper left", ncol=2)
    style(ax, ygrid=True)
    export(fig, "Figure_05")


def fig09_hidden_state_mechanism_map(data: dict[str, pd.DataFrame]) -> None:
    decoded = data["decoded"].copy()
    d = decoded[(decoded["age_h"] >= 0) & (decoded["state"].isin([1, 2, 3, 4]))].copy()
    d["spectral_instability_log_nm"] = np.log10(np.clip(d["spectral_instability"].to_numpy(dtype=float), 1e-3, None))

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    all_x = d["heat_proxy_W"].to_numpy(dtype=float)
    all_y = d["spectral_instability_log_nm"].to_numpy(dtype=float)
    ax.hexbin(
        all_x,
        all_y,
        gridsize=50,
        extent=(-0.55, 7.25, -3.35, 2.85),
        bins="log",
        mincnt=2,
        cmap="Greys",
        alpha=0.34,
        linewidths=0.0,
        zorder=0,
    )

    for state in [1, 2, 3, 4]:
        ss = d[d["state"].eq(state)]
        if ss.empty:
            continue
        x = ss["heat_proxy_W"].to_numpy(dtype=float)
        y = ss["spectral_instability_log_nm"].to_numpy(dtype=float)
        mx, xlo, xhi = read_bootstrap_interval(x, seed=700 + state)
        my, ylo, yhi = read_bootstrap_interval(y, seed=800 + state)

        geometry=read_json('plot_feature_ellipses.json').get(str(state))
        if geometry is not None:
            angle,width,height=geometry
            ell = Ellipse(
                (mx, my),
                width,
                height,
                angle=angle,
                facecolor=STATE_COLORS[state],
                edgecolor=STATE_COLORS[state],
                linewidth=1.15,
                alpha=0.16,
                zorder=3,
            )
            ax.add_patch(ell)
            outline = Ellipse(
                (mx, my),
                width,
                height,
                angle=angle,
                facecolor="none",
                edgecolor=STATE_COLORS[state],
                linewidth=1.0,
                alpha=0.78,
                zorder=4,
            )
            ax.add_patch(outline)

        ax.errorbar(
            mx,
            my,
            xerr=[[mx - xlo], [xhi - mx]],
            yerr=[[my - ylo], [yhi - my]],
            fmt=STATE_MARKERS[state],
            color=STATE_COLORS[state],
            ecolor=DARK,
            elinewidth=0.75,
            capsize=2.4,
            markersize=6.2,
            markeredgecolor=DARK,
            markeredgewidth=0.5,
            zorder=7,
        )

    ax.axvline(0, color=GRAY, linestyle="--", linewidth=0.7)
    ax.axhline(np.log10(0.1), color=GRAY, linestyle="--", linewidth=0.7)
    ax.set_xlabel("Centered UI-Power load proxy (W)")
    ax.set_ylabel("Spectral instability (nm; log scale)")
    ax.set_xlim(-0.55, 7.25)
    ax.set_ylim(-3.35, 2.85)
    ax.set_xticks([0, 1, 2, 3, 4, 5, 6, 7])
    ax.set_yticks([-3, -2, -1, 0, 1, 2])
    ax.set_yticklabels(["0.001", "0.01", "0.1", "1", "10", "100"])
    handles = [
        Line2D([0], [0], marker=STATE_MARKERS[s], linestyle="None", markerfacecolor=STATE_COLORS[s], markeredgecolor=DARK, label=STATE_NAMES[s])
        for s in [1, 2, 3, 4]
    ]
    handles.insert(0, Patch(facecolor=LIGHT_GRAY, edgecolor="none", alpha=0.45, label="Hourly density"))
    ax.legend(
        handles=handles,
        frameon=False,
        loc="lower center",
        bbox_to_anchor=(0.5, 1.02),
        ncol=5,
        columnspacing=1.0,
        handletextpad=0.45,
        fontsize=7.8,
        borderaxespad=0.0,
    )
    style(ax, xgrid=True, ygrid=True)
    export(fig, "Figure_06")


def fig11_decoded_state_route(data: dict[str, pd.DataFrame]) -> None:
    align = data["align"].copy()
    currents = np.array(sorted(align["current_A"].unique()), dtype=float)
    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    rng = np.random.default_rng(20260430)
    for current in currents:
        ax.axhline(current, color=LIGHT_GRAY, linewidth=0.42, zorder=0)

    event_medians = []
    for current in currents:
        d = align[align["current_A"].eq(current)].copy()
        y0 = float(current)
        events = d[d["E80"].eq(1)]
        cens = d[d["E80"].eq(0)]
        if len(cens):
            y = y0 + rng.normal(0, 0.018, len(cens))
            ax.scatter(
                cens["censor_age_h"],
                y,
                marker=">",
                s=46,
                facecolor="white",
                edgecolor=DARK,
                linewidth=0.95,
                zorder=4,
                label="censored without hidden L80 entry" if current == currents[0] else None,
            )
        if len(events):
            y = y0 + rng.normal(0, 0.018, len(events))
            decoded_age = events["decoded_l80_entry_age_h"].to_numpy(dtype=float)
            ax.scatter(
                events["T80_age_h"],
                y,
                marker="s",
                s=54,
                color=ACCENT,
                edgecolor=DARK,
                linewidth=0.75,
                zorder=5,
                label="observed L80 and decoded risk entry" if current == currents[-1] else None,
            )
            for obs_age, dec_age, yy in zip(events["T80_age_h"].to_numpy(dtype=float), decoded_age, y):
                if np.isfinite(dec_age):
                    ax.plot([obs_age, dec_age], [yy, yy], color=DARK, linewidth=0.7, alpha=0.62, zorder=4)
                    ax.scatter(dec_age, yy - 0.055, marker="|", s=95, color=DARK, linewidth=1.0, zorder=6)
            med, lo, hi = read_bootstrap_interval(events["T80_age_h"].to_numpy(dtype=float), seed=int(811 * current))
            ax.errorbar(
                med,
                y0 + 0.115,
                xerr=[[med - lo], [hi - med]],
                fmt="s",
                color=ACCENT,
                ecolor=DARK,
                elinewidth=1.05,
                capsize=3.0,
                markersize=6.4,
                markeredgecolor=DARK,
                markeredgewidth=0.7,
                zorder=7,
                label="bootstrap median entry age" if len(event_medians) == 0 else None,
            )
            ax.text(med, y0 + 0.18, f"{med:.0f}", ha="center", va="bottom", fontsize=10.0)
            event_medians.append((med, y0 + 0.115))
        t50 = d[d["E50"].eq(1)]
        if len(t50):
            y = y0 - 0.105 + rng.normal(0, 0.014, len(t50))
            ax.scatter(
                t50["T50_abs_h"] - (t50["T80_abs_h"] - t50["T80_age_h"]),
                y,
                marker="D",
                s=42,
                color=AUX3,
                edgecolor=DARK,
                linewidth=0.65,
                zorder=5,
                label="T50 collapse entry" if current == currents[-1] else None,
            )

    if len(event_medians) > 1:
        med_x, med_y = zip(*event_medians)
        ax.plot(med_x, med_y, color=ACCENT, linestyle="--", linewidth=1.05, zorder=3)

    ax.set_yticks(currents)
    ax.set_yticklabels([f"{c:.1f}" for c in currents])
    ax.set_xlabel("Test age (h)")
    ax.set_ylabel("Current (A)")
    ax.set_xlim(0, 535)
    ax.set_ylim(2.72, 4.82)
    handles = [
        Line2D([0], [0], marker="s", markerfacecolor=ACCENT, markeredgecolor=DARK, color="none", markersize=6.5, label="L80 event / decoded entry"),
        Line2D([0], [0], marker="D", markerfacecolor=AUX3, markeredgecolor=DARK, color="none", markersize=5.7, label="T50 collapse"),
        Line2D([0], [0], marker=">", markerfacecolor="white", markeredgecolor=DARK, color="none", markersize=6.0, label="censored, no hidden entry"),
        Line2D([0], [0], marker="s", markerfacecolor=ACCENT, markeredgecolor=DARK, color=ACCENT, linestyle="--", linewidth=1.05, markersize=6.2, label="median with 95% CI"),
    ]
    ax.legend(
        handles=handles,
        frameon=False,
        loc="lower left",
        bbox_to_anchor=(0.01, 0.02),
        ncol=1,
        fontsize=9.5,
        handlelength=1.35,
        handletextpad=0.45,
        labelspacing=0.35,
        markerscale=0.85,
    )
    style(ax, xgrid=True, ygrid=False)
    export(fig, "Figure_08")


def fig12_decoded_path_timeline(data: dict[str, pd.DataFrame]) -> None:
    decoded = data["decoded"].copy()
    endpoints = data["endpoints"].copy().set_index("file")
    d = decoded[(decoded["age_h"] >= 0) & (decoded["state"].isin([1, 2, 3, 4]))].copy()
    excluded_file = "__excluded_3A_outlier__"
    order_frame = (
        d.groupby("file", as_index=False)
        .agg(current_A=("current_A", "first"), last_age=("age_h", "max"))
        .merge(endpoints[["T80_age_h", "E80", "censor_age_h"]], left_on="file", right_index=True, how="left")
    )
    order_frame["sort_age"] = np.where(order_frame["E80"].eq(1), order_frame["T80_age_h"], order_frame["censor_age_h"])
    if order_frame["current_A"].eq(3.0).any():
        excluded_age = float(order_frame.loc[order_frame["current_A"].eq(3.0), "sort_age"].max())
        excluded_row = pd.DataFrame(
            [
                {
                    "file": excluded_file,
                    "current_A": 3.0,
                    "last_age": np.nan,
                    "T80_age_h": np.nan,
                    "E80": np.nan,
                    "censor_age_h": excluded_age,
                    "sort_age": excluded_age,
                }
            ]
        )
        order_frame = pd.concat([order_frame, excluded_row], ignore_index=True)
    order_frame = order_frame.sort_values(["current_A", "sort_age", "file"], ascending=[True, True, True]).reset_index(drop=True)
    file_to_y = {file: i for i, file in enumerate(order_frame["file"])}

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    row_height = 0.70
    for file, sub in d.sort_values(["file", "age_h"]).groupby("file", sort=False):
        if file not in file_to_y:
            continue
        y = file_to_y[file]
        sub = sub.sort_values("age_h").reset_index(drop=True)
        states = sub["state"].astype(int).to_numpy()
        ages = sub["age_h"].to_numpy(dtype=float)
        starts = [0]
        for idx in range(1, len(sub)):
            if states[idx] != states[idx - 1]:
                starts.append(idx)
        starts.append(len(sub))
        censor_age = float(endpoints.loc[file, "censor_age_h"])
        for j in range(len(starts) - 1):
            start_idx = starts[j]
            end_idx = starts[j + 1]
            state = int(states[start_idx])
            x0 = max(0.0, float(ages[start_idx]))
            x1 = float(ages[end_idx]) if end_idx < len(sub) else censor_age
            width = max(0.6, x1 - x0)
            rect = Rectangle(
                (x0, y - row_height / 2),
                width,
                row_height,
                facecolor=STATE_COLORS[state],
                edgecolor=DARK,
                linewidth=0.28,
                hatch=STATE_HATCHES[state],
                alpha=0.86,
                zorder=2,
            )
            ax.add_patch(rect)
        if int(endpoints.loc[file, "E80"]) == 1 and np.isfinite(float(endpoints.loc[file, "T80_age_h"])):
            ax.scatter(
                float(endpoints.loc[file, "T80_age_h"]),
                y,
                marker="|",
                s=52,
                color=DARK,
                linewidth=1.15,
                zorder=5,
            )
        else:
            ax.scatter(
                censor_age,
                y,
                marker=">",
                s=18,
                facecolor="white",
                edgecolor=GRAY,
                linewidth=0.75,
                zorder=5,
            )

    if excluded_file in file_to_y:
        y = file_to_y[excluded_file]
        excluded_age = float(order_frame.loc[order_frame["file"].eq(excluded_file), "sort_age"].iloc[0])
        ax.add_patch(
            Rectangle(
                (0.0, y - row_height / 2),
                excluded_age,
                row_height,
                facecolor="none",
                edgecolor=GRAY,
                linewidth=0.85,
                linestyle=(0, (3.0, 2.0)),
                zorder=3,
            )
        )

    group_centers = []
    group_labels = []
    for current, group in order_frame.groupby("current_A", sort=True):
        idxs = [file_to_y[file] for file in group["file"]]
        group_centers.append(float(np.mean(idxs)))
        group_labels.append(f"{current:.1f} A")
        ax.axhline(max(idxs) + 0.5, color=LIGHT_GRAY, linewidth=0.45, zorder=1)

    ax.set_xlabel("Test age (h)")
    ax.set_ylabel("Current group")
    ax.set_xlim(0, 510)
    ax.set_ylim(-0.7, len(order_frame) - 0.3)
    ax.set_xticks([0, 100, 200, 300, 400, 500])
    ax.set_yticks(group_centers)
    ax.set_yticklabels(group_labels)
    ax.tick_params(axis="y", length=0)
    for y in range(len(order_frame)):
        ax.axhline(y - 0.5, color=LIGHT_GRAY, linewidth=0.24, alpha=0.32, zorder=0)
    handles = [
        Patch(facecolor=STATE_COLORS[s], edgecolor=DARK, hatch=STATE_HATCHES[s], label=STATE_NAMES[s], alpha=0.86)
        for s in [1, 2, 3, 4]
    ]
    handles.extend(
        [
            Line2D([0], [0], marker="|", linestyle="None", color=DARK, markersize=7.0, markeredgewidth=1.15, label="L80"),
            Line2D([0], [0], marker=">", linestyle="None", markerfacecolor="white", markeredgecolor=GRAY, color=GRAY, markersize=5.0, label="censored"),
            Patch(facecolor="none", edgecolor=GRAY, linestyle=(0, (3.0, 2.0)), label="excluded"),
        ]
    )
    ax.legend(
        handles=handles,
        frameon=False,
        loc="lower center",
        bbox_to_anchor=(0.5, 1.015),
        ncol=7,
        fontsize=7.4,
        handlelength=1.15,
        columnspacing=0.52,
        handletextpad=0.35,
        labelspacing=0.25,
    )
    style(ax, xgrid=True, ygrid=False)
    export(fig, "Figure_15")


def read_segments(decoded: pd.DataFrame) -> pd.DataFrame:
    return pd.read_csv(SRC/'plot_segments.csv')


def fig12_current_dependent_state_clock(data: dict[str, pd.DataFrame]) -> None:
    params = data["params"]
    p = params[params["sojourn_mu_log_h"].notna()].set_index("state")
    currents = np.linspace(3.0, 4.5, 120)
    obs = read_segments(data["decoded"])

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    rng = np.random.default_rng(20260504)
    for state in [1, 2, 3]:
        row = p.loc[state]
        med = np.load(SRC/'plot_residence_curves.npz')[str(state)]
        ax.plot(currents, med, color=STATE_COLORS[state], linestyle="-", linewidth=1.35, label=STATE_NAMES[state])
        for current, ss in obs[(obs["state"].eq(state))].groupby("current_A", sort=True):
            if len(ss) < 1:
                continue
            jitter = rng.normal(0, 0.018, len(ss))
            ax.scatter(
                np.full(len(ss), current) + jitter,
                ss["duration_h"].to_numpy(dtype=float),
                s=13,
                marker=STATE_MARKERS[state],
                facecolor=STATE_COLORS[state],
                edgecolor="white",
                linewidth=0.28,
                alpha=0.34,
                zorder=2,
            )
            m, lo, hi = read_bootstrap_interval(ss["duration_h"].to_numpy(), seed=int(100 * current + state))
            ax.errorbar(current, m, yerr=[[m - lo], [hi - m]], fmt=STATE_MARKERS[state], color=STATE_COLORS[state], ecolor=DARK, capsize=2.2, markeredgecolor=DARK, markeredgewidth=0.45, markersize=5.0, zorder=5)
    ax.set_xlabel("Current stress (A)")
    ax.set_ylabel("Hidden-state residence time (h)")
    ax.set_yscale("log")
    ax.set_xticks([3.0, 3.5, 4.0, 4.5])
    ax.set_xlim(2.92, 4.58)
    ax.set_ylim(10, 4000)
    handles = [
        Line2D([0], [0], color=STATE_COLORS[s], marker=STATE_MARKERS[s], markerfacecolor=STATE_COLORS[s], markeredgecolor=DARK, label=STATE_NAMES[s])
        for s in [1, 2, 3]
    ]
    handles.append(Line2D([0], [0], marker="o", linestyle="None", markerfacecolor=GRAY, markeredgecolor="white", alpha=0.45, label="decoded segments"))
    ax.legend(handles=handles, frameon=False, loc="upper right", ncol=1)
    style(ax, xgrid=True, ygrid=True)
    export(fig, "Figure_09")


def read_extended_risk(
    params: pd.DataFrame,
    currents: np.ndarray,
    ages: np.ndarray,
    n_mc: int = 26000,
    seed: int = 20260427,
) -> np.ndarray:
    return np.load(SRC/'plot_extended_risk.npz')['risk']


def smooth_array2d(z: np.ndarray, sigma_y: float = 1.0, sigma_x: float = 1.0) -> np.ndarray:
    """Lightweight separable Gaussian smoothing for display-only cloud fields."""
    out = np.asarray(z, dtype=float)
    for axis, sigma in [(0, sigma_y), (1, sigma_x)]:
        if sigma <= 0:
            continue
        radius = max(1, int(round(3 * sigma)))
        x = np.arange(-radius, radius + 1, dtype=float)
        kernel = np.exp(-(x**2) / (2 * sigma**2))
        kernel /= kernel.sum()
        pad_width = [(0, 0), (0, 0)]
        pad_width[axis] = (radius, radius)
        padded = np.pad(out, pad_width, mode="edge")
        out = np.apply_along_axis(lambda m: np.convolve(m, kernel, mode="valid"), axis, padded)
    return out


def apply_risk_contour_halo(contour_set, labels=None, contour_width: float = 2.4, label_width: float = 1.55) -> None:
    """Keep L80 probability contours readable over risk clouds and state-boundary overlays."""
    contour_halo = [pe.Stroke(linewidth=contour_width, foreground=PALETTE["paper"], alpha=0.96), pe.Normal()]
    for artist in getattr(contour_set, "collections", []):
        artist.set_path_effects(contour_halo)
    if labels:
        label_halo = [pe.Stroke(linewidth=label_width, foreground=PALETTE["paper"], alpha=0.98), pe.Normal()]
        for label in labels:
            label.set_path_effects(label_halo)
            label.set_zorder(6.4)


def add_risk_contours(ax: plt.Axes, ages: np.ndarray, currents: np.ndarray, risk: np.ndarray, fontsize: float = 9.2, linewidth: float = 0.8) -> None:
    levels = [level for level in [0.1, 0.5, 0.9] if float(np.nanmin(risk)) < level < float(np.nanmax(risk))]
    if not levels:
        return
    linestyles = {0.1: ":", 0.5: "--", 0.9: "-"}
    label_positions = {0.1: (360, 3.66), 0.5: (448, 4.07), 0.9: (430, 4.40)}
    for level in levels:
        cs = ax.contour(
            ages,
            currents,
            risk,
            levels=[level],
            colors=DARK,
            linewidths=linewidth,
            linestyles=linestyles[level],
            zorder=5.35,
        )
        labels = ax.clabel(
            cs,
            fmt={level: f"F={level:.1f}"},
            fontsize=fontsize,
            inline=True,
            inline_spacing=4,
            manual=[label_positions[level]],
        )
        apply_risk_contour_halo(cs, labels, contour_width=linewidth + 1.35, label_width=1.45)


def read_observed_state_surface(decoded: pd.DataFrame, currents: np.ndarray, ages: np.ndarray) -> np.ndarray:
    return np.load(SRC/'plot_observed_states.npz')['state']


def read_extended_boundaries(params: pd.DataFrame, currents: np.ndarray) -> list[tuple[str, np.ndarray, str, float]]:
    v=np.load(SRC/'plot_extended_boundaries.npz'); return [(label,v[str(i)],ls,lw) for i,(label,ls,lw) in enumerate([('Stable/Drift','-.',1.02),('Drift/L80 risk','--',.86),('L80 risk/Collapse','-',.96)])]


def apply_state_boundary_halo(artists, halo_width: float = 2.7) -> None:
    """Give decoded state boundaries a white halo so they remain legible on risk clouds."""
    halo = [pe.Stroke(linewidth=halo_width, foreground=PALETTE["paper"], alpha=0.9), pe.Normal()]
    for artist in artists:
        artist.set_path_effects(halo)


def draw_state_boundary_curve(
    ax: plt.Axes,
    x: np.ndarray,
    y: np.ndarray,
    linestyle: str,
    linewidth: float,
    zorder: float = 4.25,
) -> None:
    line = ax.plot(
        x,
        y,
        color=STATE_BOUNDARY,
        linestyle=linestyle,
        linewidth=linewidth,
        alpha=0.97,
        zorder=zorder,
        solid_capstyle="round",
        dash_capstyle="round",
    )[0]
    apply_state_boundary_halo([line], halo_width=linewidth + 1.7)


def add_region_label(
    ax: plt.Axes,
    x: float,
    y: float,
    text: str,
    *,
    fontsize: float = 8.2,
    ha: str = "left",
    va: str = "center",
    alpha: float = 0.84,
    rotation: float = 0.0,
) -> None:
    label = ax.text(x, y, text, color=DARK, fontsize=fontsize, alpha=alpha, ha=ha, va=va, rotation=rotation, zorder=6.25)
    label.set_path_effects([pe.Stroke(linewidth=1.45, foreground=PALETTE["paper"], alpha=0.94), pe.Normal()])


def fig15_current_age_reliability_surface(data: dict[str, pd.DataFrame]) -> None:
    rel = data["rel"]
    endpoints = data["endpoints"]
    observed_currents = np.array(sorted(endpoints["current_A"].unique()), dtype=float)
    model_ages = np.arange(0, 501)
    risk = np.zeros((len(observed_currents), len(model_ages)), dtype=float)
    for i, current in enumerate(observed_currents):
        d = rel[(rel["method"].eq("NH_HSMM")) & (rel["current_A"].astype(str).eq(f"{current:.1f}"))].sort_values("age_h")
        survival = np.interp(model_ages, d["age_h"].to_numpy(dtype=float), d["survival"].to_numpy(dtype=float))
        risk[i] = 1.0 - survival
    current_edges = np.r_[
        observed_currents[0] - 0.25,
        (observed_currents[:-1] + observed_currents[1:]) / 2,
        observed_currents[-1] + 0.25,
    ]
    age_edges = np.r_[model_ages[0] - 0.5, model_ages[:-1] + 0.5, model_ages[-1] + 0.5]

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    im = ax.pcolormesh(
        age_edges,
        current_edges,
        risk,
        shading="flat",
        cmap=RISK_CLOUD_CMAP,
        vmin=0.0,
        vmax=1.0,
        zorder=1,
    )
    for current in observed_currents:
        ax.hlines(current, model_ages.min(), model_ages.max(), color=GRAY, linewidth=0.45, alpha=0.45, zorder=3)

    state_surface = read_observed_state_surface(data["decoded"], observed_currents, model_ages)
    state_levels = [level for level in [1.5, 2.5, 3.5] if float(np.nanmin(state_surface)) < level < float(np.nanmax(state_surface))]
    if state_levels:
        cs_state = ax.contour(
            model_ages,
            observed_currents,
            state_surface,
            levels=state_levels,
            colors=STATE_BOUNDARY,
            linewidths=[1.34, 1.16, 1.28][: len(state_levels)],
            linestyles=["-.", "--", "-"][: len(state_levels)],
            alpha=0.96,
            zorder=4.2,
        )
        apply_state_boundary_halo(getattr(cs_state, "collections", []), halo_width=2.7)
    add_risk_contours(ax, model_ages, observed_currents, risk, fontsize=7.7, linewidth=0.96)

    for _, row in endpoints.iterrows():
        cur = float(row["current_A"])
        if int(row["E80"]) == 1:
            ax.scatter(row["T80_age_h"], cur, marker="s", color=ACCENT, edgecolor=DARK, linewidth=0.55, s=30, zorder=6, clip_on=False)
        else:
            ax.scatter(row["censor_age_h"], cur, marker="o", facecolor="white", edgecolor=DARK, linewidth=0.8, s=30, zorder=6, clip_on=False)

    add_region_label(ax, 70, 3.08, "Stable")
    add_region_label(ax, 306, 3.36, "Drift")
    add_region_label(ax, 333, 4.14, "L80 risk state", fontsize=8.8, ha="center", alpha=0.96)
    add_region_label(ax, 435, 4.56, "Collapse")

    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.025)
    cbar.set_label("L80 failure probability", fontsize=9.2)
    cbar.set_ticks([0.0, 0.5, 1.0])
    cbar.ax.tick_params(labelsize=8.8, width=0.65, length=2.6)
    ax.set_xlabel("Test age (h)")
    ax.set_ylabel("Current (A)")
    ax.set_xlim(0, 505)
    ax.set_ylim(float(current_edges.min()), float(current_edges.max()))
    ax.set_yticks(observed_currents)
    handles = [
        Line2D([0], [0], marker="s", color="none", markerfacecolor=ACCENT, markeredgecolor=DARK, label="L80 event"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="white", markeredgecolor=DARK, label="Censored"),
        Line2D([0, 1], [0, 0], color=STATE_BOUNDARY, linestyle="--", linewidth=1.18, label="decoded state boundary"),
    ]
    ax.legend(handles=handles, frameon=False, loc="upper left", bbox_to_anchor=(0.012, 0.985), handletextpad=0.35, ncol=1, fontsize=8.0, borderaxespad=0.0)
    style(ax, xgrid=False, ygrid=False)
    export(fig, "Figure_12a")


def fig16_extended_current_age_risk_surface(data: dict[str, pd.DataFrame]) -> None:
    endpoints = data["endpoints"]
    ages = np.geomspace(1.0, 10000.0, 620)
    currents = np.linspace(2.0, 6.0, 241)
    risk = read_extended_risk(data["params"], currents, ages, n_mc=42000, seed=20260428)
    risk_display = np.clip(smooth_array2d(risk, sigma_y=1.0, sigma_x=1.0), 0.0, 1.0)
    log_ages = np.log10(ages)
    observed_currents = np.array(sorted(endpoints["current_A"].unique()), dtype=float)
    tested_xmax = np.log10(500.0)

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    im = ax.imshow(
        risk_display,
        extent=(float(log_ages.min()), float(log_ages.max()), float(currents.min()), float(currents.max())),
        origin="lower",
        interpolation="bicubic",
        cmap=RISK_CLOUD_CMAP,
        vmin=0.0,
        vmax=1.0,
        aspect="auto",
        zorder=1,
    )

    for current in observed_currents:
        ax.hlines(current, 0.0, tested_xmax, color=GRAY, linewidth=0.45, alpha=0.58, zorder=3)

    for boundary_label, log_boundary_age, linestyle, linewidth in read_extended_boundaries(data["params"], currents):
        band_half_width = 0.035 if boundary_label == "Stable/Drift" else 0.028
        band_alpha = 0.12 if boundary_label == "Stable/Drift" else 0.08
        ax.fill_betweenx(
            currents,
            np.clip(log_boundary_age - band_half_width, 0.0, 4.0),
            np.clip(log_boundary_age + band_half_width, 0.0, 4.0),
            color=STATE_BOUNDARY,
            alpha=band_alpha,
            linewidth=0,
            zorder=3.75,
        )
        draw_state_boundary_curve(ax, log_boundary_age, currents, linestyle=linestyle, linewidth=linewidth + 0.34)

    f_levels = [level for level in [0.1, 0.5, 0.9] if float(np.nanmin(risk)) < level < float(np.nanmax(risk))]
    if f_levels:
        cs = ax.contour(log_ages, currents, risk_display, levels=f_levels, colors=DARK, linewidths=1.0, zorder=5.35)
        label_positions = []
        for level, label_current in [(0.1, 5.48), (0.5, 4.86), (0.9, 3.26)]:
            if level not in f_levels:
                continue
            row = risk_display[np.argmin(np.abs(currents - label_current))]
            if float(row.min()) < level < float(row.max()):
                label_positions.append((float(np.interp(level, row, log_ages)), label_current))
        labels = ax.clabel(cs, fmt={0.1: "F=0.1", 0.5: "F=0.5", 0.9: "F=0.9"}, fontsize=8.8, inline=True, inline_spacing=5, manual=label_positions or None)
        apply_risk_contour_halo(cs, labels, contour_width=2.35, label_width=1.55)
    tested_rect = Rectangle(
        (0.0, observed_currents.min()),
        tested_xmax,
        observed_currents.max() - observed_currents.min(),
        fill=False,
        edgecolor=DARK,
        linewidth=0.9,
        linestyle="--",
        zorder=4,
    )
    ax.add_patch(tested_rect)

    for _, row in endpoints.iterrows():
        cur = float(row["current_A"])
        if int(row["E80"]) == 1:
            age = max(float(row["T80_age_h"]), 1.0)
            ax.scatter(np.log10(age), cur, marker="s", color=ACCENT, edgecolor=DARK, linewidth=0.65, s=42, zorder=6, clip_on=False)
        else:
            age = max(float(row["censor_age_h"]), 1.0)
            ax.scatter(np.log10(age), cur, marker="o", facecolor="white", edgecolor=DARK, linewidth=1.0, s=38, zorder=6, clip_on=False)

    add_region_label(ax, 0.36, 2.42, "Stable")
    add_region_label(ax, 2.49, 3.14, "Drift")
    l80_callout = ax.annotate(
        "L80 risk\nstate",
        xy=(2.62, 4.24),
        xytext=(2.86, 4.34),
        color=DARK,
        fontsize=7.9,
        alpha=0.86,
        ha="left",
        va="center",
        arrowprops=dict(arrowstyle="-", color=DARK, linewidth=0.55, alpha=0.72, shrinkA=0, shrinkB=0),
        zorder=6.3,
    )
    l80_callout.set_path_effects([pe.Stroke(linewidth=1.45, foreground=PALETTE["paper"], alpha=0.94), pe.Normal()])
    add_region_label(ax, 3.35, 5.48, "Collapse")

    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.025)
    cbar.set_label("L80 failure probability")
    cbar.set_ticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
    cbar.ax.tick_params(labelsize=12.0, width=0.75, length=3.0)

    ax.set_xlabel("Test age (h, log scale)")
    ax.set_ylabel("Current (A)")
    ax.set_xlim(0.0, 4.0)
    ax.set_ylim(2.0, 6.0)
    ax.set_xticks([0, 1, 2, 3, 4])
    ax.set_xticklabels(["1", "10", "100", "1,000", "10,000"])
    ax.set_yticks([2, 3, 4, 5, 6])
    handles = [
        Line2D([0], [0], marker="s", color="none", markerfacecolor=ACCENT, markeredgecolor=DARK, label="L80 event"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="white", markeredgecolor=DARK, label="Censored"),
        Line2D([0, 1], [0, 0], color=STATE_BOUNDARY, linestyle="--", linewidth=1.2, label="decoded state boundary"),
        Line2D([0, 1], [0, 0], color=DARK, linestyle="--", linewidth=0.9, label="tested window"),
    ]
    ax.legend(handles=handles, frameon=False, loc="upper left", bbox_to_anchor=(0.01, 0.99), handletextpad=0.45, ncol=1)
    style(ax, xgrid=False, ygrid=False)

    export(fig, "Figure_12b")


def read_km_curve(times: np.ndarray, events: np.ndarray) -> pd.DataFrame:
    return pd.read_csv(SRC/'plot_km.csv')


def fig18_reliability_error_density(data: dict[str, pd.DataFrame]) -> None:
    rel = data["rel"]
    endpoints = data["endpoints"]
    abl = data["abl"].set_index("method")
    km = read_km_curve(endpoints["T80_age_h"].to_numpy(), endpoints["E80"].to_numpy())
    ages = np.arange(0, 501)
    km_s = np.interp(ages, km["age_h"], km["survival"])

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    styles = [
        ("NH_HSMM", ACCENT, "///", "-"),
        ("shared_accel_HSMM_ablation", AUX1, "\\\\\\", "-."),
        ("homogeneous_HSMM_ablation", AUX3, "xx", "--"),
        ("weibull_AFT_endpoint_baseline", AUX2, "..", ":"),
    ]
    for method, color, hatch, ls in styles:
        d = rel[(rel["method"].eq(method)) & (rel["current_A"].astype(str).eq("pooled"))]
        if d.empty:
            continue
        m_s = np.interp(ages, d["age_h"], d["survival"])
        err = np.abs(m_s - km_s)
        ax.plot(ages, err, color=color, linewidth=1.25, linestyle=ls, label=METHOD_LABELS[method])
        ax.fill_between(ages, 0, err, color=color, alpha=0.12, edgecolor=color, linewidth=0.0)
    ax.set_xlabel("Test age (h)")
    ax.set_ylabel("Absolute reliability error")
    ax.set_xlim(0, 500)
    ax.set_ylim(0, 0.55)
    ax.legend(frameon=False, loc="upper left")
    style(ax)
    export(fig, "Figure_16")


def fig19_rul_bias_repair(data: dict[str, pd.DataFrame]) -> None:
    pred = data["pred"]
    obs = pred[pred["true_rul_h"].notna()].copy()
    wide = obs.pivot_table(index=["file", "current_A", "t0_h", "true_rul_h"], columns="method", values="p50_h").reset_index()
    wide["err_nh"] = wide["NH_HSMM"] - wide["true_rul_h"]
    wide["err_h"] = wide["homogeneous_HSMM_ablation"] - wide["true_rul_h"]
    wide = wide.sort_values("true_rul_h").reset_index(drop=True)
    x = np.arange(1, len(wide) + 1)

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    ax.axhline(0, color=DARK, linewidth=0.8)
    for i, row in wide.iterrows():
        color = CURRENT_COLORS[float(row["current_A"])]
        ax.plot([x[i], x[i]], [row["err_h"], row["err_nh"]], color=GRAY, linewidth=0.75, alpha=0.75)
        ax.scatter(x[i], row["err_h"], marker="^", s=25, color=AUX3, edgecolor=DARK, linewidth=0.35)
        ax.scatter(x[i], row["err_nh"], marker="s", s=25, color=color, edgecolor=DARK, linewidth=0.35)
    mae_nh = float(data["abl"].set_index("method").loc["NH_HSMM","rul_p50_mae_h"])
    mae_h = float(data["abl"].set_index("method").loc["homogeneous_HSMM_ablation","rul_p50_mae_h"])
    ax.text(
        0.03,
        0.95,
        f"MAE {mae_h:.1f} h to {mae_nh:.1f} h",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8.8,
        bbox=dict(boxstyle="round,pad=0.18", fc="none", ec="none", lw=0.0),
    )
    handles = [
        Line2D([0], [0], marker="^", color="none", markerfacecolor=AUX3, markeredgecolor=DARK, label="Stress-independent HSMM"),
        Line2D([0], [0], marker="s", color="none", markerfacecolor=GRAY, markeredgecolor=DARK, label="NH-HSMM (current-coded)"),
    ]
    ax.legend(handles=handles, frameon=False, loc="lower center", bbox_to_anchor=(0.58, 1.02), ncol=2, columnspacing=1.2, fontsize=7.8, borderaxespad=0.0)
    ax.set_xlabel("Observed prediction case")
    ax.set_ylabel("Median RUL error (h)")
    ax.set_xlim(0.3, len(wide) + 0.7)
    ax.set_ylim(min(-180, wide[["err_h", "err_nh"]].min().min() - 35), max(1000, wide[["err_h", "err_nh"]].max().max() + 140))
    ax.set_yscale("symlog", linthresh=50, linscale=0.9)
    ax.set_yticks([-100, -50, 0, 50, 100, 200, 400, 800])
    ax.set_yticklabels(["-100", "-50", "0", "50", "100", "200", "400", "800"])
    style(ax)
    export(fig, "Figure_14a")


def fig20_rul_calibration_intervals(data: dict[str, pd.DataFrame]) -> None:
    pred = data["pred"]
    obs = pred[(pred["method"].eq("NH_HSMM")) & (pred["true_rul_h"].notna())].copy()

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    for current, sub in obs.groupby("current_A", sort=True):
        color = CURRENT_COLORS[float(current)]
        yerr = np.vstack([sub["p50_h"] - sub["p10_h"], sub["p90_h"] - sub["p50_h"]])
        ax.errorbar(
            sub["true_rul_h"],
            sub["p50_h"],
            yerr=yerr,
            fmt=CURRENT_MARKERS[float(current)],
            color=color,
            ecolor=color,
            elinewidth=0.8,
            capsize=2.0,
            markeredgecolor=DARK,
            markeredgewidth=0.35,
            alpha=0.84,
            label=f"{current:.1f} A",
        )
    lim = 460
    ax.plot([0, lim], [0, lim], color=DARK, linestyle="--", linewidth=0.85)
    ax.set_xlabel("Observed RUL (h)")
    ax.set_ylabel("Predicted RUL (h)")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    ax.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.02), ncol=2, fontsize=7.8, borderaxespad=0.0)
    style(ax, xgrid=True, ygrid=True)
    export(fig, "Figure_14b")


def fig21_ablation_summary_radarless(data: dict[str, pd.DataFrame]) -> None:
    abl = data["abl"].copy()
    preferred = [
        "NH_HSMM",
        "shared_accel_HSMM_ablation",
        "weibull_AFT_endpoint_baseline",
        "wiener_degradation_FP_baseline",
        "no_explicit_duration_HMM_ablation",
        "homogeneous_HSMM_ablation",
    ]
    preferred = [m for m in preferred if m in set(abl["method"])]
    abl = abl.set_index("method").loc[preferred].reset_index()
    abl = abl.sort_values("rul_p50_mae_h", ascending=True).reset_index(drop=True)

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    y = np.arange(len(abl))
    hatches = {
        "NH_HSMM": "",
        "no_explicit_duration_HMM_ablation": "\\\\",
        "homogeneous_HSMM_ablation": "xx",
        "shared_accel_HSMM_ablation": "..",
        "weibull_AFT_endpoint_baseline": "--",
        "wiener_degradation_FP_baseline": "//",
    }
    mae = abl["rul_p50_mae_h"].to_numpy(dtype=float)
    lo = abl["rul_p50_mae_lo95_h"].to_numpy(dtype=float)
    hi = abl["rul_p50_mae_hi95_h"].to_numpy(dtype=float)
    colors = [METHOD_COLORS.get(m, GRAY) for m in abl["method"]]
    bars = ax.barh(
        y,
        mae,
        xerr=np.vstack([mae - lo, hi - mae]),
        color=colors,
        edgecolor=DARK,
        linewidth=0.75,
        alpha=0.88,
        error_kw={"elinewidth": 0.9, "ecolor": DARK, "capsize": 3.0},
    )
    for bar, method in zip(bars, abl["method"]):
        bar.set_hatch(hatches.get(method, ""))

    xmax = float(np.nanmax(hi)) * 1.46
    for i, row in abl.iterrows():
        ax.text(
            float(row["rul_p50_mae_hi95_h"]) + xmax * 0.018,
            i + 0.17,
            f"Bias {float(row['rul_p50_bias_h']):+.1f} h; coverage {float(row['rul_p10_p90_coverage']):.2f}",
            ha="left",
            va="center",
            fontsize=8.2,
            color=DARK,
        )
        ax.text(
            float(row["rul_p50_mae_hi95_h"]) + xmax * 0.018,
            i - 0.14,
            f"{float(row['rul_p50_mae_h']):.1f}",
            ha="left",
            va="center",
            fontsize=10.2,
            color=DARK,
            weight="bold",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 0.18},
            zorder=8,
        )

    ax.axvspan(0, 60, ymin=0.0, ymax=1.0, facecolor=ACCENT, alpha=0.06, edgecolor=ACCENT, linewidth=0.0)
    short_labels = {
        "NH_HSMM": "NH-HSMM",
        "shared_accel_HSMM_ablation": "Shared-accel",
        "homogeneous_HSMM_ablation": "Stress-independent",
        "weibull_AFT_endpoint_baseline": "Weibull AFT",
        "wiener_degradation_FP_baseline": "Wiener FP",
        "no_explicit_duration_HMM_ablation": "Geometric duration",
    }
    ax.set_yticks(y)
    ax.set_yticklabels([short_labels.get(m, METHOD_LABELS[m]) for m in abl["method"]])
    ax.invert_yaxis()
    ax.set_xlabel("Held-out RUL MAE (h)")
    ax.set_ylabel("")
    ax.set_xlim(0, xmax)
    style(ax, xgrid=True, ygrid=False)
    export(fig, "Figure_17")


def fig10_hidden_state_feature_signature(data: dict[str, pd.DataFrame]) -> None:
    params = data["params"].copy()
    feature_labels = {
        "D": "Depth",
        "loss_rate": "Loss rate",
        "heat_proxy_W": "Thermal load",
        "lambda_shift_nm": "Wavelength shift",
        "bw_shift_nm": "Bandwidth shift",
        "spectral_instability": "Spectral instability",
        "eta": "Efficiency",
    }
    states = [1, 2, 3, 4]
    features = list(feature_labels.keys())
    mat = np.zeros((len(features), len(states)))
    for i, feature in enumerate(features):
        for j, state in enumerate(states):
            row = params[(params["state"].eq(state)) & (params["feature"].eq(feature))]
            mat[i, j] = float(row["emission_mu_robust_z"].iloc[0]) if len(row) else np.nan
    disp = signed_log(mat)

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    signature_norm = TwoSlopeNorm(vmin=-3.0, vcenter=0.0, vmax=3.0)
    im = ax.imshow(
        disp,
        cmap=SIGNED_CMAP,
        norm=signature_norm,
        aspect="auto",
        interpolation="nearest",
    )
    for x in np.arange(-0.5, len(states), 1.0):
        ax.axvline(x, color="white", linewidth=1.0, alpha=0.85)
    for y in np.arange(-0.5, len(features), 1.0):
        ax.axhline(y, color="white", linewidth=1.0, alpha=0.85)
    for i in range(disp.shape[0]):
        for j in range(disp.shape[1]):
            val = disp[i, j]
            text_color = "white" if abs(val) > 1.9 else DARK
            ax.text(j, i, f"{val:.1f}", ha="center", va="center", fontsize=8.7, color=text_color)
    ax.set_xticks(np.arange(len(states)))
    ax.set_xticklabels([STATE_NAMES[s] for s in states])
    ax.set_yticks(np.arange(len(features)))
    ax.set_yticklabels([feature_labels[f] for f in features])
    ax.set_xlim(-0.5, len(states) - 0.5)
    ax.set_ylim(len(features) - 0.5, -0.5)
    ax.set_xlabel("Hidden degradation state")
    ax.set_ylabel("Observation feature")
    cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
    cbar.set_label("Robust signed shift")
    cbar.set_ticks([-3, -2, -1, 0, 1, 2, 3])
    cbar.ax.tick_params(labelsize=10.0, width=0.7, length=2.8)
    style(ax, xgrid=False, ygrid=False)
    export(fig, "Figure_07")


def fig13_state_occupancy_by_current(data: dict[str, pd.DataFrame]) -> None:
    decoded = data["decoded"].copy()
    d = decoded[(decoded["age_h"] >= 0) & (decoded["state"].isin([1, 2, 3, 4]))].copy()
    pct=pd.read_csv(SRC/'plot_occupancy_percent.csv',index_col=0);pct.columns=pct.columns.astype(int)

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    y = np.arange(len(pct.index))
    left = np.zeros(len(pct.index))
    for state in [1, 2, 3, 4]:
        vals = pct.get(state, pd.Series(0, index=pct.index)).to_numpy()
        bars = ax.barh(
            y,
            vals,
            left=left,
            color=STATE_COLORS[state],
            edgecolor=DARK,
            linewidth=0.55,
            hatch=STATE_HATCHES[state],
            alpha=0.82,
            label=STATE_NAMES[state],
        )
        for bar, val, lft in zip(bars, vals, left):
            if val >= 7:
                ax.text(lft + val / 2, bar.get_y() + bar.get_height() / 2, f"{val:.0f}", ha="center", va="center", fontsize=8.5, color="white" if state in [1, 4] else DARK)
        left += vals
    ax.set_yticks(y)
    ax.set_yticklabels([f"{c:.1f} A" for c in pct.index])
    ax.set_xlabel("Decoded residence share (%)")
    ax.set_ylabel("Current stress")
    ax.set_xlim(0, 100)
    ax.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.02), ncol=4, handlelength=1.5, columnspacing=1.0)
    style(ax, xgrid=True, ygrid=False)
    export(fig, "Figure_10")


def read_acceleration_interval(segments: pd.DataFrame, state: int, seed: int = 0, n_boot: int = 1500) -> tuple[float, float, float]:
    return tuple(read_json('plot_acceleration_bootstrap.json')[str(state)]['interval'])


def read_acceleration_samples(segments: pd.DataFrame, state: int, seed: int = 0, n_boot: int = 350) -> np.ndarray:
    return np.asarray(read_json('plot_acceleration_bootstrap.json')[str(state)]['values'])


def fig14_current_acceleration_coefficients(data: dict[str, pd.DataFrame]) -> None:
    p=data['params'];p=p[p.feature.isna()].set_index('state')
    models=read_json('soft_fitted_models.json')
    trace=pd.read_csv(SRC/'soft_fit_diagnostics.csv')
    ids=trace[(trace['mode']=='full')&(trace['variant']=='selected_5_state')&(trace.seed==0)&(trace.training_units==trace.training_units.max()-1)].fit_id.unique()
    fits=np.array([models[key]['theta'] for key in ids]);states=[1,2,3]
    fig,ax=plt.subplots(figsize=FIGSIZE_16_9)
    for j,state in enumerate(states):
        vals=fits[:,j,1];ax.scatter(vals,j+np.linspace(-.13,.13,len(vals)),s=22,facecolors='white',edgecolors=STATE_COLORS[state],linewidths=.8,label='Leave-one-unit training fits' if j==0 else None,zorder=3)
        value=float(p.loc[state,'current_accel_alpha']);ax.scatter([value],[j],s=62,marker='D',color=STATE_COLORS[state],edgecolors=DARK,linewidths=.6,label='Full-data soft EM fit' if j==0 else None,zorder=4)
        ax.text(value+.16,j+.2,f'{value:.2f}',fontsize=9,ha='center',va='center')
    ax.set_yticks(range(3));ax.set_yticklabels([STATE_NAMES[s] for s in states]);ax.set_xlim(0,8.4);ax.set_ylim(-.5,2.5)
    ax.set_xlabel(r'Current acceleration coefficient $\alpha_s$');ax.set_ylabel('Transient state')
    ax.legend(frameon=False,loc='lower center',bbox_to_anchor=(.5,1.02),ncol=2,fontsize=8)
    style(ax,xgrid=True,ygrid=False);export(fig,'Figure_11')


def fig17_pooled_l80_reliability(data: dict[str, pd.DataFrame]) -> None:
    endpoints = data["endpoints"].copy()
    rel = data["rel"].copy()
    km = read_km_greenwood(endpoints["T80_age_h"].to_numpy(dtype=float), endpoints["E80"].to_numpy(dtype=int))
    ages = np.arange(0, 501)
    km_surv = np.interp(ages, km["age_h"], km["survival"])
    km_lo = np.interp(ages, km["age_h"], km["lo"])
    km_hi = np.interp(ages, km["age_h"], km["hi"])

    fig, ax = plt.subplots(figsize=FIGSIZE_16_9)
    ax.fill_between(ages, km_lo, km_hi, color=GRAY, alpha=0.16, edgecolor=GRAY, linewidth=0.0, label="KM 95% CI")
    ax.step(ages, km_surv, where="post", color=DARK, linewidth=1.15, label="Empirical KM")
    for method, color, ls in [
        ("NH_HSMM", ACCENT, "-"),
        ("shared_accel_HSMM_ablation", AUX1, "-."),
        ("homogeneous_HSMM_ablation", AUX3, "--"),
        ("weibull_AFT_endpoint_baseline", AUX2, ":"),
    ]:
        d = rel[(rel["method"].eq(method)) & (rel["current_A"].astype(str).eq("pooled"))]
        if d.empty:
            continue
        ax.plot(d["age_h"], d["survival"], color=color, linestyle=ls, linewidth=1.55, label=METHOD_LABELS[method])
    event_ages = endpoints.loc[endpoints["E80"].eq(1), "T80_age_h"]
    ax.scatter(event_ages, np.full(len(event_ages), 0.035), marker="|", s=70, color=DARK, linewidth=1.1, label="L80 events")
    ax.set_xlabel("Test age (h)")
    ax.set_ylabel("L80 reliability")
    ax.set_xlim(0, 505)
    ax.set_ylim(0, 1.04)
    ax.legend(frameon=False, loc="lower left", handlelength=1.7)
    style(ax)
    export(fig, "Figure_13")


def main():
    global SRC,FIG
    parser=argparse.ArgumentParser(description='Render manuscript figures from exported results; never runs analysis.')
    parser.add_argument('--input-dir',type=Path,default=ROOT/'outputs')
    parser.add_argument('--figure-dir',type=Path,default=ROOT/'figures')
    args=parser.parse_args();SRC=args.input_dir;FIG=args.figure_dir
    manifest=read_json('plot_data_manifest.json')
    if manifest['schema_version']!=1:raise ValueError('Unsupported plotting-data schema')
    missing=[f for f in REQUIRED_MODEL_FILES+manifest['files'] if not (SRC/f).is_file()]
    if missing:raise FileNotFoundError('Run main_analysis.py first. Missing exported data: '+str(missing))
    for name,digest in manifest['source_sha256'].items():
        if hashlib.sha256((SRC/name).read_bytes()).hexdigest()!=digest:raise ValueError('Stale plot data for '+name+'; regenerate analysis outputs.')
    FIG.mkdir(parents=True,exist_ok=True)
    data={key:pd.read_csv(SRC/name) for key,name in {'baseline':'burnin_baseline_table.csv','decoded':'decoded_trajectories.csv','endpoints':'l80_t50_endpoints.csv','params':'nh_hsmm_parameters.csv','rel':'reliability_curves.csv','pred':'rul_predictions.csv','abl':'ablation_summary.csv','align':'l80_decoded_alignment.csv'}.items()}
    fig06_lifetest_observability_gap(data)
    fig08_burnin_baseline_slope(data)
    fig09_hidden_state_mechanism_map(data)
    fig10_hidden_state_feature_signature(data)
    fig11_decoded_state_route(data)
    fig12_current_dependent_state_clock(data)
    fig13_state_occupancy_by_current(data)
    fig14_current_acceleration_coefficients(data)
    fig15_current_age_reliability_surface(data)
    fig16_extended_current_age_risk_surface(data)
    fig17_pooled_l80_reliability(data)
    fig19_rul_bias_repair(data)
    fig20_rul_calibration_intervals(data)
    fig12_decoded_path_timeline(data)
    fig18_reliability_error_density(data)
    fig21_ablation_summary_radarless(data)
    print("Rendered all manuscript figures from the exported soft-model results.")

if __name__=="__main__":main()



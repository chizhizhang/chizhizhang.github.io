"""Create the editable graphical abstract from the manuscript's verified evidence chain.

The graphical abstract presents the abstract's evidence, inference and validation. The
risk field and matching survival shape use exported model curves on unlabeled
normalized display axes; other miniatures are conceptual. No model is fitted.
"""
from pathlib import Path
import csv
import math
import xml.etree.ElementTree as E

ROOT = Path(__file__).resolve().parents[1]
S = 'http://www.w3.org/2000/svg'
E.register_namespace('', S)
WHITE, INK, NAVY, BLUE, GREEN, GOLD, RED, GRAY = '#FFFFFF', '#000000', '#172C6F', '#0063D0', '#278575', '#D9A441', '#C83E36', '#7A7A7A'

def main():
    import numpy as np
    from scipy.interpolate import interp1d
    with (ROOT/'outputs/reliability_curves.csv').open(encoding='utf-8-sig') as f:
        rows=[row for row in csv.DictReader(f) if row['method']=='NH_HSMM' and row['current_A']!='pooled']
    currents=sorted({float(row['current_A']) for row in rows})
    ages=sorted({float(row['age_h']) for row in rows})
    lookup={(float(row['current_A']),float(row['age_h'])):float(row['survival']) for row in rows}
    risk=np.array([[1-lookup[c,t] for t in ages] for c in currents])
    assert np.all((risk>=0)&(risk<=1)) and np.min(np.diff(risk,axis=1))>=-1e-12
    # Linear interpolation preserves both age and current monotonicity exactly.
    field=interp1d(currents,risk,axis=0,kind='linear',bounds_error=True)
    with (ROOT/'outputs/ablation_summary.csv').open(encoding='utf-8-sig') as f:
        metrics={row['method']:float(row['rul_p50_mae_h']) for row in csv.DictReader(f)}
    svg = E.Element('{'+S+'}svg', {'viewBox':'0 0 2000 800', 'width':'2000', 'height':'800', 'font-family':'Times New Roman'})
    def add(tag, parent=svg, **attrs):
        return E.SubElement(parent, '{'+S+'}'+tag, {k.replace('_','-'):str(v) for k,v in attrs.items()})
    add('title').text = 'Censored constant-current degradation, hidden residence states and first-passage prognosis'
    add('desc').text = 'Abstract-aligned synthesis restricted to constant-stress tests: blue-laser multivariate evidence, burn-in reference, low-stress censoring and high-stress threshold events, Student-t emissions, constrained forward-backward EM, ordered risk set, stress-dependent pre-risk residence and soft state-age filtering. The continuous risk field is 1 minus exported NH-HSMM survival within the tested window; the survival curve is a 4.0 A slice. The three MAE bars are reported leave-one-unit-out duration/stress comparisons, not all benchmarks. Other glyphs are conceptual. No bottom summary lines or sample counts.'
    defs = add('defs')
    for c in [NAVY, GREEN, BLUE, RED, INK, GRAY]:
        m=add('marker',defs,id='a'+c[1:],viewBox='0 0 10 8',refX=10,refY=4,markerWidth=20,markerHeight=16,markerUnits='userSpaceOnUse',orient='auto')
        add('path',m,d='M0 0 L10 4 L0 8 Z',fill=c)
    def text(x,y,s,c=INK,size=40,bold=False,anchor='middle'):
        e=add('text',x=x,y=y,fill=c,font_family='Times New Roman',font_size=size,font_weight=600 if bold else 400,text_anchor=anchor)
        e.text=s
        return e
    def rect(x,y,w,h,c,style=None,fill='none',sw=4):
        attrs=dict(x=x,y=y,width=w,height=h,rx=8,fill=fill,stroke=c,stroke_width=sw)
        if style:attrs['stroke_dasharray']=style
        return add('rect',**attrs)
    def line(x1,y1,x2,y2,c=INK,arrow=False,dash=None,sw=4):
        attrs=dict(x1=x1,y1=y1,x2=x2,y2=y2,stroke=c,stroke_width=sw)
        if arrow:attrs['marker_end']='url(#a'+c[1:]+')'
        if dash:attrs['stroke_dasharray']=dash
        return add('line',**attrs)
    def path(points,c,sw=5):
        return add('path',d='M'+' L'.join(f'{x:.2f} {y:.2f}' for x,y in points),fill='none',stroke=c,stroke_width=sw)
    add('rect',width=2000,height=800,fill=WHITE)
    rect(20,20,510,760,GREEN,'18 7 3 7')
    rect(590,20,710,760,NAVY)
    rect(1360,20,620,760,BLUE,'16 8')
    text(275,82,'Censored ADT',GREEN,50,True)
    text(945,82,'NH-HSMM',NAVY,50,True)
    text(1670,82,'First-passage prediction',BLUE,48,True)
    text(200,144,'Constant stress',GREEN,38)
    # A neutral laser-device glyph represents the monitored test article only.
    rect(140,184,120,75,GREEN,sw=4)
    add('ellipse',cx=260,cy=221,rx=12,ry=30,fill=WHITE,stroke=GREEN,stroke_width=4)
    for x in [164,198,232]:line(x,259,x,287,GREEN,sw=4)
    for dy in [-14,0,14]:line(276,221+dy,316,221+dy,BLUE,sw=3)
    for y,s in [(148,'Optical'),(222,'Electrical'),(296,'Spectral')]:text(407,y,s,size=30)
    for y,values,c in [(180,[0,3,-3,7,-6,2,0,4,0],GREEN),(254,[0,0,0,14,14,4,4,4,4],NAVY),(328,[0,0,2,5,19,5,2,0,0],BLUE)]:
        path([(346+k*15,y-v) for k,v in enumerate(values)],c,3)
    text(200,331,'Blue laser',GREEN,34)
    text(275,390,'Burn-in reference',GREEN,38,True)
    line(154,414,154,470,GRAY,True,sw=3)
    # Endpoint and censoring glyphs remain distinct; censored records never cross L80.
    health_start=len(svg)
    add('rect',x=98,y=371,width=55,height=147,fill=GREEN,fill_opacity=.06)
    line(153,371,153,518,GRAY,dash='5 6',sw=2)
    text(280,344,'Health',size=38)
    line(92,518,470,518,arrow=True)
    line(92,518,92,361,arrow=True)
    line(100,449,460,449,RED,dash='12 8',sw=3)
    text(456,434,'L80',RED,36,anchor='end')
    path([(105,379),(130,392),(153,384),(206,396),(250,410),(295,419),(360,422)],GREEN)
    add('circle',cx=360,cy=422,r=8,fill=WHITE,stroke=GREEN,stroke_width=4)
    path([(105,392),(130,403),(153,384),(192,413),(228,428),(254,439),(278,449)],GREEN)
    add('circle',cx=278,cy=449,r=8,fill=GREEN,stroke=GREEN,stroke_width=3)
    text(465,560,'Age',size=36,anchor='end')
    text(397,394,'Low stress',GREEN,32)
    text(276,493,'High stress',GREEN,32)
    add('circle',cx=68,cy=601,r=8,fill=GREEN,stroke=GREEN,stroke_width=3)
    text(91,612,'Event',size=36,anchor='start')
    add('circle',cx=279,cy=601,r=8,fill=WHITE,stroke=GREEN,stroke_width=3)
    text(302,612,'Censored',size=36,anchor='start')
    health_elements=list(svg)[health_start:]
    # This is a across-condition duration effect; no time-varying current arrow.
    text(935,145,'Student-',NAVY,38,anchor='end')
    e=text(935,145,'t',NAVY,38,anchor='start');e.set('font-style','italic')
    text(956,145,'emissions',NAVY,38,anchor='start')
    # Marginal Student-t glyphs represent the multivariate emission evidence.
    for center,c in [(814,GREEN),(945,NAVY),(1076,BLUE)]:
        path([(x,263-77*(1+((x-center)/35)**2/4)**(-2.5)) for x in range(688,1204,4)],c,3.5)
    text(945,313,'Constrained forward–backward EM',NAVY,36)
    state_start=len(svg)
    rect(977,178,298,140,RED,sw=3.5)
    text(1126,214,'L80 risk set',RED,38,True)
    nodes=[(620,110,'Stable',NAVY),(782,115,'Drift',NAVY),(990,95,'Risk',RED),(1128,136,'Collapse',RED)]
    for x,width,label,c in nodes:
        rect(x,235,width,68,c,sw=3)
        text(x+width/2,280,label,c,32)
    for a,b in [(730,782),(897,990),(1085,1128)]:line(a,269,b,269,NAVY,True)
    state_elements=list(svg)[state_start:]
    # At higher fixed current, schematic pre-risk residence distributions shorten.
    # The two curves illustrate cross-stress acceleration; they are not fitted data.
    lower_model_start=len(svg)
    text(809,376,'Pre-risk residence',GOLD,39,True)
    line(652,562,987,562,arrow=True,sw=3)
    for mu,c,dashed in [(.26,GOLD,False),(.61,GREEN,True)]:
        points=[]
        for k in range(121):
            t=.005+k/120
            # Lognormal densities share a single vertical scale; both integrate to one.
            val=math.exp(-((math.log(t)-math.log(mu))/.36)**2/2)/(t*.36*math.sqrt(2*math.pi))
            peak=math.exp(.36**2/2)/(.26*.36*math.sqrt(2*math.pi))
            points.append((657+309*t,562-121*val/peak))
        e=path(points,c,4)
        if dashed:e.set('stroke-dasharray','12 7')
    text(723,418,'High stress',GOLD,32)
    text(901,445,'Low stress',GREEN,32)
    text(813,607,'Duration',size=36)
    text(1137,376,'Soft filtering',BLUE,39,True)
    # A small explicitly conceptual mass grid depicts a distribution, not a hard state.
    for col in range(4):
        for row in range(5):
            v=math.exp(-((col-1.4)**2+(row-2.4)**2)/2.8)
            channels=[round(255+(b-255)*v) for b in (0,99,208)]
            c='#'+''.join(f'{a:02X}' for a in channels)
            add('rect',x=1068+col*38,y=413+row*29,width=36,height=27,fill=c,stroke=BLUE,stroke_width=.8)
    text(1142,607,'State–age',BLUE,36)
    lower_model_elements=list(svg)[lower_model_start:]
    # Predictive target is first entry into the manuscript's closed risk set.
    text(1525,149,'Stress–age risk',GOLD,38,True)
    text(1818,149,'Survival',GREEN,38,True)
    def color(p):
        stops=[(0,(255,255,255)),(.5,(217,164,65)),(1,(200,62,54))]
        for (a,ca),(b,cb) in zip(stops,stops[1:]):
            if p<=b:
                u=max(0,(p-a)/(b-a))
                return '#'+''.join(f'{round(x+(y-x)*u):02X}' for x,y in zip(ca,cb))
        return RED
    for j in range(160):
        z=1-(j+.5)/160
        current=currents[0]+z*(currents[-1]-currents[0])
        row=np.clip(field(current),0,1)
        grad=add('linearGradient',defs,id=f'risk{j}',x1='0%',y1='0%',x2='100%',y2='0%')
        for t,p in zip(ages,row):
            add('stop',grad,offset=f'{100*(t-ages[0])/(ages[-1]-ages[0]):.4f}%',stop_color=color(float(p)))
        add('rect',x=1440,y=183+j*163/160,width=185,height=min(163/160+1,163-j*163/160),fill=f'url(#risk{j})')
    grad=add('linearGradient',defs,id='risk_key',x1='0%',y1='100%',x2='0%',y2='0%')
    for k in range(41):add('stop',grad,offset=f'{k*2.5}%',stop_color=color(k/40))
    add('rect',x=1640,y=183,width=12,height=163,fill='url(#risk_key)')
    text(1665,207,'1',size=30,anchor='start');text(1665,346,'0',size=30,anchor='start')
    line(1436,351,1633,351,arrow=True,sw=3)
    line(1436,351,1436,171,arrow=True,sw=3)
    text(1534,391,'Age',size=34)
    e=text(1408,268,'Stress',size=34);e.set('transform','rotate(-90 1408 268)')
    line(1720,351,1950,351,arrow=True,sw=3)
    line(1720,351,1720,171,arrow=True,sw=3)
    path([(1725+207*(t-ages[0])/(ages[-1]-ages[0]),351-158*lookup[4.0,t]) for t in ages],GREEN,4)
    text(1830,391,'Age',size=34)
    text(1670,455,'Condition-updated RUL',BLUE,40,True)
    line(1460,555,1920,555,arrow=True,sw=3)
    line(1460,555,1460,475,arrow=True,sw=3)
    curve=[]
    for k in range(101):
        t=k/100
        d=(t**2)*math.exp(-9*t)
        curve.append((1466+432*t,555-66*d/((2/9)**2*math.exp(-2))))
    path(curve,BLUE)
    text(1690,595,'Remaining life',size=32)
    text(1635,635,'Leave-one-unit-out',BLUE,32,True)
    text(1898,635,'MAE (h)',size=30)
    # Selected duration/stress ablations from the abstract, plotted on one scale.
    for y,label,key,c in [(681,'NH-HSMM','NH_HSMM',BLUE),(718,'HMM','no_explicit_duration_HMM_ablation',GRAY),(755,'HSMM (α=0)','homogeneous_HSMM_ablation',GRAY)]:
        value=metrics[key]
        if key=='homogeneous_HSMM_ablation':
            text(1538,y,'HSMM (',c,32,anchor='end')
            e=text(1538,y,'α',c,32,anchor='start');e.set('font-style','italic')
            text(1558,y,'=0)',c,32,anchor='start')
        else:text(1620,y,label,c,32,anchor='end')
        add('rect',x=1640,y=y-22,width=value*2,height=20,fill=c)
        text(1652+value*2,y,f'{value:.1f}',c,30,anchor='start')
    line(530,220,590,220,NAVY,True,sw=5)
    line(1300,575,1360,575,NAVY,True,sw=5)
    for elements,dy in [(health_elements,100),(state_elements,165),(lower_model_elements,160)]:
        group=add('g',transform=f'translate(0 {dy})')
        for element in elements:svg.remove(element);group.append(element)
    target=ROOT/'figures/Graphical_Abstract.svg'
    target.write_bytes(E.tostring(svg,encoding='utf-8'))
    # Cairo retains the cloud's native PDF gradient instead of rasterizing strips.
    import cairosvg
    from PIL import Image
    cairosvg.svg2pdf(url=str(target),write_to=str(target.with_suffix('.pdf')),output_width=640,output_height=256)
    cairosvg.svg2png(url=str(target),write_to=str(target.with_suffix('.png')),output_width=4000,output_height=1600)
    with Image.open(target.with_suffix('.png')) as im:
        im.save(target.with_suffix('.png'),dpi=(600,600))

if __name__=='__main__':
    main()

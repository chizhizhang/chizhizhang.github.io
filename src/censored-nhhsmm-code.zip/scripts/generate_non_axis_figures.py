"""Build the final Figures 01–03 as editable SVG and matching PDF/PNG.

The adjacent non_axis_design.json holds native vector objects, including editable
text, geometry, line styles and continuous scalar fields. No prior exported SVG,
manuscript file, archived script or analysis module is used as an input.
"""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SVG = 'http://www.w3.org/2000/svg'
ET.register_namespace('', SVG)


def build_node(spec, fonts):
    element = ET.Element('{' + SVG + '}' + spec['tag'], spec.get('attrs', {}))
    element.text = fonts[spec['font_style']] if 'font_style' in spec else spec.get('text')
    element.tail = spec.get('tail')
    for child in spec.get('children', []):
        element.append(build_node(child, fonts))
    return element


def check_design(root):
    frames = {e.get('id'): e for e in root.iter() if e.get('id', '').startswith('panel-')}
    for text in root.iter('{' + SVG + '}text'):
        if text.get('data-panel'):
            assert text.get('fill') == frames[text.get('data-panel')].get('stroke')
    assert not list(root.iter('{' + SVG + '}image')), 'Native SVG must not embed raster images'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figure-dir', type=Path, default=ROOT / 'figures')
    parser.add_argument('--svg-only', action='store_true', help='Build native SVG without Node/Chromium export')
    args = parser.parse_args()
    design = json.loads(Path(__file__).with_name('non_axis_design.json').read_text(encoding='utf-8'))
    if design['schema_version'] != 1:
        raise ValueError('Unsupported non-axis design schema')
    args.figure_dir.mkdir(parents=True, exist_ok=True)
    for name, spec in design['figures'].items():
        root = build_node(spec, design['font_styles'])
        check_design(root)
        source = args.figure_dir / (name + '.svg')
        source.write_bytes(ET.tostring(root, encoding='utf-8'))
        print('Generated ' + name + ' SVG')
    if not args.svg_only:
        node = shutil.which('node')
        if node is None:
            raise RuntimeError('Node.js and Playwright are required for PDF/PNG export; SVG files are ready.')
        subprocess.run([node, str(Path(__file__).with_name('export_non_axis_figures.js')),
                        str(args.figure_dir.resolve())], check=True)
        from PIL import Image
        for name in design['figures']:
            path = args.figure_dir / (name + '.png')
            with Image.open(path) as im:
                im.save(path, dpi=(600, 600))


if __name__ == '__main__':
    main()

# Reproduction workflow

Install `pip install -r scripts/requirements.txt` and run from the project root.

## Manuscript analysis

With authorized access to the restricted life-test CSV files under `data/`:

    python -B scripts/main_analysis.py --quiet
    python -B scripts/generate_figures.py

The analysis writes numerical results and all plotting inputs to `outputs/`. The separate plotting process reads those exports and generates Figures 04–17 in `figures/`, with split panels 12a/12b and 14a/14b. It does not import the analysis, estimate parameters, bootstrap statistics or simulate risk surfaces. Both scripts are standalone and independent of manuscript and submission files. Figures are supplied as PNG, PDF and editable SVG.

## Implemented estimator

Endpoint-constrained generalized EM jointly estimates Student-t emission locations, feature scales and state-specific degrees of freedom, together with hourly-grid lognormal residence locations, scales and current acceleration. Scaled forward–backward inference supplies posterior state weights, expected completed-duration counts and terminal-age weights. The terminal survivor is evaluated at observed elapsed age, with no additional unobserved hour. The fourth state is absorbing and has an emission density but no fitted exit-time distribution.

Health/rate assignments initialize EM only. Viterbi paths are decoded after fitting for interpretation. Held-out filtering uses all seven feature channels reconstructed from raw readings available by the origin, with training-only normalization and parameters. RUL simulation samples the joint state–residence-age posterior and then conditional residual and subsequent pre-risk durations. The 5000 samples per origin are capped at 1200 h; survival IAE uses a 600 h horizon. Intervals include state-age and residence variability conditional on fitted parameters, not a full parameter posterior.

The geometric-duration HMM, stress-independent HSMM and shared-acceleration HSMM are independently re-estimated on the same training folds. The geometric model includes fitted multistate Student-t emissions. Endpoint Weibull AFT uses its analytic conditional residual distribution. Failed numerical recursions raise errors, and full-data fits are not substituted for held-out training fits.

The real-data primary results are NH-HSMM MAE 42.8 h, P10–P90 coverage 0.812 and survival IAE 0.133. Geometric HMM, stress-independent HSMM, shared-acceleration HSMM and endpoint Weibull AFT MAEs are 55.9, 119.4, 46.0 and 61.3 h, respectively. The prespecified four-state model is retained; the five-state sensitivity model gives 38.0 h and is not used to select the primary fit. All 95 real-data fits meet the reported EM stopping criterion.

NH-HSMM has the manuscript's restricted constant-stress meaning: residence laws vary across assigned currents, and the augmented process is time-homogeneous conditional on current. The legacy internal identifier `selected_5_state` counts the fixed reference phase in its name; the fitted primary model has four latent degradation states. Likewise, `homogeneous_HSMM_ablation` denotes the independently refitted stress-independent model, and `no_explicit_duration_HMM_ablation` denotes the fitted geometric HMM.

## Public pseudo-data

The pseudo-data test execution and formats; they do not reproduce the restricted-data estimates. Use separate destinations:

    python -B scripts/main_analysis.py --data-dir data/pseudo_data/life_tests --out-dir achieve/pseudo_check --pseudo-data --skip-sensitivity --quiet
    python -B scripts/generate_figures.py --input-dir achieve/pseudo_check --figure-dir achieve/pseudo_figures

Omit `--skip-sensitivity` to include topology and initialization fits. Restricted raw measurements are excluded from the upload; derived real-data results and public pseudo-data are included.

## Inspectable estimation and prediction exports

- `soft_fit_diagnostics.csv`: fit identity, mode, topology initializer, seed, training-unit membership, every observed log-likelihood and convergence status.
- `soft_fitted_models.json`: all fitted normalization, emission and residence parameters, training identities and likelihood traces.
- `soft_emission_parameters.csv`: full-data fitted state/channel emissions and training standardization.
- `soft_smoothed_state_probabilities.csv`: endpoint-constrained training state probabilities.
- `soft_origin_state_age_mass.npz` and `soft_origin_mass_index.csv`: origin joint posterior arrays and their unit/age/method keys.
- `soft_origin_posteriors.csv`: state marginals, entropy, maximum joint mass and expected residence age.
- `rul_predictions.csv`, `ablation_summary.csv`, `stress_transfer_summary.csv` and `model_sensitivity_summary.csv`: scored predictions and comparisons.
- `soft_implementation_audit.json`: independent path-enumeration checks, restored-fit prediction checks, normalized posterior checks and future-observation perturbation results.

The origin export also includes sensitivity and stress-transfer predictions. The 16 primary origins are identified by method `NH_HSMM`; a concentrated state marginal does not imply a point-mass residence age.

## Plotting-data contract

The main script exports `plot_segments.csv`, bootstrap summaries, feature-ellipse geometry, Kaplan–Meier estimates, occupancy proportions, simulated current-age risk arrays, fitted boundaries and residence curves. `plot_data_manifest.json` identifies required inputs and hashes their source tables. Missing or stale exports cause the plotting process to fail. Presentation-only operations include filtering, ordering, reshaping, interpolation of displayed curves and coordinate transformations.

Figures 01–03 are generated only by `generate_non_axis_figures.py` from the final native vector objects in `non_axis_design.json`. The design includes editable text, paths, frame/title colors, dash styles and continuous fields; it does not read an old SVG or any archived generator. The fixed reference remains distinct from the four fitted states. The numerical plotting script generates Figures 04–17 only and does not overwrite these diagrams.

    python -B scripts/generate_non_axis_figures.py --svg-only

For matching PDF and 3840 × 2160 PNG exports, install the rendering dependency with `npm install --prefix scripts`, then run `python -B scripts/generate_non_axis_figures.py`. `export_non_axis_figures.js` renders the SVG in headless Chromium so embedded mathematical fonts and subscripts remain intact. An installed Chrome or Edge is detected on Windows; otherwise install the Playwright Chromium browser with `npx --prefix scripts playwright install chromium`. `BROWSER_EXECUTABLE` can specify another Chromium executable. All output files default to `figures/`; `--figure-dir` selects another destination for Figures 01–03.

The saved origin posterior arrays provide the numerical state-age distributions. Figure 11 contrasts the full-data acceleration estimates with leave-one-unit training estimates; those dots are sensitivity estimates, not confidence intervals. The legacy decoded-segment acceleration bootstrap export is a descriptive auxiliary result and is not used as uncertainty for soft EM parameters.

The graphical abstract is independently reproducible with `python -B scripts/generate_graphical_abstract.py`. It reads the exported reliability curves and comparison metrics, then writes editable SVG, vector PDF and PNG files. Its risk field and matching survival curve use those results; other small illustrations are schematic. Export requires CairoSVG and its native Cairo library; on Windows, Cairo must be available to the Python runtime. Existing final exports are supplied for use without regeneration.

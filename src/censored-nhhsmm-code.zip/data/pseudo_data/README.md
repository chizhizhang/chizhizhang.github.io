# Pseudo Data Package

These CSV files are fully derived pseudo records. The real life-test files are
first interpolated onto a 0:0.5:500 h grid; each public pseudo record is
then generated from multiple real records in the same current class. No output
file is a direct interpolation or copy of one real record.

The 3.0 A group has four source records, so all five 3.0 A pseudo records are
mixed from those four sources. The 3.5 A, 4.0 A, and 4.5 A groups each use five
source records. State-anchored degradation envelopes are applied to retain
within-current variation in stable, drift, L80-risk, and collapse residence
segments while keeping 4.5 A as the more severe stress class. Event indicators
are reported for the 95%, 90%, 80%, 50%, and 5% normalized-power thresholds.
The 80%, 50%, and 5% event counts follow the original real event structure.
The shallow 95% and 90% counts are constrained with a monotone current envelope
so a lower-current class does not show more 90% events than a higher-current
class in the public pseudo set.

Numeric values are rounded only to practical measurement precision:
`Duration_h` 1 decimal, `Current_A` 2 decimals, `Voltage_V` 2 decimals, `P` 3
decimals, `Lambda_nm` 1 decimal, and `BW_nm` 2 decimals. Trailing zeros are
not written. The auxiliary electrical and spectral columns are not generated
from fitted drift formulas. They are weighted mixtures of same-current real
records: before L95 they follow the same-time real traces, and after L95 they
are selected from real records by matching the pseudo normalized-power state;
after T05 they continue along the real failure-tail segment.

# Prefix Treatment and Bayesian Partial Pooling for Early-Stage Lifetime Prediction

Analysis and figure code accompanying the accepted JDMD manuscript.

Install with `python -m pip install -r requirements.txt`, then run from the extracted root:

    python scripts/final_laser_figures.py
    python scripts/final_battery_figures.py

Input files required by the original code:
- data/laser/gaas_laser_degradation.csv with device, operating_time_h and degradation_metric_pct columns.
- data/oxford/Oxford_Battery_Degradation_Dataset_1.mat, or the prepared data/oxford/oxford_capacity_trajectories.csv.

This is a code-only release. The input datasets are not redistributed in this archive.
Use the original study data sources or obtain the study inputs from the corresponding author.
The scripts generate their numerical exports under output/ and figure assets under figures/.
No review correspondence, manuscript files or private source measurements are included.

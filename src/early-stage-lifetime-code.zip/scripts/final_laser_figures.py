from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import curve_fit
from scipy.stats import bartlett, fisk, gamma, kstest, levene, lognorm, nakagami, norm, probplot, rayleigh, rice, weibull_min
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import HuberRegressor, RidgeCV
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "output"
FIGURE_DIR = ROOT / "figures"
DATA_DIR = ROOT / "data" / "laser"
LASER_DATA_PATH = DATA_DIR / "gaas_laser_degradation.csv"


def load_laser_degradation_data():
    df = pd.read_csv(LASER_DATA_PATH)
    expected = {"device", "operating_time_h", "degradation_metric_pct"}
    missing = expected.difference(df.columns)
    if missing:
        raise ValueError(f"{LASER_DATA_PATH} is missing columns: {sorted(missing)}")
    table = (
        df.pivot_table(
            index="device",
            columns="operating_time_h",
            values="degradation_metric_pct",
            aggfunc="first",
        )
        .sort_index(axis=0)
        .sort_index(axis=1)
    )
    if table.isna().any().any():
        raise ValueError(f"{LASER_DATA_PATH} contains an incomplete device-time grid")
    return table.columns.to_numpy(dtype=float), table.to_numpy(dtype=float)


TIME_HOURS, DEVICE_DATA = load_laser_degradation_data()

FAILURE_THRESHOLD = 10.0
INITIAL_COUNT = 6
LIFETIME_CAP = 20000.0
PREFIX_COUNTS = [4, 5, 6, 7, 8]
FIG_DPI = 300
FIG_SIZE = (6.4, 3.6)
PAPER_COLOR = "#FFFFFF"
INK_COLOR = "#000000"
BLUE = "#0063D0"
SKY = "#0152AB"
NAVY = "#172C6F"
GREEN = "#278575"
SAND = "#F8E3B3"
GOLD = "#D9A441"
RED = "#C83E36"
GRAY = "#7A7A7A"
LIGHT_GRAY = "#D8D8D8"

ACCENT_COLOR = BLUE
AUX_COLOR_1 = GREEN
AUX_COLOR_2 = GOLD
AUX_COLOR_3 = NAVY
BASELINE_COLOR = GRAY
GRID_COLOR = LIGHT_GRAY

METHOD_STYLES = {
    "Early global fit": {"color": AUX_COLOR_2, "linestyle": "--", "marker": "s", "hatch": "//"},
    "Window median": {"color": AUX_COLOR_1, "linestyle": "-.", "marker": "^", "hatch": "\\\\"},
    "Initial-emphasis (mild)": {"color": AUX_COLOR_3, "linestyle": ":", "marker": "D", "hatch": "xx"},
    "Initial-emphasis (strong)": {"color": BASELINE_COLOR, "linestyle": (0, (5, 2)), "marker": "v", "hatch": "--"},
    "Bayesian partial pooling": {"color": ACCENT_COLOR, "linestyle": "-", "marker": "o", "hatch": ""},
    "Huber feature baseline": {"color": BASELINE_COLOR, "linestyle": (0, (3, 1)), "marker": "P", "hatch": "++"},
    "Ridge feature baseline": {"color": BASELINE_COLOR, "linestyle": (0, (1, 1)), "marker": "X", "hatch": ".."},
    "SVR feature baseline": {"color": BASELINE_COLOR, "linestyle": (0, (7, 2)), "marker": "<", "hatch": "oo"},
    "RF feature baseline": {"color": BASELINE_COLOR, "linestyle": (0, (4, 1, 1, 1)), "marker": ">", "hatch": "\\\\//"},
    "Random-effects power-law": {"color": NAVY, "linestyle": (0, (2, 2)), "marker": "h", "hatch": "++"},
}

def power_model(time_value, mu, nu):
    return mu * np.power(time_value, nu)


def solve_mu_nu(t1, t2, d1, d2):
    nu = np.log(d2 / d1) / np.log(t2 / t1)
    mu = d1 / (t1**nu)
    return mu, nu


def pseudo_lifetime(mu, nu, threshold=FAILURE_THRESHOLD, cap=LIFETIME_CAP):
    value = np.power(threshold / mu, 1.0 / nu)
    return float(np.clip(value, 0.0, cap))


def fit_power_params(time_points, values):
    bounds = ([1e-9, 0.05], [1.0, 5.0])
    params, _ = curve_fit(
        power_model,
        time_points,
        values,
        p0=(1e-5, 1.0),
        bounds=bounds,
        maxfev=20000,
    )
    return float(params[0]), float(params[1])


def fit_power_params_with_cov(time_points, values):
    bounds = ([1e-9, 0.05], [1.0, 5.0])
    params, covariance = curve_fit(
        power_model,
        time_points,
        values,
        p0=(1e-5, 1.0),
        bounds=bounds,
        maxfev=20000,
    )
    return np.asarray(params, dtype=float), np.asarray(covariance, dtype=float)


def fit_power_lifetime(time_points, values):
    mu, nu = fit_power_params(time_points, values)
    return pseudo_lifetime(mu, nu)


def prefix_window_estimates(time_points, values, limit):
    estimates = []
    for idx in range(limit - 1):
        t1, t2 = time_points[idx], time_points[idx + 1]
        d1, d2 = values[idx], values[idx + 1]
        mu, nu = solve_mu_nu(t1, t2, d1, d2)
        estimates.append(pseudo_lifetime(mu, nu))
    return np.asarray(estimates, dtype=float)


def prefix_weights(length, strength):
    index = np.arange(length, dtype=float)
    raw = np.exp(-strength * index)
    return raw / raw.sum()


def empirical_bayes_pool(window_df):
    log_value = np.log(window_df["window_lifetime"].to_numpy())
    centered = window_df.assign(log_value=log_value)
    grouped = centered.groupby("device")["log_value"]
    device_mean = grouped.mean()
    within_var = grouped.var(ddof=1).fillna(0.0)
    pooled_mean = float(device_mean.mean())
    sigma2 = float(np.maximum(within_var.mean(), 1e-3))
    between = float(np.var(device_mean, ddof=1)) if len(device_mean) > 1 else sigma2
    tau2 = float(np.maximum(between - sigma2 / grouped.size().mean(), 1e-3))

    posterior_rows = []
    for device, values in grouped:
        values = values.to_numpy()
        n_obs = len(values)
        obs_mean = float(values.mean())
        posterior_var = 1.0 / (n_obs / sigma2 + 1.0 / tau2)
        posterior_mean = posterior_var * (n_obs * obs_mean / sigma2 + pooled_mean / tau2)
        posterior_rows.append(
            {
                "device": device,
                "posterior_log_mean": posterior_mean,
                "posterior_log_sd": np.sqrt(posterior_var),
                "posterior_lifetime": float(np.clip(np.exp(posterior_mean), 0.0, LIFETIME_CAP)),
            }
        )

    return pd.DataFrame(posterior_rows), {"pooled_log_mean": pooled_mean, "sigma2": sigma2, "tau2": tau2}


def early_feature_matrix(initial_count=INITIAL_COUNT):
    rows = []
    early_times = TIME_HOURS[:initial_count]
    for values in DEVICE_DATA:
        prefix = values[:initial_count]
        features = []
        features.extend(prefix.tolist())
        features.extend(np.diff(prefix).tolist())
        features.append(float(prefix[-1] - prefix[0]))
        features.append(float((prefix[-1] - prefix[0]) / (early_times[-1] - early_times[0])))
        features.extend(np.polyfit(early_times, prefix, 1).tolist())
        features.extend(np.polyfit(early_times, prefix, 2).tolist())
        try:
            mu, nu = fit_power_params(early_times, prefix)
            features.extend([mu, nu, pseudo_lifetime(mu, nu)])
        except Exception:
            features.extend([np.nan, np.nan, np.nan])
        rows.append(features)
    return np.asarray(rows, dtype=float)


def direct_feature_baseline_predictions(reference_df, initial_count=INITIAL_COUNT):
    x = early_feature_matrix(initial_count)
    y = reference_df.sort_values("device")["reference_lifetime"].to_numpy(dtype=float)
    devices = reference_df.sort_values("device")["device"].to_numpy(dtype=int)
    loo = LeaveOneOut()
    models = {
        "Huber feature baseline": make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            HuberRegressor(alpha=0.01, epsilon=1.35, max_iter=1000),
        ),
        "Ridge feature baseline": make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            RidgeCV(alphas=np.logspace(-2, 4, 50)),
        ),
        "SVR feature baseline": make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            SVR(C=1000, gamma="scale", epsilon=100),
        ),
        "RF feature baseline": RandomForestRegressor(n_estimators=500, min_samples_leaf=2, random_state=7),
    }

    rows = []
    for method, model in models.items():
        predicted = np.clip(cross_val_predict(model, x, y, cv=loo), 0.0, LIFETIME_CAP)
        for device, reference, estimate in zip(devices, y, predicted):
            rows.append(
                {
                    "device": int(device),
                    "method": method,
                    "reference_lifetime": float(reference),
                    "predicted_lifetime": float(estimate),
                    "abs_error": float(abs(estimate - reference)),
                    "signed_error": float(estimate - reference),
                    "relative_error_pct": float(100.0 * (estimate - reference) / reference),
                }
            )
    return rows


def random_effects_power_law_predictions(reference_df, initial_count=INITIAL_COUNT):
    early_times = TIME_HOURS[:initial_count]
    lifetime_rows = []
    window_log_rows = []
    for device_id, values in enumerate(DEVICE_DATA, start=1):
        early_lifetime = fit_power_lifetime(early_times, values[:initial_count])
        lifetime_rows.append(
            {
                "device": device_id,
                "early_power_lifetime": early_lifetime,
                "log_lifetime": float(np.log(early_lifetime)),
            }
        )
        for window_lifetime in prefix_window_estimates(TIME_HOURS, values, initial_count):
            window_log_rows.append({"device": device_id, "log_window_lifetime": float(np.log(window_lifetime))})

    lifetime_df = pd.DataFrame(lifetime_rows)
    window_log_df = pd.DataFrame(window_log_rows)
    within_var = float(np.maximum(window_log_df.groupby("device")["log_window_lifetime"].var(ddof=1).mean(), 1e-3))
    pooled_mean = float(lifetime_df["log_lifetime"].mean())
    between_var = float(np.maximum(lifetime_df["log_lifetime"].var(ddof=1) - within_var, 1e-3))
    reliability = between_var / (between_var + within_var)
    lifetime_df["shrunk_log_lifetime"] = pooled_mean + reliability * (lifetime_df["log_lifetime"] - pooled_mean)
    lifetime_df["predicted_lifetime"] = np.exp(lifetime_df["shrunk_log_lifetime"])

    prediction_rows = []
    reference_lookup = reference_df.set_index("device")["reference_lifetime"].to_dict()
    for _, row in lifetime_df.iterrows():
        estimate = float(np.clip(row["predicted_lifetime"], 0.0, LIFETIME_CAP))
        reference = float(reference_lookup[int(row["device"])])
        prediction_rows.append(
            {
                "device": int(row["device"]),
                "method": "Random-effects power-law",
                "reference_lifetime": reference,
                "predicted_lifetime": estimate,
                "abs_error": abs(estimate - reference),
                "signed_error": estimate - reference,
                "relative_error_pct": 100.0 * (estimate - reference) / reference,
                "log_lifetime_reliability": float(reliability),
                "within_log_variance": within_var,
                "between_log_variance": between_var,
            }
        )
    return pd.DataFrame(prediction_rows)


def build_prediction_tables(initial_count=INITIAL_COUNT):
    full_rows = []
    early_rows = []
    window_rows = []

    early_times = TIME_HOURS[:initial_count]

    for device_id, values in enumerate(DEVICE_DATA, start=1):
        full_rows.append(
            {
                "device": device_id,
                "reference_lifetime": fit_power_lifetime(TIME_HOURS, values),
            }
        )
        early_rows.append(
            {
                "device": device_id,
                "early_global": fit_power_lifetime(early_times, values[:initial_count]),
            }
        )
        windows = prefix_window_estimates(TIME_HOURS, values, initial_count)
        for window_id, estimate in enumerate(windows, start=1):
            window_rows.append(
                {
                    "device": device_id,
                    "window_id": window_id,
                    "window_lifetime": estimate,
                }
            )

    reference_df = pd.DataFrame(full_rows)
    early_df = pd.DataFrame(early_rows)
    window_df = pd.DataFrame(window_rows)

    weights_mild = prefix_weights(initial_count - 1, strength=0.55)
    weights_strong = prefix_weights(initial_count - 1, strength=0.95)

    weighted_rows = []
    for device, chunk in window_df.groupby("device"):
        values = chunk["window_lifetime"].to_numpy()
        weighted_rows.append(
            {
                "device": device,
                "window_median": float(np.median(values)),
                "ioe_mild": float(np.dot(weights_mild, values)),
                "ioe_strong": float(np.dot(weights_strong, values)),
            }
        )

    weighted_df = pd.DataFrame(weighted_rows)
    pooled_df, hyper = empirical_bayes_pool(window_df)

    prediction_df = (
        reference_df.merge(early_df, on="device")
        .merge(weighted_df, on="device")
        .merge(pooled_df[["device", "posterior_lifetime"]], on="device")
    )
    prediction_df.rename(columns={"posterior_lifetime": "pooled_bayes"}, inplace=True)

    method_map = {
        "early_global": "Early global fit",
        "window_median": "Window median",
        "ioe_mild": "Initial-emphasis (mild)",
        "ioe_strong": "Initial-emphasis (strong)",
        "pooled_bayes": "Bayesian partial pooling",
    }

    long_rows = []
    for _, row in prediction_df.iterrows():
        reference = row["reference_lifetime"]
        for column, label in method_map.items():
            estimate = row[column]
            long_rows.append(
                {
                    "device": int(row["device"]),
                    "method": label,
                    "reference_lifetime": reference,
                    "predicted_lifetime": estimate,
                    "abs_error": abs(estimate - reference),
                    "signed_error": estimate - reference,
                    "relative_error_pct": 100.0 * (estimate - reference) / reference,
                }
            )

    long_rows.extend(direct_feature_baseline_predictions(reference_df, initial_count))

    summary_df = (
        pd.DataFrame(long_rows)
        .groupby("method", as_index=False)
        .agg(
            mean_abs_error=("abs_error", "mean"),
            rmse=("signed_error", lambda x: float(np.sqrt(np.mean(np.square(x))))),
            median_abs_error=("abs_error", "median"),
            mean_signed_error=("signed_error", "mean"),
            over_prediction_rate=("signed_error", lambda x: float(100.0 * np.mean(np.asarray(x) > 0))),
            mean_relative_error_pct=("relative_error_pct", "mean"),
        )
        .sort_values("mean_abs_error")
    )

    return prediction_df, window_df, pd.DataFrame(long_rows), summary_df, weights_mild, weights_strong, hyper


def summarize_random_effects(random_effects_df):
    errors = random_effects_df["abs_error"].to_numpy(dtype=float)
    signed = random_effects_df["signed_error"].to_numpy(dtype=float)
    relative = random_effects_df["relative_error_pct"].to_numpy(dtype=float)
    return pd.DataFrame(
        [
            {
                "method": "Random-effects power-law",
                "mean_abs_error": float(errors.mean()),
                "rmse": float(np.sqrt(np.mean(np.square(signed)))),
                "median_abs_error": float(np.median(errors)),
                "mean_signed_error": float(signed.mean()),
                "over_prediction_rate": float(100.0 * np.mean(signed > 0)),
                "mean_relative_error_pct": float(relative.mean()),
            }
        ]
    )


def posterior_interval_table(prediction_df, window_df):
    posterior_df, _ = empirical_bayes_pool(window_df)
    interval_base = prediction_df[["device", "reference_lifetime"]].merge(posterior_df, on="device")
    rows = []
    for _, row in interval_base.iterrows():
        for level, z_value in [(90, norm.ppf(0.95)), (95, norm.ppf(0.975))]:
            lower = float(np.exp(row["posterior_log_mean"] - z_value * row["posterior_log_sd"]))
            upper = float(np.exp(row["posterior_log_mean"] + z_value * row["posterior_log_sd"]))
            rows.append(
                {
                    "device": int(row["device"]),
                    "interval_level": level,
                    "posterior_median": float(np.exp(row["posterior_log_mean"])),
                    "lower": lower,
                    "upper": upper,
                    "reference_lifetime": float(row["reference_lifetime"]),
                    "covered": bool(lower <= row["reference_lifetime"] <= upper),
                    "interval_width": upper - lower,
                }
            )
    return pd.DataFrame(rows)


def interval_summary(interval_df):
    rows = []
    for level, chunk in interval_df.groupby("interval_level"):
        rows.append(
            {
                "interval_level": int(level),
                "covered": int(chunk["covered"].sum()),
                "n": int(len(chunk)),
                "empirical_coverage_pct": float(100.0 * chunk["covered"].mean()),
                "median_width_h": float(chunk["interval_width"].median()),
            }
        )
    return pd.DataFrame(rows).sort_values("interval_level")


def hyperparameter_sensitivity_table(window_df):
    rows = []
    for dropped_device in sorted(window_df["device"].unique()):
        loo_window = window_df[window_df["device"] != dropped_device]
        _, hyper = empirical_bayes_pool(loo_window)
        window_count = float(loo_window.groupby("device").size().mean())
        population_weight = hyper["sigma2"] / (window_count * hyper["tau2"] + hyper["sigma2"])
        rows.append(
            {
                "dropped_device": int(dropped_device),
                "pooled_log_mean": hyper["pooled_log_mean"],
                "sigma2": hyper["sigma2"],
                "tau2": hyper["tau2"],
                "population_shrinkage_weight": population_weight,
            }
        )
    return pd.DataFrame(rows)


def residual_diagnostics(window_df):
    posterior_df, _ = empirical_bayes_pool(window_df)
    diagnostic_df = window_df.merge(posterior_df[["device", "posterior_log_mean"]], on="device")
    diagnostic_df["log_window_lifetime"] = np.log(diagnostic_df["window_lifetime"])
    diagnostic_df["residual"] = diagnostic_df["log_window_lifetime"] - diagnostic_df["posterior_log_mean"]
    grouped = [chunk["residual"].to_numpy(dtype=float) for _, chunk in diagnostic_df.groupby("window_id")]
    bartlett_stat, bartlett_p = bartlett(*grouped)
    levene_stat, levene_p = levene(*grouped, center="median")
    summary = pd.DataFrame(
        [
            {
                "residual_mean": float(diagnostic_df["residual"].mean()),
                "residual_sd": float(diagnostic_df["residual"].std(ddof=1)),
                "bartlett_stat": float(bartlett_stat),
                "bartlett_p": float(bartlett_p),
                "levene_stat": float(levene_stat),
                "levene_p": float(levene_p),
            }
        ]
    )
    return diagnostic_df, summary


def configure_style():
    sns.set_theme(style="white")
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "STIX Two Text", "STIXGeneral", "DejaVu Serif"],
            "mathtext.fontset": "stix",
            "font.size": 11,
            "axes.titlesize": 11,
            "axes.labelsize": 12,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
            "figure.facecolor": PAPER_COLOR,
            "axes.facecolor": PAPER_COLOR,
            "axes.edgecolor": INK_COLOR,
            "axes.linewidth": 0.9,
            "grid.color": GRID_COLOR,
            "grid.linewidth": 0.55,
            "grid.alpha": 0.7,
            "lines.linewidth": 1.6,
            "xtick.direction": "in",
            "ytick.direction": "in",
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
            "xtick.major.size": 4.0,
            "ytick.major.size": 4.0,
            "axes.spines.top": True,
            "axes.spines.right": True,
            "savefig.facecolor": PAPER_COLOR,
            "savefig.dpi": FIG_DPI,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "hatch.linewidth": 0.6,
        }
    )


def apply_journal_axes(ax, grid_axis="y"):
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.9)
        spine.set_color(INK_COLOR)
    ax.tick_params(axis="both", which="major", direction="in", top=True, right=True, width=0.8, length=4.0)
    ax.tick_params(axis="both", which="minor", direction="in", top=True, right=True, width=0.6, length=2.5)
    ax.grid(False)
    if grid_axis in {"x", "y", "both"}:
        ax.grid(True, axis=grid_axis, color=GRID_COLOR, linewidth=0.55, alpha=0.75)
    ax.set_facecolor(PAPER_COLOR)


def apply_journal_legend(ax, **kwargs):
    legend = ax.legend(frameon=False, facecolor="none", framealpha=0.0, **kwargs)
    if legend is not None:
        legend.get_frame().set_linewidth(0.0)
        legend.get_frame().set_facecolor("none")
        legend.get_frame().set_alpha(0.0)
    return legend


def save_journal_figure(fig, stem):
    for ext in ("png", "pdf"):
        fig.savefig(FIGURE_DIR / f"{stem}.{ext}", dpi=FIG_DPI, facecolor=PAPER_COLOR)


def clear_generated_figures():
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    stems = [
        "fig01_early_stage_degradation_setting",
        "fig02_local_window_instability",
        "fig03_initial_window_weight_profiles",
        "fig04_bayesian_shrinkage_mechanism",
        "fig05_prediction_distribution_by_method",
        "fig06_absolute_error_distribution",
        "fig07_mae_ranking_bootstrap_ci",
        "fig08_prefix_length_sensitivity",
        "fig09_representative_device_prediction_behavior",
        "fig10_random_effects_baseline_comparison",
        "fig11_bpp_posterior_intervals",
        "fig12_residual_diagnostics",
        "supp_fig01_power_model_comparison",
        "supp_fig02_reference_lifetime_distribution",
        "supp_fig03_log_reference_qq",
        "fig01_power_model_comparison",
        "fig02_reference_lifetime_distribution",
        "fig03_log_reference_qq",
        "fig04_early_stage_degradation_setting",
        "fig05_initial_window_weight_profiles",
        "fig06_local_window_instability",
        "fig07_bayesian_shrinkage_mechanism",
        "fig08_prediction_distribution_by_method",
        "fig09_absolute_error_distribution",
        "fig10_mae_ranking_bootstrap_ci",
        "fig11_prefix_length_sensitivity",
        "fig12_representative_short_life_device",
        "fig13_representative_median_life_device",
        "fig14_representative_long_life_device",
    ]
    for stem in stems:
        for ext in ("png", "pdf"):
            path = FIGURE_DIR / f"{stem}.{ext}"
            if path.exists():
                path.unlink()


def bootstrap_mean_ci(values, n_boot=5000, seed=20260509):
    rng = np.random.default_rng(seed)
    values = np.asarray(values, dtype=float)
    if len(values) == 0:
        return np.nan, np.nan
    draws = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    return tuple(np.percentile(draws, [2.5, 97.5]))


def compute_fit_metrics(observed, predicted, parameter_count):
    residual = observed - predicted
    rss = float(np.sum(residual**2))
    n_obs = len(observed)
    aic = n_obs * np.log(rss / n_obs) + 2 * parameter_count
    bic = n_obs * np.log(rss / n_obs) + parameter_count * np.log(n_obs)
    rmse = float(np.sqrt(rss / n_obs))
    return aic, bic, rmse


def linear_trend(time_value, gamma_value):
    return gamma_value * time_value


def quadratic_trend(time_value, gamma_value, delta_value):
    return gamma_value * time_value + delta_value * np.square(time_value)


def exponential_trend(time_value, alpha_value, beta_value):
    return alpha_value * (np.exp(beta_value * time_value) - 1.0)


def logarithmic_trend(time_value, eta_value, delta_value):
    return eta_value * np.log1p(delta_value * time_value)


def candidate_trend_specs():
    return {
        "Linear": {
            "fn": linear_trend,
            "p0": (0.002,),
            "bounds": ([1e-8], [1.0]),
            "color": BASELINE_COLOR,
            "linestyle": "--",
        },
        "Quadratic": {
            "fn": quadratic_trend,
            "p0": (0.001, 1e-7),
            "bounds": ([1e-8, 1e-10], [1.0, 1.0]),
            "color": AUX_COLOR_1,
            "linestyle": "-.",
        },
        "Power-law": {
            "fn": power_model,
            "p0": (1e-5, 1.0),
            "bounds": ([1e-10, 0.05], [1.0, 5.0]),
            "color": ACCENT_COLOR,
            "linestyle": "-",
        },
        "Exponential": {
            "fn": exponential_trend,
            "p0": (0.10, 1e-4),
            "bounds": ([1e-8, 1e-8], [10.0, 1.0]),
            "color": AUX_COLOR_3,
            "linestyle": ":",
        },
        "Logarithmic": {
            "fn": logarithmic_trend,
            "p0": (1.0, 1e-3),
            "bounds": ([1e-8, 1e-8], [100.0, 10.0]),
            "color": AUX_COLOR_2,
            "linestyle": (0, (5, 2)),
        },
    }


def fit_candidate_trends():
    trend_specs = candidate_trend_specs()
    trend_rows = []
    best_counts = {name: 0 for name in trend_specs}
    mean_curve = DEVICE_DATA.mean(axis=0)
    mean_predictions = []

    for device_id, values in enumerate(DEVICE_DATA, start=1):
        device_scores = []
        for name, spec in trend_specs.items():
            params, _ = curve_fit(
                spec["fn"],
                TIME_HOURS,
                values,
                p0=spec["p0"],
                bounds=spec["bounds"],
                maxfev=50000,
            )
            predicted = spec["fn"](TIME_HOURS, *params)
            aic, bic, rmse = compute_fit_metrics(values, predicted, len(params))
            trend_rows.append(
                {
                    "device": device_id,
                    "model": name,
                    "aic": aic,
                    "bic": bic,
                    "rmse": rmse,
                }
            )
            device_scores.append((aic, name))
        best_counts[min(device_scores)[1]] += 1

    for name, spec in trend_specs.items():
        params, _ = curve_fit(
            spec["fn"],
            TIME_HOURS,
            mean_curve,
            p0=spec["p0"],
            bounds=spec["bounds"],
            maxfev=50000,
        )
        mean_predictions.append(
            {
                "model": name,
                "predicted": spec["fn"](TIME_HOURS, *params),
            }
        )

    trend_df = pd.DataFrame(trend_rows)
    summary_df = (
        trend_df.groupby("model", as_index=False)
        .agg(
            mean_aic=("aic", "mean"),
            mean_bic=("bic", "mean"),
            median_rmse=("rmse", "median"),
        )
        .sort_values("mean_aic")
    )
    summary_df["best_aic_count"] = summary_df["model"].map(best_counts)
    return trend_df, summary_df, mean_curve, mean_predictions


def fit_reference_distributions(reference_values):
    distribution_specs = {
        "Weibull": (weibull_min, {"floc": 0}),
        "Lognormal": (lognorm, {"floc": 0}),
        "Gamma": (gamma, {"floc": 0}),
        "Nakagami": (nakagami, {"floc": 0}),
        "Log-logistic": (fisk, {"floc": 0}),
        "Rice": (rice, {"floc": 0}),
        "Rayleigh": (rayleigh, {}),
    }
    rows = []
    fitted = {}
    for name, (dist, kwargs) in distribution_specs.items():
        params = dist.fit(reference_values, **kwargs)
        log_likelihood = float(np.sum(dist.logpdf(reference_values, *params)))
        aic = 2 * len(params) - 2 * log_likelihood
        bic = len(params) * np.log(len(reference_values)) - 2 * log_likelihood
        ks_stat, ks_p = kstest(reference_values, dist.cdf, args=params)
        rows.append(
            {
                "distribution": name,
                "aic": aic,
                "bic": bic,
                "ks_stat": float(ks_stat),
                "ks_p_value": float(ks_p),
            }
        )
        fitted[name] = {"dist": dist, "params": params}
    summary_df = pd.DataFrame(rows).sort_values("aic")
    return summary_df, fitted


def save_supplement_trend_figure(mean_curve, mean_predictions):
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    ax.scatter(TIME_HOURS, mean_curve, color=INK_COLOR, s=42, zorder=3, label="Fleet mean")
    for item in mean_predictions:
        spec = candidate_trend_specs()[item["model"]]
        ax.plot(
            TIME_HOURS,
            item["predicted"],
            color=spec["color"],
            linestyle=spec["linestyle"],
            linewidth=2.0,
            label=item["model"],
        )
    ax.set_xlabel("Operating time (h)")
    ax.set_ylabel("Mean degradation metric (%)")
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, ncol=2, loc="upper left")
    fig.tight_layout()
    save_journal_figure(fig, "supp_fig01_power_model_comparison")
    plt.close(fig)


def save_supplement_distribution_figure(reference_values, fitted):
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    x_min = reference_values.min() * 0.90
    x_max = reference_values.max() * 1.26
    bins = np.linspace(reference_values.min() * 0.9, reference_values.max() * 1.08, 8)
    ax.hist(
        reference_values,
        bins=bins,
        density=True,
        color=LIGHT_GRAY,
        edgecolor=INK_COLOR,
        linewidth=0.9,
        hatch="//",
    )
    x_grid = np.linspace(x_min, x_max, 500)
    color_map = {
        "Weibull": ACCENT_COLOR,
        "Lognormal": AUX_COLOR_1,
        "Gamma": AUX_COLOR_2,
        "Nakagami": AUX_COLOR_3,
        "Log-logistic": BASELINE_COLOR,
        "Rice": NAVY,
        "Rayleigh": LIGHT_GRAY,
    }
    style_map = {
        "Weibull": "-",
        "Lognormal": "--",
        "Gamma": "-.",
        "Nakagami": ":",
        "Log-logistic": (0, (5, 2)),
        "Rice": (0, (3, 1, 1, 1)),
        "Rayleigh": (0, (7, 2)),
    }
    for name, item in fitted.items():
        density = item["dist"].pdf(x_grid, *item["params"])
        ax.plot(x_grid, density, color=color_map[name], linestyle=style_map[name], linewidth=2.0, label=name)
    ax.set_xlabel("Reference lifetime from full-history power-law fit (h)")
    ax.set_ylabel("Density")
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(0, ax.get_ylim()[1] * 1.10)
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, ncol=1, loc="upper right", handlelength=2.2)
    fig.tight_layout()
    save_journal_figure(fig, "supp_fig02_reference_lifetime_distribution")
    plt.close(fig)


def save_supplement_logqq_figure(reference_values):
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    (osm, osr), (slope, intercept, _) = probplot(np.log(reference_values), dist="norm")
    ax.scatter(osm, osr, color=ACCENT_COLOR, edgecolor=INK_COLOR, linewidth=0.5, s=34)
    x_line = np.array([osm.min(), osm.max()])
    ax.plot(x_line, slope * x_line + intercept, color=BASELINE_COLOR, linestyle="--", linewidth=1.6)
    ax.set_xlabel("Theoretical normal quantiles")
    ax.set_ylabel("Observed log-reference lifetime")
    apply_journal_axes(ax, grid_axis="both")
    fig.tight_layout()
    save_journal_figure(fig, "supp_fig03_log_reference_qq")
    plt.close(fig)


def save_supplementary_outputs(prediction_df):
    trend_df, trend_summary_df, mean_curve, mean_predictions = fit_candidate_trends()
    reference_summary_df, fitted = fit_reference_distributions(prediction_df["reference_lifetime"].to_numpy())

    trend_df.to_csv(OUTPUT_DIR / "supp_model_comparison_device_level.csv", index=False)
    trend_summary_df.to_csv(OUTPUT_DIR / "supp_model_comparison_summary.csv", index=False)
    reference_summary_df.to_csv(OUTPUT_DIR / "supp_reference_distribution_summary.csv", index=False)

    save_supplement_trend_figure(mean_curve, mean_predictions)
    save_supplement_distribution_figure(prediction_df["reference_lifetime"].to_numpy(), fitted)
    save_supplement_logqq_figure(prediction_df["reference_lifetime"].to_numpy())


def save_trajectory_figure():
    initial_time = TIME_HOURS[INITIAL_COUNT - 1]
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    ax.axvspan(
        0,
        initial_time,
        color=SAND,
        alpha=0.9,
        hatch="//",
        linewidth=0,
        zorder=0,
        label="Initial-data window",
    )

    reference_lifetimes = [fit_power_lifetime(TIME_HOURS, row) for row in DEVICE_DATA]
    ranked = np.argsort(reference_lifetimes)
    focus_devices = [ranked[1], ranked[len(ranked) // 2], ranked[-2]]
    focus_styles = [
        {"color": ACCENT_COLOR, "marker": "o", "linestyle": "-"},
        {"color": AUX_COLOR_1, "marker": "s", "linestyle": "--"},
        {"color": AUX_COLOR_2, "marker": "^", "linestyle": "-."},
    ]

    for idx, row in enumerate(DEVICE_DATA):
        ax.plot(TIME_HOURS, row, color=BASELINE_COLOR, linewidth=0.9, alpha=0.45, zorder=1)
        ax.scatter(TIME_HOURS[:INITIAL_COUNT], row[:INITIAL_COUNT], s=18, color=GRAY, alpha=0.55, zorder=2)

    for style, idx in zip(focus_styles, focus_devices):
        label = f"Device {idx + 1}"
        ax.plot(
            TIME_HOURS,
            DEVICE_DATA[idx],
            color=style["color"],
            linestyle=style["linestyle"],
            linewidth=2.1,
            alpha=0.95,
            zorder=3,
            label=label,
        )
        ax.scatter(
            TIME_HOURS[:INITIAL_COUNT],
            DEVICE_DATA[idx][:INITIAL_COUNT],
            s=42,
            color=style["color"],
            marker=style["marker"],
            edgecolor=PAPER_COLOR,
            linewidth=0.7,
            zorder=4,
        )
        ax.scatter(
            TIME_HOURS[INITIAL_COUNT:],
            DEVICE_DATA[idx][INITIAL_COUNT:],
            s=32,
            facecolors=PAPER_COLOR,
            edgecolors=style["color"],
            marker=style["marker"],
            linewidth=1.0,
            zorder=4,
        )

    ax.axhline(FAILURE_THRESHOLD, color=INK_COLOR, linestyle="--", linewidth=1.3, label="Failure threshold")
    ax.set_xlim(0, TIME_HOURS[-1] + 100)
    ax.set_ylim(0, 13)
    ax.set_xlabel("Operating time (h)")
    ax.set_ylabel("Degradation metric (%)")
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, ncol=2, loc="upper left")
    fig.tight_layout()
    save_journal_figure(fig, "fig01_early_stage_degradation_setting")
    plt.close(fig)


def save_weight_figure(weights_mild, weights_strong):
    x = np.arange(1, len(weights_mild) + 1)
    uniform = np.full_like(weights_mild, 1.0 / len(weights_mild))

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    ax.plot(
        x,
        uniform,
        marker="o",
        linewidth=1.5,
        linestyle="-",
        color=BASELINE_COLOR,
        markeredgecolor=INK_COLOR,
        label="Uniform aggregation",
    )
    ax.plot(
        x,
        weights_mild,
        marker="s",
        linewidth=1.6,
        linestyle="--",
        color=AUX_COLOR_1,
        markeredgecolor=INK_COLOR,
        label="Initial-emphasis (mild)",
    )
    ax.plot(
        x,
        weights_strong,
        marker="^",
        linewidth=1.6,
        linestyle="-.",
        color=ACCENT_COLOR,
        markeredgecolor=INK_COLOR,
        label="Initial-emphasis (strong)",
    )

    ax.fill_between(x, 0, weights_strong, color=SAND, alpha=0.65, linewidth=0, hatch="//")
    ax.set_xlabel("Initial-window index")
    ax.set_ylabel("Aggregation weight")
    ax.set_xticks(x)
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, loc="upper right")
    fig.tight_layout()
    save_journal_figure(fig, "fig03_initial_window_weight_profiles")
    plt.close(fig)


def save_local_instability_figure(window_df, prediction_df):
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    for _, chunk in window_df.groupby("device"):
        ax.plot(
            chunk["window_id"],
            chunk["window_lifetime"],
            color=BASELINE_COLOR,
            linewidth=0.9,
            alpha=0.45,
            zorder=1,
        )

    ranked = prediction_df.sort_values("reference_lifetime")["device"].tolist()
    selected = [ranked[1], ranked[len(ranked) // 2], ranked[-2]]
    styles = [
        {"color": ACCENT_COLOR, "linestyle": "-", "marker": "o"},
        {"color": AUX_COLOR_1, "linestyle": "--", "marker": "s"},
        {"color": AUX_COLOR_2, "linestyle": "-.", "marker": "^"},
    ]
    for device, style in zip(selected, styles):
        chunk = window_df[window_df["device"] == device]
        ax.plot(
            chunk["window_id"],
            chunk["window_lifetime"],
            marker=style["marker"],
            color=style["color"],
            linestyle=style["linestyle"],
            linewidth=1.8,
            markersize=5.5,
            markeredgecolor=INK_COLOR,
            markeredgewidth=0.5,
            label=f"Device {device}",
            zorder=3,
        )

    ax.set_xlabel("Initial-window index")
    ax.set_ylabel("Local pseudo-lifetime (h)")
    ax.set_xticks(sorted(window_df["window_id"].unique()))
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, ncol=3, loc="upper left")
    fig.tight_layout()
    save_journal_figure(fig, "fig02_local_window_instability")
    plt.close(fig)


def save_shrinkage_figure(prediction_df):
    pooled_center = prediction_df["pooled_bayes"].mean()
    plot_df = prediction_df[["device", "window_median", "pooled_bayes"]].copy()
    plot_df = plot_df.sort_values("window_median").reset_index(drop=True)
    y = np.arange(len(plot_df))

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    for idx, row in plot_df.iterrows():
        ax.plot(
            [row["window_median"], row["pooled_bayes"]],
            [y[idx], y[idx]],
            color=LIGHT_GRAY,
            linewidth=1.2,
            zorder=1,
        )
    ax.scatter(
        plot_df["window_median"],
        y,
        s=38,
        color=AUX_COLOR_2,
        marker="s",
        edgecolor=INK_COLOR,
        linewidth=0.5,
        label="Window median",
        zorder=3,
    )
    ax.scatter(
        plot_df["pooled_bayes"],
        y,
        s=42,
        color=ACCENT_COLOR,
        marker="o",
        edgecolor=INK_COLOR,
        linewidth=0.5,
        label="Bayesian partial pooling",
        zorder=4,
    )
    ax.axvline(pooled_center, color=INK_COLOR, linestyle="--", linewidth=1.2, label="Fleet-level center")

    for idx in [0, len(plot_df) // 2, len(plot_df) - 1]:
        row = plot_df.iloc[idx]
        ax.text(row["pooled_bayes"] + 60, y[idx] + 0.08, f"Device {int(row['device'])}", fontsize=11, color=GRAY)

    ax.set_xlabel("Predicted lifetime (h)")
    ax.set_ylabel("Ordered devices")
    ax.set_yticks([])
    right_limit = max(plot_df["window_median"].max(), plot_df["pooled_bayes"].max()) * 1.12
    ax.set_xlim(0, right_limit)
    apply_journal_axes(ax, grid_axis="x")
    apply_journal_legend(ax, loc="lower right")
    fig.tight_layout()
    save_journal_figure(fig, "fig04_bayesian_shrinkage_mechanism")
    plt.close(fig)


def save_distribution_figure(long_df):
    order = [
        "Early global fit",
        "Window median",
        "Initial-emphasis (mild)",
        "Initial-emphasis (strong)",
        "Bayesian partial pooling",
    ]
    palette_map = {method: METHOD_STYLES[method]["color"] for method in order}

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    sns.violinplot(
        data=long_df,
        x="predicted_lifetime",
        y="method",
        hue="method",
        order=order,
        hue_order=order,
        palette=palette_map,
        inner=None,
        linewidth=0.7,
        cut=0,
        saturation=0.9,
        legend=False,
        ax=ax,
    )
    sns.boxplot(
        data=long_df,
        x="predicted_lifetime",
        y="method",
        order=order,
        width=0.18,
        showcaps=True,
        boxprops={"facecolor": PAPER_COLOR, "edgecolor": INK_COLOR, "linewidth": 0.9},
        medianprops={"color": INK_COLOR, "linewidth": 1.3},
        whiskerprops={"color": INK_COLOR, "linewidth": 0.9},
        capprops={"color": INK_COLOR, "linewidth": 0.9},
        showfliers=False,
        ax=ax,
    )
    sns.stripplot(
        data=long_df,
        x="predicted_lifetime",
        y="method",
        order=order,
        color=INK_COLOR,
        size=3.5,
        alpha=0.5,
        jitter=0.15,
        ax=ax,
    )
    ax.set_xlabel("Predicted lifetime (h)")
    ax.set_ylabel("")
    apply_journal_axes(ax, grid_axis="x")
    fig.tight_layout()
    save_journal_figure(fig, "fig05_prediction_distribution_by_method")
    plt.close(fig)


def save_error_distribution_figure(long_df, summary_df):
    order = summary_df["method"].tolist()
    palette_map = {method: METHOD_STYLES[method]["color"] for method in order}

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()

    sns.boxplot(
        data=long_df,
        x="abs_error",
        y="method",
        hue="method",
        order=order,
        hue_order=order,
        palette=palette_map,
        showfliers=False,
        width=0.56,
        legend=False,
        ax=ax,
    )
    for patch, method in zip(ax.patches, order):
        patch.set_hatch(METHOD_STYLES[method]["hatch"])
        patch.set_edgecolor(INK_COLOR)
        patch.set_linewidth(0.8)
    sns.stripplot(
        data=long_df,
        x="abs_error",
        y="method",
        order=order,
        color=INK_COLOR,
        size=3.5,
        alpha=0.5,
        jitter=0.2,
        ax=ax,
    )
    ax.set_xlabel("Absolute error vs full-history reference (h)")
    ax.set_ylabel("")
    ax.set_xlim(0, long_df["abs_error"].max() * 1.12)
    apply_journal_axes(ax, grid_axis="x")

    fig.tight_layout()
    save_journal_figure(fig, "fig06_absolute_error_distribution")
    plt.close(fig)


def save_error_ranking_figure(long_df, summary_df):
    bar_df = summary_df.copy()
    ci_rows = []
    for idx, method in enumerate(bar_df["method"]):
        values = long_df.loc[long_df["method"] == method, "abs_error"].to_numpy()
        ci_low, ci_high = bootstrap_mean_ci(values, seed=20260509 + idx)
        ci_rows.append({"method": method, "ci_low": ci_low, "ci_high": ci_high})
    bar_df = bar_df.merge(pd.DataFrame(ci_rows), on="method")

    y = np.arange(len(bar_df))
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()

    for idx, row in bar_df.iterrows():
        style = METHOD_STYLES[row["method"]]
        ax.barh(
            y[idx],
            row["mean_abs_error"],
            height=0.58,
            color=style["color"],
            edgecolor=INK_COLOR,
            linewidth=0.8,
            hatch=style["hatch"],
            zorder=2,
        )
        ax.errorbar(
            row["mean_abs_error"],
            y[idx],
            xerr=np.array(
                [
                    [row["mean_abs_error"] - row["ci_low"]],
                    [row["ci_high"] - row["mean_abs_error"]],
                ]
            ),
            fmt="none",
            ecolor=INK_COLOR,
            elinewidth=1.0,
            capsize=3.0,
            capthick=1.0,
            zorder=4,
        )
        ax.text(
            row["ci_high"] + 35,
            y[idx],
            f"{row['mean_abs_error']:.1f}",
            va="center",
            ha="left",
            fontsize=11,
            color=INK_COLOR,
        )

    right_limit = bar_df["ci_high"].max() * 1.18
    ax.set_xlim(0, right_limit)
    ax.set_yticks(y)
    ax.set_yticklabels(bar_df["method"])
    ax.invert_yaxis()
    ax.set_xlabel("Mean absolute error (h)")
    ax.set_ylabel("")
    apply_journal_axes(ax, grid_axis="x")

    fig.tight_layout()
    save_journal_figure(fig, "fig07_mae_ranking_bootstrap_ci")
    plt.close(fig)


def save_prefix_sensitivity_figure():
    rows = []
    for prefix_count in PREFIX_COUNTS:
        _, _, long_df, summary_df, _, _, _ = build_prediction_tables(initial_count=prefix_count)
        for _, row in summary_df.iterrows():
            values = long_df.loc[long_df["method"] == row["method"], "abs_error"].to_numpy()
            ci_low, ci_high = bootstrap_mean_ci(values, seed=20260509 + prefix_count * 17 + len(rows))
            rows.append(
                {
                    "prefix_count": prefix_count,
                    "method": row["method"],
                    "mean_abs_error": row["mean_abs_error"],
                    "ci_low": ci_low,
                    "ci_high": ci_high,
                }
            )

    prefix_df = pd.DataFrame(rows)
    order = [
        "Early global fit",
        "Window median",
        "Initial-emphasis (mild)",
        "Initial-emphasis (strong)",
        "Bayesian partial pooling",
    ]
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    for method in order:
        chunk = prefix_df[prefix_df["method"] == method]
        style = METHOD_STYLES[method]
        yerr = np.vstack(
            [
                chunk["mean_abs_error"].to_numpy() - chunk["ci_low"].to_numpy(),
                chunk["ci_high"].to_numpy() - chunk["mean_abs_error"].to_numpy(),
            ]
        )
        ax.errorbar(
            chunk["prefix_count"],
            chunk["mean_abs_error"],
            yerr=yerr,
            marker=style["marker"],
            linestyle=style["linestyle"],
            linewidth=1.5,
            markersize=4.8,
            color=style["color"],
            markeredgecolor=INK_COLOR,
            markeredgewidth=0.45,
            elinewidth=0.8,
            capsize=2.5,
            label=method,
        )

    ax.set_xlabel("Number of initial observations")
    ax.set_ylabel("Mean absolute error (h)")
    ax.set_xticks(PREFIX_COUNTS)
    ax.set_ylim(0, prefix_df["ci_high"].max() * 1.12)
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, ncol=2, loc="upper right")
    fig.tight_layout()
    save_journal_figure(fig, "fig08_prefix_length_sensitivity")
    plt.close(fig)

    prefix_df.to_csv(OUTPUT_DIR / "journal_prefix_sensitivity.csv", index=False)


def save_representative_device_behavior_figure(prediction_df):
    ranked = prediction_df.sort_values("reference_lifetime")["device"].tolist()
    selected = [ranked[1], ranked[len(ranked) // 2], ranked[-2]]
    method_columns = [
        ("early_global", "Early global fit"),
        ("window_median", "Window median"),
        ("ioe_mild", "Initial-emphasis (mild)"),
        ("ioe_strong", "Initial-emphasis (strong)"),
        ("pooled_bayes", "Bayesian partial pooling"),
    ]
    legend_labels = {
        "Early global fit": "Early global",
        "Window median": "Window median",
        "Initial-emphasis (mild)": "Initial mild",
        "Initial-emphasis (strong)": "Initial strong",
        "Bayesian partial pooling": "BPP",
    }
    offsets = np.linspace(-0.25, 0.25, len(method_columns))
    y_base = np.arange(len(selected))
    case_labels = ["shorter-life", "intermediate", "longer-life"]

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    for lane, device in enumerate(selected):
        row = prediction_df[prediction_df["device"] == device].iloc[0]
        ax.hlines(y_base[lane], 0, max(row[[col for col, _ in method_columns]].max(), row["reference_lifetime"]) * 1.04,
                  color=GRID_COLOR, linewidth=0.9, zorder=0)
        ax.scatter(
            row["reference_lifetime"],
            y_base[lane],
            marker="x",
            s=56,
            color=INK_COLOR,
            linewidth=1.3,
            label="Full reference" if lane == 0 else None,
            zorder=4,
        )
        for offset, (column, method) in zip(offsets, method_columns):
            style = METHOD_STYLES[method]
            ax.scatter(
                row[column],
                y_base[lane] + offset,
                marker=style["marker"],
                s=42,
                facecolor=style["color"],
                edgecolor=INK_COLOR,
                linewidth=0.7,
                label=legend_labels[method] if lane == 0 else None,
                zorder=3,
            )

    x_max = float(
        prediction_df.loc[prediction_df["device"].isin(selected), [col for col, _ in method_columns] + ["reference_lifetime"]]
        .to_numpy()
        .max()
    )
    ax.set_xlim(0, x_max * 1.12)
    ax.set_ylim(-0.45, len(selected) + 0.65)
    ax.set_yticks(y_base)
    ax.set_yticklabels([f"Device {device} ({label})" for device, label in zip(selected, case_labels)])
    ax.set_xlabel("Predicted lifetime (h)")
    ax.set_ylabel("")
    apply_journal_axes(ax, grid_axis="x")
    apply_journal_legend(ax, ncol=3, loc="upper left", columnspacing=1.0, handlelength=1.4)
    fig.tight_layout()
    save_journal_figure(fig, "fig09_representative_device_prediction_behavior")
    plt.close(fig)


def save_random_effects_baseline_figure(long_df, random_effects_df):
    selected_methods = [
        "Bayesian partial pooling",
        "Early global fit",
        "Random-effects power-law",
        "Window median",
        "Initial-emphasis (mild)",
        "Initial-emphasis (strong)",
    ]
    plot_long = pd.concat(
        [
            long_df[long_df["method"].isin(selected_methods)],
            random_effects_df[["device", "method", "reference_lifetime", "predicted_lifetime", "abs_error", "signed_error", "relative_error_pct"]],
        ],
        ignore_index=True,
    )
    summary_rows = []
    for idx, method in enumerate(selected_methods):
        errors = plot_long.loc[plot_long["method"] == method, "abs_error"].to_numpy(dtype=float)
        ci_low, ci_high = bootstrap_mean_ci(errors, seed=20260710 + idx)
        summary_rows.append(
            {
                "method": method,
                "mean_abs_error": float(errors.mean()),
                "ci_low": ci_low,
                "ci_high": ci_high,
            }
        )
    bar_df = pd.DataFrame(summary_rows).sort_values("mean_abs_error").reset_index(drop=True)
    y = np.arange(len(bar_df))

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    for idx, row in bar_df.iterrows():
        style = METHOD_STYLES[row["method"]]
        ax.barh(
            y[idx],
            row["mean_abs_error"],
            height=0.6,
            color=style["color"],
            edgecolor=INK_COLOR,
            linewidth=0.8,
            hatch=style["hatch"],
            zorder=2,
        )
        ax.errorbar(
            row["mean_abs_error"],
            y[idx],
            xerr=np.array([[row["mean_abs_error"] - row["ci_low"]], [row["ci_high"] - row["mean_abs_error"]]]),
            fmt="none",
            ecolor=INK_COLOR,
            elinewidth=1.0,
            capsize=3.0,
            capthick=1.0,
            zorder=4,
        )
        ax.text(row["ci_high"] + 35, y[idx], f"{row['mean_abs_error']:.1f}", va="center", ha="left", fontsize=11)

    ax.set_yticks(y)
    ax.set_yticklabels(bar_df["method"])
    ax.invert_yaxis()
    ax.set_xlabel("Mean absolute error (h)")
    ax.set_xlim(0, bar_df["ci_high"].max() * 1.18)
    apply_journal_axes(ax, grid_axis="x")
    fig.tight_layout()
    save_journal_figure(fig, "fig10_random_effects_baseline_comparison")
    plt.close(fig)


def save_bpp_interval_figure(interval_df):
    plot_df = interval_df[interval_df["interval_level"] == 95].copy()
    interval90 = interval_df[interval_df["interval_level"] == 90].set_index("device")
    plot_df = plot_df.sort_values("posterior_median").reset_index(drop=True)
    y = np.arange(len(plot_df))

    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    ax.hlines(
        y,
        plot_df["lower"],
        plot_df["upper"],
        color=BASELINE_COLOR,
        linewidth=3.0,
        alpha=0.75,
        label="95% interval",
        zorder=1,
    )
    ax.hlines(
        y,
        interval90.loc[plot_df["device"], "lower"].to_numpy(dtype=float),
        interval90.loc[plot_df["device"], "upper"].to_numpy(dtype=float),
        color=ACCENT_COLOR,
        linewidth=1.8,
        label="90% interval",
        zorder=2,
    )
    ax.scatter(
        plot_df["posterior_median"],
        y,
        marker="o",
        s=28,
        color=ACCENT_COLOR,
        edgecolor=INK_COLOR,
        linewidth=0.6,
        label="Posterior median",
        zorder=3,
    )
    ax.scatter(
        plot_df["reference_lifetime"],
        y,
        marker="x",
        s=44,
        color=INK_COLOR,
        linewidth=1.1,
        label="Full-history reference",
        zorder=4,
    )
    ax.set_yticks(y)
    ax.set_yticklabels([f"D{int(d)}" for d in plot_df["device"]])
    ax.set_xlabel("Lifetime (h)")
    ax.set_ylabel("Ordered device")
    ax.set_xlim(0, plot_df["upper"].max() * 1.08)
    apply_journal_axes(ax, grid_axis="x")
    apply_journal_legend(ax, ncol=1, loc="upper left", handlelength=2.0)
    fig.tight_layout()
    save_journal_figure(fig, "fig11_bpp_posterior_intervals")
    plt.close(fig)


def save_residual_diagnostics_figure(diagnostic_df):
    fig = plt.figure(figsize=FIG_SIZE)
    ax = fig.gca()
    ax.scatter(
        diagnostic_df["posterior_log_mean"],
        diagnostic_df["residual"],
        s=20,
        color=ACCENT_COLOR,
        edgecolor=INK_COLOR,
        linewidth=0.45,
        alpha=0.86,
    )
    ax.axhline(0, color=INK_COLOR, linestyle="--", linewidth=0.9)
    x = diagnostic_df["posterior_log_mean"].to_numpy(dtype=float)
    y = diagnostic_df["residual"].to_numpy(dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    xs = np.linspace(x.min(), x.max(), 100)
    ax.plot(xs, slope * xs + intercept, color=AUX_COLOR_2, linewidth=1.5, linestyle="-.", label="Linear trend")
    ax.set_xlabel("Fitted log-lifetime")
    ax.set_ylabel("Residual")
    y_abs = max(abs(float(np.min(y))), abs(float(np.max(y))))
    ax.set_ylim(-1.12 * y_abs, 1.12 * y_abs)
    apply_journal_axes(ax, grid_axis="y")
    apply_journal_legend(ax, loc="upper left")
    fig.tight_layout()
    save_journal_figure(fig, "fig12_residual_diagnostics")
    plt.close(fig)


def ensure_directories():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)


def main():
    ensure_directories()
    clear_generated_figures()
    configure_style()

    prediction_df, window_df, long_df, summary_df, weights_mild, weights_strong, hyper = build_prediction_tables()
    reference_df = prediction_df[["device", "reference_lifetime"]]
    random_effects_df = random_effects_power_law_predictions(reference_df)
    random_effects_summary_df = summarize_random_effects(random_effects_df)
    interval_df = posterior_interval_table(prediction_df, window_df)
    interval_summary_df = interval_summary(interval_df)
    sensitivity_df = hyperparameter_sensitivity_table(window_df)
    residual_df, residual_summary_df = residual_diagnostics(window_df)

    prediction_df.to_csv(OUTPUT_DIR / "journal_device_predictions.csv", index=False)
    window_df.to_csv(OUTPUT_DIR / "journal_window_estimates.csv", index=False)
    long_df.to_csv(OUTPUT_DIR / "journal_method_predictions_long.csv", index=False)
    summary_df.to_csv(OUTPUT_DIR / "journal_method_summary.csv", index=False)
    random_effects_df.to_csv(OUTPUT_DIR / "journal_random_effects_powerlaw_predictions.csv", index=False)
    random_effects_summary_df.to_csv(OUTPUT_DIR / "journal_random_effects_powerlaw_summary.csv", index=False)
    interval_df.to_csv(OUTPUT_DIR / "journal_bpp_posterior_intervals.csv", index=False)
    interval_summary_df.to_csv(OUTPUT_DIR / "journal_bpp_interval_summary.csv", index=False)
    sensitivity_df.to_csv(OUTPUT_DIR / "journal_empirical_bayes_loo_sensitivity.csv", index=False)
    residual_df.to_csv(OUTPUT_DIR / "journal_residual_diagnostics.csv", index=False)
    residual_summary_df.to_csv(OUTPUT_DIR / "journal_residual_diagnostics_summary.csv", index=False)
    pd.DataFrame(
        {
            "window_index": np.arange(1, len(weights_mild) + 1),
            "uniform": np.full(len(weights_mild), 1.0 / len(weights_mild)),
            "initial_emphasis_mild": weights_mild,
            "initial_emphasis_strong": weights_strong,
        }
    ).to_csv(OUTPUT_DIR / "journal_prefix_weights.csv", index=False)
    pd.DataFrame([hyper]).to_csv(OUTPUT_DIR / "journal_empirical_bayes_hyperparameters.csv", index=False)

    save_trajectory_figure()
    save_weight_figure(weights_mild, weights_strong)
    save_local_instability_figure(window_df, prediction_df)
    save_shrinkage_figure(prediction_df)
    save_distribution_figure(long_df)
    save_error_distribution_figure(long_df, summary_df)
    save_error_ranking_figure(long_df, summary_df)
    save_prefix_sensitivity_figure()
    save_representative_device_behavior_figure(prediction_df)
    save_random_effects_baseline_figure(long_df, random_effects_df)
    save_bpp_interval_figure(interval_df)
    save_residual_diagnostics_figure(residual_df)
    save_supplementary_outputs(prediction_df)

    print("Saved updated journal figures and summary tables.")


if __name__ == "__main__":
    main()


from __future__ import annotations

import re
import warnings
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.io as sio
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import HuberRegressor, RidgeCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "output"
FIG_DIR = ROOT / "figures"
DATA_DIR = ROOT / "data" / "oxford"
MAT_FILE = DATA_DIR / "Oxford_Battery_Degradation_Dataset_1.mat"
CAPACITY_CSV = DATA_DIR / "oxford_capacity_trajectories.csv"

FIGSIZE = (6.4, 3.6)  # 16:9 at 300 dpi gives 1920 x 1080 px.
DPI = 300
THRESHOLD_RETENTION = 0.95
PREFIX_CYCLES = np.arange(100, 501, 100)
BOOTSTRAP_REPS = 8000

COLORS = {
    "paper": "#FFFFFF",
    "ink": "#000000",
    "blue": "#0063D0",
    "sky": "#0152AB",
    "navy": "#172C6F",
    "green": "#278575",
    "sand": "#F8E3B3",
    "gold": "#D9A441",
    "red": "#C83E36",
    "gray": "#7A7A7A",
    "light_gray": "#D8D8D8",
    "accent": "#0063D0",
    "aux1": "#278575",
    "aux2": "#D9A441",
    "aux3": "#172C6F",
    "baseline": "#7A7A7A",
    "light_grid": "#D8D8D8",
    "text": "#000000",
}

METHOD_DISPLAY = {
    "Bayesian partial pooling": "Bayesian partial pooling",
    "Window median": "Window median",
    "Early global mean": "Global mean",
    "Initial-emphasis mild": "Initial mild",
    "Initial-emphasis strong": "Initial strong",
    "Huber feature baseline": "Huber direct",
    "Ridge feature baseline": "Ridge direct",
    "RF feature baseline": "RF direct",
    "SVR feature baseline": "SVR direct",
}

BATTERY_METHOD_STYLES = {
    "Bayesian partial pooling": {"color": COLORS["blue"], "hatch": ""},
    "Window median": {"color": COLORS["green"], "hatch": "\\\\"},
    "Early global mean": {"color": COLORS["gold"], "hatch": "//"},
    "Initial-emphasis mild": {"color": COLORS["navy"], "hatch": "xx"},
    "Initial-emphasis strong": {"color": COLORS["gray"], "hatch": "--"},
    "Ridge feature baseline": {"color": COLORS["gray"], "hatch": ".."},
    "Huber feature baseline": {"color": COLORS["gray"], "hatch": "++"},
    "RF feature baseline": {"color": COLORS["gray"], "hatch": "\\\\//"},
    "SVR feature baseline": {"color": COLORS["gray"], "hatch": "oo"},
}


def apply_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "STIX Two Text", "STIXGeneral", "DejaVu Serif"],
            "mathtext.fontset": "stix",
            "font.size": 11,
            "axes.labelsize": 12,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
            "figure.facecolor": COLORS["paper"],
            "axes.facecolor": COLORS["paper"],
            "axes.edgecolor": COLORS["ink"],
            "text.color": COLORS["ink"],
            "axes.linewidth": 0.9,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
            "xtick.major.size": 4,
            "ytick.major.size": 4,
            "savefig.dpi": DPI,
            "savefig.facecolor": COLORS["paper"],
            "figure.dpi": DPI,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "hatch.linewidth": 0.65,
        }
    )


def polish_axis(ax: plt.Axes, grid_axis: str = "x") -> None:
    ax.grid(True, axis=grid_axis, color=COLORS["light_grid"], linewidth=0.6, alpha=0.85)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_linewidth(0.9)
        spine.set_color(COLORS["ink"])
    ax.tick_params(colors=COLORS["text"])
    ax.xaxis.label.set_color(COLORS["text"])
    ax.yaxis.label.set_color(COLORS["text"])


def save_figure(fig: plt.Figure, stem: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf"):
        fig.savefig(FIG_DIR / f"{stem}.{suffix}", dpi=DPI, facecolor=COLORS["paper"])
    plt.close(fig)


def clear_generated_figures() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    stems = [
        "fig13_battery_capacity_trajectories",
        "fig14_battery_error_ranking",
        "fig15_battery_predicted_vs_observed",
    ]
    for stem in stems:
        for suffix in ("png", "pdf"):
            path = FIG_DIR / f"{stem}.{suffix}"
            if path.exists():
                path.unlink()


def extract_oxford_capacity() -> pd.DataFrame:
    if not MAT_FILE.exists():
        raise FileNotFoundError(
            f"Oxford public battery dataset not found: {MAT_FILE}. "
            "Download Oxford_Battery_Degradation_Dataset_1.mat to data/oxford first."
        )

    mat = sio.loadmat(MAT_FILE, squeeze_me=True, struct_as_record=False)
    rows: list[dict[str, float | int | str]] = []
    for cell_id in sorted(k for k in mat if k.startswith("Cell")):
        cell = mat[cell_id]
        for field in cell._fieldnames:
            match = re.fullmatch(r"cyc(\d+)", field)
            if match is None:
                continue

            cycle = int(match.group(1))
            discharge = getattr(cell, field).C1dc
            q = np.asarray(discharge.q, dtype=float).ravel()
            v = np.asarray(discharge.v, dtype=float).ravel()
            temperature = np.asarray(discharge.T, dtype=float).ravel()
            time_days = np.asarray(discharge.t, dtype=float).ravel()

            rows.append(
                {
                    "cell_index": cell_id,
                    "cycle_index": cycle,
                    "discharge_capacity_ah": float(-np.nanmin(q) / 1000.0),
                    "end_voltage_v": float(v[-1]),
                    "mean_temperature_c": float(np.nanmean(temperature)),
                    "duration_h": float((time_days[-1] - time_days[0]) * 24.0),
                }
            )

    df = pd.DataFrame(rows).sort_values(["cell_index", "cycle_index"]).reset_index(drop=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(CAPACITY_CSV, index=False)
    return df


def load_capacity_data() -> pd.DataFrame:
    if not CAPACITY_CSV.exists():
        return extract_oxford_capacity()
    return pd.read_csv(CAPACITY_CSV)


def capacity_at(group: pd.DataFrame, cycle: int) -> float:
    group = group.sort_values("cycle_index")
    return float(
        np.interp(
            cycle,
            group["cycle_index"].to_numpy(dtype=float),
            group["discharge_capacity_ah"].to_numpy(dtype=float),
        )
    )


def threshold_life(df: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    lives: dict[str, float] = {}
    references: dict[str, float] = {}
    for cell, group in df.groupby("cell_index", sort=True):
        group = group.sort_values("cycle_index")
        reference = float(group[group["cycle_index"] <= 200]["discharge_capacity_ah"].median())
        threshold = THRESHOLD_RETENTION * reference
        references[cell] = reference

        cycles = group["cycle_index"].to_numpy(dtype=float)
        capacities = group["discharge_capacity_ah"].to_numpy(dtype=float)
        for index in range(len(cycles) - 1):
            q0 = capacities[index]
            q1 = capacities[index + 1]
            if q0 >= threshold and q1 < threshold:
                fraction = (threshold - q0) / (q1 - q0)
                lives[cell] = float(cycles[index] + fraction * (cycles[index + 1] - cycles[index]))
                break

    return pd.Series(lives, name="threshold_life").sort_index(), pd.Series(references, name="q_ref").sort_index()


def early_feature_matrix(df: pd.DataFrame) -> pd.DataFrame:
    feature_cycles = [0, 100, 200, 300, 400, 500]
    rows = []
    for cell, group in df.groupby("cell_index", sort=True):
        group = group.sort_values("cycle_index")
        row: dict[str, float | str] = {"cell_index": cell}
        for cycle in feature_cycles:
            row[f"q{cycle}"] = capacity_at(group, cycle)

        x = np.asarray(feature_cycles[1:], dtype=float)
        q = np.asarray([row[f"q{cycle}"] for cycle in feature_cycles[1:]], dtype=float)
        row["q_drop_0_500"] = float(row["q0"] - row["q500"])
        row["q_drop_100_500"] = float(row["q100"] - row["q500"])
        row["q_mean_100_500"] = float(np.mean(q))
        row["q_std_100_500"] = float(np.std(q, ddof=1))
        row["q_slope_100_500"] = float(np.polyfit(x, q, 1)[0])
        row["q_curve_100_500"] = float(np.polyfit(x, q, 2)[0])
        rows.append(row)

    return pd.DataFrame(rows).set_index("cell_index")


def raw_window_features(df: pd.DataFrame, q_ref: pd.Series) -> pd.DataFrame:
    rows = []
    for cell, group in df.groupby("cell_index", sort=True):
        group = group.sort_values("cycle_index")
        reference = float(q_ref.loc[cell])
        threshold_fade = max(reference * (1.0 - THRESHOLD_RETENTION), 1e-5)
        capacities = np.asarray([capacity_at(group, int(cycle)) for cycle in PREFIX_CYCLES], dtype=float)
        fades = np.maximum(reference - capacities, 1e-6)

        for index in range(len(PREFIX_CYCLES) - 1):
            t1 = float(PREFIX_CYCLES[index])
            t2 = float(PREFIX_CYCLES[index + 1])
            f1 = float(fades[index])
            f2 = float(fades[index + 1])
            raw_life = np.nan
            if np.isfinite(f1 + f2) and f2 > f1:
                slope = np.log(f2 / f1) / np.log(t2 / t1)
                if slope > 0:
                    intercept = np.log(f1) - slope * np.log(t1)
                    raw_life = np.exp((np.log(threshold_fade) - intercept) / slope)
            if not np.isfinite(raw_life):
                raw_life = float(PREFIX_CYCLES[-1] * 3.0)

            rows.append(
                {
                    "cell_index": cell,
                    "window_id": index + 1,
                    "raw_life": float(np.clip(raw_life, PREFIX_CYCLES[-1] * 0.7, 9000.0)),
                    "q_ref": reference,
                    "dq": float(capacities[index] - capacities[index + 1]),
                    "local_slope": float((capacities[index + 1] - capacities[index]) / (t2 - t1)),
                }
            )
    return pd.DataFrame(rows)


def fit_calibrated_window_predictions(
    train_windows: pd.DataFrame,
    target_train: pd.Series,
    apply_windows: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    calibration_windows = train_windows[train_windows["cell_index"].isin(target_train.index)].copy()
    calibration_windows["target"] = calibration_windows["cell_index"].map(target_train)

    train_predictions = []
    apply_predictions = []
    for window_id in sorted(calibration_windows["window_id"].unique()):
        calibration = calibration_windows[calibration_windows["window_id"] == window_id]
        x_train = np.column_stack(
            [
                np.log(calibration["raw_life"]),
                calibration["q_ref"],
                calibration["dq"],
                calibration["local_slope"],
            ]
        )
        y_train = np.log(calibration["target"])
        model = make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            RidgeCV(alphas=np.logspace(-3, 3, 30)),
        )
        model.fit(x_train, y_train)

        for source, destination in ((calibration_windows, train_predictions), (apply_windows, apply_predictions)):
            chunk = source[source["window_id"] == window_id]
            x_apply = np.column_stack(
                [
                    np.log(chunk["raw_life"]),
                    chunk["q_ref"],
                    chunk["dq"],
                    chunk["local_slope"],
                ]
            )
            predicted = np.exp(model.predict(x_apply))
            out = chunk[["cell_index", "window_id"]].copy()
            out["window_lifetime"] = np.clip(predicted, 300.0, 9000.0)
            destination.append(out)

    return pd.concat(train_predictions, ignore_index=True), pd.concat(apply_predictions, ignore_index=True)


def weighted_bayesian_partial_pooling(
    train_windows: pd.DataFrame,
    target_train: pd.Series,
    apply_windows: pd.DataFrame,
    *,
    use_window_reliability: bool = True,
    use_fleet_shrinkage: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    train = train_windows.copy()
    train["target"] = train["cell_index"].map(target_train)
    train["log_residual"] = np.log(train["window_lifetime"]) - np.log(train["target"])

    residual_var = float(max(train["log_residual"].var(ddof=1), 1e-5))
    if use_window_reliability:
        window_var = (
            train.groupby("window_id")["log_residual"]
            .var(ddof=1)
            .fillna(residual_var)
            .clip(lower=1e-4)
        )
    else:
        window_var = pd.Series(
            residual_var,
            index=pd.Index(sorted(train["window_id"].unique()), name="window_id"),
        )
    window_bias = train.groupby("window_id")["log_residual"].mean().fillna(0.0)

    train["corrected_log"] = train.apply(
        lambda row: float(np.log(row["window_lifetime"]) - window_bias.loc[row["window_id"]]),
        axis=1,
    )
    device_mean = train.groupby("cell_index")["corrected_log"].mean()
    pooled_mean = float(device_mean.mean())
    average_information = float(
        np.mean(
            [
                sum(1.0 / window_var.loc[window_id] for window_id in train[train["cell_index"] == cell]["window_id"])
                for cell in target_train.index
            ]
        )
    )
    tau2 = float(max(np.var(device_mean, ddof=1) - 1.0 / max(average_information, 1e-9), 1e-5))

    def apply_model(source: pd.DataFrame) -> pd.DataFrame:
        rows = []
        for cell, chunk in source.groupby("cell_index", sort=True):
            logs = []
            precisions = []
            for _, row in chunk.sort_values("window_id").iterrows():
                logs.append(float(np.log(row["window_lifetime"]) - window_bias.loc[row["window_id"]]))
                precisions.append(float(1.0 / window_var.loc[row["window_id"]]))
            logs_array = np.asarray(logs, dtype=float)
            precision_array = np.asarray(precisions, dtype=float)
            if use_fleet_shrinkage:
                posterior_var = float(1.0 / (precision_array.sum() + 1.0 / tau2))
                posterior_mean = float(
                    posterior_var * ((logs_array * precision_array).sum() + pooled_mean / tau2)
                )
            else:
                posterior_var = float(1.0 / precision_array.sum())
                posterior_mean = float((logs_array * precision_array).sum() / precision_array.sum())
            rows.append(
                {
                    "cell_index": cell,
                    "mean_log": posterior_mean,
                    "var_log": posterior_var,
                    "prediction": float(np.exp(posterior_mean)),
                }
            )
        return pd.DataFrame(rows).set_index("cell_index")

    return apply_model(apply_windows), apply_model(train_windows)


def direct_feature_predictions(
    train_features: pd.DataFrame,
    target_train: pd.Series,
    apply_features: pd.DataFrame,
) -> dict[str, pd.Series]:
    models = {
        "Huber feature baseline": make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            HuberRegressor(alpha=0.01, epsilon=1.5, max_iter=1000),
        ),
        "Ridge feature baseline": make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            RidgeCV(alphas=np.logspace(-2, 3, 20)),
        ),
        "RF feature baseline": RandomForestRegressor(n_estimators=500, min_samples_leaf=2, random_state=2),
        "SVR feature baseline": make_pipeline(
            SimpleImputer(),
            StandardScaler(),
            SVR(C=20, gamma="scale", epsilon=100),
        ),
    }

    predictions = {}
    for name, model in models.items():
        model.fit(train_features, target_train.astype(float))
        predictions[name] = pd.Series(
            np.clip(model.predict(apply_features), 300.0, 9000.0),
            index=apply_features.index,
        )
    return predictions


def summarize_prediction_frame(prediction_df: pd.DataFrame) -> pd.DataFrame:
    return (
        prediction_df.assign(
            abs_error=lambda x: x["signed_error"].abs(),
            squared_error=lambda x: np.square(x["signed_error"]),
            over_prediction=lambda x: x["signed_error"] > 0,
        )
        .groupby("method", as_index=False)
        .agg(
            mae=("abs_error", "mean"),
            rmse=("squared_error", lambda values: float(np.sqrt(np.mean(values)))),
            bias=("signed_error", "mean"),
            median_ae=("abs_error", "median"),
            over_prediction_rate=("over_prediction", lambda values: 100.0 * float(np.mean(values))),
        )
    )


def conformal_quantile(abs_residuals: np.ndarray, level: float) -> float:
    if len(abs_residuals) == 0:
        return 0.0
    adjusted = np.ceil((len(abs_residuals) + 1) * level) / len(abs_residuals)
    adjusted = min(float(adjusted), 1.0)
    return float(np.quantile(abs_residuals, adjusted, method="higher"))


def battery_results() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df = load_capacity_data()
    observed, q_ref = threshold_life(df)
    if len(observed) < 3:
        raise RuntimeError("Fewer than three Oxford cells crossed the selected capacity-retention threshold.")

    windows = raw_window_features(df, q_ref)
    features = early_feature_matrix(df).loc[observed.index]

    prediction_rows = []
    bpp_state_rows = []
    for test_cell in observed.index:
        train_cells = observed.index.drop(test_cell)
        train_calibrated, test_calibrated = fit_calibrated_window_predictions(
            windows[windows["cell_index"].isin(train_cells)],
            observed.loc[train_cells],
            windows[windows["cell_index"] == test_cell],
        )
        bpp_test, bpp_train = weighted_bayesian_partial_pooling(
            train_calibrated,
            observed.loc[train_cells],
            test_calibrated,
        )

        train_log_residual = np.log(observed.loc[train_cells]) - bpp_train.loc[train_cells, "mean_log"]
        abs_train_residual = np.abs(train_log_residual.to_numpy(dtype=float))
        bpp_mean = float(bpp_test.loc[test_cell, "mean_log"])
        bpp_var = float(bpp_test.loc[test_cell, "var_log"])
        bpp_prediction = float(bpp_test.loc[test_cell, "prediction"])
        method_predictions: dict[str, float] = {
            "Bayesian partial pooling": bpp_prediction,
            "Window median": float(test_calibrated["window_lifetime"].median()),
            "Early global mean": float(test_calibrated["window_lifetime"].mean()),
        }

        sorted_windows = test_calibrated.sort_values("window_id")
        for strength, name in ((0.55, "Initial-emphasis mild"), (0.95, "Initial-emphasis strong")):
            weights = np.exp(-strength * np.arange(len(sorted_windows)))
            weights = weights / weights.sum()
            method_predictions[name] = float(np.dot(weights, sorted_windows["window_lifetime"]))

        method_predictions.update(
            {
                name: float(series.loc[test_cell])
                for name, series in direct_feature_predictions(
                    features.loc[train_cells],
                    observed.loc[train_cells],
                    features.loc[[test_cell]],
                ).items()
            }
        )

        observed_life = float(observed.loc[test_cell])
        for method, prediction in method_predictions.items():
            prediction_rows.append(
                {
                    "cell_index": test_cell,
                    "method": method,
                    "observed_threshold_life": observed_life,
                    "predicted_threshold_life": float(prediction),
                    "signed_error": float(prediction - observed_life),
                }
            )

        bpp_state_rows.append(
            {
                "cell_index": test_cell,
                "mean_log": bpp_mean,
                "var_log": bpp_var,
                "observed_threshold_life": observed_life,
                "predicted_threshold_life": bpp_prediction,
                "fold_train_abs_log_residual_q90": conformal_quantile(abs_train_residual, 0.90),
            }
        )

    prediction_df = pd.DataFrame(prediction_rows)
    summary_df = summarize_prediction_frame(prediction_df).sort_values("mae")

    bpp_state_df = pd.DataFrame(bpp_state_rows).set_index("cell_index")
    bpp_log_residual = np.log(bpp_state_df["observed_threshold_life"]) - np.log(
        bpp_state_df["predicted_threshold_life"]
    )
    loocv_residual_scale = float(np.sqrt(np.mean(np.square(bpp_log_residual))))
    interval_rows = []
    bpp_interval_rows = []
    for cell, row in bpp_state_df.iterrows():
        predictive_sd = float(np.sqrt(row["var_log"] + loocv_residual_scale**2))
        for level, z_value in ((90, 1.6448536269514722), (95, 1.959963984540054)):
            lower = float(np.exp(row["mean_log"] - z_value * predictive_sd))
            upper = float(np.exp(row["mean_log"] + z_value * predictive_sd))
            observed_life = float(row["observed_threshold_life"])
            interval_rows.append(
                {
                    "cell_index": cell,
                    "interval_level": level,
                    "lower": lower,
                    "upper": upper,
                    "covered": bool(lower <= observed_life <= upper),
                    "width": float(upper - lower),
                    "loocv_log_residual_scale": loocv_residual_scale,
                }
            )
            bpp_interval_rows.append(
                {
                    "cell_index": cell,
                    "interval_level": level,
                    "observed_threshold_life": observed_life,
                    "predicted_threshold_life": float(row["predicted_threshold_life"]),
                    "lower": lower,
                    "upper": upper,
                }
            )

    interval_detail_df = pd.DataFrame(interval_rows)
    interval_df = (
        interval_detail_df.groupby("interval_level", as_index=False)
        .agg(
            covered=("covered", "sum"),
            n=("covered", "size"),
            empirical_coverage=("covered", lambda values: 100.0 * float(np.mean(values))),
            median_width=("width", "median"),
        )
        .sort_values("interval_level")
    )
    bpp_interval_df = pd.DataFrame(bpp_interval_rows)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    prediction_df.to_csv(OUTPUT_DIR / "battery_threshold_predictions.csv", index=False)
    summary_df.to_csv(OUTPUT_DIR / "battery_method_summary.csv", index=False)
    interval_df.to_csv(OUTPUT_DIR / "battery_interval_summary.csv", index=False)
    bpp_interval_df.to_csv(OUTPUT_DIR / "battery_bpp_intervals.csv", index=False)
    return prediction_df, summary_df, interval_df, bpp_interval_df


def battery_ablation_table() -> pd.DataFrame:
    df = load_capacity_data()
    observed, q_ref = threshold_life(df)
    windows = raw_window_features(df, q_ref)

    rows = []
    for test_cell in observed.index:
        train_cells = observed.index.drop(test_cell)
        train_calibrated, test_calibrated = fit_calibrated_window_predictions(
            windows[windows["cell_index"].isin(train_cells)],
            observed.loc[train_cells],
            windows[windows["cell_index"] == test_cell],
        )
        observed_life = float(observed.loc[test_cell])

        variants = [
            (
                "Full Bayesian partial pooling",
                "Complete model",
                train_calibrated,
                test_calibrated,
                {},
            ),
            (
                "No fleet shrinkage",
                "Remove population prior",
                train_calibrated,
                test_calibrated,
                {"use_fleet_shrinkage": False},
            ),
            (
                "No partial pooling",
                "Window median",
                None,
                test_calibrated,
                {},
            ),
            (
                "Equal window reliability",
                "Use common window variance",
                train_calibrated,
                test_calibrated,
                {"use_window_reliability": False},
            ),
            (
                "No local-window calibration",
                "Use raw local extrapolations",
                windows[windows["cell_index"].isin(train_cells)].rename(columns={"raw_life": "window_lifetime"}),
                windows[windows["cell_index"] == test_cell].rename(columns={"raw_life": "window_lifetime"}),
                {},
            ),
        ]

        for method, perturbation, train_source, test_source, kwargs in variants:
            if train_source is None:
                prediction = float(test_source["window_lifetime"].median())
            else:
                prediction_df, _ = weighted_bayesian_partial_pooling(
                    train_source,
                    observed.loc[train_cells],
                    test_source,
                    **kwargs,
                )
                prediction = float(prediction_df.loc[test_cell, "prediction"])
            rows.append(
                {
                    "cell_index": test_cell,
                    "method": method,
                    "perturbation": perturbation,
                    "observed_threshold_life": observed_life,
                    "predicted_threshold_life": prediction,
                    "signed_error": prediction - observed_life,
                }
            )

    prediction_df = pd.DataFrame(rows)
    summary_df = summarize_prediction_frame(prediction_df)
    full_mae = float(summary_df.loc[summary_df["method"] == "Full Bayesian partial pooling", "mae"].iloc[0])
    order = [
        "Full Bayesian partial pooling",
        "No fleet shrinkage",
        "No partial pooling",
        "Equal window reliability",
        "No local-window calibration",
    ]
    perturbation_map = prediction_df.drop_duplicates("method").set_index("method")["perturbation"]
    summary_df["perturbation"] = summary_df["method"].map(perturbation_map)
    summary_df["delta_mae"] = summary_df["mae"] - full_mae
    summary_df["order"] = summary_df["method"].map({name: idx for idx, name in enumerate(order)})
    summary_df = summary_df.sort_values("order").drop(columns="order")
    summary_df.to_csv(OUTPUT_DIR / "battery_bpp_ablation_summary.csv", index=False)
    prediction_df.to_csv(OUTPUT_DIR / "battery_bpp_ablation_predictions.csv", index=False)
    return summary_df


def plot_capacity_trajectories() -> None:
    df = load_capacity_data()
    observed, q_ref = threshold_life(df)
    fig = plt.figure(figsize=FIGSIZE)
    ax = fig.gca()

    palette = [COLORS["blue"], COLORS["green"], COLORS["gold"], COLORS["navy"]]
    markers = ["o", "s", "^", "D"]
    linestyles = ["-", "--"]
    for index, (cell, group) in enumerate(df.groupby("cell_index", sort=True)):
        group = group.sort_values("cycle_index")
        color = palette[index % len(palette)]
        marker = markers[index % len(markers)]
        linestyle = linestyles[index // len(palette)]
        ax.plot(
            group["cycle_index"],
            group["discharge_capacity_ah"],
            color=color,
            linestyle=linestyle,
            linewidth=1.25,
            marker=marker,
            markevery=max(1, len(group) // 9),
            markersize=3.8,
            markerfacecolor=COLORS["paper"],
            markeredgewidth=0.75,
            markeredgecolor=COLORS["ink"],
            label=cell.replace("Cell", "Cell "),
            alpha=0.92,
        )

    threshold_capacity = float(THRESHOLD_RETENTION * q_ref.median())
    ax.axhline(
        threshold_capacity,
        color=COLORS["baseline"],
        linewidth=1.0,
        linestyle=(0, (4, 2)),
        label="95% retention",
    )
    ax.axvspan(0, PREFIX_CYCLES[-1], color=COLORS["sand"], alpha=0.38, linewidth=0, hatch="//")
    ax.set_xlabel("Cycle number")
    ax.set_ylabel("Discharge capacity (Ah)")
    ax.set_xlim(-100, float(df["cycle_index"].max()) + 250)
    ax.set_ylim(0.44, 0.76)
    polish_axis(ax, "both")
    ax.legend(
        ncol=3,
        frameon=False,
        facecolor="none",
        framealpha=0.0,
        loc="lower left",
        columnspacing=0.9,
        handlelength=1.7,
        handletextpad=0.45,
    )
    fig.tight_layout()
    save_figure(fig, "fig13_battery_capacity_trajectories")


def battery_prediction_table() -> pd.DataFrame:
    _, summary_df, _, _ = battery_results()
    return summary_df


def bootstrap_mae_ci(errors: np.ndarray, reps: int = BOOTSTRAP_REPS) -> tuple[float, float]:
    rng = np.random.default_rng(20260509)
    errors = np.abs(np.asarray(errors, dtype=float))
    samples = rng.choice(errors, size=(reps, len(errors)), replace=True)
    boot = samples.mean(axis=1)
    return float(np.quantile(boot, 0.025)), float(np.quantile(boot, 0.975))


def plot_error_ranking() -> None:
    prediction_df, summary_df, _, _ = battery_results()
    ci_rows = []
    for method, chunk in prediction_df.groupby("method"):
        low, high = bootstrap_mae_ci(chunk["signed_error"].to_numpy(dtype=float))
        ci_rows.append({"method": method, "mae_low": low, "mae_high": high})
    plot_df = summary_df.merge(pd.DataFrame(ci_rows), on="method").sort_values("mae", ascending=True)
    y = np.arange(len(plot_df))

    fig = plt.figure(figsize=FIGSIZE, constrained_layout=True)
    ax = fig.gca()
    bar_colors = []
    hatches = []
    for method in plot_df["method"]:
        style = BATTERY_METHOD_STYLES.get(method, {"color": COLORS["gray"], "hatch": ".."})
        bar_colors.append(style["color"])
        hatches.append(style["hatch"])

    bars = ax.barh(
        y,
        plot_df["mae"],
        color=bar_colors,
        edgecolor=COLORS["ink"],
        linewidth=0.8,
        height=0.68,
    )
    for bar, hatch in zip(bars, hatches):
        bar.set_hatch(hatch)

    xerr = np.vstack(
        [
            plot_df["mae"] - plot_df["mae_low"],
            plot_df["mae_high"] - plot_df["mae"],
        ]
    )
    ax.errorbar(
        plot_df["mae"],
        y,
        xerr=xerr,
        fmt="none",
        ecolor=COLORS["ink"],
        elinewidth=0.8,
        capsize=3,
        capthick=0.8,
        zorder=3,
    )
    max_x = float(plot_df["mae_high"].max())
    label_offset = max_x * 0.025
    label_positions = []
    for yi, value, high in zip(y, plot_df["mae"], plot_df["mae_high"]):
        label_x = max(float(value), float(high)) + label_offset
        label_positions.append(label_x)
        ax.text(label_x, yi, f"{value:.1f}", va="center", ha="left", fontsize=11)

    ax.set_yticks(y)
    ax.set_yticklabels([METHOD_DISPLAY[m] for m in plot_df["method"]])
    ax.invert_yaxis()
    ax.set_xlabel("LOOCV MAE (cycles)")
    ax.set_xlim(0, max(max_x * 1.18, max(label_positions) * 1.08))
    polish_axis(ax, "x")
    save_figure(fig, "fig14_battery_error_ranking")


def plot_predicted_vs_observed() -> None:
    prediction_df, _, _, bpp_interval_df = battery_results()
    bpp_df = prediction_df[prediction_df["method"] == "Bayesian partial pooling"].copy()
    intervals = bpp_interval_df[bpp_interval_df["interval_level"] == 95].set_index("cell_index")
    bpp_df = bpp_df.join(intervals[["lower", "upper"]], on="cell_index")

    fig = plt.figure(figsize=FIGSIZE, constrained_layout=True)
    ax = fig.gca()
    observed = bpp_df["observed_threshold_life"].to_numpy(dtype=float)
    predicted = bpp_df["predicted_threshold_life"].to_numpy(dtype=float)
    lower = bpp_df["lower"].to_numpy(dtype=float)
    upper = bpp_df["upper"].to_numpy(dtype=float)
    yerr = np.vstack([predicted - lower, upper - predicted])

    min_axis = float(min(observed.min(), lower.min()) - 70)
    max_axis = float(max(observed.max(), upper.max()) + 80)
    ax.plot([min_axis, max_axis], [min_axis, max_axis], color=COLORS["baseline"], linewidth=1.0, linestyle="--")
    ax.errorbar(
        observed,
        predicted,
        yerr=yerr,
        fmt="o",
        markersize=5.5,
        color=COLORS["accent"],
        markerfacecolor=COLORS["paper"],
        markeredgecolor=COLORS["ink"],
        markeredgewidth=0.9,
        ecolor=COLORS["accent"],
        elinewidth=1.0,
        capsize=3,
        capthick=0.9,
        label="Bayesian partial pooling with 95% interval",
    )
    label_offsets = {
        "Cell1": (-44, 22),
        "Cell2": (18, 18),
        "Cell3": (18, -16),
        "Cell4": (18, 18),
        "Cell5": (-54, -22),
        "Cell6": (-40, -18),
        "Cell7": (18, 18),
        "Cell8": (18, 18),
    }
    for _, row in bpp_df.iterrows():
        dx, dy = label_offsets.get(row["cell_index"], (13, 13))
        ax.text(
            row["observed_threshold_life"] + dx,
            row["predicted_threshold_life"] + dy,
            row["cell_index"].replace("Cell", "C"),
            fontsize=11,
        )

    ax.set_xlabel("Observed threshold life (cycles)")
    ax.set_ylabel("Predicted threshold life (cycles)")
    ax.set_xlim(min_axis, max_axis)
    ax.set_ylim(min_axis, max_axis)
    polish_axis(ax, "both")
    ax.legend(frameon=False, facecolor="none", framealpha=0.0, loc="lower right")
    save_figure(fig, "fig15_battery_predicted_vs_observed")


def main() -> None:
    warnings.filterwarnings("ignore", category=UserWarning, module="sklearn")
    apply_style()
    clear_generated_figures()
    if not CAPACITY_CSV.exists():
        extract_oxford_capacity()
    battery_ablation_table()
    plot_capacity_trajectories()
    plot_error_ranking()
    plot_predicted_vs_observed()


if __name__ == "__main__":
    main()


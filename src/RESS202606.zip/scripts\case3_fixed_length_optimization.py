# -*- coding: utf-8 -*-
"""Run Case Study III: fixed-length inspection baselines.

This script optimizes fixed inspection-count policies for n = 1, 2, 3, and 4.
For each n, it searches inspection times and maintenance thresholds with a
two-objective NSGA-II algorithm, then aggregates the fixed-n fronts for comparison
with the variable-length policy.

Outputs are written to outputs/case3/ and are used by the manuscript's Case
Study III tables and Fig. 14. The script is standalone and does not import other
project scripts.
"""

from __future__ import annotations

# Article mapping:
# - Case Study III, fixed-length inspection baselines for n = 1, 2, 3, 4.
# - Generates outputs/case3/fixed_n_*/ and outputs/case3/all_fixed_n/ for Fig. 14
#   and fixed-n comparison tables.
# - Standalone by design: no imports from other project scripts and no writes to
#   LaTeX/submission folders.

import os
import math
import json
import argparse
from dataclasses import dataclass
from typing import Tuple, List, Dict, Any

import numpy as np
import pandas as pd


# tqdm (ETA progress bars)
try:
    from tqdm.auto import tqdm, trange  # type: ignore
except Exception:
    tqdm = None
    trange = None

BAR_FMT = "{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]"

# Resolve inputs and outputs from the project root, independent of the shell's
# current working directory.
WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


# -----------------------------
# Repro / runtime
# -----------------------------
SEED = 123

N_MC = 60000
POP_SIZE = 100
N_GEN = 100
ARCHIVE_MAX = 3000


# -----------------------------
# Fixed-n runs
# -----------------------------
N_LIST = [1, 2, 3, 4]
N_MAX_FOR_PRESAMPLE = int(max(N_LIST))


# -----------------------------
# Schedule constraints
# -----------------------------
MIN_GAP_H = 100.0
T_HORIZON_H = 8000.0

T1_MIN = 80.0
T1_MAX = 4000.0


# -----------------------------
# Degradation model
# -----------------------------
B_CENTER = 0.10
B_SD = 0.042
B_MIN = 0.01
B_MAX = 0.30
c_MEDIAN = 0.0873
c_LN_SD = 0.05

x_th = 0.20
x_min = 1e-3


# -----------------------------
# Shallow screening outcome model: PoD drives the binary alarm, from which
# TP/FN/FP/TN are counted relative to x_A; deep confirmation is deterministic.
# -----------------------------
POD_X50_REF = 0.10
POD_PMIN_AT_XMIN = 1.0e-3
POD_BETA = math.log(POD_PMIN_AT_XMIN / (1.0 - POD_PMIN_AT_XMIN)) / math.log(x_min / POD_X50_REF)
POD_ALPHA = -POD_BETA * math.log(POD_X50_REF)


# -----------------------------
# Maintenance effects
# -----------------------------
TEFF_A_MEAN = 1000.0
TEFF_A_SD = 500.0


# -----------------------------
# Costs (NO lab-time monetization)
# -----------------------------
COST_INSP_SHALLOW = 1.0
COST_INSP_DEEP = 3.0
COST_MAINT_A = 15.0
COST_MAINT_B = 50.0


# -----------------------------
# Threshold constraints
# -----------------------------
X_A_MIN = 0.02
X_A_MAX = 0.12
MIN_AB_GAP = 0.02
X_B_EPS = 1e-3


# -----------------------------
# Encoding bounds
# x = [t1, extra2..extra_n, x_A, x_B]
# -----------------------------
EXTRA_MAX = 4000.0


# -----------------------------
# Utilities
# -----------------------------

def ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)


def lognormal_mu_sigma_from_mean_sd(mean: float, sd: float) -> Tuple[float, float]:
    var = sd ** 2
    sigma2 = math.log(1.0 + var / (mean ** 2))
    sigma = math.sqrt(sigma2)
    mu = math.log(mean) - 0.5 * sigma2
    return mu, sigma


def sample_b_random_effect(rng: np.random.Generator, size) -> np.ndarray:
    """Bounded logistic-normal random effect for the power-law exponent b."""
    y = (B_CENTER - B_MIN) / (B_MAX - B_MIN)
    eta_mu = math.log(y / (1.0 - y))
    eta_sigma = B_SD / ((B_MAX - B_MIN) * y * (1.0 - y))
    eta = rng.normal(loc=eta_mu, scale=eta_sigma, size=size)
    return B_MIN + (B_MAX - B_MIN) / (1.0 + np.exp(-eta))


def logistic_stable(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z)
    out = np.empty_like(z, dtype=float)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1.0 + ez)
    return out


def pod_shallow(delta: np.ndarray) -> np.ndarray:
    d = np.asarray(delta, dtype=float)
    out = np.zeros_like(d)
    m = d > x_min
    if np.any(m):
        z = POD_ALPHA + POD_BETA * np.log(d[m])
        out[m] = logistic_stable(z)
    return np.clip(out, 0.0, 1.0)


def sample_tlife0_from_pdf(csv_path: str, n: int, rng: np.random.Generator) -> np.ndarray:
    df = pd.read_csv(csv_path)
    if "t" not in df.columns or "pdf" not in df.columns:
        raise ValueError("tlife0_pdf.csv must contain columns: t, pdf")

    t = df["t"].to_numpy(dtype=float)
    p = df["pdf"].to_numpy(dtype=float)
    if np.any(t <= 0) or np.any(p < 0):
        raise ValueError("PDF requires t>0 and pdf>=0.")

    order = np.argsort(t)
    t = t[order]
    p = p[order]

    cdf = np.zeros_like(t)
    area = 0.0
    for i in range(1, len(t)):
        area += 0.5 * (p[i - 1] + p[i]) * (t[i] - t[i - 1])
        cdf[i] = area
    if area <= 0:
        raise ValueError("PDF integrates to zero.")
    cdf /= area

    u = rng.random(n)
    return np.interp(u, cdf, t)


# -----------------------------
# Decode / repair for fixed n
# -----------------------------

def decode_and_repair_fixed(x: np.ndarray, n: int) -> Tuple[np.ndarray, float, float]:
    """Return (t_schedule (len n), x_A, x_B)."""
    x = np.asarray(x, dtype=float)
    if n < 1:
        raise ValueError("n must be >=1")

    # thresholds with constraints
    x_A = float(np.clip(x[-2], X_A_MIN, X_A_MAX - 1e-12))
    x_B_lo = x_A + MIN_AB_GAP
    x_B_hi = x_th - X_B_EPS
    if x_B_lo > x_B_hi:
        x_A = max(X_A_MIN, x_B_hi - MIN_AB_GAP)
        x_A = min(x_A, X_A_MAX - 1e-12)
        x_B_lo = x_A + MIN_AB_GAP
    x_B = float(np.clip(x[-1], x_B_lo, x_B_hi))

    # t1 bounded by minimum required span
    min_span = (n - 1) * MIN_GAP_H
    t1_hi = min(T1_MAX, T_HORIZON_H - min_span)
    t1 = float(np.clip(x[0], T1_MIN, t1_hi))

    if n == 1:
        return np.array([t1], dtype=float), x_A, x_B

    extras = np.clip(x[1:1 + (n - 1)], 0.0, EXTRA_MAX)

    base = MIN_GAP_H * (n - 1)
    avail = T_HORIZON_H - t1
    slack = max(0.0, avail - base)

    s_ex = float(np.sum(extras))
    if s_ex <= 1e-12:
        scale = 0.0
    else:
        scale = min(1.0, slack / s_ex)

    gaps = MIN_GAP_H + extras * scale

    t = np.empty(n, dtype=float)
    t[0] = t1
    for i in range(1, n):
        t[i] = t[i - 1] + gaps[i - 1]
    t[-1] = min(t[-1], T_HORIZON_H)

    return t, x_A, x_B


def repair_vector_fixed(x: np.ndarray, n: int) -> np.ndarray:
    x = np.asarray(x, dtype=float).copy()

    # structure: [t1, extras...(n-1), x_A, x_B]
    x[0] = float(np.clip(x[0], T1_MIN, T1_MAX))
    if n > 1:
        x[1:1 + (n - 1)] = np.clip(x[1:1 + (n - 1)], 0.0, EXTRA_MAX)

    x[-2] = float(np.clip(x[-2], X_A_MIN, X_A_MAX))
    x[-1] = float(np.clip(x[-1], X_A_MIN + MIN_AB_GAP, x_th - X_B_EPS))

    # re-decode to enforce coupling constraints and horizon scaling
    t, x_A, x_B = decode_and_repair_fixed(x, n)
    x[-2] = x_A
    x[-1] = x_B

    # re-encode extras from the (possibly scaled) schedule
    if n > 1:
        gaps = np.diff(t)
        extras = np.clip(gaps - MIN_GAP_H, 0.0, EXTRA_MAX)
        x[1:1 + (n - 1)] = extras

    # make sure t1 feasible w.r.t min span
    min_span = (n - 1) * MIN_GAP_H
    t1_hi = min(T1_MAX, T_HORIZON_H - min_span)
    x[0] = float(np.clip(x[0], T1_MIN, t1_hi))

    return x


# -----------------------------
# Monte Carlo presampling (common random numbers across n)
# -----------------------------

@dataclass
class PreSample:
    # cycle parameters for up to (N_MAX_FOR_PRESAMPLE) replacements => cycles = N_MAX_FOR_PRESAMPLE+1
    c_cycle: np.ndarray        # shape (N_MC, N_CYCLES)
    b_cycle: np.ndarray        # shape (N_MC, N_CYCLES)
    tfail0_cycle: np.ndarray   # shape (N_MC, N_CYCLES)

    # shallow indication uniforms at each scheduled inspection
    u_shallow: np.ndarray      # shape (N_MC, N_MAX_FOR_PRESAMPLE)

    # maintenance A teff draws at each inspection
    teffA: np.ndarray          # shape (N_MC, N_MAX_FOR_PRESAMPLE)


def presample_mc(n: int, seed: int) -> PreSample:
    rng = np.random.default_rng(seed)
    n_cycles = N_MAX_FOR_PRESAMPLE + 1

    pdf_path = os.path.join(WORKSPACE_ROOT, "data", "tlife0_pdf.csv")
    b = sample_b_random_effect(rng, (n, n_cycles))
    if os.path.exists(pdf_path):
        tf = sample_tlife0_from_pdf(pdf_path, n * n_cycles, rng).reshape(n, n_cycles)
        c = (x_th / (tf ** b))
    else:
        c = rng.lognormal(mean=math.log(c_MEDIAN), sigma=c_LN_SD, size=(n, n_cycles))
        tf = (x_th / c) ** (1.0 / b)

    u_shallow = rng.random((n, N_MAX_FOR_PRESAMPLE))

    mu_te, sig_te = lognormal_mu_sigma_from_mean_sd(TEFF_A_MEAN, TEFF_A_SD)
    teffA = rng.lognormal(mean=mu_te, sigma=sig_te, size=(n, N_MAX_FOR_PRESAMPLE))

    return PreSample(c_cycle=c, b_cycle=b, tfail0_cycle=tf, u_shallow=u_shallow, teffA=teffA)


# -----------------------------
# Policy simulation (vectorized over MC samples) for fixed n
# -----------------------------

def simulate_policy_fixed(x: np.ndarray, S: PreSample, n: int) -> Tuple[float, float, float, float, str, float, float, float, float, float, float, float]:
    """Returns:
    (E_cost, E_life, E_num_maintA, E_num_maintB, t_schedule_str, x_A, x_B,
     E_num_FP, E_num_TP, E_num_FN, E_num_TN, E_num_deep)
    """
    t_sched, x_A, x_B = decode_and_repair_fixed(x, n)

    N = S.u_shallow.shape[0]
    idxN = np.arange(N)

    active = np.ones(N, dtype=bool)
    t0 = np.zeros(N, dtype=float)      # cycle start (absolute)
    delay = np.zeros(N, dtype=float)   # virtual time delay
    cyc = np.zeros(N, dtype=int)       # cycle index (replacement count)

    total_cost = np.zeros(N, dtype=float)
    nA = np.zeros(N, dtype=float)
    nB = np.zeros(N, dtype=float)
    n_fp = np.zeros(N, dtype=float)
    n_tp = np.zeros(N, dtype=float)
    n_fn = np.zeros(N, dtype=float)
    n_tn = np.zeros(N, dtype=float)
    n_deep = np.zeros(N, dtype=float)

    def c_now() -> np.ndarray:
        return S.c_cycle[idxN, cyc]

    def b_now() -> np.ndarray:
        return S.b_cycle[idxN, cyc]

    def tfail0_now() -> np.ndarray:
        return S.tfail0_cycle[idxN, cyc]

    def tfail_abs() -> np.ndarray:
        return t0 + delay + tfail0_now()

    def damage_at(t: float) -> np.ndarray:
        teff = np.maximum(t - t0 - delay, 0.0)
        return c_now() * (teff ** b_now())

    for i in range(n):
        t = float(t_sched[i])

        do_shallow = active.copy()
        if not np.any(do_shallow):
            break

        # Eq. 10a: scheduled shallow cost always charged for active units
        total_cost[do_shallow] += COST_INSP_SHALLOW

        # if already failed before this inspection, discover now and terminate thereafter
        failed_before = do_shallow & (t > tfail_abs())
        if np.any(failed_before):
            active[failed_before] = False

        alive = do_shallow & (~failed_before)
        if not np.any(alive):
            continue

        d = damage_at(t)
        p = pod_shallow(d)
        ind = alive & (S.u_shallow[:, i] < p)
        true_defect = d >= x_A
        no_alarm = alive & (~ind)
        n_fp[ind & (~true_defect)] += 1.0
        n_tp[ind & true_defect] += 1.0
        n_fn[no_alarm & true_defect] += 1.0
        n_tn[no_alarm & (~true_defect)] += 1.0
        if not np.any(ind):
            continue

        # deep deterministic (perfect confirmation)
        # Deep confirmation is performed after every shallow alarm. If d < x_A,
        # the alarm is a false positive: only the deep-inspection cost is added,
        # and no maintenance/state update follows. If d >= x_A, the alarm is a
        # true positive and can trigger Action A or B below.
        total_cost[ind] += COST_INSP_DEEP
        n_deep[ind] += 1.0

        # Maintenance B (replacement) if delta >= x_B
        do_B = ind & (d >= x_B)
        if np.any(do_B):
            total_cost[do_B] += COST_MAINT_B
            nB[do_B] += 1.0
            t0[do_B] = t
            delay[do_B] = 0.0
            cyc[do_B] = np.minimum(cyc[do_B] + 1, N_MAX_FOR_PRESAMPLE)

        # Maintenance A if x_A <= delta < x_B
        do_A = ind & (~do_B) & (d >= x_A)
        if np.any(do_A):
            total_cost[do_A] += COST_MAINT_A
            nA[do_A] += 1.0
            delay[do_A] += S.teffA[do_A, i]

    life = np.minimum(tfail_abs(), T_HORIZON_H)

    t_schedule_str = ",".join([f"{tt:.3f}" for tt in t_sched])
    return (
        float(np.mean(total_cost)),
        float(np.mean(life)),
        float(np.mean(nA)),
        float(np.mean(nB)),
        t_schedule_str,
        float(x_A),
        float(x_B),
        float(np.mean(n_fp)),
        float(np.mean(n_tp)),
        float(np.mean(n_fn)),
        float(np.mean(n_tn)),
        float(np.mean(n_deep)),
    )


# -----------------------------
# NSGA-II (2 objectives) for fixed n
# -----------------------------

def dominates_2d(fa: Tuple[float, float], fb: Tuple[float, float]) -> bool:
    # minimization
    return (fa[0] <= fb[0] and fa[1] <= fb[1]) and (fa[0] < fb[0] or fa[1] < fb[1])


def fast_nondominated_sort_2d(F: List[Tuple[float, float]]) -> List[List[int]]:
    n = len(F)
    Sset = [set() for _ in range(n)]
    n_dom = np.zeros(n, dtype=int)
    fronts: List[List[int]] = [[]]

    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if dominates_2d(F[p], F[q]):
                Sset[p].add(q)
            elif dominates_2d(F[q], F[p]):
                n_dom[p] += 1
        if n_dom[p] == 0:
            fronts[0].append(p)

    i = 0
    while fronts[i]:
        nxt: List[int] = []
        for p in fronts[i]:
            for q in Sset[p]:
                n_dom[q] -= 1
                if n_dom[q] == 0:
                    nxt.append(q)
        i += 1
        fronts.append(nxt)

    fronts.pop()
    return fronts


def crowding_distance_2d(F: List[Tuple[float, float]], front: List[int]) -> np.ndarray:
    dist = np.zeros(len(front), dtype=float)
    if len(front) == 0:
        return dist
    if len(front) <= 2:
        dist[:] = np.inf
        return dist

    vals = np.array([F[i] for i in front], dtype=float)
    for j in range(2):
        order = np.argsort(vals[:, j])
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf
        vmin = vals[order[0], j]
        vmax = vals[order[-1], j]
        if vmax - vmin < 1e-12:
            continue
        for k in range(1, len(front) - 1):
            dist[order[k]] += (vals[order[k + 1], j] - vals[order[k - 1], j]) / (vmax - vmin)

    return dist


def tournament_select(rng: np.random.Generator, idx: np.ndarray, ranks: np.ndarray, crowds: np.ndarray) -> int:
    a, b = rng.choice(idx, size=2, replace=False)
    if ranks[a] < ranks[b]:
        return int(a)
    if ranks[b] < ranks[a]:
        return int(b)
    return int(a if crowds[a] > crowds[b] else b)


def sbx_crossover(rng: np.random.Generator, p1: np.ndarray, p2: np.ndarray,
                  bounds: List[Tuple[float, float]], eta: float = 15.0, p_c: float = 0.9) -> Tuple[np.ndarray, np.ndarray]:
    c1, c2 = p1.copy(), p2.copy()
    if rng.random() > p_c:
        return c1, c2

    for i, (xL, xU) in enumerate(bounds):
        x1, x2 = float(p1[i]), float(p2[i])
        if abs(x1 - x2) < 1e-12:
            continue
        if x1 > x2:
            x1, x2 = x2, x1
        u = rng.random()

        beta = 1.0 + (2.0 * (x1 - xL) / (x2 - x1))
        alpha = 2.0 - beta ** (-(eta + 1.0))
        if u <= 1.0 / alpha:
            betaq = (u * alpha) ** (1.0 / (eta + 1.0))
        else:
            betaq = (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0))
        child1 = 0.5 * ((x1 + x2) - betaq * (x2 - x1))

        beta = 1.0 + (2.0 * (xU - x2) / (x2 - x1))
        alpha = 2.0 - beta ** (-(eta + 1.0))
        if u <= 1.0 / alpha:
            betaq = (u * alpha) ** (1.0 / (eta + 1.0))
        else:
            betaq = (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0))
        child2 = 0.5 * ((x1 + x2) + betaq * (x2 - x1))

        c1[i] = float(np.clip(child1, xL, xU))
        c2[i] = float(np.clip(child2, xL, xU))

    return c1, c2


def poly_mutation(rng: np.random.Generator, x: np.ndarray,
                  bounds: List[Tuple[float, float]], eta: float = 20.0, p_m: float = 0.18) -> np.ndarray:
    y = x.copy()
    for i, (xL, xU) in enumerate(bounds):
        if rng.random() > p_m:
            continue
        xi = float(y[i])
        if xU - xL < 1e-12:
            continue
        delta1 = (xi - xL) / (xU - xL)
        delta2 = (xU - xi) / (xU - xL)
        u = rng.random()
        mut_pow = 1.0 / (eta + 1.0)
        if u < 0.5:
            xy = 1.0 - delta1
            val = 2.0 * u + (1.0 - 2.0 * u) * (xy ** (eta + 1.0))
            dq = val ** mut_pow - 1.0
        else:
            xy = 1.0 - delta2
            val = 2.0 * (1.0 - u) + 2.0 * (u - 0.5) * (xy ** (eta + 1.0))
            dq = 1.0 - val ** mut_pow
        xi = xi + dq * (xU - xL)
        y[i] = float(np.clip(xi, xL, xU))

    return y


def evaluate_population_fixed(X: np.ndarray, S: PreSample, n: int, desc: str, leave: bool, position: int):
    """Evaluate a population for fixed n.

    Returns arrays:
      cost, life, nA, nB, t_schedule_str, x_A, x_B, nFP, nTP, nFN, nTN, nDeep
    """
    m = X.shape[0]
    cost = np.zeros(m)
    life = np.zeros(m)
    nA = np.zeros(m)
    nB = np.zeros(m)
    ts = np.empty(m, dtype=object)
    aA = np.zeros(m)
    aB = np.zeros(m)
    nFP = np.zeros(m)
    nTP = np.zeros(m)
    nFN = np.zeros(m)
    nTN = np.zeros(m)
    nDeep = np.zeros(m)

    it = range(m)
    if tqdm is not None:
        it = tqdm(
            it,
            desc=desc,
            leave=leave,
            position=position,
            bar_format=BAR_FMT,
            dynamic_ncols=True,
            mininterval=0.5,
            smoothing=0.1,
        )

    for i in it:
        c, l, ma, mb, tstr, aa, ab, fp, tp, fn, tn, nd = simulate_policy_fixed(X[i], S, n)
        cost[i] = c
        life[i] = l
        nA[i] = ma
        nB[i] = mb
        ts[i] = tstr
        aA[i] = aa
        aB[i] = ab
        nFP[i] = fp
        nTP[i] = tp
        nFN[i] = fn
        nTN[i] = tn
        nDeep[i] = nd

    return cost, life, nA, nB, ts, aA, aB, nFP, nTP, nFN, nTN, nDeep


def nondominated_mask_2d(cost: np.ndarray, neg_life: np.ndarray) -> np.ndarray:
    m = len(cost)
    keep = np.ones(m, dtype=bool)
    for i in range(m):
        if not keep[i]:
            continue
        for j in range(m):
            if i == j or not keep[i]:
                continue
            if (cost[j] <= cost[i] and neg_life[j] <= neg_life[i]) and (cost[j] < cost[i] or neg_life[j] < neg_life[i]):
                keep[i] = False
                break
    return keep


def update_archive_2d(archive: Dict[str, Any], X: np.ndarray, objs: np.ndarray, extra: np.ndarray, max_size: int) -> None:
    # objs: [cost, -life]
    if archive["X"].size == 0:
        archive["X"] = X.copy()
        archive["objs"] = objs.copy()
        archive["extra"] = extra.copy()
    else:
        archive["X"] = np.vstack([archive["X"], X])
        archive["objs"] = np.vstack([archive["objs"], objs])
        archive["extra"] = np.vstack([archive["extra"], extra])

    keep = nondominated_mask_2d(archive["objs"][:, 0], archive["objs"][:, 1])
    archive["X"] = archive["X"][keep]
    archive["objs"] = archive["objs"][keep]
    archive["extra"] = archive["extra"][keep]

    if archive["X"].shape[0] > max_size:
        idx = list(range(archive["X"].shape[0]))
        F_list = [(float(archive["objs"][i, 0]), float(archive["objs"][i, 1])) for i in idx]
        cd = crowding_distance_2d(F_list, idx)
        order = np.argsort(-cd)
        sel = order[:max_size]
        archive["X"] = archive["X"][sel]
        archive["objs"] = archive["objs"][sel]
        archive["extra"] = archive["extra"][sel]


def nsga2_optimize_fixed_n(n: int, S: PreSample, seed: int = SEED) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)

    # dim: t1 + (n-1) extras + x_A + x_B
    dim = 1 + max(0, n - 1) + 2

    # bounds for genetic operators (coarse; repaired after)
    bounds: List[Tuple[float, float]] = []
    bounds.append((T1_MIN, T1_MAX))
    for _ in range(max(0, n - 1)):
        bounds.append((0.0, EXTRA_MAX))
    bounds.append((X_A_MIN, X_A_MAX))
    bounds.append((X_A_MIN + MIN_AB_GAP, x_th))

    # init
    X = np.zeros((POP_SIZE, dim), dtype=float)
    for i in range(POP_SIZE):
        t1 = rng.uniform(T1_MIN, T1_MAX)
        extras = rng.uniform(0.0, EXTRA_MAX, size=(max(0, n - 1),))
        aA = rng.uniform(X_A_MIN, X_A_MAX)
        aB = rng.uniform(aA + MIN_AB_GAP, x_th - X_B_EPS)
        x = np.concatenate([[t1], extras, [aA, aB]]).astype(float)
        X[i] = repair_vector_fixed(x, n)

    archive = dict(
        X=np.empty((0, dim), dtype=float),
        objs=np.empty((0, 2), dtype=float),
        extra=np.empty((0, 10), dtype=object),  # [t_schedule, x_A, x_B, E_num_maintA, E_num_maintB, E_num_FP, E_num_TP, E_num_FN, E_num_TN, E_num_deep]
    )

    gen_it = (
        trange(
            N_GEN,
            desc=f"NSGA-II (n={n})",
            bar_format=BAR_FMT,
            dynamic_ncols=True,
            mininterval=0.5,
            smoothing=0.1,
            position=0,
        )
        if trange is not None else range(N_GEN)
    )

    for _ in gen_it:
        # evaluate current pop
        cost, life, nA, nB, ts, aA, aB, nFP, nTP, nFN, nTN, nDeep = evaluate_population_fixed(
            X, S, n, desc=f"Eval(pop) n={n}", leave=False, position=1
        )
        objs = np.column_stack([cost, -life])
        extra = np.array(
            [
                [
                    ts[i], float(aA[i]), float(aB[i]), float(nA[i]), float(nB[i]),
                    float(nFP[i]), float(nTP[i]), float(nFN[i]), float(nTN[i]), float(nDeep[i]),
                ]
                for i in range(POP_SIZE)
            ],
            dtype=object,
        )
        update_archive_2d(archive, X, objs, extra, ARCHIVE_MAX)

        # ranks+crowding
        F_list = [(float(objs[i, 0]), float(objs[i, 1])) for i in range(POP_SIZE)]
        fronts = fast_nondominated_sort_2d(F_list)

        ranks = np.full(POP_SIZE, 10**9, dtype=int)
        crowds = np.zeros(POP_SIZE, dtype=float)
        for r, fr in enumerate(fronts):
            for idx in fr:
                ranks[idx] = r
            cd = crowding_distance_2d(F_list, fr)
            for j, idx in enumerate(fr):
                crowds[idx] = cd[j]

        # offspring
        offspring = []
        idx_all = np.arange(POP_SIZE)
        while len(offspring) < POP_SIZE:
            p1 = X[tournament_select(rng, idx_all, ranks, crowds)]
            p2 = X[tournament_select(rng, idx_all, ranks, crowds)]
            c1, c2 = sbx_crossover(rng, p1, p2, bounds=bounds)
            c1 = poly_mutation(rng, c1, bounds=bounds)
            c2 = poly_mutation(rng, c2, bounds=bounds)
            c1 = repair_vector_fixed(c1, n)
            c2 = repair_vector_fixed(c2, n)
            offspring.append(c1)
            if len(offspring) < POP_SIZE:
                offspring.append(c2)
        X_off = np.array(offspring, dtype=float)

        # union + environmental selection
        X_u = np.vstack([X, X_off])
        cost_u, life_u, _, _, _, _, _, _, _, _, _, _ = evaluate_population_fixed(
            X_u, S, n, desc=f"Eval(union) n={n}", leave=False, position=1
        )
        objs_u = np.column_stack([cost_u, -life_u])
        F_u = [(float(objs_u[i, 0]), float(objs_u[i, 1])) for i in range(X_u.shape[0])]
        fronts_u = fast_nondominated_sort_2d(F_u)

        sel: List[int] = []
        for fr in fronts_u:
            if len(sel) + len(fr) <= POP_SIZE:
                sel.extend(fr)
            else:
                cd = crowding_distance_2d(F_u, fr)
                order = np.argsort(-cd)
                need = POP_SIZE - len(sel)
                sel.extend([fr[i] for i in order[:need]])
                break

        X = X_u[np.array(sel, dtype=int)]

    return {"archive": archive}


# -----------------------------
# DataFrames + representative tables
# -----------------------------

def build_pareto_dataframe_fixed(archive: Dict[str, Any], n: int) -> pd.DataFrame:
    X = archive["X"]
    objs = archive["objs"]
    extra = archive["extra"]

    df = pd.DataFrame({
        "E_cost": objs[:, 0].astype(float),
        "E_life_h": (-objs[:, 1]).astype(float),
        "n_insp": int(n),
        "x_A": extra[:, 1].astype(float),
        "x_B": extra[:, 2].astype(float),
        "E_num_maintA": extra[:, 3].astype(float),
        "E_num_maintB": extra[:, 4].astype(float),
        "E_num_FP": extra[:, 5].astype(float),
        "E_num_TP": extra[:, 6].astype(float),
        "E_num_FN": extra[:, 7].astype(float),
        "E_num_TN": extra[:, 8].astype(float),
        "E_num_deep": extra[:, 9].astype(float),
        "t_schedule": extra[:, 0].astype(str),
    })

    df = df.sort_values(["E_cost", "E_life_h"], ascending=[True, False]).reset_index(drop=True)
    return df


def representative_table_2d(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    c = df["E_cost"].to_numpy()
    picks = []
    for tag, q in (("Q25", 0.25), ("Q50", 0.50), ("Q75", 0.75)):
        target = np.quantile(c, q)
        idx = int(np.argmin(np.abs(c - target)))
        picks.append((tag, idx))

    seen, rows = set(), []
    for tag, idx in picks:
        if idx in seen:
            continue
        seen.add(idx)
        r = df.iloc[idx].to_dict()
        r["Tag"] = tag
        rows.append(r)

    out = pd.DataFrame(rows)
    cols = [
        "Tag", "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
        "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
        "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
    ]
    return out[cols]


def pareto_mask_2d_life_cost(df: pd.DataFrame) -> np.ndarray:
    """2D Pareto in (maximize life, minimize cost)."""
    vals = df[["E_life_h", "E_cost"]].to_numpy()
    is_pareto = np.ones(vals.shape[0], dtype=bool)
    for i, (x, y) in enumerate(vals):
        if np.any((vals[:, 0] >= x) & (vals[:, 1] <= y) & ((vals[:, 0] > x) | (vals[:, 1] < y))):
            is_pareto[i] = False
    return is_pareto


def global_representative_table(df_all: pd.DataFrame) -> pd.DataFrame:
    """Q25/Q50/Q75 on the GLOBAL 2D envelope (maximize life, minimize cost)."""
    if df_all.empty:
        return df_all

    is_pareto = pareto_mask_2d_life_cost(df_all)
    df_front = df_all[is_pareto].copy().reset_index(drop=True)
    if df_front.empty:
        return df_front

    c = df_front["E_cost"].to_numpy()
    picks = []
    for tag, q in (("Q25", 0.25), ("Q50", 0.50), ("Q75", 0.75)):
        target = np.quantile(c, q)
        idx = int(np.argmin(np.abs(c - target)))
        picks.append((tag, idx))

    rows = []
    for tag, idx in picks:
        r = df_front.iloc[idx].to_dict()
        r["Tag"] = tag
        rows.append(r)

    out = pd.DataFrame(rows)
    cols = [
        "Tag", "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
        "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
        "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
    ]
    return out[cols]


# -----------------------------
# Settings
# -----------------------------

def collect_settings_common() -> Dict[str, Any]:
    return {
        "SEED": SEED,
        "N_MC": N_MC,
        "POP_SIZE": POP_SIZE,
        "N_GEN": N_GEN,
        "N_LIST": N_LIST,
        "MIN_GAP_H": MIN_GAP_H,
        "T_HORIZON_H": T_HORIZON_H,
        "B_model": "bounded logistic-normal random effect",
        "B_CENTER": B_CENTER,
        "B_SD": B_SD,
        "B_MIN": B_MIN,
        "B_MAX": B_MAX,
        "x_th": x_th,
        "c_MEDIAN": c_MEDIAN,
        "c_LN_SD": c_LN_SD,
        "x_min": x_min,
        "POD_CALIBRATION": "two-point reference: PoD(x_min)=1e-3 and PoD(x50)=0.5",
        "POD_X50_REF": POD_X50_REF,
        "POD_PMIN_AT_XMIN": POD_PMIN_AT_XMIN,
        "POD_ALPHA": POD_ALPHA,
        "POD_BETA": POD_BETA,
        "TEFF_A_MEAN": TEFF_A_MEAN,
        "TEFF_A_SD": TEFF_A_SD,
        "COSTS": {
            "C_ins_s": COST_INSP_SHALLOW,
            "C_ins_d": COST_INSP_DEEP,
            "C_ma_A": COST_MAINT_A,
            "C_ma_B": COST_MAINT_B,
        },
        "THRESHOLD_CONSTRAINTS": {
            "x_A_max": X_A_MAX,
            "x_B_lt_x_th": True,
            "x_B_minus_x_A_min": MIN_AB_GAP,
        },
        "ENCODING_PER_N": "x=[t1,extra2..extra_n,x_A,x_B]; gaps=MIN_GAP+extra; extras scaled to fit horizon",
        "PROGRESS": "tqdm nested (gen + eval) with ETA",
        "NOTE": "PoD drives shallow TP/FN/FP/TN outcomes; deep confirmation is deterministic.",
    }


def collect_settings_for_n(n: int) -> Dict[str, Any]:
    s = collect_settings_common()
    s["n_insp"] = int(n)
    return s


# -----------------------------
# Main
# -----------------------------

def main() -> None:
    global SEED, N_MC, POP_SIZE, N_GEN, N_LIST

    parser = argparse.ArgumentParser(
        description=(
            "Reproduce Case Study III: fixed-length inspection-policy "
            "baselines for selected inspection counts."
        )
    )
    parser.add_argument("--out-root", default=os.path.join(WORKSPACE_ROOT, "outputs", "case3"), help="Root directory for generated Case 3 outputs.")
    parser.add_argument("--seed", type=int, default=SEED, help="Random seed used for Monte Carlo sampling and optimization.")
    parser.add_argument("--n-mc", type=int, default=N_MC, help="Number of Monte Carlo samples.")
    parser.add_argument("--pop-size", type=int, default=POP_SIZE, help="NSGA-II population size.")
    parser.add_argument("--n-gen", type=int, default=N_GEN, help="Number of NSGA-II generations.")
    parser.add_argument("--n-list", type=int, nargs="+", default=list(N_LIST), help="Inspection counts to optimize, for example: --n-list 1 2 3 4.")
    args = parser.parse_args()

    SEED = args.seed
    N_MC = args.n_mc
    POP_SIZE = args.pop_size
    N_GEN = args.n_gen
    N_LIST = tuple(args.n_list)

    # common MC presample shared across all n
    S = presample_mc(N_MC, SEED)

    df_all_list: List[pd.DataFrame] = []

    for n in N_LIST:
        out_dir = os.path.abspath(os.path.join(args.out_root, f"fixed_n_{n}"))
        ensure_dir(out_dir)

        res = nsga2_optimize_fixed_n(n=n, S=S, seed=SEED)
        archive = res["archive"]

        settings = collect_settings_for_n(n)
        with open(os.path.join(out_dir, "settings.json"), "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)

        # pareto set for this n
        df_pareto = build_pareto_dataframe_fixed(archive, n=n)

        cols_all = [
            "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
            "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
            "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
        ]
        df_pareto[cols_all].to_csv(os.path.join(out_dir, "pareto_solutions.csv"), index=False)

        df_table = representative_table_2d(df_pareto)
        cols_tag = [
            "Tag", "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
            "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
            "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
        ]
        df_table[cols_tag].to_csv(os.path.join(out_dir, "pareto_table.csv"), index=False)

        df_all_list.append(df_pareto[cols_all].copy())

    # aggregated global results (2D envelope across all n)
    out_all = os.path.abspath(os.path.join(args.out_root, "all_fixed_n"))
    ensure_dir(out_all)

    df_all = pd.concat(df_all_list, axis=0, ignore_index=True) if df_all_list else pd.DataFrame()

    settings_all = collect_settings_common()
    with open(os.path.join(out_all, "settings.json"), "w", encoding="utf-8") as f:
        json.dump(settings_all, f, indent=2)

    if not df_all.empty:
        cols_all = [
            "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
            "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
            "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
        ]
        df_all[cols_all].to_csv(os.path.join(out_all, "pareto_solutions.csv"), index=False)

        df_global_table = global_representative_table(df_all)
        df_global_table.to_csv(os.path.join(out_all, "pareto_table.csv"), index=False)

    else:
        # still create empty placeholders for consistency
        pd.DataFrame().to_csv(os.path.join(out_all, "pareto_solutions.csv"), index=False)
        pd.DataFrame().to_csv(os.path.join(out_all, "pareto_table.csv"), index=False)


if __name__ == "__main__":
    main()

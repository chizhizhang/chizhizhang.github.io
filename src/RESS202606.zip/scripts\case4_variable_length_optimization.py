# -*- coding: utf-8 -*-
"""Run Case Study IV: variable-length inspection scheduling.

This script jointly optimizes the number of inspections, inspection times, and
maintenance thresholds with a three-objective NSGA-II algorithm. A repair step
maps the fixed-length encoded decision vector to a feasible variable-length
schedule before Monte Carlo evaluation.

Outputs are written to outputs/case4/ and are used by the manuscript's Case
Study IV tables, Fig. 15, and Fig. 16. The script is standalone and does not
import other project scripts.
"""

from __future__ import annotations

# Article mapping:
# - Case Study IV, variable-length inspection scheduling.
# - Generates outputs/case4/pareto_solutions.csv and pareto_table.csv for Fig. 15,
#   Fig. 16, and the variable-length representative-policy table.
# - Standalone by design: no imports from other project scripts and no writes to
#   LaTeX/submission folders.

import os
import math
import json
import argparse
import ast
from dataclasses import dataclass
from typing import Tuple, List, Dict, Any

import numpy as np
import pandas as pd


# tqdm (ETA progress bars)
try:
    from tqdm.auto import tqdm, trange  # type: ignore
except Exception:
    tqdm = None
    trange = None

BAR_FMT = "{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]"

# Resolve inputs and outputs from the project root, independent of the shell's
# current working directory.
WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


# -----------------------------
# Repro / runtime
# -----------------------------
SEED = 123

N_MC = 60000
POP_SIZE = 100
N_GEN = 100
ARCHIVE_MAX = 3000


# -----------------------------
# Variable n
# -----------------------------
N_MAX = 10          # can be > 4
MIN_GAP_H = 100.0   # t_{i}-t_{i-1} >= 100h
T_HORIZON_H = 8000.0

T1_MIN = 80.0
T1_MAX = 4000.0


# -----------------------------
# Degradation model
# -----------------------------
B_CENTER = 0.10
B_SD = 0.042
B_MIN = 0.01
B_MAX = 0.30
c_MEDIAN = 0.0873
c_LN_SD = 0.05

x_th = 0.20
x_min = 1e-3


# -----------------------------
# Shallow screening outcome model: PoD drives the binary alarm, from which
# TP/FN/FP/TN are counted relative to x_A; deep confirmation is deterministic.
# PoD(x) = logistic( POD_ALPHA + POD_BETA * ln(delta) ), for delta > x_min else 0
# -----------------------------
POD_X50_REF = 0.10
POD_PMIN_AT_XMIN = 1.0e-3
POD_BETA = math.log(POD_PMIN_AT_XMIN / (1.0 - POD_PMIN_AT_XMIN)) / math.log(x_min / POD_X50_REF)
POD_ALPHA = -POD_BETA * math.log(POD_X50_REF)


# -----------------------------
# Maintenance effects
# -----------------------------
TEFF_A_MEAN = 1000.0
TEFF_A_SD = 500.0


# -----------------------------
# Costs (NO lab-time monetization)
# -----------------------------
COST_INSP_SHALLOW = 1.0
COST_INSP_DEEP = 3.0
COST_MAINT_A = 15.0
COST_MAINT_B = 50.0


# -----------------------------
# Threshold constraints
# -----------------------------
X_A_MIN = 0.02
X_A_MAX = 0.12
MIN_AB_GAP = 0.02
X_B_EPS = 1e-3


# Reported Case 4 Max-Life policy used for the optional leave-one-out diagnostic.
MAX_LIFE_TIMES_H = (80.312, 180.549, 282.470, 382.759, 482.759, 582.759)
MAX_LIFE_X_A = 0.119378
MAX_LIFE_X_B = 0.139378


# -----------------------------
# Encoding bounds
# x = [n_raw, t1, extra2..extraNmax, x_A, x_B]
# extra_i >= 0, gaps_i = MIN_GAP + extra_i
# -----------------------------
N_RAW_MIN, N_RAW_MAX = 1.0, float(N_MAX)
EXTRA_MAX = 4000.0      # upper bound on "extra" gap above MIN_GAP


# -----------------------------
# Utilities
# -----------------------------
def ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def lognormal_mu_sigma_from_mean_sd(mean: float, sd: float) -> Tuple[float, float]:
    var = sd ** 2
    sigma2 = math.log(1.0 + var / (mean ** 2))
    sigma = math.sqrt(sigma2)
    mu = math.log(mean) - 0.5 * sigma2
    return mu, sigma


def sample_b_random_effect(rng: np.random.Generator, size) -> np.ndarray:
    """Bounded logistic-normal random effect for the power-law exponent b."""
    y = (B_CENTER - B_MIN) / (B_MAX - B_MIN)
    eta_mu = math.log(y / (1.0 - y))
    eta_sigma = B_SD / ((B_MAX - B_MIN) * y * (1.0 - y))
    eta = rng.normal(loc=eta_mu, scale=eta_sigma, size=size)
    return B_MIN + (B_MAX - B_MIN) / (1.0 + np.exp(-eta))


def logistic_stable(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z)
    out = np.empty_like(z, dtype=float)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1.0 + ez)
    return out

def pod_shallow(delta: np.ndarray) -> np.ndarray:
    d = np.asarray(delta, dtype=float)
    out = np.zeros_like(d)
    m = d > x_min
    if np.any(m):
        z = POD_ALPHA + POD_BETA * np.log(d[m])
        out[m] = logistic_stable(z)
    return np.clip(out, 0.0, 1.0)

def sample_tlife0_from_pdf(csv_path: str, n: int, rng: np.random.Generator) -> np.ndarray:
    df = pd.read_csv(csv_path)
    if "t" not in df.columns or "pdf" not in df.columns:
        raise ValueError("tlife0_pdf.csv must contain columns: t, pdf")
    t = df["t"].to_numpy(dtype=float)
    p = df["pdf"].to_numpy(dtype=float)

    if np.any(t <= 0) or np.any(p < 0):
        raise ValueError("PDF requires t>0 and pdf>=0.")

    order = np.argsort(t)
    t = t[order]
    p = p[order]

    cdf = np.zeros_like(t)
    area = 0.0
    for i in range(1, len(t)):
        area += 0.5 * (p[i - 1] + p[i]) * (t[i] - t[i - 1])
        cdf[i] = area
    if area <= 0:
        raise ValueError("PDF integrates to zero.")
    cdf /= area

    u = rng.random(n)
    return np.interp(u, cdf, t)

def decode_and_repair(x: np.ndarray) -> Tuple[int, np.ndarray, float, float, np.ndarray]:
    """
    Returns:
      n, t_schedule (len n), x_A, x_B, gaps_used (len max(n-1,0))
    """
    x = np.asarray(x, dtype=float).copy()

    n = int(np.clip(int(round(x[0])), 1, N_MAX))

    # thresholds with constraints
    x_A = float(np.clip(x[-2], X_A_MIN, X_A_MAX - 1e-12))
    x_B_lo = x_A + MIN_AB_GAP
    x_B_hi = x_th - X_B_EPS
    if x_B_lo > x_B_hi:
        x_A = max(X_A_MIN, x_B_hi - MIN_AB_GAP)
        x_A = min(x_A, X_A_MAX - 1e-12)
        x_B_lo = x_A + MIN_AB_GAP
    x_B = float(np.clip(x[-1], x_B_lo, x_B_hi))

    # t1 feasibility depends on n due to minimum span
    min_span = (n - 1) * MIN_GAP_H
    t1_hi = min(T1_MAX, T_HORIZON_H - min_span)
    t1 = float(np.clip(x[1], T1_MIN, t1_hi))

    extras = np.clip(x[2:2 + (N_MAX - 1)], 0.0, EXTRA_MAX)
    if n <= 1:
        return n, np.array([t1], dtype=float), x_A, x_B, np.zeros((0,), dtype=float)

    extras_used = extras[: n - 1].copy()
    base = MIN_GAP_H * (n - 1)
    avail = T_HORIZON_H - t1
    slack = max(0.0, avail - base)

    s_ex = float(np.sum(extras_used))
    scale = 0.0 if s_ex <= 1e-12 else min(1.0, slack / s_ex)
    gaps_used = MIN_GAP_H + extras_used * scale

    t = np.empty(n, dtype=float)
    t[0] = t1
    for i in range(1, n):
        t[i] = t[i - 1] + gaps_used[i - 1]
    t[-1] = min(t[-1], T_HORIZON_H)
    return n, t, x_A, x_B, gaps_used

def repair_vector(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float).copy()

    x[0] = float(np.clip(x[0], N_RAW_MIN, N_RAW_MAX))
    x[1] = float(np.clip(x[1], T1_MIN, T1_MAX))
    x[2:2 + (N_MAX - 1)] = np.clip(x[2:2 + (N_MAX - 1)], 0.0, EXTRA_MAX)

    x[-2] = float(np.clip(x[-2], X_A_MIN, X_A_MAX))
    x[-1] = float(np.clip(x[-1], X_A_MIN + MIN_AB_GAP, x_th - X_B_EPS))

    n, t, x_A, x_B, gaps_used = decode_and_repair(x)

    x[0] = float(n)
    x[1] = float(t[0])

    extras = np.zeros(N_MAX - 1, dtype=float)
    if n > 1:
        extras[: n - 1] = np.clip(gaps_used - MIN_GAP_H, 0.0, EXTRA_MAX)
    x[2:2 + (N_MAX - 1)] = extras

    x[-2] = float(x_A)
    x[-1] = float(x_B)
    return x


# -----------------------------
# Monte Carlo presampling (common random numbers)
# -----------------------------
@dataclass
class PreSample:
    # cycle parameters for up to (N_MAX) replacements => N_MAX+1 cycles
    c_cycle: np.ndarray        # shape (N, N_MAX+1)
    b_cycle: np.ndarray        # shape (N, N_MAX+1)
    tfail0_cycle: np.ndarray   # shape (N, N_MAX+1)

    # shallow indication uniforms at each scheduled inspection
    u_shallow: np.ndarray      # shape (N, N_MAX)

    # maintenance A teff draws at each inspection
    teffA: np.ndarray          # shape (N, N_MAX)

def presample_mc(n: int, seed: int) -> PreSample:
    rng = np.random.default_rng(seed)
    n_cycles = N_MAX + 1

    pdf_path = os.path.join(WORKSPACE_ROOT, "data", "tlife0_pdf.csv")
    b = sample_b_random_effect(rng, (n, n_cycles))
    if os.path.exists(pdf_path):
        tf = sample_tlife0_from_pdf(pdf_path, n * n_cycles, rng).reshape(n, n_cycles)
        c = (x_th / (tf ** b))
    else:
        c = rng.lognormal(mean=math.log(c_MEDIAN), sigma=c_LN_SD, size=(n, n_cycles))
        tf = (x_th / c) ** (1.0 / b)

    u_shallow = rng.random((n, N_MAX))

    mu_te, sig_te = lognormal_mu_sigma_from_mean_sd(TEFF_A_MEAN, TEFF_A_SD)
    teffA = rng.lognormal(mean=mu_te, sigma=sig_te, size=(n, N_MAX))

    return PreSample(c_cycle=c, b_cycle=b, tfail0_cycle=tf, u_shallow=u_shallow, teffA=teffA)


# -----------------------------
# Policy simulation (vectorized per policy)
# -----------------------------
def simulate_policy(x: np.ndarray, S: PreSample) -> Tuple[float, float, int, float, float, str, float, float, float, float, float, float, float]:
    """
    Returns:
      (E_cost, E_life, n_insp, E_num_maintA, E_num_maintB, t_schedule_str, x_A, x_B,
       E_num_FP, E_num_TP, E_num_FN, E_num_TN, E_num_deep)
    """
    n, t_sched, x_A, x_B, _ = decode_and_repair(x)

    N = S.u_shallow.shape[0]
    idxN = np.arange(N)

    active = np.ones(N, dtype=bool)
    t0 = np.zeros(N, dtype=float)
    delay = np.zeros(N, dtype=float)
    cyc = np.zeros(N, dtype=int)

    total_cost = np.zeros(N, dtype=float)
    nA = np.zeros(N, dtype=float)
    nB = np.zeros(N, dtype=float)
    n_fp = np.zeros(N, dtype=float)
    n_tp = np.zeros(N, dtype=float)
    n_fn = np.zeros(N, dtype=float)
    n_tn = np.zeros(N, dtype=float)
    n_deep = np.zeros(N, dtype=float)

    def c_now() -> np.ndarray:
        return S.c_cycle[idxN, cyc]

    def b_now() -> np.ndarray:
        return S.b_cycle[idxN, cyc]

    def tfail0_now() -> np.ndarray:
        return S.tfail0_cycle[idxN, cyc]

    def tfail_abs() -> np.ndarray:
        return t0 + delay + tfail0_now()

    def damage_at(t: float) -> np.ndarray:
        teff = np.maximum(t - t0 - delay, 0.0)
        return c_now() * (teff ** b_now())

    for i in range(n):
        t = float(t_sched[i])

        do_shallow = active.copy()
        if not np.any(do_shallow):
            break

        # Eq. 10a: scheduled shallow cost always charged for active units
        total_cost[do_shallow] += COST_INSP_SHALLOW

        # if already failed before this inspection, discover now and terminate thereafter
        failed_before = do_shallow & (t > tfail_abs())
        if np.any(failed_before):
            active[failed_before] = False

        alive = do_shallow & (~failed_before)
        if not np.any(alive):
            continue

        d = damage_at(t)
        p = pod_shallow(d)
        ind = alive & (S.u_shallow[:, i] < p)
        true_defect = d >= x_A
        no_alarm = alive & (~ind)
        n_fp[ind & (~true_defect)] += 1.0
        n_tp[ind & true_defect] += 1.0
        n_fn[no_alarm & true_defect] += 1.0
        n_tn[no_alarm & (~true_defect)] += 1.0
        if not np.any(ind):
            continue

        # deep deterministic (perfect confirmation)
        # Deep confirmation is performed after every shallow alarm. If d < x_A,
        # the alarm is a false positive: only the deep-inspection cost is added,
        # and no maintenance/state update follows. If d >= x_A, the alarm is a
        # true positive and can trigger Action A or B below.
        total_cost[ind] += COST_INSP_DEEP
        n_deep[ind] += 1.0

        # Maintenance B (replacement) if delta >= x_B
        do_B = ind & (d >= x_B)
        if np.any(do_B):
            total_cost[do_B] += COST_MAINT_B
            nB[do_B] += 1.0
            t0[do_B] = t
            delay[do_B] = 0.0
            cyc[do_B] = np.minimum(cyc[do_B] + 1, N_MAX)

        # Maintenance A if x_A <= delta < x_B
        do_A = ind & (~do_B) & (d >= x_A)
        if np.any(do_A):
            total_cost[do_A] += COST_MAINT_A
            nA[do_A] += 1.0
            delay[do_A] += S.teffA[do_A, i]

    life = np.minimum(tfail_abs(), T_HORIZON_H)

    t_schedule_str = ",".join([f"{tt:.3f}" for tt in t_sched])
    return (float(np.mean(total_cost)),
            float(np.mean(life)),
            int(n),
            float(np.mean(nA)),
            float(np.mean(nB)),
            t_schedule_str,
            float(x_A),
            float(x_B),
            float(np.mean(n_fp)),
            float(np.mean(n_tp)),
            float(np.mean(n_fn)),
            float(np.mean(n_tn)),
            float(np.mean(n_deep)))


# -----------------------------
# NSGA-II (3 objectives)
# -----------------------------
def dominates(fa: np.ndarray, fb: np.ndarray) -> bool:
    # minimization
    return np.all(fa <= fb) and np.any(fa < fb)

def fast_nondominated_sort(F: np.ndarray) -> List[List[int]]:
    n = F.shape[0]
    Sset = [set() for _ in range(n)]
    n_dom = np.zeros(n, dtype=int)
    fronts: List[List[int]] = [[]]

    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if dominates(F[p], F[q]):
                Sset[p].add(q)
            elif dominates(F[q], F[p]):
                n_dom[p] += 1
        if n_dom[p] == 0:
            fronts[0].append(p)

    i = 0
    while fronts[i]:
        nxt: List[int] = []
        for p in fronts[i]:
            for q in Sset[p]:
                n_dom[q] -= 1
                if n_dom[q] == 0:
                    nxt.append(q)
        i += 1
        fronts.append(nxt)
    fronts.pop()
    return fronts

def crowding_distance(F: np.ndarray, front: List[int]) -> np.ndarray:
    m = F.shape[1]
    dist = np.zeros(len(front), dtype=float)
    if len(front) == 0:
        return dist
    if len(front) <= 2:
        dist[:] = np.inf
        return dist
    vals = F[np.array(front, dtype=int), :]

    for j in range(m):
        order = np.argsort(vals[:, j])
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf
        vmin = vals[order[0], j]
        vmax = vals[order[-1], j]
        if vmax - vmin < 1e-12:
            continue
        for k in range(1, len(front) - 1):
            dist[order[k]] += (vals[order[k + 1], j] - vals[order[k - 1], j]) / (vmax - vmin)
    return dist

def tournament_select(rng: np.random.Generator, idx: np.ndarray, ranks: np.ndarray, crowds: np.ndarray) -> int:
    a, b = rng.choice(idx, size=2, replace=False)
    if ranks[a] < ranks[b]:
        return int(a)
    if ranks[b] < ranks[a]:
        return int(b)
    return int(a if crowds[a] > crowds[b] else b)

def sbx_crossover(rng: np.random.Generator, p1: np.ndarray, p2: np.ndarray,
                  eta: float = 15.0, p_c: float = 0.9) -> Tuple[np.ndarray, np.ndarray]:
    c1, c2 = p1.copy(), p2.copy()
    if rng.random() > p_c:
        return c1, c2

    bounds: List[Tuple[float, float]] = []
    bounds.append((N_RAW_MIN, N_RAW_MAX))         # n_raw
    bounds.append((T1_MIN, T1_MAX))               # t1
    for _ in range(N_MAX - 1):
        bounds.append((0.0, EXTRA_MAX))           # extras
    bounds.append((X_A_MIN, X_A_MAX))             # x_A
    bounds.append((X_A_MIN + MIN_AB_GAP, x_th))   # x_B (coarse; repaired later)

    for i, (xL, xU) in enumerate(bounds):
        x1, x2 = float(p1[i]), float(p2[i])
        if abs(x1 - x2) < 1e-12:
            continue
        if x1 > x2:
            x1, x2 = x2, x1
        u = rng.random()

        beta = 1.0 + (2.0 * (x1 - xL) / (x2 - x1))
        alpha = 2.0 - beta ** (-(eta + 1.0))
        if u <= 1.0 / alpha:
            betaq = (u * alpha) ** (1.0 / (eta + 1.0))
        else:
            betaq = (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0))
        child1 = 0.5 * ((x1 + x2) - betaq * (x2 - x1))

        beta = 1.0 + (2.0 * (xU - x2) / (x2 - x1))
        alpha = 2.0 - beta ** (-(eta + 1.0))
        if u <= 1.0 / alpha:
            betaq = (u * alpha) ** (1.0 / (eta + 1.0))
        else:
            betaq = (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0))
        child2 = 0.5 * ((x1 + x2) + betaq * (x2 - x1))

        c1[i] = float(np.clip(child1, xL, xU))
        c2[i] = float(np.clip(child2, xL, xU))

    return repair_vector(c1), repair_vector(c2)

def poly_mutation(rng: np.random.Generator, x: np.ndarray,
                  eta: float = 20.0, p_m: float = 0.18) -> np.ndarray:
    y = x.copy()

    bounds: List[Tuple[float, float]] = []
    bounds.append((N_RAW_MIN, N_RAW_MAX))
    bounds.append((T1_MIN, T1_MAX))
    for _ in range(N_MAX - 1):
        bounds.append((0.0, EXTRA_MAX))
    bounds.append((X_A_MIN, X_A_MAX))
    bounds.append((X_A_MIN + MIN_AB_GAP, x_th))

    for i, (xL, xU) in enumerate(bounds):
        if rng.random() > p_m:
            continue
        xi = float(y[i])
        if xU - xL < 1e-12:
            continue
        delta1 = (xi - xL) / (xU - xL)
        delta2 = (xU - xi) / (xU - xL)
        u = rng.random()
        mut_pow = 1.0 / (eta + 1.0)
        if u < 0.5:
            xy = 1.0 - delta1
            val = 2.0 * u + (1.0 - 2.0 * u) * (xy ** (eta + 1.0))
            dq = val ** mut_pow - 1.0
        else:
            xy = 1.0 - delta2
            val = 2.0 * (1.0 - u) + 2.0 * (u - 0.5) * (xy ** (eta + 1.0))
            dq = 1.0 - val ** mut_pow
        xi = xi + dq * (xU - xL)
        y[i] = float(np.clip(xi, xL, xU))

    return repair_vector(y)

def evaluate_population(X: np.ndarray, S: PreSample, desc: str, leave: bool, position: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns:
      cost, life, ninsp, nA, nB, t_schedule_str, x_A, x_B, nFP, nTP, nFN, nTN, nDeep
      (all arrays length len(X))
    """
    n = X.shape[0]
    cost = np.zeros(n)
    life = np.zeros(n)
    ninsp = np.zeros(n, dtype=int)
    nA = np.zeros(n)
    nB = np.zeros(n)
    ts = np.empty(n, dtype=object)
    aA = np.zeros(n)
    aB = np.zeros(n)
    nFP = np.zeros(n)
    nTP = np.zeros(n)
    nFN = np.zeros(n)
    nTN = np.zeros(n)
    nDeep = np.zeros(n)

    it = range(n)
    if tqdm is not None:
        it = tqdm(
            it,
            desc=desc,
            leave=leave,
            position=position,
            bar_format=BAR_FMT,
            dynamic_ncols=True,
            mininterval=0.5,
            smoothing=0.1,
        )

    for i in it:
        c, l, nn, ma, mb, tstr, aa, ab, fp, tp, fn, tn, nd = simulate_policy(X[i], S)
        cost[i] = c
        life[i] = l
        ninsp[i] = nn
        nA[i] = ma
        nB[i] = mb
        ts[i] = tstr
        aA[i] = aa
        aB[i] = ab
        nFP[i] = fp
        nTP[i] = tp
        nFN[i] = fn
        nTN[i] = tn
        nDeep[i] = nd

    return cost, life, ninsp, nA, nB, ts, aA, aB, nFP, nTP, nFN, nTN, nDeep

def nondominated_mask_nd(F: np.ndarray) -> np.ndarray:
    n = F.shape[0]
    keep = np.ones(n, dtype=bool)
    for i in range(n):
        if not keep[i]:
            continue
        for j in range(n):
            if i == j or not keep[i]:
                continue
            if dominates(F[j], F[i]):
                keep[i] = False
                break
    return keep

def update_archive(archive: Dict[str, Any],
                   X: np.ndarray, F: np.ndarray, extra: np.ndarray,
                   max_size: int) -> None:
    if archive["X"].size == 0:
        archive["X"] = X.copy()
        archive["F"] = F.copy()
        archive["extra"] = extra.copy()
    else:
        archive["X"] = np.vstack([archive["X"], X])
        archive["F"] = np.vstack([archive["F"], F])
        archive["extra"] = np.vstack([archive["extra"], extra])

    keep = nondominated_mask_nd(archive["F"])
    archive["X"] = archive["X"][keep]
    archive["F"] = archive["F"][keep]
    archive["extra"] = archive["extra"][keep]

    if archive["X"].shape[0] > max_size:
        idx = list(range(archive["X"].shape[0]))
        cd = crowding_distance(archive["F"], idx)
        order = np.argsort(-cd)
        sel = order[:max_size]
        archive["X"] = archive["X"][sel]
        archive["F"] = archive["F"][sel]
        archive["extra"] = archive["extra"][sel]


# -----------------------------
# Outputs
# -----------------------------
def build_pareto_dataframe(archive: Dict[str, Any]) -> pd.DataFrame:
    F = archive["F"]          # [cost, -life, n]
    extra = archive["extra"]  # [t_schedule_str, x_A, x_B, E_num_maintA, E_num_maintB, E_num_FP, E_num_TP, E_num_FN, E_num_TN, E_num_deep]

    df = pd.DataFrame({
        "E_cost": F[:, 0],
        "E_life_h": -F[:, 1],
        "n_insp": F[:, 2].astype(int),
        "x_A": extra[:, 1].astype(float),
        "x_B": extra[:, 2].astype(float),
        "E_num_maintA": extra[:, 3].astype(float),
        "E_num_maintB": extra[:, 4].astype(float),
        "E_num_FP": extra[:, 5].astype(float),
        "E_num_TP": extra[:, 6].astype(float),
        "E_num_FN": extra[:, 7].astype(float),
        "E_num_TN": extra[:, 8].astype(float),
        "E_num_deep": extra[:, 9].astype(float),
        "t_schedule": extra[:, 0].astype(str),
    })
    df = df.sort_values(["E_cost", "E_life_h", "n_insp"], ascending=[True, False, True]).reset_index(drop=True)
    return df

def representative_table(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    c = df["E_cost"].to_numpy()
    l = df["E_life_h"].to_numpy()
    n = df["n_insp"].to_numpy()

    picks = [("Min-n", int(np.argmin(n)))]
    for tag, q in (("Q25", 0.25), ("Q50", 0.50), ("Q75", 0.75)):
        target = np.quantile(c, q)
        idx = int(np.argmin(np.abs(c - target)))
        picks.append((tag, idx))
    picks.append(("Max-Life", int(np.argmax(l))))

    seen, rows = set(), []
    for tag, idx in picks:
        if idx in seen:
            continue
        seen.add(idx)
        r = df.iloc[idx].to_dict()
        r["Tag"] = tag
        rows.append(r)

    out = pd.DataFrame(rows)
    cols = [
        "Tag", "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
        "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
        "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
    ]
    return out[cols]

def pareto_mask_2d_life_cost(df: pd.DataFrame) -> np.ndarray:
    """
    Global Pareto in 2D projection (maximize life, minimize cost).
    """
    vals = df[["E_life_h", "E_cost"]].to_numpy()
    is_pareto = np.ones(vals.shape[0], dtype=bool)
    for i, (x, y) in enumerate(vals):
        # dominated if exists j with life>=x and cost<=y and at least one strict
        if np.any((vals[:, 0] >= x) & (vals[:, 1] <= y) & ((vals[:, 0] > x) | (vals[:, 1] < y))):
            is_pareto[i] = False
    return is_pareto


def vector_from_fixed_schedule(times: Tuple[float, ...], x_A: float, x_B: float) -> np.ndarray:
    """Encode a fixed schedule into the Case 4 variable-length decision vector."""
    if not times:
        raise ValueError("At least one inspection time is required.")
    if len(times) > N_MAX:
        raise ValueError(f"Schedule length {len(times)} exceeds N_MAX={N_MAX}.")
    times_arr = np.array(sorted(float(t) for t in times), dtype=float)
    x = np.zeros(1 + 1 + (N_MAX - 1) + 2, dtype=float)
    x[0] = float(len(times_arr))
    x[1] = float(times_arr[0])
    if len(times_arr) > 1:
        gaps = np.diff(times_arr)
        x[2:2 + len(gaps)] = np.maximum(gaps - MIN_GAP_H, 0.0)
    x[-2] = float(x_A)
    x[-1] = float(x_B)
    return repair_vector(x)


def export_leave_one_out_analysis(out_dir: str, *, seed: int, n_mc: int) -> str:
    """Evaluate the marginal value of each inspection in the reported Max-Life policy."""
    S = presample_mc(n_mc, seed)
    baseline_x = vector_from_fixed_schedule(MAX_LIFE_TIMES_H, MAX_LIFE_X_A, MAX_LIFE_X_B)
    baseline = simulate_policy(baseline_x, S)
    base_cost, base_life, base_n, base_a, base_b, base_schedule, _, _, base_fp, base_tp, base_fn, base_tn, base_deep = baseline

    rows = []
    for idx, removed_time in enumerate(MAX_LIFE_TIMES_H):
        reduced_times = tuple(t for j, t in enumerate(MAX_LIFE_TIMES_H) if j != idx)
        reduced_x = vector_from_fixed_schedule(reduced_times, MAX_LIFE_X_A, MAX_LIFE_X_B)
        result = simulate_policy(reduced_x, S)
        cost, life, n_insp, n_a, n_b, schedule, x_a, x_b, n_fp, n_tp, n_fn, n_tn, n_deep = result
        rows.append({
            "removed_inspection_index": idx + 1,
            "removed_time_h": removed_time,
            "remaining_schedule_h": schedule,
            "baseline_n": base_n,
            "remaining_n": n_insp,
            "baseline_E_life_h": base_life,
            "reduced_E_life_h": life,
            "life_loss_h": base_life - life,
            "baseline_E_cost": base_cost,
            "reduced_E_cost": cost,
            "cost_reduction": base_cost - cost,
            "baseline_E_num_deep": base_deep,
            "reduced_E_num_deep": n_deep,
            "baseline_E_num_FP": base_fp,
            "reduced_E_num_FP": n_fp,
            "baseline_E_num_TP": base_tp,
            "reduced_E_num_TP": n_tp,
            "baseline_E_num_FN": base_fn,
            "reduced_E_num_FN": n_fn,
            "baseline_E_num_TN": base_tn,
            "reduced_E_num_TN": n_tn,
            "baseline_E_num_maintA": base_a,
            "reduced_E_num_maintA": n_a,
            "baseline_E_num_maintB": base_b,
            "reduced_E_num_maintB": n_b,
            "x_A": x_a,
            "x_B": x_b,
        })

    df = pd.DataFrame(rows).sort_values("life_loss_h", ascending=False)
    csv_path = os.path.join(out_dir, "leave_one_out_inspection_value.csv")
    df.to_csv(csv_path, index=False)
    return csv_path


def pod_params_from_x50(x50: float) -> Tuple[float, float]:
    """Return alpha and beta for PoD(x_min)=POD_PMIN_AT_XMIN and PoD(x50)=0.5."""
    beta = math.log(POD_PMIN_AT_XMIN / (1.0 - POD_PMIN_AT_XMIN)) / math.log(x_min / float(x50))
    alpha = -beta * math.log(float(x50))
    return alpha, beta


def parse_schedule(value: Any) -> Tuple[float, ...]:
    """Parse a schedule cell such as '[80.5, 180.5]' from the representative CSV."""
    if isinstance(value, (list, tuple, np.ndarray)):
        return tuple(float(v) for v in value)
    parsed = ast.literal_eval(str(value))
    if isinstance(parsed, (int, float)):
        return (float(parsed),)
    return tuple(float(v) for v in parsed)


def export_representative_sensitivity(
    out_dir: str,
    *,
    table_csv: str | None,
    seed: int,
    n_mc: int,
) -> str:
    """Re-evaluate representative policies under controlled screening/effect scenarios."""
    global POD_ALPHA, POD_BETA, TEFF_A_MEAN, TEFF_A_SD

    if table_csv is None:
        table_csv = os.path.join(out_dir, "pareto_table.csv")
    if not os.path.exists(table_csv):
        raise FileNotFoundError(f"Representative table not found: {table_csv}")

    reps = pd.read_csv(table_csv)
    required = {"Tag", "x_A", "x_B", "t_schedule"}
    missing = required.difference(reps.columns)
    if missing:
        raise ValueError(f"Representative table missing columns: {sorted(missing)}")

    scenarios = [
        ("baseline", POD_X50_REF, TEFF_A_MEAN, TEFF_A_SD),
        ("higher_screening_sensitivity", 0.08, TEFF_A_MEAN, TEFF_A_SD),
        ("lower_screening_sensitivity", 0.12, TEFF_A_MEAN, TEFF_A_SD),
        ("weaker_action_A", POD_X50_REF, 800.0, 400.0),
        ("stronger_action_A", POD_X50_REF, 1200.0, 600.0),
    ]

    old_alpha, old_beta = POD_ALPHA, POD_BETA
    old_teff_mean, old_teff_sd = TEFF_A_MEAN, TEFF_A_SD
    rows = []
    try:
        for scenario, pod_x50, teff_mean, teff_sd in scenarios:
            POD_ALPHA, POD_BETA = pod_params_from_x50(pod_x50)
            TEFF_A_MEAN, TEFF_A_SD = teff_mean, teff_sd
            S = presample_mc(n_mc, seed)
            for _, row in reps.iterrows():
                x = vector_from_fixed_schedule(
                    parse_schedule(row["t_schedule"]),
                    float(row["x_A"]),
                    float(row["x_B"]),
                )
                cost, life, n_insp, n_a, n_b, schedule, x_a, x_b, n_fp, n_tp, n_fn, n_tn, n_deep = simulate_policy(x, S)
                rows.append({
                    "Scenario": scenario,
                    "Tag": row["Tag"],
                    "pod_x50": pod_x50,
                    "teff_A_mean_h": teff_mean,
                    "teff_A_sd_h": teff_sd,
                    "E_cost": cost,
                    "E_life_h": life,
                    "n_insp": n_insp,
                    "x_A": x_a,
                    "x_B": x_b,
                    "E_num_maintA": n_a,
                    "E_num_maintB": n_b,
                    "E_num_deep": n_deep,
                    "E_num_FP": n_fp,
                    "E_num_TP": n_tp,
                    "E_num_FN": n_fn,
                    "E_num_TN": n_tn,
                    "t_schedule": schedule,
                })
    finally:
        POD_ALPHA, POD_BETA = old_alpha, old_beta
        TEFF_A_MEAN, TEFF_A_SD = old_teff_mean, old_teff_sd

    df = pd.DataFrame(rows)
    base = df[df["Scenario"] == "baseline"][["Tag", "E_cost", "E_life_h"]].rename(
        columns={"E_cost": "baseline_E_cost", "E_life_h": "baseline_E_life_h"}
    )
    df = df.merge(base, on="Tag", how="left")
    df["delta_E_cost_vs_baseline"] = df["E_cost"] - df["baseline_E_cost"]
    df["delta_E_life_h_vs_baseline"] = df["E_life_h"] - df["baseline_E_life_h"]
    csv_path = os.path.join(out_dir, "representative_sensitivity.csv")
    df.to_csv(csv_path, index=False)
    return csv_path

# -----------------------------
# Main optimize
# -----------------------------
def collect_settings() -> Dict[str, Any]:
    return {
        "SEED": SEED,
        "N_MC": N_MC,
        "POP_SIZE": POP_SIZE,
        "N_GEN": N_GEN,
        "N_MAX": N_MAX,
        "MIN_GAP_H": MIN_GAP_H,
        "T_HORIZON_H": T_HORIZON_H,
        "B_model": "bounded logistic-normal random effect",
        "B_CENTER": B_CENTER,
        "B_SD": B_SD,
        "B_MIN": B_MIN,
        "B_MAX": B_MAX,
        "x_th": x_th,
        "c_MEDIAN": c_MEDIAN,
        "c_LN_SD": c_LN_SD,
        "x_min": x_min,
        "POD_CALIBRATION": "two-point reference: PoD(x_min)=1e-3 and PoD(x50)=0.5",
        "POD_X50_REF": POD_X50_REF,
        "POD_PMIN_AT_XMIN": POD_PMIN_AT_XMIN,
        "POD_ALPHA": POD_ALPHA,
        "POD_BETA": POD_BETA,
        "TEFF_A_MEAN": TEFF_A_MEAN,
        "TEFF_A_SD": TEFF_A_SD,
        "COSTS": {
            "C_ins_s": COST_INSP_SHALLOW,
            "C_ins_d": COST_INSP_DEEP,
            "C_ma_A": COST_MAINT_A,
            "C_ma_B": COST_MAINT_B,
        },
        "THRESHOLD_CONSTRAINTS": {
            "x_A_max": X_A_MAX,
            "x_B_lt_x_th": True,
            "x_B_minus_x_A_min": MIN_AB_GAP,
        },
        "ENCODING": "x=[n_raw,t1,extra2..extraNmax,x_A,x_B]; gaps=MIN_GAP+extra; extras scaled to fit horizon",
        "PROGRESS": "tqdm nested (gen + eval) with ETA",
    }

def nsga2_optimize(seed: int = SEED) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    S = presample_mc(N_MC, seed)

    dim = 1 + 1 + (N_MAX - 1) + 2  # n_raw + t1 + extras + aA + aB

    # init population
    X = np.zeros((POP_SIZE, dim), dtype=float)
    for i in range(POP_SIZE):
        n_raw = rng.uniform(N_RAW_MIN, N_RAW_MAX)
        t1 = rng.uniform(T1_MIN, T1_MAX)
        extras = rng.uniform(0.0, EXTRA_MAX, size=(N_MAX - 1))
        aA = rng.uniform(X_A_MIN, X_A_MAX)
        aB = rng.uniform(aA + MIN_AB_GAP, x_th - X_B_EPS)
        x = np.concatenate([[n_raw, t1], extras, [aA, aB]])
        X[i] = repair_vector(x)

    archive = dict(
        X=np.empty((0, dim), dtype=float),
        F=np.empty((0, 3), dtype=float),        # [cost, -life, n] all minimized
        extra=np.empty((0, 10), dtype=object),   # [t_schedule_str, x_A, x_B, E_num_maintA, E_num_maintB, E_num_FP, E_num_TP, E_num_FN, E_num_TN, E_num_deep]
    )

    gen_it = (
        trange(
            N_GEN,
            desc="NSGA-II",
            bar_format=BAR_FMT,
            dynamic_ncols=True,
            mininterval=0.5,
            smoothing=0.1,
            position=0,
        )
        if trange is not None else range(N_GEN)
    )

    for _ in gen_it:
        # evaluate current pop (inner bar with ETA)
        cost, life, ninsp, nA, nB, ts, aA, aB, nFP, nTP, nFN, nTN, nDeep = evaluate_population(
            X, S, desc="Eval(pop)", leave=False, position=1
        )
        F = np.column_stack([cost, -life, ninsp.astype(float)])

        extra_arr = np.array(
            [
                [
                    ts[i], float(aA[i]), float(aB[i]), float(nA[i]), float(nB[i]),
                    float(nFP[i]), float(nTP[i]), float(nFN[i]), float(nTN[i]), float(nDeep[i]),
                ]
                for i in range(POP_SIZE)
            ],
            dtype=object,
        )
        update_archive(archive, X, F, extra_arr, ARCHIVE_MAX)

        # ranks + crowding for selection
        fronts = fast_nondominated_sort(F)
        ranks = np.full(POP_SIZE, 10**9, dtype=int)
        crowds = np.zeros(POP_SIZE, dtype=float)
        for r, fr in enumerate(fronts):
            for idx in fr:
                ranks[idx] = r
            cd = crowding_distance(F, fr)
            for j, idx in enumerate(fr):
                crowds[idx] = cd[j]

        # offspring
        offspring = []
        idx_all = np.arange(POP_SIZE)
        while len(offspring) < POP_SIZE:
            p1 = X[tournament_select(rng, idx_all, ranks, crowds)]
            p2 = X[tournament_select(rng, idx_all, ranks, crowds)]
            c1, c2 = sbx_crossover(rng, p1, p2)
            c1 = poly_mutation(rng, c1)
            c2 = poly_mutation(rng, c2)
            offspring.append(c1)
            if len(offspring) < POP_SIZE:
                offspring.append(c2)
        X_off = np.array(offspring, dtype=float)

        # environmental selection on union
        X_u = np.vstack([X, X_off])
        cost_u, life_u, ninsp_u, _, _, _, _, _, _, _, _, _, _ = evaluate_population(
            X_u, S, desc="Eval(union)", leave=False, position=1
        )
        F_u = np.column_stack([cost_u, -life_u, ninsp_u.astype(float)])

        fronts_u = fast_nondominated_sort(F_u)
        sel = []
        for fr in fronts_u:
            if len(sel) + len(fr) <= POP_SIZE:
                sel.extend(fr)
            else:
                cd = crowding_distance(F_u, fr)
                order = np.argsort(-cd)
                need = POP_SIZE - len(sel)
                sel.extend([fr[i] for i in order[:need]])
                break
        X = X_u[np.array(sel, dtype=int)]

    return {"archive": archive, "settings": collect_settings()}


def main() -> None:
    global SEED, N_MC, POP_SIZE, N_GEN

    parser = argparse.ArgumentParser(
        description=(
            "Reproduce Case Study IV: variable-length inspection scheduling "
            "with a three-objective NSGA-II search."
        )
    )
    parser.add_argument("--out-dir", default=os.path.join(WORKSPACE_ROOT, "outputs", "case4"), help="Directory for generated Case 4 outputs.")
    parser.add_argument("--seed", type=int, default=SEED, help="Random seed used for Monte Carlo sampling and optimization.")
    parser.add_argument("--n-mc", type=int, default=N_MC, help="Number of Monte Carlo samples.")
    parser.add_argument("--pop-size", type=int, default=POP_SIZE, help="NSGA-II population size.")
    parser.add_argument("--n-gen", type=int, default=N_GEN, help="Number of NSGA-II generations.")
    parser.add_argument("--leave-one-out", action="store_true", help="Also write Case 4 Max-Life leave-one-out inspection-value diagnostic.")
    parser.add_argument("--representative-sensitivity", action="store_true", help="Also re-evaluate representative policies under PoD and maintenance-effect scenarios.")
    parser.add_argument("--sensitivity-only", action="store_true", help="Skip optimization and only write representative_sensitivity.csv from an existing pareto_table.csv.")
    parser.add_argument("--sensitivity-table", default=None, help="Optional representative table CSV for --representative-sensitivity or --sensitivity-only.")
    args = parser.parse_args()

    SEED = args.seed
    N_MC = args.n_mc
    POP_SIZE = args.pop_size
    N_GEN = args.n_gen

    out_dir = os.path.abspath(args.out_dir)
    ensure_dir(out_dir)

    if args.sensitivity_only:
        sens_csv = export_representative_sensitivity(
            out_dir,
            table_csv=args.sensitivity_table,
            seed=SEED,
            n_mc=N_MC,
        )
        print(f"Representative sensitivity diagnostic written to: {sens_csv}")
        return

    res = nsga2_optimize(SEED)
    archive = res["archive"]
    settings = res["settings"]

    with open(os.path.join(out_dir, "settings.json"), "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)

    df_pareto = build_pareto_dataframe(archive)

    # all-pareto (no Tag)
    cols_all = [
        "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
        "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
        "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
    ]
    df_pareto[cols_all].to_csv(os.path.join(out_dir, "pareto_solutions.csv"), index=False)

    # representative with Tag
    df_table = representative_table(df_pareto)
    cols_tag = [
        "Tag", "E_cost", "E_life_h", "n_insp", "x_A", "x_B",
        "E_num_maintA", "E_num_maintB", "E_num_deep", "E_num_FP",
        "E_num_TP", "E_num_FN", "E_num_TN", "t_schedule",
    ]
    df_table[cols_tag].to_csv(os.path.join(out_dir, "pareto_table.csv"), index=False)

    pd.set_option("display.width", 240)
    pd.set_option("display.max_columns", 200)
    print("\n=== Representative Pareto Table (Tag) ===\n")
    print(df_table[cols_tag].to_string(index=False))
    if args.leave_one_out:
        loo_csv = export_leave_one_out_analysis(out_dir, seed=SEED, n_mc=N_MC)
        print(f"Leave-one-out inspection-value diagnostic written to: {loo_csv}")
    if args.representative_sensitivity:
        sens_csv = export_representative_sensitivity(
            out_dir,
            table_csv=args.sensitivity_table,
            seed=SEED,
            n_mc=N_MC,
        )
        print(f"Representative sensitivity diagnostic written to: {sens_csv}")
    print(f"\nSaved outputs to: {out_dir}")
    print(f"Pareto set size (3 objectives): {len(df_pareto)}")

if __name__ == "__main__":
    main()

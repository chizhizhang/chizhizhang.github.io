"""Generate Case 1 inspection-maintenance data tables.

This script owns the Case 1 model, Monte Carlo samples, optimal inspection-time
search, and CSV outputs used by the manuscript figures. It deliberately does
not import project plotting code and does not create image files.
"""

from __future__ import annotations

# Article mapping:
# - Case Study I, single scheduled inspection.
# - Generates CSV tables for Fig. 8, Fig. 9, Fig. 10, Fig. 11, and Table 1.
# - Does not import any other project script and does not touch LaTeX/submission files.

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


# Resolve paths from the project root so the script remains portable inside the
# final code package.
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "outputs" / "case1"

N_MC = 300_000
SEED = 42

C_MEAN = 1.25e-4
C_SD = 0.2e-4
TOC_MEAN, TOC_SD = 50.0, 10.0
TE1_MEAN, TE1_SD = 1000.0, 200.0
TE2_MEAN, TE2_SD = 4000.0, 800.0

X_TH = 0.5
X_MIN = 0.001
X50_LEVELS = (0.1, 0.3, 0.5)
CRITERIA_SETS = ((0.0, 0.0), (0.3, 0.5), (0.0, 1.0))

CDF_GRID = 900


def lognormal_mu_sigma_from_mean_sd(mean: float, sd: float) -> tuple[float, float]:
    if mean <= 0.0 or sd <= 0.0:
        raise ValueError("Lognormal mean/sd must be positive.")
    sigma2 = math.log(1.0 + (sd * sd) / (mean * mean))
    sigma = math.sqrt(sigma2)
    mu = math.log(mean) - 0.5 * sigma2
    return mu, sigma


def cdf_on_grid(values: np.ndarray, n_grid: int = CDF_GRID) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        grid = np.linspace(0.0, 1.0, n_grid)
        return grid, np.zeros_like(grid)
    x_max = float(np.quantile(values, 0.9995))
    x_max = max(x_max, float(np.median(values)) * 1.5, 1.0)
    grid = np.linspace(0.0, x_max, n_grid)
    cdf = np.searchsorted(np.sort(values), grid, side="right") / values.size
    return grid, cdf


def histogram_pdf(values: np.ndarray, n_bins: int = 320) -> pd.DataFrame:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    x_hi = float(np.quantile(values, 0.9995))
    bins = np.linspace(0.0, x_hi, n_bins + 1)
    hist, edges = np.histogram(values[(values >= 0.0) & (values <= x_hi)], bins=bins, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    return pd.DataFrame({"time_h": centers, "pdf": hist})


def minimize_bounded_golden(
    objective,
    lower: float,
    upper: float,
    *,
    xatol: float = 1.0e-3,
    max_iter: int = 200,
) -> tuple[float, float]:
    """Small bounded scalar minimizer used to keep Case 1 self-contained."""
    a = float(lower)
    b = float(upper)
    inv_phi = (math.sqrt(5.0) - 1.0) / 2.0
    inv_phi2 = (3.0 - math.sqrt(5.0)) / 2.0

    h = b - a
    if h <= xatol:
        x = 0.5 * (a + b)
        return x, float(objective(x))

    c = a + inv_phi2 * h
    d = a + inv_phi * h
    yc = float(objective(c))
    yd = float(objective(d))

    for _ in range(max_iter):
        if abs(b - a) <= xatol:
            break
        if yc < yd:
            b, d, yd = d, c, yc
            h = b - a
            c = a + inv_phi2 * h
            yc = float(objective(c))
        else:
            a, c, yc = c, d, yd
            h = b - a
            d = a + inv_phi * h
            yd = float(objective(d))

    if yc < yd:
        return c, yc
    return d, yd


class Case1Model:
    def __init__(self, n_mc: int, seed: int) -> None:
        self.n = int(n_mc)
        rng = np.random.default_rng(seed)

        mu_toc, sg_toc = lognormal_mu_sigma_from_mean_sd(TOC_MEAN, TOC_SD)
        mu_c, sg_c = lognormal_mu_sigma_from_mean_sd(C_MEAN, C_SD)
        mu_te1, sg_te1 = lognormal_mu_sigma_from_mean_sd(TE1_MEAN, TE1_SD)
        mu_te2, sg_te2 = lognormal_mu_sigma_from_mean_sd(TE2_MEAN, TE2_SD)

        self.t_oc = rng.lognormal(mu_toc, sg_toc, self.n)
        self.c_rate = rng.lognormal(mu_c, sg_c, self.n)
        self.t_eff_a = rng.lognormal(mu_te1, sg_te1, self.n)
        self.t_eff_b = rng.lognormal(mu_te2, sg_te2, self.n)
        self.x_th = float(X_TH)
        self.x_min = float(X_MIN)
        self.t_life_0 = self.t_oc + self.x_th / self.c_rate

    def x_at(self, t_h: float) -> np.ndarray:
        dt = float(t_h) - self.t_oc
        return np.where(dt <= 0.0, 0.0, self.c_rate * dt)

    def pod(self, damage: np.ndarray, x_50: float) -> np.ndarray:
        damage = np.asarray(damage, dtype=float)
        d = np.maximum(damage, 1.0e-15)
        logit_pmin = math.log(self.x_min / (1.0 - self.x_min))
        denom = math.log(self.x_min / float(x_50))
        beta = 5.0 if abs(denom) < 1.0e-12 else logit_pmin / denom
        alpha = -beta * math.log(float(x_50))
        z = alpha + beta * np.log(d)
        out = np.empty_like(z)
        pos = z >= 0.0
        out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
        ez = np.exp(z[~pos])
        out[~pos] = ez / (1.0 + ez)
        out = np.where(damage < self.x_min, 0.0, out)
        return np.clip(out, 0.0, 1.0)

    def simulate(self, t_insp: float, x_50: float, x_a: float, x_b: float) -> tuple[np.ndarray, np.ndarray]:
        if x_a > x_b:
            raise ValueError("Require x_a <= x_b.")
        t0 = self.t_life_0
        x_insp = self.x_at(t_insp)
        pod = self.pod(x_insp, x_50)
        late = float(t_insp) > t0
        early = ~late

        t_life = t0.copy()
        if np.any(early):
            t_detected = t0.copy()
            maint_a = (x_insp >= x_a) & (x_insp < x_b) & early
            maint_b = (x_insp >= x_b) & early
            t_detected[maint_a] = t0[maint_a] + self.t_eff_a[maint_a]
            t_detected[maint_b] = t0[maint_b] + self.t_eff_b[maint_b]
            t_life[early] = (1.0 - pod[early]) * t0[early] + pod[early] * t_detected[early]

        t_delay = (t0 - self.t_oc).copy()
        if np.any(early):
            t_delay_detected = np.where(x_insp >= x_a, float(t_insp) - self.t_oc, t0 - self.t_oc)
            t_delay[early] = (1.0 - pod[early]) * (t0[early] - self.t_oc[early]) + pod[early] * t_delay_detected[early]
        return t_life, t_delay

    def expected_service_life(self, t_insp: float, x_50: float, x_a: float, x_b: float) -> float:
        t_life, _ = self.simulate(t_insp, x_50, x_a, x_b)
        return float(np.mean(t_life))

    def optimize_inspection_time(self, x_50: float, x_a: float, x_b: float) -> tuple[float, float]:
        hi = max(float(np.quantile(self.t_life_0, 0.95)), 1.0)

        def objective(t_h: float) -> float:
            return -self.expected_service_life(t_h, x_50, x_a, x_b)

        t_opt, _ = minimize_bounded_golden(objective, 0.0, hi, xatol=1.0e-3)
        return t_opt, self.expected_service_life(t_opt, x_50, x_a, x_b)


def make_table1(model: Case1Model) -> pd.DataFrame:
    rows: list[dict[str, float | str]] = []
    for x_a, x_b in CRITERIA_SETS:
        row_t: dict[str, float | str] = {"Metric": "t_insp_h", "x_A": x_a, "x_B": x_b}
        row_life: dict[str, float | str] = {"Metric": "E_t_life_h", "x_A": x_a, "x_B": x_b}
        for x_50 in X50_LEVELS:
            t_opt, e_opt = model.optimize_inspection_time(x_50, x_a, x_b)
            row_t[f"x50_{x_50:.1f}"] = round(t_opt, 2)
            row_life[f"x50_{x_50:.1f}"] = round(e_opt, 2)
        rows.extend([row_t, row_life])
    return pd.DataFrame(rows)


def write_time_damage_summary(model: Case1Model, out_dir: Path) -> None:
    x_grid = np.linspace(0.0, 1.0, 501)
    t_x = model.t_oc[:, None] + x_grid[None, :] / model.c_rate[:, None]
    pd.DataFrame(
        {
            "damage": x_grid,
            "mean_time_h": t_x.mean(axis=0),
            "std_time_h": t_x.std(axis=0),
        }
    ).to_csv(out_dir / "fig8a_time_damage_summary.csv", index=False)

    rows = []
    for damage in (0.2, 0.4, 0.6, 0.8):
        samples = model.t_oc + damage / model.c_rate
        grid, cdf = cdf_on_grid(samples)
        rows.extend({"damage": damage, "time_h": float(x), "cdf": float(y)} for x, y in zip(grid, cdf))
    pd.DataFrame(rows).to_csv(out_dir / "fig8a_time_damage_cdf.csv", index=False)


def curve_summary(label: str, values: np.ndarray, t_opt: float, x_50: float, x_a: float, x_b: float) -> dict[str, float | str]:
    values = values[np.isfinite(values)]
    return {
        "label": label,
        "t_insp_h": t_opt,
        "x50": x_50,
        "x_A": x_a,
        "x_B": x_b,
        "mean_h": float(np.mean(values)),
        "median_h": float(np.quantile(values, 0.5)),
        "p90_h": float(np.quantile(values, 0.9)),
        "p99_h": float(np.quantile(values, 0.99)),
    }


def write_policy_curves(model: Case1Model, out_dir: Path) -> None:
    curve_rows = []
    summary_rows = []

    def add_curve(figure: str, label: str, values: np.ndarray, t_opt: float, x_50: float, x_a: float, x_b: float) -> None:
        grid, cdf = cdf_on_grid(values)
        curve_rows.extend(
            {
                "figure": figure,
                "label": label,
                "time_h": float(x),
                "cdf": float(y),
                "t_insp_h": t_opt,
                "x50": x_50,
                "x_A": x_a,
                "x_B": x_b,
            }
            for x, y in zip(grid, cdf)
        )
        summary_rows.append(curve_summary(f"{figure}:{label}", values, t_opt, x_50, x_a, x_b))

    x_a, x_b = 0.3, 0.5
    for x_50 in (0.1, 0.5):
        t_opt, _ = model.optimize_inspection_time(x_50, x_a, x_b)
        t_life, t_delay = model.simulate(t_opt, x_50, x_a, x_b)
        add_curve("fig9a", f"x50={x_50:.1f}", t_life, t_opt, x_50, x_a, x_b)
        add_curve("fig10a", f"x50={x_50:.1f}", t_delay, t_opt, x_50, x_a, x_b)
        add_curve("fig11a", f"x50={x_50:.1f}", np.maximum(t_life - t_opt, 0.0), t_opt, x_50, x_a, x_b)

    x_50 = 0.1
    for x_a, x_b in CRITERIA_SETS:
        t_opt, _ = model.optimize_inspection_time(x_50, x_a, x_b)
        t_life, t_delay = model.simulate(t_opt, x_50, x_a, x_b)
        label = f"x_A={x_a:.1f}, x_B={x_b:.1f}"
        add_curve("fig9b", label, t_life, t_opt, x_50, x_a, x_b)
        add_curve("fig10b", label, t_delay, t_opt, x_50, x_a, x_b)
        add_curve("fig11b", label, np.maximum(t_life - t_opt, 0.0), t_opt, x_50, x_a, x_b)

    pd.DataFrame(curve_rows).to_csv(out_dir / "fig9_to_fig11_cdf_curves.csv", index=False)
    pd.DataFrame(summary_rows).to_csv(out_dir / "fig9_to_fig11_curve_summary.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Reproduce Case Study I CSV tables for the single-inspection "
            "maintenance policy."
        )
    )
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT, help="Directory for generated Case 1 CSV outputs.")
    parser.add_argument("--n-mc", type=int, default=N_MC, help="Number of Monte Carlo samples.")
    parser.add_argument("--seed", type=int, default=SEED, help="Random seed for reproducible sampling.")
    args = parser.parse_args()

    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    model = Case1Model(args.n_mc, args.seed)

    make_table1(model).to_csv(out_dir / "table1_case1.csv", index=False)
    write_time_damage_summary(model, out_dir)
    histogram_pdf(model.t_life_0).to_csv(out_dir / "fig8b_initial_service_life_pdf.csv", index=False)
    write_policy_curves(model, out_dir)

    settings = {
        "n_mc": args.n_mc,
        "seed": args.seed,
        "x_th": X_TH,
        "x_min": X_MIN,
        "x50_levels": list(X50_LEVELS),
        "criteria_sets": [list(x) for x in CRITERIA_SETS],
        "c_rate_mean_sd": [C_MEAN, C_SD],
        "t_oc_mean_sd_h": [TOC_MEAN, TOC_SD],
        "t_eff_A_mean_sd_h": [TE1_MEAN, TE1_SD],
        "t_eff_B_mean_sd_h": [TE2_MEAN, TE2_SD],
    }
    (out_dir / "settings.json").write_text(json.dumps(settings, indent=2), encoding="utf-8")
    print(f"Case 1 data written: {out_dir}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""Run Case Study II: two scheduled inspections with servicing only.

This script implements the two-stage shallow/deep inspection decision tree for
exactly two scheduled inspections. It optimizes the first inspection time, the
inter-inspection gap, and the servicing threshold x_A with a two-objective NSGA-II
search.

Outputs are written to outputs/case2/ and are used by the manuscript's Case
Study II tables and Fig. 13. The script is standalone and does not import other
project scripts.
"""

from __future__ import annotations

# Article mapping:
# - Case Study II, two scheduled inspections with servicing only.
# - Generates outputs/case2/pareto_solutions.csv and pareto_table.csv for Fig. 13
#   and the representative-policy table.
# - Standalone by design: no imports from other project scripts and no writes to
#   LaTeX/submission folders.

import os
import math
import json
import argparse
from dataclasses import dataclass
from typing import Tuple, List, Dict, Any

import numpy as np
import pandas as pd


# tqdm (ETA progress bars)
try:
    from tqdm.auto import tqdm, trange  # type: ignore
except Exception:
    tqdm = None
    trange = None

BAR_FMT = "{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]"

# Resolve inputs and outputs from the project root, independent of the shell's
# current working directory.
WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


# -----------------------------
# Repro / runtime
# -----------------------------
SEED = 123
N_MC = 60000
POP_SIZE = 100
N_GEN = 100
ARCHIVE_MAX = 2500


# -----------------------------
# Physics / lab constraints
# -----------------------------
B_CENTER = 0.10
B_SD = 0.042
B_MIN = 0.01
B_MAX = 0.30
c_MEDIAN = 0.0873
c_LN_SD = 0.05

x_th = 0.20
x_min = 1e-3

MIN_GAP_H = 100.0
T_HORIZON_H = 8000.0

T1_MIN, T1_MAX = 80.0, 4000.0
GAP_MIN, GAP_MAX = MIN_GAP_H, 2500.0
X_A_MIN, X_A_MAX = 0.02, x_th - 0.005


# -----------------------------
# Shallow screening outcome model. PoD drives the binary alarm, from which
# TP/FN/FP/TN are counted relative to x_A; deep confirmation is deterministic.
# PoD(x) = logistic( POD_ALPHA + POD_BETA * ln(delta) )
# -----------------------------
POD_X50_REF = 0.10
POD_PMIN_AT_XMIN = 1.0e-3
POD_BETA = math.log(POD_PMIN_AT_XMIN / (1.0 - POD_PMIN_AT_XMIN)) / math.log(x_min / POD_X50_REF)
POD_ALPHA = -POD_BETA * math.log(POD_X50_REF)


# -----------------------------
# Maintenance A (virtual-time delay)
# -----------------------------
TEFF_A_MEAN = 1000.0
TEFF_A_SD   = 500.0


# -----------------------------
# Costs (NO lab-time monetization)
# Kim-style semantics: shallow cost every scheduled insp; deep cost only after indication
# -----------------------------
COST_INSP_SHALLOW = 1.0
COST_INSP_DEEP    = 3.0
COST_MAINT_A      = 15.0


# -----------------------------
# Utilities
# -----------------------------
def ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def lognormal_mu_sigma_from_mean_sd(mean: float, sd: float) -> Tuple[float, float]:
    var = sd ** 2
    sigma2 = math.log(1.0 + var / (mean ** 2))
    sigma = math.sqrt(sigma2)
    mu = math.log(mean) - 0.5 * sigma2
    return mu, sigma


def sample_b_random_effect(rng: np.random.Generator, size) -> np.ndarray:
    """Bounded logistic-normal random effect for the power-law exponent b."""
    y = (B_CENTER - B_MIN) / (B_MAX - B_MIN)
    eta_mu = math.log(y / (1.0 - y))
    eta_sigma = B_SD / ((B_MAX - B_MIN) * y * (1.0 - y))
    eta = rng.normal(loc=eta_mu, scale=eta_sigma, size=size)
    return B_MIN + (B_MAX - B_MIN) / (1.0 + np.exp(-eta))


def logistic_stable(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z)
    out = np.empty_like(z, dtype=float)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1.0 + ez)
    return out

def pod_shallow(delta: np.ndarray) -> np.ndarray:
    d = np.asarray(delta, dtype=float)
    out = np.zeros_like(d)
    m = d > x_min
    if np.any(m):
        z = POD_ALPHA + POD_BETA * np.log(d[m])
        out[m] = logistic_stable(z)
    return np.clip(out, 0.0, 1.0)

def sample_tlife0_from_pdf(csv_path: str, n: int, rng: np.random.Generator) -> np.ndarray:
    df = pd.read_csv(csv_path)
    if "t" not in df.columns or "pdf" not in df.columns:
        raise ValueError("tlife0_pdf.csv must contain columns: t, pdf")
    t = df["t"].to_numpy(dtype=float)
    p = df["pdf"].to_numpy(dtype=float)
    if np.any(t <= 0) or np.any(p < 0):
        raise ValueError("PDF requires t>0 and pdf>=0.")

    order = np.argsort(t)
    t = t[order]
    p = p[order]

    cdf = np.zeros_like(t)
    area = 0.0
    for i in range(1, len(t)):
        area += 0.5 * (p[i - 1] + p[i]) * (t[i] - t[i - 1])
        cdf[i] = area
    if area <= 0:
        raise ValueError("PDF integrates to zero.")
    cdf /= area

    u = rng.random(n)
    return np.interp(u, cdf, t)

def repair_policy(x: np.ndarray) -> np.ndarray:
    t1, gap, aA = map(float, x)
    # t1 bounded, but also must allow t2<=horizon with at least min gap
    t1_hi = min(T1_MAX, T_HORIZON_H - GAP_MIN)
    t1 = float(np.clip(t1, T1_MIN, t1_hi))

    gap_hi = min(GAP_MAX, max(GAP_MIN, T_HORIZON_H - t1))
    gap = float(np.clip(gap, GAP_MIN, gap_hi))

    aA = float(np.clip(aA, X_A_MIN, X_A_MAX))
    return np.array([t1, gap, aA], dtype=float)


# -----------------------------
# Monte Carlo presampling (common random numbers)
# -----------------------------
@dataclass
class PreSample:
    c: np.ndarray
    b: np.ndarray
    tfail0: np.ndarray
    u1: np.ndarray
    u2: np.ndarray
    teff1: np.ndarray
    teff2: np.ndarray

def presample_mc(n: int, seed: int) -> PreSample:
    rng = np.random.default_rng(seed)

    pdf_path = os.path.join(WORKSPACE_ROOT, "data", "tlife0_pdf.csv")
    b = sample_b_random_effect(rng, n)
    if os.path.exists(pdf_path):
        tfail0 = sample_tlife0_from_pdf(pdf_path, n, rng)
        c = x_th / (tfail0 ** b)
    else:
        c = rng.lognormal(mean=math.log(c_MEDIAN), sigma=c_LN_SD, size=n)
        tfail0 = (x_th / c) ** (1.0 / b)

    u1 = rng.random(n)
    u2 = rng.random(n)

    mu_te, sig_te = lognormal_mu_sigma_from_mean_sd(TEFF_A_MEAN, TEFF_A_SD)
    teff1 = rng.lognormal(mean=mu_te, sigma=sig_te, size=n)
    teff2 = rng.lognormal(mean=mu_te, sigma=sig_te, size=n)

    return PreSample(c=c, b=b, tfail0=tfail0, u1=u1, u2=u2, teff1=teff1, teff2=teff2)


# -----------------------------
# Policy simulation (Kim-aligned 10a + 8a logic)
# -----------------------------
def simulate_policy(x: np.ndarray, S: PreSample) -> Tuple[float, float, float, float, float, float, float, float]:
    """
    Returns:
      (E_cost, E_life, E_num_deep, E_num_maintA,
       E_num_FP, E_num_TP, E_num_FN, E_num_TN)

    Notes:
      - "termination" is by discovered failure at a scheduled inspection. It stops future inspection costs.
      - service life is the (possibly delayed) failure time, right-censored at T_HORIZON_H.
    """
    t1, gap, x_A = map(float, x)
    t2 = t1 + gap

    c = S.c
    b = S.b
    tfail0 = S.tfail0
    delay = np.zeros_like(tfail0, dtype=float)

    total_cost = np.zeros_like(tfail0, dtype=float)
    n_deep = np.zeros_like(tfail0, dtype=float)
    n_maint = np.zeros_like(tfail0, dtype=float)
    n_fp = np.zeros_like(tfail0, dtype=float)
    n_tp = np.zeros_like(tfail0, dtype=float)
    n_fn = np.zeros_like(tfail0, dtype=float)
    n_tn = np.zeros_like(tfail0, dtype=float)

    active = np.ones_like(tfail0, dtype=bool)  # not yet terminated by discovered failure

    def tfail(dly: np.ndarray) -> np.ndarray:
        return dly + tfail0

    def damage_at(t_insp: float, dly: np.ndarray) -> np.ndarray:
        t_eff = np.maximum(t_insp - dly, 0.0)
        return c * (t_eff ** b)

    def one_inspection(t_insp: float, u: np.ndarray, teff: np.ndarray):
        nonlocal delay, total_cost, n_deep, n_maint, active

        do_shallow = active
        if not np.any(do_shallow):
            return

        # Eq. 10a: scheduled shallow cost always charged (for active)
        total_cost[do_shallow] += COST_INSP_SHALLOW

        # if already failed before this inspection: discover now and terminate thereafter
        failed_before = do_shallow & (t_insp > tfail(delay))
        if np.any(failed_before):
            active[failed_before] = False

        alive = do_shallow & (~failed_before)
        if not np.any(alive):
            return

        d = damage_at(t_insp, delay)
        p = pod_shallow(d)
        indicates = alive & (u < p)
        true_defect = d >= x_A
        no_alarm = alive & (~indicates)
        n_fp[indicates & (~true_defect)] += 1.0
        n_tp[indicates & true_defect] += 1.0
        n_fn[no_alarm & true_defect] += 1.0
        n_tn[no_alarm & (~true_defect)] += 1.0
        if not np.any(indicates):
            return

        # Deep confirmation is performed after every shallow alarm. If d < x_A,
        # this alarm is a false positive: charge deep-inspection cost only and
        # leave the degradation state unchanged. If d >= x_A, the alarm is a
        # true positive and may trigger maintenance below.
        total_cost[indicates] += COST_INSP_DEEP
        n_deep[indicates] += 1.0

        # maintenance A if x_A <= delta < x_th
        do_A = indicates & (d >= x_A) & (d < x_th - 1e-12)
        if np.any(do_A):
            total_cost[do_A] += COST_MAINT_A
            n_maint[do_A] += 1.0
            delay[do_A] += teff[do_A]

    one_inspection(t1, S.u1, S.teff1)
    one_inspection(t2, S.u2, S.teff2)

    life = tfail(delay)
    life = np.minimum(life, T_HORIZON_H)

    return (
        float(np.mean(total_cost)),
        float(np.mean(life)),
        float(np.mean(n_deep)),
        float(np.mean(n_maint)),
        float(np.mean(n_fp)),
        float(np.mean(n_tp)),
        float(np.mean(n_fn)),
        float(np.mean(n_tn)),
    )


# -----------------------------
# NSGA-II (2 objectives: minimize cost, minimize -life)
# -----------------------------
def dominates_2d(fa: Tuple[float, float], fb: Tuple[float, float]) -> bool:
    return (fa[0] <= fb[0] and fa[1] <= fb[1]) and (fa[0] < fb[0] or fa[1] < fb[1])

def fast_nondominated_sort(F: List[Tuple[float, float]]) -> List[List[int]]:
    n = len(F)
    Sset = [set() for _ in range(n)]
    n_dom = np.zeros(n, dtype=int)
    fronts: List[List[int]] = [[]]

    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if dominates_2d(F[p], F[q]):
                Sset[p].add(q)
            elif dominates_2d(F[q], F[p]):
                n_dom[p] += 1
        if n_dom[p] == 0:
            fronts[0].append(p)

    i = 0
    while fronts[i]:
        nxt: List[int] = []
        for p in fronts[i]:
            for q in Sset[p]:
                n_dom[q] -= 1
                if n_dom[q] == 0:
                    nxt.append(q)
        i += 1
        fronts.append(nxt)
    fronts.pop()
    return fronts

def crowding_distance(F: List[Tuple[float, float]], front: List[int]) -> np.ndarray:
    dist = np.zeros(len(front), dtype=float)
    if len(front) == 0:
        return dist
    if len(front) <= 2:
        dist[:] = np.inf
        return dist
    vals = np.array([F[i] for i in front], dtype=float)
    for j in range(2):
        order = np.argsort(vals[:, j])
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf
        vmin = vals[order[0], j]
        vmax = vals[order[-1], j]
        if vmax - vmin < 1e-12:
            continue
        for k in range(1, len(front) - 1):
            dist[order[k]] += (vals[order[k + 1], j] - vals[order[k - 1], j]) / (vmax - vmin)
    return dist

def tournament_select(rng: np.random.Generator, idx: np.ndarray, ranks: np.ndarray, crowds: np.ndarray) -> int:
    a, b = rng.choice(idx, size=2, replace=False)
    if ranks[a] < ranks[b]:
        return int(a)
    if ranks[b] < ranks[a]:
        return int(b)
    return int(a if crowds[a] > crowds[b] else b)

def sbx_crossover(rng: np.random.Generator, p1: np.ndarray, p2: np.ndarray,
                  eta: float = 15.0, p_c: float = 0.9) -> Tuple[np.ndarray, np.ndarray]:
    c1, c2 = p1.copy(), p2.copy()
    if rng.random() > p_c:
        return c1, c2

    bounds = [(T1_MIN, T1_MAX), (GAP_MIN, GAP_MAX), (X_A_MIN, X_A_MAX)]
    for i, (xL, xU) in enumerate(bounds):
        x1, x2 = float(p1[i]), float(p2[i])
        if abs(x1 - x2) < 1e-12:
            continue
        if x1 > x2:
            x1, x2 = x2, x1
        u = rng.random()

        beta = 1.0 + (2.0 * (x1 - xL) / (x2 - x1))
        alpha = 2.0 - beta ** (-(eta + 1.0))
        if u <= 1.0 / alpha:
            betaq = (u * alpha) ** (1.0 / (eta + 1.0))
        else:
            betaq = (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0))
        child1 = 0.5 * ((x1 + x2) - betaq * (x2 - x1))

        beta = 1.0 + (2.0 * (xU - x2) / (x2 - x1))
        alpha = 2.0 - beta ** (-(eta + 1.0))
        if u <= 1.0 / alpha:
            betaq = (u * alpha) ** (1.0 / (eta + 1.0))
        else:
            betaq = (1.0 / (2.0 - u * alpha)) ** (1.0 / (eta + 1.0))
        child2 = 0.5 * ((x1 + x2) + betaq * (x2 - x1))

        c1[i] = float(np.clip(child1, xL, xU))
        c2[i] = float(np.clip(child2, xL, xU))

    return repair_policy(c1), repair_policy(c2)

def poly_mutation(rng: np.random.Generator, x: np.ndarray,
                  eta: float = 20.0, p_m: float = 0.25) -> np.ndarray:
    y = x.copy()
    bounds = [(T1_MIN, T1_MAX), (GAP_MIN, GAP_MAX), (X_A_MIN, X_A_MAX)]
    for i, (xL, xU) in enumerate(bounds):
        if rng.random() > p_m:
            continue
        xi = float(y[i])
        if xU - xL < 1e-12:
            continue
        delta1 = (xi - xL) / (xU - xL)
        delta2 = (xU - xi) / (xU - xL)
        u = rng.random()
        mut_pow = 1.0 / (eta + 1.0)
        if u < 0.5:
            xy = 1.0 - delta1
            val = 2.0 * u + (1.0 - 2.0 * u) * (xy ** (eta + 1.0))
            dq = val ** mut_pow - 1.0
        else:
            xy = 1.0 - delta2
            val = 2.0 * (1.0 - u) + 2.0 * (u - 0.5) * (xy ** (eta + 1.0))
            dq = 1.0 - val ** mut_pow
        xi = xi + dq * (xU - xL)
        y[i] = float(np.clip(xi, xL, xU))
    return repair_policy(y)

def evaluate_population(X: np.ndarray, S: PreSample, desc: str, leave: bool, position: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = X.shape[0]
    cost = np.zeros(n)
    life = np.zeros(n)
    extra = np.zeros((n, 6))

    it = range(n)
    if tqdm is not None:
        it = tqdm(
            it,
            desc=desc,
            leave=leave,
            position=position,
            bar_format=BAR_FMT,
            dynamic_ncols=True,
            mininterval=0.5,
            smoothing=0.1,
        )

    for i in it:
        cst, lf, nd, nm, fp, tp, fn, tn = simulate_policy(X[i], S)
        cost[i], life[i] = cst, lf
        extra[i] = [nd, nm, fp, tp, fn, tn]
    return cost, life, extra

def nondominated_mask(cost: np.ndarray, neg_life: np.ndarray) -> np.ndarray:
    n = len(cost)
    keep = np.ones(n, dtype=bool)
    for i in range(n):
        if not keep[i]:
            continue
        for j in range(n):
            if i == j or not keep[i]:
                continue
            if (cost[j] <= cost[i] and neg_life[j] <= neg_life[i]) and (cost[j] < cost[i] or neg_life[j] < neg_life[i]):
                keep[i] = False
                break
    return keep

def update_archive(archive: Dict[str, Any], X: np.ndarray, objs: np.ndarray, extra: np.ndarray,
                   max_size: int) -> None:
    if archive["X"].size == 0:
        archive["X"] = X.copy()
        archive["objs"] = objs.copy()
        archive["extra"] = extra.copy()
    else:
        archive["X"] = np.vstack([archive["X"], X])
        archive["objs"] = np.vstack([archive["objs"], objs])
        archive["extra"] = np.vstack([archive["extra"], extra])

    keep = nondominated_mask(archive["objs"][:, 0], archive["objs"][:, 1])
    archive["X"] = archive["X"][keep]
    archive["objs"] = archive["objs"][keep]
    archive["extra"] = archive["extra"][keep]

    if archive["X"].shape[0] > max_size:
        idx = list(range(archive["X"].shape[0]))
        F = [(float(archive["objs"][i, 0]), float(archive["objs"][i, 1])) for i in idx]
        cd = crowding_distance(F, idx)
        order = np.argsort(-cd)
        sel = order[:max_size]
        archive["X"] = archive["X"][sel]
        archive["objs"] = archive["objs"][sel]
        archive["extra"] = archive["extra"][sel]


def collect_settings() -> Dict[str, Any]:
    return {
        "SEED": SEED,
        "N_MC": N_MC,
        "POP_SIZE": POP_SIZE,
        "N_GEN": N_GEN,
        "B_model": "bounded logistic-normal random effect",
        "B_CENTER": B_CENTER,
        "B_SD": B_SD,
        "B_MIN": B_MIN,
        "B_MAX": B_MAX,
        "x_th": x_th,
        "x_min": x_min,
        "MIN_GAP_H": MIN_GAP_H,
        "T_HORIZON_H": T_HORIZON_H,
        "c_MEDIAN": c_MEDIAN,
        "c_LN_SD": c_LN_SD,
        "POD_CALIBRATION": "two-point reference: PoD(x_min)=1e-3 and PoD(x50)=0.5",
        "POD_X50_REF": POD_X50_REF,
        "POD_PMIN_AT_XMIN": POD_PMIN_AT_XMIN,
        "POD_ALPHA": POD_ALPHA,
        "POD_BETA": POD_BETA,
        "TEFF_A_MEAN": TEFF_A_MEAN,
        "TEFF_A_SD": TEFF_A_SD,
        "COSTS": {
            "C_ins_s": COST_INSP_SHALLOW,
            "C_ins_d": COST_INSP_DEEP,
            "C_ma_A": COST_MAINT_A,
        },
        "BOUNDS": {
            "t1": [T1_MIN, T1_MAX],
            "gap": [GAP_MIN, GAP_MAX],
            "x_A": [X_A_MIN, X_A_MAX],
        },
        "KIM_SEMANTICS": "shallow charged each scheduled insp; deep deterministic after indication; failure discovery terminates future inspections; service life is failure time (censored).",
        "PROGRESS": "tqdm nested (gen + eval) with ETA",
    }

def nsga2_optimize(seed: int = SEED) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    S = presample_mc(N_MC, seed)

    # init population
    X = np.zeros((POP_SIZE, 3), dtype=float)
    for i in range(POP_SIZE):
        t1 = rng.uniform(T1_MIN, min(T1_MAX, T_HORIZON_H - GAP_MIN))
        gap = rng.uniform(GAP_MIN, min(GAP_MAX, max(GAP_MIN, T_HORIZON_H - t1)))
        aA = rng.uniform(X_A_MIN, X_A_MAX)
        X[i] = repair_policy(np.array([t1, gap, aA], dtype=float))

    archive = dict(
        X=np.empty((0, 3), dtype=float),
        objs=np.empty((0, 2), dtype=float),   # [cost, -life]
        extra=np.empty((0, 6), dtype=float),  # [E_num_deep, E_num_maintA, E_num_FP, E_num_TP, E_num_FN, E_num_TN]
    )

    gen_it = (
        trange(
            N_GEN,
            desc="NSGA-II",
            bar_format=BAR_FMT,
            dynamic_ncols=True,
            mininterval=0.5,
            smoothing=0.1,
            position=0,
        )
        if trange is not None else range(N_GEN)
    )

    for _ in gen_it:
        # evaluate current pop (inner ETA bar)
        cost, life, extra = evaluate_population(X, S, desc="Eval(pop)", leave=False, position=1)
        objs = np.column_stack([cost, -life])
        update_archive(archive, X, objs, extra, ARCHIVE_MAX)

        # ranks + crowding
        F = [(float(objs[i, 0]), float(objs[i, 1])) for i in range(POP_SIZE)]
        fronts = fast_nondominated_sort(F)

        ranks = np.full(POP_SIZE, 10**9, dtype=int)
        crowds = np.zeros(POP_SIZE, dtype=float)
        for r, fr in enumerate(fronts):
            for idx in fr:
                ranks[idx] = r
            cd = crowding_distance(F, fr)
            for j, idx in enumerate(fr):
                crowds[idx] = cd[j]

        # offspring
        offspring = []
        idx_all = np.arange(POP_SIZE)
        while len(offspring) < POP_SIZE:
            p1 = X[tournament_select(rng, idx_all, ranks, crowds)]
            p2 = X[tournament_select(rng, idx_all, ranks, crowds)]
            c1, c2 = sbx_crossover(rng, p1, p2)
            c1 = poly_mutation(rng, c1)
            c2 = poly_mutation(rng, c2)
            offspring.append(c1)
            if len(offspring) < POP_SIZE:
                offspring.append(c2)
        X_off = np.array(offspring, dtype=float)

        # union evaluation (inner ETA bar)
        X_u = np.vstack([X, X_off])
        cost_u, life_u, _ = evaluate_population(X_u, S, desc="Eval(union)", leave=False, position=1)
        objs_u = np.column_stack([cost_u, -life_u])
        F_u = [(float(objs_u[i, 0]), float(objs_u[i, 1])) for i in range(X_u.shape[0])]
        fronts_u = fast_nondominated_sort(F_u)

        sel = []
        for fr in fronts_u:
            if len(sel) + len(fr) <= POP_SIZE:
                sel.extend(fr)
            else:
                cd = crowding_distance(F_u, fr)
                order = np.argsort(-cd)
                need = POP_SIZE - len(sel)
                sel.extend([fr[i] for i in order[:need]])
                break
        X = X_u[np.array(sel, dtype=int)]

    return {"archive": archive, "settings": collect_settings()}


# -----------------------------
# Pareto outputs
# -----------------------------
def build_pareto_dataframe(archive: Dict[str, Any]) -> pd.DataFrame:
    X = archive["X"]
    objs = archive["objs"]
    extra = archive["extra"]

    t1 = X[:, 0]
    gap = X[:, 1]
    t2 = t1 + gap
    aA = X[:, 2]

    df = pd.DataFrame({
        "t1_h": t1,
        "t2_h": t2,
        "gap_h": gap,
        "x_A": aA,
        "E_cost": objs[:, 0],
        "E_life_h": -objs[:, 1],
        "E_num_deep": extra[:, 0],
        "E_num_maintA": extra[:, 1],
        "E_num_FP": extra[:, 2],
        "E_num_TP": extra[:, 3],
        "E_num_FN": extra[:, 4],
        "E_num_TN": extra[:, 5],
    })
    df = df.sort_values(["E_cost", "E_life_h"], ascending=[True, False]).reset_index(drop=True)
    return df

def representative_table(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    c = df["E_cost"].to_numpy()
    picks = []
    for tag, q in (("Q25", 0.25), ("Q50", 0.50), ("Q75", 0.75)):
        target = np.quantile(c, q)
        idx = int(np.argmin(np.abs(c - target)))
        picks.append((tag, idx))

    seen = set()
    rows = []
    for tag, idx in picks:
        if idx in seen:
            continue
        seen.add(idx)
        r = df.iloc[idx].to_dict()
        r["Tag"] = tag
        rows.append(r)

    out = pd.DataFrame(rows)
    cols = [
        "Tag", "E_cost", "E_life_h", "x_A", "t1_h", "t2_h", "gap_h",
        "E_num_deep", "E_num_maintA", "E_num_FP", "E_num_TP", "E_num_FN", "E_num_TN",
    ]
    return out[cols]

# -----------------------------
# Main
# -----------------------------
def main() -> None:
    global SEED, N_MC, POP_SIZE, N_GEN

    parser = argparse.ArgumentParser(
        description=(
            "Reproduce Case Study II: two scheduled inspections with servicing "
            "only, optimized by a two-objective NSGA-II search."
        )
    )
    parser.add_argument("--out-dir", default=os.path.join(WORKSPACE_ROOT, "outputs", "case2"), help="Directory for generated Case 2 outputs.")
    parser.add_argument("--seed", type=int, default=SEED, help="Random seed used for Monte Carlo sampling and optimization.")
    parser.add_argument("--n-mc", type=int, default=N_MC, help="Number of Monte Carlo samples.")
    parser.add_argument("--pop-size", type=int, default=POP_SIZE, help="NSGA-II population size.")
    parser.add_argument("--n-gen", type=int, default=N_GEN, help="Number of NSGA-II generations.")
    args = parser.parse_args()

    SEED = args.seed
    N_MC = args.n_mc
    POP_SIZE = args.pop_size
    N_GEN = args.n_gen

    out_dir = os.path.abspath(args.out_dir)
    ensure_dir(out_dir)

    res = nsga2_optimize(SEED)
    archive = res["archive"]
    settings = res["settings"]

    with open(os.path.join(out_dir, "settings.json"), "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)

    df_pareto = build_pareto_dataframe(archive)
    cols_all = [
        "E_cost", "E_life_h", "x_A", "t1_h", "t2_h", "gap_h",
        "E_num_deep", "E_num_maintA", "E_num_FP", "E_num_TP", "E_num_FN", "E_num_TN",
    ]
    df_pareto[cols_all].to_csv(os.path.join(out_dir, "pareto_solutions.csv"), index=False)

    df_table = representative_table(df_pareto)
    cols_tag = [
        "Tag", "E_cost", "E_life_h", "x_A", "t1_h", "t2_h", "gap_h",
        "E_num_deep", "E_num_maintA", "E_num_FP", "E_num_TP", "E_num_FN", "E_num_TN",
    ]
    df_table[cols_tag].to_csv(os.path.join(out_dir, "pareto_table.csv"), index=False)

    pd.set_option("display.width", 240)
    pd.set_option("display.max_columns", 200)
    print("\n=== Representative Pareto Table (Tag) ===\n")
    print(df_table[cols_tag].to_string(index=False))
    print(f"\nSaved outputs to: {out_dir}")
    print(f"Pareto set size: {len(df_pareto)}")

if __name__ == "__main__":
    main()

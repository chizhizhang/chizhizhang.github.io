#!/usr/bin/env python3
"""Numerical reproduction of the covariate-dependent HSMM manuscript.

This independent script contains model inference, simulation, laser validation,
the HUST battery extension, baselines, sensitivity analyses and plot-data export.
It uses no local helper imports or plotting libraries. See README.md for commands.
"""
from __future__ import annotations


# Data, duration models and ordered prediction
# ------------------------------------------------------------------------
#!/usr/bin/env python3


import argparse
import concurrent.futures
import copy
import csv
import hashlib
import json
import math
import os
import platform
import shutil
import subprocess
import sys
import time
import tracemalloc
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import gammaln, ndtr, ndtri, log_ndtr


ROOT = Path(__file__).resolve().parents[1]
FEATURE_COLUMNS = [
    "degradation_depth",
    "loss_rate",
    "heat_proxy_w",
    "wavelength_shift_nm",
    "bandwidth_shift_nm",
    "spectral_instability",
    "electrical_efficiency",
]
STATE_LABELS_4 = ["Stable operation", "Drift", "L80 risk", "Collapse"]
ENGINEERING_TRANSITION_TARGETS = {"L90": 1, "L80": 2, "T50": 3}
PRIMARY_MULTISTAGE_ESTIMAND = "equal_target_macro"
REPORTED_RELIABILITY_TRANSITION = "L80"
EPS = 1e-12


@dataclass(frozen=True)
class ThresholdEvidence:
    """Persistent threshold event or right-censoring record for one state boundary."""

    name: str
    level: float
    target_state: int
    event: int
    event_index: int | None
    event_low: int | None
    event_high: int | None
    censor_index: int | None = None


@dataclass
class UnitSequence:
    """One condition-monitoring trajectory and its endpoint evidence."""

    unit_id: str
    current: float
    age: np.ndarray
    x: np.ndarray
    temperature: np.ndarray
    flow: np.ndarray
    event: int
    event_index: int | None
    event_low: int | None
    event_high: int | None
    censor_index: int
    frame: pd.DataFrame
    true_path: np.ndarray | None = None
    true_event_index: int | None = None
    thresholds: dict[str, ThresholdEvidence] | None = None
    true_transition_indices: dict[str, int | None] | None = None
    true_pace: float | None = None

    def prefix(self, end_index: int) -> "UnitSequence":
        """Return observations through end_index without future endpoint labels."""

        j = int(max(0, min(end_index, len(self.age) - 1)))
        frame = self.frame.iloc[: j + 1].copy()
        prefix_thresholds: dict[str, ThresholdEvidence] | None = None
        if self.thresholds is not None:
            prefix_thresholds = {}
            for name, evidence in self.thresholds.items():
                observed = bool(
                    evidence.event
                    and evidence.event_high is not None
                    and evidence.event_high <= j
                )
                prefix_thresholds[name] = ThresholdEvidence(
                    name=evidence.name,
                    level=evidence.level,
                    target_state=evidence.target_state,
                    event=int(observed),
                    event_index=evidence.event_index if observed else None,
                    event_low=evidence.event_low if observed else None,
                    event_high=evidence.event_high if observed else None,
                    censor_index=(
                        evidence.event_high
                        if observed
                        else min(
                            j,
                            j if evidence.censor_index is None else int(evidence.censor_index),
                        )
                    ),
                )
        l80 = None if prefix_thresholds is None else prefix_thresholds.get("L80")
        return UnitSequence(
            unit_id=self.unit_id,
            current=self.current,
            age=self.age[: j + 1].copy(),
            x=self.x[: j + 1].copy(),
            temperature=self.temperature[: j + 1].copy(),
            flow=self.flow[: j + 1].copy(),
            event=0 if l80 is None else l80.event,
            event_index=None if l80 is None else l80.event_index,
            event_low=None if l80 is None else l80.event_low,
            event_high=None if l80 is None else l80.event_high,
            censor_index=j,
            frame=frame,
            true_path=None,
            true_event_index=None,
            thresholds=prefix_thresholds,
            true_transition_indices=None,
            true_pace=None,
        )


def load_config(path: Path) -> dict[str, Any]:
    """Read JSON-compatible YAML without requiring PyYAML."""

    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml  # type: ignore

            return yaml.safe_load(text)
        except ImportError as exc:
            raise RuntimeError(
                "The configuration is not JSON-compatible YAML and PyYAML is unavailable."
            ) from exc


def keyed_rng(seed: int, *parts: Any) -> np.random.Generator:
    """Create an order-independent stream for paired Monte Carlo comparisons."""

    key = "|".join([str(seed), *(str(part) for part in parts)])
    digest = hashlib.sha256(key.encode("utf-8")).digest()
    return np.random.default_rng(int.from_bytes(digest[:8], byteorder="little", signed=False))


def json_ready(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    return value


def first_index_at_or_after(values: np.ndarray, target: float) -> int:
    idx = int(np.searchsorted(values, target, side="left"))
    return min(idx, len(values) - 1)


def persistent_crossing(y: np.ndarray, threshold: float, window: int) -> int | None:
    hit = np.asarray(y <= threshold, dtype=bool)
    for idx in range(0, len(hit) - window + 1):
        if bool(hit[idx : idx + window].all()):
            return idx
    return None


def make_threshold_evidence(
    y: np.ndarray,
    name: str,
    level: float,
    target_state: int,
    persistence: int,
) -> ThresholdEvidence:
    """Construct one persistent event interval, or its right-censored record."""

    event_index = persistent_crossing(y, level, persistence)
    event_high = (
        None
        if event_index is None
        else min(event_index + persistence - 1, len(y) - 1)
    )
    return ThresholdEvidence(
        name=name,
        level=float(level),
        target_state=int(target_state),
        event=int(event_index is not None),
        event_index=event_index,
        event_low=event_index,
        event_high=event_high,
        censor_index=(len(y) - 1 if event_index is None else event_high),
    )


def mask_primary_observations(
    unit: UnitSequence,
    start_index: int,
    *,
    feature_indices: Iterable[int] = (0, 1, 2),
) -> UnitSequence:
    """Hide a trailing primary-sensor block without leaking threshold events.

    The multichannel trajectory can continue after the primary optical channel
    becomes unavailable.  Persistent threshold evidence is then observable
    only through ``start_index - 1``.  A threshold completed before the outage
    is retained; a crossing completed inside or after the outage is hidden and
    becomes observation-censored at the last primary-channel reading.  This is
    distinct from administrative right censoring of the entire unit sequence.
    """

    masked = copy.deepcopy(unit)
    start = int(np.clip(start_index, 0, len(masked.age)))
    if start >= len(masked.age):
        return masked
    indices = [int(index) for index in feature_indices]
    if indices:
        masked.x[start:, indices] = np.nan
    for column in (
        "power_w",
        "normalized_power",
        "degradation_depth",
        "loss_rate",
        "heat_proxy_w",
    ):
        if column in masked.frame:
            masked.frame.loc[masked.frame.index[start:], column] = np.nan

    if masked.thresholds is not None:
        last_observed = start - 1
        updated: dict[str, ThresholdEvidence] = {}
        for name, evidence in masked.thresholds.items():
            completed_before_outage = bool(
                evidence.event
                and evidence.event_high is not None
                and int(evidence.event_high) < start
            )
            if completed_before_outage:
                updated[name] = copy.deepcopy(evidence)
                continue
            prior_censor = (
                len(masked.age) - 1
                if evidence.censor_index is None
                else int(evidence.censor_index)
            )
            updated[name] = ThresholdEvidence(
                name=evidence.name,
                level=evidence.level,
                target_state=evidence.target_state,
                event=0,
                event_index=None,
                event_low=None,
                event_high=None,
                censor_index=min(prior_censor, last_observed),
            )
        masked.thresholds = updated
        l80 = updated.get("L80")
        if l80 is not None:
            masked.event = int(l80.event)
            masked.event_index = l80.event_index
            masked.event_low = l80.event_low
            masked.event_high = l80.event_high
    return masked


def causal_slope(values: np.ndarray, window: int) -> np.ndarray:
    out = np.zeros_like(values, dtype=float)
    for i in range(len(values)):
        j = max(0, i - window)
        out[i] = (float(values[i]) - float(values[j])) / max(float(i - j), 1.0)
    return out


def rolling_std_causal(values: np.ndarray, window: int) -> np.ndarray:
    return (
        pd.Series(values)
        .rolling(window=window, min_periods=3)
        .std()
        .fillna(0.0)
        .to_numpy(dtype=float)
    )


def read_life_file(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, comment="#").sort_values("Duration_h").reset_index(drop=True)
    required = {"Duration_h", "Current_A", "Voltage_V", "P", "Lambda_nm", "BW_nm"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"{path.name} is missing columns: {missing}")
    if frame[list(required)].isna().any().any():
        raise ValueError(f"{path.name} contains missing required values")
    if not np.all(np.diff(frame["Duration_h"].to_numpy(dtype=float)) > 0):
        raise ValueError(f"{path.name} has non-increasing timestamps")
    return frame


def causal_step_interpolate(
    query_time: np.ndarray,
    observation_time: np.ndarray,
    observation_values: np.ndarray,
) -> np.ndarray:
    """Map each query to the latest observation available at that time.

    The engineering records are irregularly sampled.  Linear interpolation
    would combine the measurements on both sides of a query and would
    therefore disclose part of the next observation to an earlier prediction
    origin.  This past-only step interpolation preserves the information set
    that would have been available online.
    """

    query = np.asarray(query_time, dtype=float)
    observed_at = np.asarray(observation_time, dtype=float)
    values = np.asarray(observation_values, dtype=float)
    if observed_at.ndim != 1 or values.ndim != 1 or observed_at.size != values.size:
        raise ValueError("Observation times and values must be aligned one-dimensional arrays")
    if observed_at.size == 0 or not np.all(np.diff(observed_at) > 0):
        raise ValueError("Observation times must be nonempty and strictly increasing")
    source_index = np.searchsorted(observed_at, query, side="right") - 1
    if np.any(source_index < 0):
        raise ValueError("A query precedes the first available observation")
    return values[source_index]


def build_dataset(root: Path, cfg: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame, list[UnitSequence]]:
    """Create causal post-burn features and endpoints from untouched CSV files.

    The first raw observation at or after the protocol reference age defines
    the unit-specific baseline.  That observation becomes model age zero.
    Earlier burn-in observations are never interpolated, featurized, decoded,
    or used to estimate residence times.
    """

    data_cfg = cfg["data"]
    data_dir = root / cfg["project"]["data_dir"]
    life_paths = sorted(data_dir.glob(data_cfg["life_pattern"]))
    if len(life_paths) != 19:
        raise ValueError(f"Expected 19 life-test files, found {len(life_paths)}")

    telemetry = pd.read_csv(data_dir / data_cfg["telemetry_file"], comment="#")
    required_tel = {"Duration(h)", "FlowValue(L/Min)", *data_cfg["current_to_module"].values()}
    missing_tel = sorted(required_tel.difference(telemetry.columns))
    if missing_tel:
        raise ValueError(f"Telemetry is missing columns: {missing_tel}")
    telemetry = telemetry.sort_values("Duration(h)").drop_duplicates("Duration(h)", keep="last")
    tele_age = telemetry["Duration(h)"].to_numpy(dtype=float)
    tele_flow = telemetry["FlowValue(L/Min)"].to_numpy(dtype=float)

    all_frames: list[pd.DataFrame] = []
    endpoints: list[dict[str, Any]] = []
    units: list[UnitSequence] = []
    step = float(data_cfg["grid_step_h"])
    ref_age = float(data_cfg["reference_age_h"])
    persistence = int(data_cfg["persistence_points"])

    for path in life_paths:
        raw = read_life_file(path)
        raw_age = raw["Duration_h"].to_numpy(dtype=float)
        reference_raw_index = first_index_at_or_after(raw_age, ref_age)
        reference_raw = raw.iloc[reference_raw_index]
        reference_age = float(reference_raw["Duration_h"])
        postburn_max_age = (
            math.floor((float(raw_age[-1]) - reference_age) / step) * step
        )
        if postburn_max_age < 1.0:
            raise ValueError(
                f"{path.name} has no usable post-burn observation window"
            )
        age = np.arange(
            0.0, postburn_max_age + 0.5 * step, step, dtype=float
        )
        raw_grid_age = reference_age + age
        interp: dict[str, np.ndarray] = {}
        for col in ["Current_A", "Voltage_V", "P", "Lambda_nm", "BW_nm"]:
            interp[col] = causal_step_interpolate(
                raw_grid_age, raw_age, raw[col].to_numpy(dtype=float)
            )

        p0 = float(reference_raw["P"])
        # The duration acceleration uses the assigned test-current stratum,
        # not a statistic from the complete measurement trajectory.  Infer
        # that stratum once from the reference reading and keep the raw,
        # causally sampled current in the emission features.
        current = float(round(float(reference_raw["Current_A"]) * 2.0) / 2.0)
        current_key = f"{current:.1f}"
        if current_key not in data_cfg["current_to_module"]:
            raise ValueError(f"No telemetry mapping for current {current:.3f} A")
        temp_col = data_cfg["current_to_module"][current_key]
        temperature = causal_step_interpolate(
            raw_grid_age,
            tele_age,
            telemetry[temp_col].to_numpy(dtype=float),
        )
        flow = causal_step_interpolate(raw_grid_age, tele_age, tele_flow)

        y = interp["P"] / max(p0, EPS)
        depth = 1.0 - y
        slope = np.maximum(0.0, causal_slope(depth, int(data_cfg["slope_window"])))
        input_power = interp["Current_A"] * interp["Voltage_V"]
        base_input = float(reference_raw["Current_A"] * reference_raw["Voltage_V"])
        heat_proxy = (input_power - interp["P"]) - (base_input - p0)
        wavelength_shift = interp["Lambda_nm"] - float(reference_raw["Lambda_nm"])
        bandwidth_shift = interp["BW_nm"] - float(reference_raw["BW_nm"])
        spectral = np.sqrt(
            rolling_std_causal(wavelength_shift, int(data_cfg["spectral_window"])) ** 2
            + rolling_std_causal(bandwidth_shift, int(data_cfg["spectral_window"])) ** 2
        )
        efficiency = interp["P"] / np.maximum(input_power, EPS)
        thresholds = {
            "L90": make_threshold_evidence(
                y, "L90", float(data_cfg["l90_threshold"]), 1, persistence
            ),
            "L80": make_threshold_evidence(
                y, "L80", float(data_cfg["l80_threshold"]), 2, persistence
            ),
            "T50": make_threshold_evidence(
                y, "T50", float(data_cfg["t50_threshold"]), 3, persistence
            ),
        }
        l80 = thresholds["L80"]
        event_idx = l80.event_index
        event = l80.event
        event_low = l80.event_low
        event_high = l80.event_high
        event_age = float(age[event_idx]) if event_idx is not None else float(age[-1])

        frame = pd.DataFrame(
            {
                "unit_id": path.stem,
                "source_file": path.name,
                "age_h": age,
                "raw_age_h": raw_grid_age,
                "reference_age_h": reference_age,
                "current_a": current,
                "power_w": interp["P"],
                "voltage_v": interp["Voltage_V"],
                "wavelength_nm": interp["Lambda_nm"],
                "bandwidth_nm": interp["BW_nm"],
                "normalized_power": y,
                "degradation_depth": depth,
                "loss_rate": slope,
                "heat_proxy_w": heat_proxy,
                "wavelength_shift_nm": wavelength_shift,
                "bandwidth_shift_nm": bandwidth_shift,
                "spectral_instability": spectral,
                "electrical_efficiency": efficiency,
                "module_temperature_c": temperature,
                "flow_l_min": flow,
                "event_l90": thresholds["L90"].event,
                "event_l80": event,
                "event_t50": thresholds["T50"].event,
                "event_time_h": event_age,
                "censor_time_h": float(age[-1]),
            }
        )
        x = frame[FEATURE_COLUMNS].to_numpy(dtype=float)
        units.append(
            UnitSequence(
                unit_id=path.stem,
                current=current,
                age=age,
                x=x,
                temperature=temperature,
                flow=flow,
                event=event,
                event_index=event_idx,
                event_low=event_low,
                event_high=event_high,
                censor_index=len(age) - 1,
                frame=frame,
                thresholds=thresholds,
            )
        )
        all_frames.append(frame)
        endpoint_row: dict[str, Any] = {
            "unit_id": path.stem,
            "source_file": path.name,
            "current_a": current,
            "reference_age_h": reference_age,
            "censor_time_h": float(age[-1]),
            "raw_censor_time_h": float(reference_age + age[-1]),
        }
        for name, evidence in thresholds.items():
            key = name.lower()
            endpoint_row[f"event_{key}"] = evidence.event
            endpoint_row[f"event_time_{key}_h"] = (
                float(age[evidence.event_index])
                if evidence.event_index is not None
                else float(age[-1])
            )
            endpoint_row[f"raw_event_time_{key}_h"] = (
                float(reference_age + age[evidence.event_index])
                if evidence.event_index is not None
                else np.nan
            )
            endpoint_row[f"event_index_{key}"] = (
                evidence.event_index if evidence.event_index is not None else -1
            )
            endpoint_row[f"event_interval_low_{key}_h"] = (
                float(age[evidence.event_low]) if evidence.event_low is not None else np.nan
            )
            endpoint_row[f"event_interval_high_{key}_h"] = (
                float(age[evidence.event_high]) if evidence.event_high is not None else np.nan
            )
        # Stable aliases retained for existing downstream L80 reliability code.
        endpoint_row.update(
            {
                "event_time_h": event_age,
                "raw_event_time_h": (
                    float(reference_age + event_age) if event else np.nan
                ),
                "event_index": event_idx if event_idx is not None else -1,
                "event_interval_low_h": (
                    float(age[event_low]) if event_low is not None else np.nan
                ),
                "event_interval_high_h": (
                    float(age[event_high]) if event_high is not None else np.nan
                ),
            }
        )
        endpoints.append(endpoint_row)

    long_frame = pd.concat(all_frames, ignore_index=True)
    endpoint_frame = pd.DataFrame(endpoints).sort_values(["current_a", "unit_id"]).reset_index(drop=True)
    return long_frame, endpoint_frame, units


def robust_location_scale(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    array = np.asarray(values, dtype=float)
    if array.ndim != 2:
        raise ValueError("robust_location_scale expects a two-dimensional array")
    center = np.zeros(array.shape[1], dtype=float)
    scale = np.ones(array.shape[1], dtype=float)
    for column in range(array.shape[1]):
        observed = array[np.isfinite(array[:, column]), column]
        if observed.size == 0:
            continue
        median = float(np.median(observed))
        mad = float(np.median(np.abs(observed - median)) * 1.4826)
        std = float(np.std(observed, ddof=1)) if observed.size > 1 else 0.0
        center[column] = median
        scale[column] = mad if mad > 1e-6 else (std if std > 1e-6 else 1.0)
    return center, np.maximum(scale, 1e-4)


def causal_locf(values: np.ndarray, initial: float) -> np.ndarray:
    """Causally fill unavailable readings without consulting future samples."""

    source = np.asarray(values, dtype=float)
    out = np.empty_like(source, dtype=float)
    last = float(initial)
    for idx, value in enumerate(source):
        if np.isfinite(value):
            last = float(value)
        out[idx] = last
    return out


def threshold_path(
    unit: UnitSequence,
    states: int,
    risk_state: int,
    jitter: float = 0.0,
    nested_threshold_initialization: bool = False,
) -> np.ndarray:
    """Legacy-style monotone threshold route used only for initialization/baseline."""

    # The legacy route has no multichannel missing-data model.  LOCF is its
    # strongest simple causal fallback and avoids advantaging the proposed
    # method through an artificially non-causal interpolation baseline.
    depth = causal_locf(unit.frame["degradation_depth"].to_numpy(dtype=float), 0.0)
    y = causal_locf(unit.frame["normalized_power"].to_numpy(dtype=float), 1.0)
    slope = causal_locf(unit.frame["loss_rate"].to_numpy(dtype=float), 0.0)
    path = np.zeros(len(depth), dtype=int)
    if states == 4 and unit.thresholds and nested_threshold_initialization:
        # The prespecified engineering system uses four post-burn states aligned
        # with nested persistent L90, L80, and T50 evidence.  Multiple starts
        # choose different feasible entries inside each persistence interval;
        # they never change the state count or skip a state boundary.
        fraction = float(np.clip(0.5 + 20.0 * jitter, 0.0, 1.0))
        for evidence in sorted(unit.thresholds.values(), key=lambda item: item.target_state):
            if not evidence.event or evidence.event_low is None:
                continue
            high = evidence.event_high if evidence.event_high is not None else evidence.event_low
            entry = int(round(evidence.event_low + fraction * (high - evidence.event_low)))
            path[entry:] = np.maximum(path[entry:], evidence.target_state)
        return np.maximum.accumulate(path)
    if states == 3:
        path[(depth >= 0.075 + jitter) | ((depth >= 0.04) & (slope >= 0.00045))] = 1
        path[y <= 0.8] = 2
    elif states == 4:
        path[(depth >= 0.08 + jitter) | ((depth >= 0.045) & (slope >= 0.00045))] = 1
        path[y <= 0.8] = 2
        path[y <= 0.5] = 3
    elif states == 5:
        path[(depth >= 0.05 + jitter) | ((depth >= 0.035) & (slope >= 0.00035))] = 1
        path[(depth >= 0.10 + jitter) | (slope >= 0.00060)] = 2
        path[y <= 0.8] = 3
        path[y <= 0.5] = 4
    else:
        quantiles = np.quantile(depth, np.linspace(0, 1, states + 1)[1:-1])
        for state, threshold in enumerate(quantiles, start=1):
            path[depth >= threshold] = state
    path = np.maximum.accumulate(path)
    if states == 4 and unit.thresholds:
        # Retain the full prespecified four-state semantics in this fallback
        # route: L90, L80, and T50 identify entry into Drift, L80
        # risk, and Collapse, respectively.  L80 remains the engineering
        # reliability endpoint but is not the only modeled transition.
        route_boundaries = [unit.thresholds[name] for name in ("L90", "L80", "T50")]
        for evidence in route_boundaries:
            target = evidence.target_state
            if evidence.event and evidence.event_low is not None:
                path[: evidence.event_low] = np.minimum(path[: evidence.event_low], target - 1)
                if evidence.event_high is not None:
                    path[evidence.event_high :] = np.maximum(path[evidence.event_high :], target)
            else:
                path = np.minimum(path, target - 1)
    elif unit.event and unit.event_low is not None:
        path[: unit.event_low] = np.minimum(path[: unit.event_low], risk_state - 1)
        if unit.event_high is not None:
            path[unit.event_high :] = np.maximum(path[unit.event_high :], risk_state)
    elif not unit.event:
        path = np.minimum(path, risk_state - 1)
    return np.maximum.accumulate(path)


def path_segments(unit: UnitSequence, path: np.ndarray) -> list[dict[str, Any]]:
    changes = np.flatnonzero(np.diff(path) != 0) + 1
    starts = np.r_[0, changes]
    ends = np.r_[changes - 1, len(path) - 1]
    segments: list[dict[str, Any]] = []
    for start, end in zip(starts, ends):
        segment_x = np.asarray(unit.x[start : end + 1], dtype=float)
        observed_count = np.sum(np.isfinite(segment_x), axis=0)
        feature_mean = np.divide(
            np.nansum(segment_x, axis=0),
            observed_count,
            out=np.full(segment_x.shape[1], np.nan, dtype=float),
            where=observed_count > 0,
        )
        segments.append(
            {
                "unit_id": unit.unit_id,
                "state": int(path[start]),
                "start": int(start),
                "end": int(end),
                "duration": int(end - start + 1),
                "complete": int(end < len(path) - 1),
                "current": float(unit.current),
                "temperature": float(np.mean(unit.temperature[start : end + 1])),
                "flow": float(np.mean(unit.flow[start : end + 1])),
                "feature_mean": feature_mean,
            }
        )
    return segments


def student_logpdf_matrix(x: np.ndarray, mu: np.ndarray, scale: np.ndarray, df: float) -> np.ndarray:
    """Independent Student-t emission score over the channels observed at each time.

    A missing channel contributes exactly zero log evidence.  Consequently, a
    fully missing observation leaves the semi-Markov duration and transition
    model to propagate state belief instead of injecting an imputed pseudo-
    measurement.  Complete-data results are numerically identical to the
    previous implementation.
    """

    observed = np.isfinite(x)
    z = (x[:, None, :] - mu[None, :, :]) / scale[None, :, :]
    constant = gammaln((df + 1.0) / 2.0) - gammaln(df / 2.0) - 0.5 * math.log(df * math.pi)
    terms = constant - np.log(scale[None, :, :]) - 0.5 * (df + 1.0) * np.log1p((z * z) / df)
    return np.sum(np.where(observed[:, None, :], terms, 0.0), axis=2)


def standardized_x(unit: UnitSequence, params: dict[str, Any]) -> np.ndarray:
    center = np.asarray(params.get("feature_center", np.zeros(unit.x.shape[1])), dtype=float)
    scale = np.asarray(params.get("feature_scale", np.ones(unit.x.shape[1])), dtype=float)
    return (unit.x - center[None, :]) / np.maximum(scale[None, :], 1e-8)


def endpoint_anchor_loglik(unit: UnitSequence, params: dict[str, Any]) -> np.ndarray:
    """Softly align all four state regions with L90, L80, and T50 evidence."""

    states = int(params["states"])
    weight = float(params.get("endpoint_anchor_weight", 0.0))
    if weight <= 0:
        return np.zeros((len(unit.age), states), dtype=float)
    scale = max(float(params.get("endpoint_anchor_scale", 0.025)), 1e-4)
    y = unit.frame["normalized_power"].to_numpy(dtype=float)
    observed = np.isfinite(y)
    out = np.zeros((len(y), states), dtype=float)
    if states == 4:
        boundaries = [(0.9, 1), (0.8, 2), (0.5, 3)]
    else:
        boundaries = [(0.8, int(params["risk_state"]))]
    boundary_weight = weight / len(boundaries)
    for level, target_state in boundaries:
        p_cross = np.zeros(len(y), dtype=float)
        p_cross[observed] = 1.0 / (
            1.0 + np.exp(np.clip((y[observed] - level) / scale, -50.0, 50.0))
        )
        out[observed, :target_state] += boundary_weight * np.log(
            np.clip(1.0 - p_cross[observed, None], 1e-12, 1.0)
        )
        out[observed, target_state:] += boundary_weight * np.log(
            np.clip(p_cross[observed, None], 1e-12, 1.0)
        )
    return out


def auxiliary_threshold_loglik(unit: UnitSequence, params: dict[str, Any]) -> np.ndarray:
    """Add weak interval/censor evidence for diagnostic threshold boundaries.

    A diagnostic threshold supplies two sentinel labels for an observed event
    (pre-entry at low-1 and post-entry at high) or one terminal pre-entry label
    when right censored.  The score therefore uses the event record without
    treating every hour as an independent label or turning L90 into a hard
    engineering failure definition.
    """

    states = int(params["states"])
    out = np.zeros((len(unit.age), states), dtype=float)
    if not unit.thresholds:
        return out
    weight = float(params.get("auxiliary_threshold_log_odds", 0.0))
    if weight <= 0:
        return out
    auxiliary = set(params.get("auxiliary_thresholds", []))
    hard = set(params.get("hard_thresholds", []))
    for name in sorted(auxiliary - hard):
        evidence = unit.thresholds.get(name)
        if evidence is None:
            continue
        target = int(evidence.target_state)
        if evidence.event and evidence.event_low is not None and evidence.event_high is not None:
            if evidence.event_low > 0:
                out[evidence.event_low - 1, target:] -= weight
            out[evidence.event_high, :target] -= weight
        else:
            censor = (
                len(unit.age) - 1
                if evidence.censor_index is None
                else int(np.clip(evidence.censor_index, 0, len(unit.age) - 1))
            )
            out[censor, target:] -= weight
    return out


def allowed_predecessors(state: int, states: int) -> list[int]:
    if state == 0:
        return []
    return [state - 1]


def transition_matrix(paths: list[np.ndarray], states: int, direct_collapse: float) -> np.ndarray:
    """Strict prespecified ordered topology: s -> s+1 only."""

    matrix = np.zeros((states, states), dtype=float)
    for state in range(states - 1):
        matrix[state, state + 1] = 1.0
    matrix[-1, -1] = 1.0
    return matrix


def fit_emissions(
    units: list[UnitSequence],
    paths: list[np.ndarray],
    states: int,
    shrinkage: float,
    feature_center: np.ndarray,
    feature_scale: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    transformed = [
        (unit.x - feature_center[None, :]) / np.maximum(feature_scale[None, :], 1e-8)
        for unit in units
    ]
    pooled = np.vstack(transformed)
    global_mu, global_scale = robust_location_scale(pooled)
    means = np.zeros((states, pooled.shape[1]), dtype=float)
    scales = np.zeros_like(means)
    for state in range(states):
        pieces = [values[path == state] for values, path in zip(transformed, paths) if np.any(path == state)]
        values = np.vstack(pieces) if pieces else np.empty((0, pooled.shape[1]))
        if len(values) < 8:
            means[state] = global_mu
            scales[state] = global_scale
        else:
            loc, scale = robust_location_scale(values)
            means[state] = loc
            scales[state] = (1.0 - shrinkage) * scale + shrinkage * global_scale
    return means, np.maximum(scales, 1e-4)


def normal_logsf(z: np.ndarray | float) -> np.ndarray:
    z_arr = np.asarray(z, dtype=float)
    return log_ndtr(-z_arr)


def discrete_lognormal_logprob(
    duration: np.ndarray, eta: np.ndarray, sigma: float | np.ndarray
) -> np.ndarray:
    d = np.asarray(duration, dtype=float)
    if np.any(d < 1) or np.any(np.asarray(sigma) <= 0):
        raise ValueError("Durations must be positive and duration scales positive")
    z_hi = (np.log(d + 0.5) - eta) / sigma
    z_lo = (np.log(d - 0.5) - eta) / sigma
    # Use the CDF in the left tail and survival in the right tail. Direct
    # subtraction of two CDFs loses the mass of long but valid residences.
    log_a = np.where(z_lo > 0, log_ndtr(-z_lo), log_ndtr(z_hi))
    log_b = np.where(z_lo > 0, log_ndtr(-z_hi), log_ndtr(z_lo))
    log_mass = log_a + np.log(-np.expm1(np.minimum(log_b - log_a, -np.finfo(float).eps)))
    log_normalizer = log_ndtr((np.asarray(eta) - math.log(0.5)) / sigma)
    return np.minimum(log_mass - log_normalizer, 0.0)


def discrete_lognormal_logsurvival(
    duration: np.ndarray, eta: np.ndarray, sigma: float | np.ndarray
) -> np.ndarray:
    d = np.asarray(duration, dtype=float)
    if np.any(d < 1) or np.any(np.asarray(sigma) <= 0):
        raise ValueError("Durations must be positive and duration scales positive")
    z = (np.log(d - 0.5) - eta) / sigma
    log_normalizer = log_ndtr((np.asarray(eta) - math.log(0.5)) / sigma)
    return np.minimum(normal_logsf(z) - log_normalizer, 0.0)


def environment_scaler(units: list[UnitSequence]) -> dict[str, float]:
    temp = np.concatenate([unit.temperature for unit in units])
    flow = np.concatenate([unit.flow for unit in units])
    return {
        "temp_center": float(np.mean(temp)),
        "temp_scale": float(max(np.std(temp, ddof=1), 1e-4)),
        "flow_center": float(np.mean(flow)),
        "flow_scale": float(max(np.std(flow, ddof=1), 1e-4)),
    }


def initial_duration_parameters(
    units: list[UnitSequence],
    paths: list[np.ndarray],
    states: int,
    scaler: dict[str, float],
    current_reference: float,
) -> dict[str, np.ndarray | float]:
    segments = [segment for unit, path in zip(units, paths) for segment in path_segments(unit, path)]
    dur_mu = np.full(states, math.log(80.0), dtype=float)
    dur_sigma = np.full(states, 0.65, dtype=float)
    alpha = np.zeros(states, dtype=float)
    for state in range(states):
        rows = [row for row in segments if row["state"] == state]
        if rows:
            logs = np.log(np.maximum([row["duration"] for row in rows], 1))
            dur_mu[state] = float(np.mean(logs))
            dur_sigma[state] = float(np.clip(np.std(logs, ddof=1) if len(logs) > 1 else 0.55, 0.2, 1.5))
        # Starting every acceleration coefficient at its lower bound can make
        # finite-difference L-BFGS-B stop there even when complete transitions
        # show a strong current-duration gradient.  Use a bounded regression
        # on completed segments only as an initialization; the censored
        # lognormal likelihood below remains the estimator.
        complete_rows = [row for row in rows if bool(row["complete"])]
        if len(complete_rows) >= 3:
            current_x = np.log(
                np.maximum([row["current"] for row in complete_rows], 1e-6)
                / max(float(current_reference), 1e-6)
            )
            duration_y = np.log(
                np.maximum([row["duration"] for row in complete_rows], 1)
            )
            centered_x = current_x - np.mean(current_x)
            denominator = float(np.dot(centered_x, centered_x))
            if denominator > 1e-6:
                slope = float(np.dot(centered_x, duration_y - np.mean(duration_y)) / denominator)
                alpha[state] = float(np.clip(-slope, 0.0, 5.5))
                dur_mu[state] = float(np.mean(duration_y + alpha[state] * current_x))
                residual = duration_y - (dur_mu[state] - alpha[state] * current_x)
                if len(residual) > 1:
                    dur_sigma[state] = float(np.clip(np.std(residual, ddof=1), 0.2, 1.5))
    return {
        "dur_mu": dur_mu,
        "dur_sigma": dur_sigma,
        "alpha": alpha,
        "gamma": np.zeros(2, dtype=float),
        **scaler,
    }


def duration_auxiliary_loading(params: dict[str, Any], state: int) -> float:
    loadings = params.get("duration_auxiliary_state_loadings")
    if loadings is not None:
        values = np.asarray(loadings, dtype=float)
        if values.size != int(params["states"]):
            raise ValueError(
                "duration_auxiliary_state_loadings must have one value per state"
            )
        return float(values[state])
    auxiliary_states = set(
        int(value)
        for value in params.get(
            "duration_auxiliary_states",
            range(max(int(params.get("states", 1)) - 1, 0)),
        )
    )
    return 1.0 if state in auxiliary_states else 0.0


def duration_linear_predictor(
    params: dict[str, Any],
    state: int,
    current: float,
    temperature: np.ndarray,
    flow: np.ndarray,
    auxiliary: np.ndarray | None = None,
) -> np.ndarray:
    eta = np.full_like(np.asarray(temperature, dtype=float), float(params["dur_mu"][state]), dtype=float)
    eta -= float(params["alpha"][state]) * math.log(max(current, 1e-6) / float(params["current_reference"]))
    if bool(params.get("environment", False)):
        tz = (np.asarray(temperature) - float(params["temp_center"])) / float(params["temp_scale"])
        fz = (np.asarray(flow) - float(params["flow_center"])) / float(params["flow_scale"])
        eta += float(params["gamma"][0]) * tz + float(params["gamma"][1]) * fz
    beta = np.asarray(params.get("duration_aux_beta", []), dtype=float)
    auxiliary_loading = duration_auxiliary_loading(params, state)
    if beta.size and abs(auxiliary_loading) > EPS:
        if auxiliary is None:
            auxiliary_z = np.zeros((eta.size, beta.size), dtype=float)
        else:
            auxiliary_values = np.asarray(auxiliary, dtype=float)
            if auxiliary_values.ndim == 1:
                auxiliary_values = auxiliary_values[None, :]
            if auxiliary_values.shape[1] != beta.size:
                raise ValueError(
                    "Duration auxiliary covariate width does not match duration_aux_beta"
                )
            center = np.asarray(params["duration_aux_center"], dtype=float)
            scale = np.asarray(params["duration_aux_scale"], dtype=float)
            auxiliary_z = (
                np.where(np.isfinite(auxiliary_values), auxiliary_values, center[None, :])
                - center[None, :]
            ) / np.maximum(scale[None, :], 1e-8)
        if auxiliary_z.shape[0] == 1 and eta.size != 1:
            auxiliary_z = np.repeat(auxiliary_z, eta.size, axis=0)
        if auxiliary_z.shape[0] != eta.size:
            raise ValueError(
                "Duration auxiliary covariate rows do not match the predictor length"
            )
        eta += auxiliary_loading * (auxiliary_z @ beta)
    return eta


def fit_duration_parameters(
    units: list[UnitSequence],
    paths: list[np.ndarray],
    params: dict[str, Any],
    environment: bool,
    homogeneous: bool,
    ridge: float,
    weighted_records: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    states = int(params["states"])
    absorbing = states - 1
    if params.get("duration_type") == "geometric":
        probabilities = np.full(states, 1.0 / 50.0, dtype=float)
        rows = [segment for unit, path in zip(units, paths) for segment in path_segments(unit, path)]
        for state in range(absorbing):
            selected = [row for row in rows if row["state"] == state]
            if selected:
                exits = sum(bool(row["complete"]) or params.get("terminal_duration_treatment") == "complete" for row in selected)
                stays = sum(float(row["duration"]) - 1.0 for row in selected)
                probabilities[state] = exits / max(exits + stays, 1.0)
        updated = copy.deepcopy(params)
        updated["geometric_p"] = np.clip(probabilities, 1e-6, 1.0 - 1e-6)
        updated["geometric_p"][absorbing] = 1e-4
        updated["alpha"] = np.zeros(states)
        updated["gamma"] = np.zeros(2)
        updated["duration_aux_beta"] = np.zeros_like(
            np.asarray(params.get("duration_aux_beta", []), dtype=float)
        )
        return updated

    all_rows = weighted_records if weighted_records is not None else [
        segment
        for unit, path in zip(units, paths)
        for segment in path_segments(unit, path)
    ]
    auxiliary_indices = np.asarray(
        params.get("duration_auxiliary_indices", []), dtype=int
    )
    # An absorbing residence has contribution one, in every estimator.
    rows = [row for row in all_rows if int(row["state"]) != absorbing]
    if not rows:
        updated = copy.deepcopy(params)
        updated["duration_optimizer_success"] = False
        updated["duration_optimizer_message"] = "No identifiable non-absorbing dwell records"
        return updated
    state_arr = np.array([row["state"] for row in rows], dtype=int)
    duration = np.array([row["duration"] for row in rows], dtype=float)
    record_weight = np.array([row.get("weight", 1.0) for row in rows], dtype=float)
    complete = np.array([row["complete"] for row in rows], dtype=bool)
    terminal_treatment = str(
        params.get("terminal_duration_treatment", "survival")
    )
    if terminal_treatment not in {"survival", "complete"}:
        raise ValueError(
            "terminal_duration_treatment must be 'survival' or 'complete'"
        )
    if terminal_treatment == "complete":
        # Classification-score configuration: terminal dwell lengths enter
        # the path objective through the completed-duration mass. This is
        # evaluated alongside, rather than interpreted as, a censoring
        # likelihood contribution.
        complete = np.ones_like(complete, dtype=bool)
    current = np.array([row["current"] for row in rows], dtype=float)
    temp = np.array([row["temperature"] for row in rows], dtype=float)
    flow = np.array([row["flow"] for row in rows], dtype=float)
    temp_z = (temp - float(params["temp_center"])) / float(params["temp_scale"])
    flow_z = (flow - float(params["flow_center"])) / float(params["flow_scale"])
    log_current = np.log(np.maximum(current, 1e-6) / float(params["current_reference"]))
    if auxiliary_indices.size:
        auxiliary = np.vstack(
            [np.asarray(row["feature_mean"], dtype=float)[auxiliary_indices] for row in rows]
        )
        auxiliary_center = np.asarray(params["duration_aux_center"], dtype=float)
        auxiliary_scale = np.asarray(params["duration_aux_scale"], dtype=float)
        auxiliary_z = (
            np.where(np.isfinite(auxiliary), auxiliary, auxiliary_center[None, :])
            - auxiliary_center[None, :]
        ) / np.maximum(auxiliary_scale[None, :], 1e-8)
    else:
        auxiliary_z = np.empty((len(rows), 0), dtype=float)

    x0 = np.r_[
        np.asarray(params["dur_mu"], dtype=float),
        np.log(np.asarray(params["dur_sigma"], dtype=float)),
        np.asarray(params["alpha"], dtype=float),
        np.asarray(params["gamma"], dtype=float),
        np.asarray(params.get("duration_aux_beta", []), dtype=float),
    ]

    def unpack(
        theta: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        mu = theta[:states]
        sigma = np.exp(theta[states : 2 * states])
        alpha = theta[2 * states : 3 * states]
        gamma = theta[3 * states : 3 * states + 2]
        beta = theta[3 * states + 2 : 3 * states + 2 + auxiliary_indices.size]
        if homogeneous:
            alpha = np.zeros_like(alpha)
        elif bool(params.get("shared_acceleration", False)):
            shared_alpha = float(alpha[0])
            alpha = np.r_[
                np.full(absorbing, shared_alpha, dtype=float),
                0.0,
            ]
        if not environment:
            gamma = np.zeros_like(gamma)
        return mu, sigma, alpha, gamma, beta

    def objective(theta: np.ndarray) -> float:
        mu, sigma, alpha, gamma, beta = unpack(theta)
        eta = (
            mu[state_arr]
            - alpha[state_arr] * log_current
            + gamma[0] * temp_z
            + gamma[1] * flow_z
        )
        if beta.size:
            loadings = np.asarray(
                [
                    duration_auxiliary_loading(params, int(state))
                    for state in state_arr
                ],
                dtype=float,
            )
            eta += loadings * (auxiliary_z @ beta)
        state_sigma = sigma[state_arr]
        log_probability = discrete_lognormal_logprob(duration, eta, state_sigma)
        log_survival = discrete_lognormal_logsurvival(duration, eta, state_sigma)
        value = -float(np.sum(record_weight * np.where(complete, log_probability, log_survival)))
        value += float(ridge * np.sum(gamma * gamma))
        value += float(
            params.get("duration_auxiliary_ridge", 0.0) * np.sum(beta * beta)
        )
        # State-specific acceleration is retained, but small-sample folds need
        # shrinkage to keep a few high-current segments from driving the
        # coefficients to their bounds.
        if bool(params.get("shared_acceleration", False)):
            value += float(
                params.get("current_acceleration_ridge", 0.0)
                * alpha[0]
                * alpha[0]
            )
        else:
            value += float(
                params.get("current_acceleration_ridge", 0.0)
                * np.sum(alpha * alpha)
            )
        nonabsorbing_alpha = alpha[:absorbing]
        alpha_prior_ridge = float(params.get("duration_alpha_prior_ridge", 0.0))
        if nonabsorbing_alpha.size and alpha_prior_ridge > 0:
            alpha_prior_mean = float(params.get("duration_alpha_prior_mean", 0.0))
            if bool(params.get("shared_acceleration", False)):
                value += float(
                    alpha_prior_ridge
                    * (nonabsorbing_alpha[0] - alpha_prior_mean) ** 2
                )
            else:
                value += float(
                    alpha_prior_ridge
                    * np.sum((nonabsorbing_alpha - alpha_prior_mean) ** 2)
                )
        if (
            nonabsorbing_alpha.size > 1
            and not bool(params.get("shared_acceleration", False))
        ):
            value += float(
                params.get("duration_alpha_pooling_ridge", 0.0)
                * np.sum((nonabsorbing_alpha - np.mean(nonabsorbing_alpha)) ** 2)
            )
        nonabsorbing_log_sigma = np.log(np.maximum(sigma[:absorbing], EPS))
        if nonabsorbing_log_sigma.size > 1:
            value += float(
                params.get("duration_sigma_pooling_ridge", 0.0)
                * np.sum(
                    (nonabsorbing_log_sigma - np.mean(nonabsorbing_log_sigma)) ** 2
                )
            )
        return value

    sigma_min = float(params.get("duration_sigma_min", 0.15))
    sigma_max = float(params.get("duration_sigma_max", 1.8))
    alpha_max = float(params.get("duration_alpha_max", 6.0))
    bounds: list[tuple[float, float]] = []
    bounds += [(math.log(1.5), math.log(900.0))] * states
    bounds += [(math.log(sigma_min), math.log(sigma_max))] * states
    bounds += [(0.0, alpha_max)] * states
    bounds += [(-2.5, 2.5), (-2.5, 2.5)]
    auxiliary_bound = float(params.get("duration_auxiliary_bound", 2.5))
    bounds += [(-auxiliary_bound, auxiliary_bound)] * auxiliary_indices.size
    # The final Collapse state is absorbing.  Its residence time has no exit
    # event in these life-test records, so a parametric dwell distribution is
    # not identifiable and is not used for first entry into Collapse.
    bounds[absorbing] = (x0[absorbing], x0[absorbing])
    bounds[states + absorbing] = (
        x0[states + absorbing],
        x0[states + absorbing],
    )
    bounds[2 * states + absorbing] = (0.0, 0.0)
    if homogeneous:
        for i in range(2 * states, 3 * states):
            bounds[i] = (0.0, 0.0)
    elif bool(params.get("shared_acceleration", False)):
        for i in range(2 * states + 1, 3 * states):
            bounds[i] = (x0[i], x0[i])
    if not environment:
        gamma_start = 3 * states
        bounds[gamma_start : gamma_start + 2] = [(0.0, 0.0), (0.0, 0.0)]
    result = minimize(objective, x0, method="L-BFGS-B", bounds=bounds, options={"maxiter": 250})
    theta = result.x if result.success or np.isfinite(result.fun) else x0
    mu, sigma, alpha, gamma, beta = unpack(theta)
    updated = copy.deepcopy(params)
    updated.update(
        {
            "dur_mu": mu,
            "dur_sigma": sigma,
            "alpha": alpha,
            "gamma": gamma,
            "duration_aux_beta": beta,
            "duration_optimizer_success": bool(result.success),
            "duration_optimizer_message": str(result.message),
        }
    )
    return updated


def duration_regularization(params: dict[str, Any]) -> float:
    """Penalty used in both estimation and classification acceptance checks."""
    if params.get("duration_type") == "geometric":
        return 0.0
    alpha = np.asarray(params["alpha"], dtype=float)[:int(params["states"]) - 1]
    shared = bool(params.get("shared_acceleration", False))
    fitted_alpha = alpha[:1] if shared else alpha
    value = float(params.get("current_acceleration_ridge", 0.0)) * np.sum(fitted_alpha**2)
    value += float(params.get("duration_alpha_prior_ridge", 0.0)) * np.sum((fitted_alpha - float(params.get("duration_alpha_prior_mean", 0.0)))**2)
    if not shared:
        value += float(params.get("duration_alpha_pooling_ridge", 0.0)) * np.sum((alpha - np.mean(alpha))**2)
    logs = np.log(np.asarray(params["dur_sigma"], dtype=float)[:int(params["states"]) - 1])
    value += float(params.get("duration_sigma_pooling_ridge", 0.0)) * np.sum((logs - np.mean(logs))**2)
    value += float(params.get("environment_ridge", 0.0)) * np.sum(np.asarray(params.get("gamma", [0.0, 0.0]))**2)
    value += float(params.get("duration_auxiliary_ridge", 0.0)) * np.sum(np.asarray(params.get("duration_aux_beta", []))**2)
    return float(value)


def constraint_mask(
    unit: UnitSequence,
    states: int,
    risk_state: int,
    constrained: bool,
    hard_thresholds: Iterable[str] | None = None,
) -> np.ndarray:
    allowed = np.ones((len(unit.age), states), dtype=bool)
    if not constrained:
        return allowed
    if states == 4 and unit.thresholds:
        # Each persistent threshold is an interval-censored entry into the
        # corresponding ordered state; absence by C_i is a right-censoring
        # constraint.  Thus L90/L80/T50 contribute 17/9/6 records instead of
        # collapsing all pre-L80 histories into one censoring category.
        selected = set(unit.thresholds) if hard_thresholds is None else set(hard_thresholds)
        for evidence in sorted(unit.thresholds.values(), key=lambda item: item.target_state):
            if evidence.name not in selected:
                continue
            target = int(evidence.target_state)
            if target <= 0 or target >= states:
                raise ValueError(f"Invalid target state {target} for {evidence.name}")
            if evidence.event and evidence.event_low is not None and evidence.event_high is not None:
                allowed[: evidence.event_low, target:] = False
                allowed[evidence.event_high :, :target] = False
            else:
                censor = (
                    len(unit.age) - 1
                    if evidence.censor_index is None
                    else int(np.clip(evidence.censor_index, -1, len(unit.age) - 1))
                )
                if censor >= 0:
                    allowed[: censor + 1, target:] = False
        return allowed
    if unit.event and unit.event_low is not None and unit.event_high is not None:
        allowed[: unit.event_low, risk_state:] = False
        allowed[unit.event_high :, :risk_state] = False
    elif not unit.event:
        allowed[:, risk_state:] = False
    return allowed


def segmental_viterbi(
    unit: UnitSequence,
    params: dict[str, Any],
    constrained: bool = True,
) -> tuple[np.ndarray, float, float]:
    """Decode the exact best duration-aware path under endpoint constraints."""

    constant_covariates = (not params.get("environment", False)) or (np.ptp(unit.temperature) == 0 and np.ptp(unit.flow) == 0)
    if constant_covariates and not len(params.get("duration_auxiliary_indices", [])) and int(params["states"]) == 4 and params.get("use_fast_inference", True):
        try:
            pass
        except ImportError:
            pass
        else:
            return inference_fast_viterbi(unit, params, constrained)

    states = int(params["states"])
    risk_state = int(params["risk_state"])
    t_count = len(unit.age)
    emission = student_logpdf_matrix(
        standardized_x(unit, params),
        np.asarray(params["emission_mu"]),
        np.asarray(params["emission_scale"]),
        float(params["student_df"]),
    )
    emission += endpoint_anchor_loglik(unit, params)
    emission += auxiliary_threshold_loglik(unit, params)
    emission_prefix = np.vstack([np.zeros((1, states)), np.cumsum(emission, axis=0)])
    temp_prefix = np.r_[0.0, np.cumsum(unit.temperature)]
    flow_prefix = np.r_[0.0, np.cumsum(unit.flow)]
    duration_auxiliary_indices = np.asarray(
        params.get("duration_auxiliary_indices", []), dtype=int
    )
    if duration_auxiliary_indices.size:
        duration_auxiliary = np.asarray(
            unit.x[:, duration_auxiliary_indices], dtype=float
        )
        duration_auxiliary_center = np.asarray(
            params["duration_aux_center"], dtype=float
        )
        duration_auxiliary = np.where(
            np.isfinite(duration_auxiliary),
            duration_auxiliary,
            duration_auxiliary_center[None, :],
        )
        duration_auxiliary_prefix = np.vstack(
            [
                np.zeros((1, duration_auxiliary_indices.size), dtype=float),
                np.cumsum(duration_auxiliary, axis=0),
            ]
        )
    else:
        duration_auxiliary_prefix = np.empty((t_count + 1, 0), dtype=float)
    allowed = constraint_mask(
        unit,
        states,
        risk_state,
        constrained,
        hard_thresholds=params.get("hard_thresholds"),
    )
    invalid_prefix = np.vstack(
        [np.r_[0, np.cumsum(~allowed[:, state])] for state in range(states)]
    )

    best = np.full((t_count, states), -np.inf, dtype=float)
    second = np.full_like(best, -np.inf)
    prev_end = np.full((t_count, states), -2, dtype=np.int32)
    prev_state = np.full((t_count, states), -1, dtype=np.int16)
    best_duration = np.zeros((t_count, states), dtype=np.int32)
    log_transition = np.log(np.clip(np.asarray(params["transition"], dtype=float), 1e-300, 1.0))
    max_duration = int(params["max_duration"])

    for end in range(t_count):
        terminal = end == t_count - 1
        duration_cap = end + 1 if terminal else min(end + 1, max_duration)
        durations = np.arange(1, duration_cap + 1, dtype=int)
        starts = end - durations + 1
        segment_temp = (temp_prefix[end + 1] - temp_prefix[starts]) / durations
        segment_flow = (flow_prefix[end + 1] - flow_prefix[starts]) / durations
        segment_auxiliary = (
            (
                duration_auxiliary_prefix[end + 1]
                - duration_auxiliary_prefix[starts]
            )
            / durations[:, None]
            if duration_auxiliary_indices.size
            else None
        )

        for state in range(states):
            valid = (invalid_prefix[state, end + 1] - invalid_prefix[state, starts]) == 0
            if not np.any(valid):
                continue
            segment_emission = emission_prefix[end + 1, state] - emission_prefix[starts, state]
            if terminal and state == states - 1:
                # Collapse is absorbing; only its entry time is modeled.
                duration_score = np.zeros_like(durations, dtype=float)
            elif params.get("duration_type") == "geometric":
                probability = float(np.asarray(params["geometric_p"])[state])
                if terminal and params.get("terminal_duration_treatment", "survival") == "survival":
                    duration_score = (durations - 1) * math.log(max(1.0 - probability, EPS))
                else:
                    duration_score = (durations - 1) * math.log(max(1.0 - probability, EPS)) + math.log(
                        max(probability, EPS)
                    )
            else:
                eta = duration_linear_predictor(
                    params,
                    state,
                    unit.current,
                    segment_temp,
                    segment_flow,
                    segment_auxiliary,
                )
                terminal_treatment = str(
                    params.get("terminal_duration_treatment", "survival")
                )
                if terminal and terminal_treatment == "survival":
                    duration_score = discrete_lognormal_logsurvival(
                        durations, eta, float(np.asarray(params["dur_sigma"])[state])
                    )
                else:
                    duration_score = discrete_lognormal_logprob(
                        durations, eta, float(np.asarray(params["dur_sigma"])[state])
                    )
            segment_score = segment_emission + duration_score

            candidate_best = np.full(len(durations), -np.inf, dtype=float)
            candidate_second = np.full(len(durations), -np.inf, dtype=float)
            candidate_prev_state = np.full(len(durations), -1, dtype=np.int16)
            zero_start = starts == 0
            if state == 0:
                candidate_best[zero_start] = 0.0
            predecessors = allowed_predecessors(state, states)
            nonzero = starts > 0
            if predecessors and np.any(nonzero):
                prior_end = starts[nonzero] - 1
                values: list[np.ndarray] = []
                labels: list[int] = []
                for predecessor in predecessors:
                    values.append(best[prior_end, predecessor] + log_transition[predecessor, state])
                    labels.append(predecessor)
                    values.append(second[prior_end, predecessor] + log_transition[predecessor, state])
                    labels.append(predecessor)
                stacked = np.vstack(values)
                order = np.argsort(stacked, axis=0)
                best_rows = order[-1]
                second_rows = order[-2] if stacked.shape[0] > 1 else order[-1]
                columns = np.arange(len(prior_end))
                candidate_best[nonzero] = stacked[best_rows, columns]
                candidate_second[nonzero] = stacked[second_rows, columns]
                candidate_prev_state[nonzero] = np.asarray(labels, dtype=int)[best_rows]

            score_best = np.where(valid, candidate_best + segment_score, -np.inf)
            score_second = np.where(valid, candidate_second + segment_score, -np.inf)
            merged = np.r_[score_best, score_second]
            finite = np.flatnonzero(np.isfinite(merged))
            if finite.size == 0:
                continue
            order = finite[np.argsort(merged[finite])]
            best_index = int(order[-1])
            best[end, state] = float(merged[best_index])
            if len(order) > 1:
                second[end, state] = float(merged[int(order[-2])])
            duration_index = best_index % len(durations)
            chosen_start = int(starts[duration_index])
            prev_end[end, state] = chosen_start - 1
            prev_state[end, state] = int(candidate_prev_state[duration_index])
            best_duration[end, state] = int(durations[duration_index])

    final_candidates: list[tuple[float, int]] = []
    for state in range(states):
        if np.isfinite(best[-1, state]):
            final_candidates.append((float(best[-1, state]), state))
    if not final_candidates:
        raise RuntimeError(f"No feasible constrained path for unit {unit.unit_id}")
    final_candidates.sort(key=lambda item: item[0])
    best_score, state = final_candidates[-1]
    numeric_second = [float(second[-1, s]) for s in range(states) if np.isfinite(second[-1, s])]
    numeric_second.extend(score for score, _ in final_candidates[:-1])
    second_score = max(numeric_second) if numeric_second else -np.inf

    decoded = np.full(t_count, -1, dtype=int)
    end = t_count - 1
    current_state = int(state)
    guard = 0
    while end >= 0:
        duration = int(best_duration[end, current_state])
        if duration <= 0:
            raise RuntimeError(f"Invalid backpointer for {unit.unit_id} at t={end}, state={current_state}")
        start = end - duration + 1
        decoded[start : end + 1] = current_state
        next_end = int(prev_end[end, current_state])
        next_state = int(prev_state[end, current_state])
        end, current_state = next_end, next_state
        guard += 1
        if guard > states + t_count:
            raise RuntimeError("Backtracking guard triggered")
    if np.any(decoded < 0):
        raise RuntimeError(f"Incomplete decoded path for {unit.unit_id}")
    return decoded, best_score, second_score


def make_initial_parameters(
    units: list[UnitSequence],
    paths: list[np.ndarray],
    cfg: dict[str, Any],
    environment: bool,
    duration_type: str,
    homogeneous: bool,
    terminal_duration_treatment: str = "survival",
    shared_acceleration: bool = False,
) -> dict[str, Any]:
    model_cfg = cfg["model"]
    states = int(model_cfg["states"])
    scaler = environment_scaler(units)
    feature_center, feature_scale = robust_location_scale(np.vstack([unit.x for unit in units]))
    duration_auxiliary_features = list(
        model_cfg.get("duration_auxiliary_features", [])
    )
    unknown_duration_features = sorted(
        set(duration_auxiliary_features) - set(FEATURE_COLUMNS)
    )
    if unknown_duration_features:
        raise ValueError(
            "Unknown duration auxiliary features: "
            + ", ".join(unknown_duration_features)
        )
    duration_auxiliary_indices = np.asarray(
        [FEATURE_COLUMNS.index(name) for name in duration_auxiliary_features],
        dtype=int,
    )
    if duration_auxiliary_indices.size:
        duration_aux_center, duration_aux_scale = robust_location_scale(
            np.vstack(
                [unit.x[:, duration_auxiliary_indices] for unit in units]
            )
        )
    else:
        duration_aux_center = np.empty(0, dtype=float)
        duration_aux_scale = np.empty(0, dtype=float)
    current_reference = float(cfg["data"]["current_reference_a"])
    duration = initial_duration_parameters(
        units, paths, states, scaler, current_reference
    )
    emission_mu, emission_scale = fit_emissions(
        units,
        paths,
        states,
        float(model_cfg["emission_shrinkage"]),
        feature_center,
        feature_scale,
    )
    params: dict[str, Any] = {
        "states": states,
        "risk_state": int(model_cfg["risk_state"]),
        "max_duration": int(model_cfg["max_duration"]),
        "student_df": float(model_cfg["student_df"]),
        "emission_weight": float(model_cfg.get("emission_weight", 1.0)),
        "environment_ridge": float(model_cfg.get("environment_ridge", 0.0)),
        "use_fast_inference": bool(model_cfg.get("use_fast_inference", True)),
        "feature_center": feature_center,
        "feature_scale": feature_scale,
        "endpoint_anchor_weight": float(model_cfg.get("endpoint_anchor_weight", 0.0)),
        "endpoint_anchor_scale": float(model_cfg.get("endpoint_anchor_scale", 0.025)),
        "hard_thresholds": list(model_cfg.get("hard_thresholds", ["L90", "L80", "T50"])),
        "auxiliary_thresholds": list(model_cfg.get("auxiliary_thresholds", [])),
        "auxiliary_threshold_log_odds": float(
            model_cfg.get("auxiliary_threshold_log_odds", 0.0)
        ),
        "nested_threshold_initialization": bool(
            model_cfg.get("nested_threshold_initialization", False)
        ),
        "current_acceleration_ridge": float(model_cfg.get("current_acceleration_ridge", 0.0)),
        "duration_alpha_pooling_ridge": float(
            model_cfg.get("duration_alpha_pooling_ridge", 0.0)
        ),
        "duration_alpha_prior_mean": float(
            model_cfg.get("duration_alpha_prior_mean", 0.0)
        ),
        "duration_alpha_prior_ridge": float(
            model_cfg.get("duration_alpha_prior_ridge", 0.0)
        ),
        "duration_sigma_pooling_ridge": float(
            model_cfg.get("duration_sigma_pooling_ridge", 0.0)
        ),
        "duration_sigma_min": float(model_cfg.get("duration_sigma_min", 0.15)),
        "duration_sigma_max": float(model_cfg.get("duration_sigma_max", 1.8)),
        "duration_alpha_max": float(model_cfg.get("duration_alpha_max", 6.0)),
        "duration_auxiliary_features": duration_auxiliary_features,
        "duration_auxiliary_indices": duration_auxiliary_indices,
        "duration_auxiliary_states": [
            int(value)
            for value in model_cfg.get(
                "duration_auxiliary_states", list(range(states - 1))
            )
        ],
        "duration_auxiliary_state_loadings": (
            [
                float(value)
                for value in model_cfg["duration_auxiliary_state_loadings"]
            ]
            if "duration_auxiliary_state_loadings" in model_cfg
            else None
        ),
        "duration_aux_center": duration_aux_center,
        "duration_aux_scale": duration_aux_scale,
        "duration_aux_beta": np.zeros(
            duration_auxiliary_indices.size, dtype=float
        ),
        "duration_auxiliary_ridge": float(
            model_cfg.get("duration_auxiliary_ridge", 0.0)
        ),
        "duration_auxiliary_bound": float(
            model_cfg.get("duration_auxiliary_bound", 2.5)
        ),
        "emission_mu": emission_mu,
        "emission_scale": emission_scale,
        "transition": transition_matrix(
            paths, states, float(model_cfg["direct_collapse_probability"])
        ),
        "duration_type": duration_type,
        "environment": environment,
        "homogeneous": homogeneous,
        "shared_acceleration": shared_acceleration,
        "terminal_duration_treatment": terminal_duration_treatment,
        "current_reference": current_reference,
        **duration,
    }
    # Every scored start must lie in the same feasible set as its M-step.
    # Otherwise a narrow, infeasible initial sigma can beat every legal update
    # and be retained as a spurious "best fit" after rejecting all updates.
    active = slice(0, states - 1)
    params["dur_mu"][active] = np.clip(params["dur_mu"][active], math.log(1.5), math.log(900.0))
    params["dur_sigma"][active] = np.clip(params["dur_sigma"][active], params["duration_sigma_min"], params["duration_sigma_max"])
    params["alpha"][active] = np.clip(params["alpha"][active], 0.0, params["duration_alpha_max"])
    params["alpha"][states - 1] = 0.0
    params["initial_parameters_projected_to_bounds"] = True
    if homogeneous:
        params["alpha"] = np.zeros(states, dtype=float)
    elif shared_acceleration:
        nonabsorbing = max(states - 1, 1)
        shared = float(np.mean(np.asarray(params["alpha"])[:nonabsorbing]))
        params["alpha"][:nonabsorbing] = shared
        params["alpha"][states - 1] = 0.0
    if duration_type == "geometric":
        params["geometric_p"] = np.full(states, 0.02, dtype=float)
        params = fit_duration_parameters(
            units,
            paths,
            params,
            environment=False,
            homogeneous=True,
            ridge=float(model_cfg["environment_ridge"]),
        )
    return params


def update_parameters(
    units: list[UnitSequence],
    paths: list[np.ndarray],
    params: dict[str, Any],
    cfg: dict[str, Any],
    *,
    update_emissions: bool = True,
) -> dict[str, Any]:
    updated = copy.deepcopy(params)
    if update_emissions:
        updated["emission_mu"], updated["emission_scale"] = fit_emissions(
            units,
            paths,
            int(params["states"]),
            float(cfg["model"]["emission_shrinkage"]),
            np.asarray(params["feature_center"], dtype=float),
            np.asarray(params["feature_scale"], dtype=float),
        )
    updated["transition"] = transition_matrix(
        paths,
        int(params["states"]),
        float(cfg["model"]["direct_collapse_probability"]),
    )
    updated = fit_duration_parameters(
        units,
        paths,
        updated,
        environment=bool(params["environment"]),
        homogeneous=bool(params["homogeneous"]),
        ridge=float(cfg["model"]["environment_ridge"]),
    )
    return updated


def decode_collection(
    units: list[UnitSequence], params: dict[str, Any], constrained: bool
) -> tuple[list[np.ndarray], float, list[dict[str, Any]]]:
    paths: list[np.ndarray] = []
    objective = 0.0
    diagnostics: list[dict[str, Any]] = []
    for unit in units:
        path, score, runner_up = segmental_viterbi(unit, params, constrained=constrained)
        paths.append(path)
        objective += score
        diagnostics.append(
            {
                "unit_id": unit.unit_id,
                "score": score,
                "runner_up_score": runner_up,
                "score_gap": score - runner_up if np.isfinite(runner_up) else np.nan,
                "segments": int(1 + np.sum(np.diff(path) != 0)),
            }
        )
    return paths, float(objective - duration_regularization(params)), diagnostics


def train_model(
    units: list[UnitSequence],
    cfg: dict[str, Any],
    *,
    environment: bool = False,
    constrained: bool = True,
    duration_type: str = "lognormal",
    homogeneous: bool = False,
    terminal_duration_treatment: str = "survival",
    shared_acceleration: bool = False,
    quick: bool = False,
) -> tuple[dict[str, Any], list[np.ndarray], pd.DataFrame]:
    """Fit a classification-likelihood HSMM with exact constrained decoding."""

    starts = 1 if quick else int(cfg["model"]["multi_starts"])
    iterations = min(2, int(cfg["model"]["max_iterations"])) if quick else int(
        cfg["model"]["max_iterations"]
    )
    tolerance = float(cfg["model"]["objective_tolerance"])
    if terminal_duration_treatment not in {"survival", "complete"}:
        raise ValueError(
            "terminal_duration_treatment must be 'survival' or 'complete'"
        )
    if homogeneous and shared_acceleration:
        raise ValueError(
            "homogeneous and shared_acceleration cannot both be enabled"
        )
    best_fit: tuple[dict[str, Any], list[np.ndarray], float] | None = None
    history_rows: list[dict[str, Any]] = []
    states = int(cfg["model"]["states"])
    risk_state = int(cfg["model"]["risk_state"])

    for start_id in range(starts):
        jitter = (start_id - (starts - 1) / 2.0) * 0.012
        initial_paths = [
            threshold_path(
                unit,
                states,
                risk_state,
                jitter=jitter,
                nested_threshold_initialization=bool(
                    cfg["model"].get("nested_threshold_initialization", False)
                ),
            )
            for unit in units
        ]
        params = make_initial_parameters(
            units,
            initial_paths,
            cfg,
            environment,
            duration_type,
            homogeneous,
            terminal_duration_treatment,
            shared_acceleration,
        )
        paths, objective, diagnostics = decode_collection(units, params, constrained)
        history_rows.append(
            {
                "start": start_id,
                "iteration": 0,
                "objective": objective,
                "accepted": True,
                "converged": False,
                "optimizer_success": bool(params.get("duration_optimizer_success", True)),
            }
        )
        converged = False
        convergence_reason = "iteration_limit"
        for iteration in range(1, iterations + 1):
            # Duration/transition updates maximize the corresponding
            # classification-likelihood blocks.  Robust shrunken Student-t
            # emission estimates are deliberately not exact MLEs, so accept
            # their block only when the same constrained objective does not
            # decrease.
            core_candidate = update_parameters(
                units, paths, params, cfg, update_emissions=False
            )
            core_paths, core_objective, core_diagnostics = decode_collection(
                units, core_candidate, constrained
            )
            emission_candidate = copy.deepcopy(core_candidate)
            (
                emission_candidate["emission_mu"],
                emission_candidate["emission_scale"],
            ) = fit_emissions(
                units,
                paths,
                int(params["states"]),
                float(cfg["model"]["emission_shrinkage"]),
                np.asarray(params["feature_center"], dtype=float),
                np.asarray(params["feature_scale"], dtype=float),
            )
            emission_paths, emission_objective, emission_diagnostics = decode_collection(
                units, emission_candidate, constrained
            )
            emission_accepted = emission_objective + tolerance >= core_objective
            if emission_accepted:
                candidate = emission_candidate
                candidate_paths = emission_paths
                candidate_objective = emission_objective
                diagnostics = emission_diagnostics
            else:
                candidate = core_candidate
                candidate_paths = core_paths
                candidate_objective = core_objective
                diagnostics = core_diagnostics
            accepted = candidate_objective + tolerance >= objective
            history_rows.append(
                {
                    "start": start_id,
                    "iteration": iteration,
                    "objective": candidate_objective,
                    "accepted": accepted,
                    "emission_update_accepted": emission_accepted,
                    "converged": False,
                    "optimizer_success": bool(candidate.get("duration_optimizer_success", True)),
                }
            )
            if not accepted:
                converged = False
                convergence_reason = "no_acceptable_improvement"
                history_rows[-1]["converged"] = False
                break
            relative_gain = (candidate_objective - objective) / max(abs(objective), 1.0)
            params, paths, objective = candidate, candidate_paths, candidate_objective
            if relative_gain < tolerance:
                converged = True
                convergence_reason = "relative_objective_tolerance"
                history_rows[-1]["converged"] = True
                break
        params["converged"] = converged
        params["convergence_reason"] = convergence_reason
        params["objective"] = objective
        params["constrained"] = constrained
        params["path_diagnostics"] = diagnostics
        if best_fit is None or objective > best_fit[2]:
            best_fit = (params, paths, objective)

    if best_fit is None:
        raise RuntimeError("No model fit completed")
    return best_fit[0], best_fit[1], pd.DataFrame(history_rows)


def load_model(path: Path) -> dict[str, Any]:
    params = json.loads(path.read_text(encoding="utf-8"))
    for key in [
        "emission_mu",
        "emission_scale",
        "feature_center",
        "feature_scale",
        "transition",
        "dur_mu",
        "dur_sigma",
        "alpha",
        "gamma",
        "duration_auxiliary_indices",
        "duration_aux_center",
        "duration_aux_scale",
        "duration_aux_beta",
        "geometric_p",
    ]:
        if key in params:
            params[key] = np.asarray(params[key], dtype=float)
    return params


def duration_hazard(
    params: dict[str, Any],
    state: int,
    age: np.ndarray,
    current: float,
    temperature: float,
    flow: float,
    auxiliary: np.ndarray | None = None,
) -> np.ndarray:
    age_arr = np.asarray(age, dtype=float)
    if params.get("duration_type") == "geometric":
        return np.full_like(age_arr, float(np.asarray(params["geometric_p"])[state]))
    eta = duration_linear_predictor(
        params,
        state,
        current,
        np.full_like(age_arr, temperature),
        np.full_like(age_arr, flow),
        auxiliary,
    )
    log_p = discrete_lognormal_logprob(
        age_arr, eta, float(np.asarray(params["dur_sigma"])[state])
    )
    log_s = discrete_lognormal_logsurvival(
        age_arr, eta, float(np.asarray(params["dur_sigma"])[state])
    )
    return np.clip(np.exp(log_p - log_s), 1e-6, 0.999)


def state_age_filter(
    unit: UnitSequence,
    params: dict[str, Any],
    *,
    condition_event_free: bool = True,
    survival_state: int | None = None,
) -> np.ndarray:
    """Filter the state--age distribution through the observation time.

    RUL predictions are issued only while the first-passage endpoint has not
    occurred. Therefore the filter conditions on survival evidence in
    addition to the observed emissions. Without this truncation, filtered
    mass that has already crossed into the risk set is incorrectly reported
    as zero RUL.
    """

    constant_covariates = (not params.get("environment", False)) or (np.ptp(unit.temperature) == 0 and np.ptp(unit.flow) == 0)
    if constant_covariates and not len(params.get("duration_auxiliary_indices", [])) and int(params["states"]) == 4 and params.get("use_fast_inference", True):
        try:
            pass
        except ImportError:
            pass
        else:
            return inference_fast_filter(unit, params, condition_event_free, survival_state)

    states = int(params["states"])
    max_age = len(unit.age) + 2
    posterior = np.zeros((states, max_age), dtype=float)
    log_emission = student_logpdf_matrix(
        standardized_x(unit, params),
        np.asarray(params["emission_mu"]),
        np.asarray(params["emission_scale"]),
        float(params["student_df"]),
    )
    log_emission += endpoint_anchor_loglik(unit, params)
    log_emission += auxiliary_threshold_loglik(unit, params)
    emission = np.exp(log_emission - np.max(log_emission, axis=1, keepdims=True))
    posterior[0, 1] = 1.0
    posterior *= emission[0, :, None]
    posterior /= max(posterior.sum(), EPS)
    transition = np.asarray(params["transition"], dtype=float)
    risk_state = int(params["risk_state"])
    absorbing_target = risk_state if survival_state is None else int(survival_state)
    observed_path_mask = constraint_mask(
        unit,
        states,
        risk_state,
        constrained=True,
        hard_thresholds=params.get("hard_thresholds"),
    )
    posterior *= observed_path_mask[0, :, None]
    posterior /= max(posterior.sum(), EPS)

    for t in range(1, len(unit.age)):
        predicted = np.zeros_like(posterior)
        for state in range(states):
            active_ages = np.flatnonzero(posterior[state] > 0)
            if active_ages.size == 0:
                continue
            hazards = duration_hazard(
                params,
                state,
                active_ages,
                unit.current,
                float(unit.temperature[t - 1]),
                float(unit.flow[t - 1]),
                (
                    unit.x[
                        t - 1,
                        np.asarray(
                            params.get("duration_auxiliary_indices", []),
                            dtype=int,
                        ),
                    ]
                    if len(params.get("duration_auxiliary_indices", []))
                    else None
                ),
            )
            mass = posterior[state, active_ages]
            stay_age = active_ages + 1
            valid_stay = stay_age < max_age
            predicted[state, stay_age[valid_stay]] += mass[valid_stay] * (1.0 - hazards[valid_stay])
            exit_mass = float(np.sum(mass * hazards))
            if state == states - 1:
                predicted[state, 1] += exit_mass
            else:
                targets = np.flatnonzero(transition[state] > 0)
                for target in targets:
                    predicted[target, 1] += exit_mass * transition[state, target]
        predicted *= emission[t, :, None]
        predicted *= observed_path_mask[t, :, None]
        if condition_event_free:
            predicted[absorbing_target:, :] = 0.0
        total = float(predicted.sum())
        if not np.isfinite(total) or total <= 0:
            predicted = np.zeros_like(predicted)
            feasible = np.flatnonzero(observed_path_mask[t])
            if condition_event_free:
                feasible = feasible[feasible < absorbing_target]
            fallback_state = int(feasible[-1]) if feasible.size else 0
            predicted[fallback_state, 1] = 1.0
        else:
            predicted /= total
        posterior = predicted
    return posterior


def hard_route_state_age(unit: UnitSequence, params: dict[str, Any]) -> np.ndarray:
    path = threshold_path(
        unit,
        int(params["states"]),
        int(params["risk_state"]),
        nested_threshold_initialization=bool(params.get("nested_threshold_initialization", False)),
    )
    state = int(path[-1])
    last_change = int(np.flatnonzero(path != state)[-1] + 1) if np.any(path != state) else 0
    posterior = np.zeros((int(params["states"]), len(unit.age) + 2), dtype=float)
    posterior[state, len(path) - last_change] = 1.0
    return posterior


def sample_conditional_duration(
    rng: np.random.Generator,
    params: dict[str, Any],
    state: int,
    current: float,
    temperature: float,
    flow: float,
    minimum_age: int,
    auxiliary: np.ndarray | None = None,
) -> int:
    if params.get("duration_type") == "categorical":
        return int(sample_conditional_duration_batch(rng, params, state, current, temperature, flow, np.array([minimum_age]))[0])
    if params.get("duration_type") == "geometric":
        probability = float(np.asarray(params["geometric_p"])[state])
        return int(minimum_age + rng.geometric(probability) - 1)
    eta = float(
        duration_linear_predictor(
            params,
            state,
            current,
            np.array([temperature]),
            np.array([flow]),
            auxiliary,
        )[0]
    )
    sigma = float(np.asarray(params["dur_sigma"])[state])
    lower = ndtr((math.log(max(minimum_age - 0.5, 1e-6)) - eta) / sigma)
    # Extreme state ages can place the conditional lower CDF within machine
    # precision of one.  Preserve a finite upper-tail interval instead of
    # passing a reversed interval to the random generator.
    upper_probability = 1.0 - 1e-12
    lower = float(np.clip(lower, 0.0, 1.0 - 2e-12))
    u = float(rng.uniform(lower, upper_probability))
    z = math.sqrt(2.0) * _erfinv(2.0 * u - 1.0)
    duration = int(max(minimum_age, round(math.exp(eta + sigma * z))))
    return duration


def sample_conditional_duration_batch(
    rng: np.random.Generator,
    params: dict[str, Any],
    state: int,
    current: float,
    temperature: float,
    flow: float,
    minimum_age: np.ndarray,
    auxiliary: np.ndarray | None = None,
) -> np.ndarray:
    """Vectorized conditional dwell sampling for a shared state/covariate."""

    minimum = np.maximum(np.asarray(minimum_age, dtype=int), 1)
    if minimum.size == 0:
        return minimum.copy()
    if params.get("duration_type") == "categorical":
        p = np.asarray(params["duration_pmf"])[state]
        if np.any(minimum > len(p)):
            raise ValueError("Conditional age exceeds categorical duration support")
        cdf = np.r_[0.0, np.cumsum(p)]
        cdf[-1] = 1.0
        lower = cdf[minimum - 1]
        draws = lower + (1.0 - lower) * rng.random(minimum.size)
        return np.maximum(minimum, np.minimum(np.searchsorted(cdf, draws, side="right"), len(p)))
    if params.get("duration_type") == "geometric":
        probability = float(np.asarray(params["geometric_p"])[state])
        return minimum + rng.geometric(probability, size=minimum.size) - 1
    eta = float(
        duration_linear_predictor(
            params,
            state,
            current,
            np.array([temperature]),
            np.array([flow]),
            auxiliary,
        )[0]
    )
    sigma = float(np.asarray(params["dur_sigma"])[state])
    lower = ndtr(
        (
            np.log(np.maximum(minimum.astype(float) - 0.5, 1e-6))
            - eta
        )
        / sigma
    )
    lower = np.clip(lower, 0.0, 1.0 - 2e-12)
    u = rng.uniform(lower, 1.0 - 1e-12)
    duration = np.rint(np.exp(eta + sigma * ndtri(u))).astype(int)
    return np.maximum(minimum, duration)


def _erfinv(value: float) -> float:
    """Inverse erf through scipy's normal quantile without importing scipy.stats."""

    from scipy.special import ndtri

    return float(ndtri((value + 1.0) / 2.0) / math.sqrt(2.0))


def sample_rul(
    unit: UnitSequence,
    params: dict[str, Any],
    rng: np.random.Generator,
    samples: int,
    hard_route: bool = False,
    target_state: int | None = None,
) -> np.ndarray:
    passage_state = int(params["risk_state"]) if target_state is None else int(target_state)
    # Event-free conditioning must come from the observable prefix, not the
    # simulation's latent truth used only to select evaluation records.
    # A noisy early crossing is a prediction error, not a reason to reset
    # the filter to an invented state and residence age.
    confirmed_target = any(
        evidence.target_state == passage_state and evidence.event
        for evidence in (unit.thresholds or {}).values()
    )
    posterior = (
        hard_route_state_age(unit, params)
        if hard_route
        else state_age_filter(unit, params, condition_event_free=not confirmed_target, survival_state=passage_state)
    )
    flat = posterior.ravel()
    flat /= max(float(flat.sum()), EPS)
    choices = rng.choice(len(flat), size=samples, p=flat)
    state_choices, age_choices = np.unravel_index(choices, posterior.shape)
    transition = np.asarray(params["transition"], dtype=float)
    temperature = float(unit.temperature[-1])
    flow = float(unit.flow[-1])
    duration_auxiliary_indices = np.asarray(
        params.get("duration_auxiliary_indices", []), dtype=int
    )
    duration_auxiliary = (
        unit.x[-1, duration_auxiliary_indices]
        if duration_auxiliary_indices.size
        else None
    )
    out = np.zeros(samples, dtype=float)

    # With the ordered left-to-right topology used by the paper, each
    # pre-passage state has one deterministic successor.  Batch every draw
    # sharing an initial state instead of looping over Monte Carlo samples.
    successors: dict[int, int] = {}
    deterministic = True
    for state in range(passage_state):
        targets = np.flatnonzero(transition[state] > 0)
        if targets.size == 0:
            successors[state] = min(state + 1, int(params["states"]) - 1)
        elif targets.size == 1 and int(targets[0]) > state:
            successors[state] = int(targets[0])
        else:
            deterministic = False
            break
    if deterministic:
        for initial_state in np.unique(state_choices):
            state = int(initial_state)
            if state >= passage_state:
                continue
            selected = np.flatnonzero(state_choices == initial_state)
            ages = np.maximum(age_choices[selected].astype(int), 1)
            duration = sample_conditional_duration_batch(
                rng,
                params,
                state,
                unit.current,
                temperature,
                flow,
                ages,
                duration_auxiliary,
            )
            total = np.maximum(duration - ages + 1, 0)
            guard = 0
            while state < passage_state and guard < int(params["states"]) + 3:
                state = successors[state]
                if state >= passage_state:
                    break
                duration = sample_conditional_duration_batch(
                    rng,
                    params,
                    state,
                    unit.current,
                    temperature,
                    flow,
                    np.ones(len(selected), dtype=int),
                    duration_auxiliary,
                )
                total += duration
                guard += 1
            out[selected] = np.minimum(total.astype(float), 2500.0)
        return out

    for sample_id, (initial_state, initial_age) in enumerate(zip(state_choices, age_choices)):
        state = int(initial_state)
        age = max(int(initial_age), 1)
        if state >= passage_state:
            continue
        duration = sample_conditional_duration(
            rng,
            params,
            state,
            unit.current,
            temperature,
            flow,
            age,
            duration_auxiliary,
        )
        # At segment age one, a segment of duration D reaches its successor
        # after D sampling intervals.
        total = max(duration - age + 1, 0)
        guard = 0
        while state < passage_state and guard < int(params["states"]) + 3:
            targets = np.flatnonzero(transition[state] > 0)
            if targets.size == 0:
                state = min(state + 1, int(params["states"]) - 1)
            else:
                probabilities = transition[state, targets]
                probabilities = probabilities / probabilities.sum()
                state = int(rng.choice(targets, p=probabilities))
            if state >= passage_state:
                break
            duration = sample_conditional_duration(
                rng,
                params,
                state,
                unit.current,
                temperature,
                flow,
                1,
                duration_auxiliary,
            )
            total += duration
            guard += 1
        out[sample_id] = min(float(total), 2500.0)
    return out


def empirical_crps(samples: np.ndarray, observation: float) -> float:
    samples = np.sort(np.asarray(samples, dtype=float))
    n = len(samples)
    if n == 0:
        return np.nan
    first = float(np.mean(np.abs(samples - observation)))
    weights = 2 * np.arange(1, n + 1) - n - 1
    pair_term = float(2.0 * np.sum(weights * samples) / (n * n))
    return first - 0.5 * pair_term


def draw_independent_censor_index(
    rng: np.random.Generator,
    length: int,
    censor_probability: float,
    censor_time_fraction_range: tuple[float, float] = (0.35, 0.55),
) -> int:
    """Draw an administrative dropout time without using latent event time."""

    probability = float(censor_probability)
    low, high = (float(value) for value in censor_time_fraction_range)
    if not 0.0 <= probability <= 1.0:
        raise ValueError("censor_probability must lie in [0, 1]")
    if not 0.0 <= low < high < 1.0:
        raise ValueError(
            "censor_time_fraction_range must satisfy 0 <= low < high < 1"
        )
    if rng.random() >= probability:
        return int(length - 1)
    fraction = float(rng.uniform(low, high))
    return int(np.clip(round(fraction * (length - 1)), 1, length - 2))


def simulate_unit(
    rng: np.random.Generator,
    unit_id: str,
    length: int,
    current: float,
    overlap: float,
    nonhomogeneity: float,
    censor_probability: float,
    pace_heterogeneity: float = 0.0,
    censor_time_fraction_range: tuple[float, float] = (0.35, 0.55),
    persistence: int = 5,
    duration_multipliers: tuple[float, float, float] = (1.0, 1.0, 1.0),
) -> UnitSequence:
    states = 4
    risk_state = 2
    temperature = 25.5 + 0.18 * np.sin(np.linspace(0, 3 * math.pi, length)) + rng.normal(0, 0.03, length)
    flow = 16.0 - 0.012 * np.arange(length) + rng.normal(0, 0.15, length)
    # The two pre-risk means keep the latent L80 passage within the 180-step
    # study for nearly every unit, so the requested 20/50/80% random-censoring
    # factors are not confounded by a large administrative-censoring fraction.
    duration_mu = np.log(np.array([55.0, 50.0, 36.0, 80.0]))
    duration_mu[:3] += np.log(np.asarray(duration_multipliers, dtype=float))
    # The state-specific current effects create moderate heterogeneous stress
    # sensitivity. This avoids a near-homogeneous data generator that would be
    # inconsistent with the stated NH-HSMM research question.
    alpha = nonhomogeneity * np.array([1.20, 2.40, 1.80, 0.10])
    pace_strength = max(float(pace_heterogeneity), 0.0)
    latent_pace = float(rng.normal()) if pace_strength > 0 else 0.0
    pace_loadings = np.array([0.0, 1.0, 0.1, 0.0], dtype=float)
    # Draw every nonabsorbing dwell before constructing the observation
    # window.  The resulting transition times remain available even when a
    # transition occurs after administrative follow-up; they are simulation
    # truth only and are never used to construct observed threshold labels.
    state_durations: list[int] = []
    for state in range(states - 1):
        eta = (
            duration_mu[state]
            - alpha[state] * math.log(current / 3.0)
            + pace_strength * pace_loadings[state] * latent_pace
        )
        duration = max(2, int(round(rng.lognormal(eta, 0.35))))
        state_durations.append(duration)
    transition_times = np.cumsum(state_durations, dtype=int)
    full_true_path = np.searchsorted(
        transition_times,
        np.arange(length, dtype=int),
        side="right",
    ).astype(int)
    true_transition_indices = {
        "L90": int(transition_times[0]),
        "L80": int(transition_times[1]),
        "T50": int(transition_times[2]),
    }
    feature_means = np.array(
        [
            [0.02, 0.00005, 0.00, 0.00, 0.00, 0.03, 0.32],
            [0.10, 0.00045, 0.35, 0.16, 0.06, 0.08, 0.29],
            [0.25, 0.00140, 1.05, 0.52, 0.22, 0.19, 0.22],
            [0.55, 0.00300, 2.20, 1.45, 0.78, 0.50, 0.10],
        ],
        dtype=float,
    )
    # At overlap=1 these scales yield a genuinely intermediate recovery
    # problem rather than a near-separable ceiling; the 0.6 and 1.5 factors
    # then provide meaningful low- and high-overlap perturbations.
    feature_noise = np.array([0.05, 0.00045, 0.35, 0.18, 0.10, 0.06, 0.025], dtype=float)
    x = feature_means[full_true_path] + rng.standard_t(
        df=5, size=(length, len(FEATURE_COLUMNS))
    ) * feature_noise[None, :] * max(overlap, 0.2)
    if pace_strength > 0:
        # A positive latent pace denotes longer Drift residence.  The auxiliary
        # optical/electrical channels carry a noisy causal proxy for that unit
        # effect even when the primary power channel becomes unavailable.
        pace_feature_effect = np.array(
            [0.0, 0.0, 0.0, -0.20, -0.12, -0.08, 0.05],
            dtype=float,
        )
        x += (
            pace_strength
            * latent_pace
            * pace_feature_effect[None, :]
        )
    x[:, 0] = np.clip(x[:, 0], -0.03, 0.99)
    x[:, 1] = np.maximum(x[:, 1], 0.0)
    normalized_power = np.clip(1.0 - x[:, 0], 0.01, 1.1)
    event_index = true_transition_indices["L80"]
    observed_end = draw_independent_censor_index(
        rng,
        length,
        censor_probability,
        censor_time_fraction_range,
    )
    true_path = full_true_path[: observed_end + 1]
    x = x[: observed_end + 1]
    normalized_power = normalized_power[: observed_end + 1]
    temperature = temperature[: observed_end + 1]
    flow = flow[: observed_end + 1]
    age = np.arange(observed_end + 1, dtype=float)
    frame = pd.DataFrame(
        {
            "unit_id": unit_id,
            "age_h": age,
            "current_a": current,
            "normalized_power": normalized_power,
            **{name: x[:, idx] for idx, name in enumerate(FEATURE_COLUMNS)},
            "module_temperature_c": temperature,
            "flow_l_min": flow,
        }
    )
    # Observed labels are constructed exclusively from the noisy normalized
    # power trajectory with the same persistent-threshold rule used for the
    # experimental data.  Latent state transitions above remain separate.
    thresholds: dict[str, ThresholdEvidence] = {}
    for name, level, target_state in [("L90", 0.9, 1), ("L80", 0.8, 2), ("T50", 0.5, 3)]:
        thresholds[name] = make_threshold_evidence(
            normalized_power,
            name,
            level,
            target_state,
            persistence,
        )
    l80 = thresholds["L80"]
    observed_event_index = l80.event_index
    return UnitSequence(
        unit_id=unit_id,
        current=current,
        age=age,
        x=x,
        temperature=temperature,
        flow=flow,
        event=l80.event,
        event_index=observed_event_index,
        event_low=observed_event_index,
        event_high=None if observed_event_index is None else min(observed_event_index + 4, len(age) - 1),
        censor_index=len(age) - 1,
        frame=frame,
        true_path=true_path,
        true_event_index=event_index,
        thresholds=thresholds,
        true_transition_indices=true_transition_indices,
        true_pace=latent_pace,
    )


PROPOSED = "Unregularized constrained SVT NH-HSMM"
ADAPTIVE = "SA-SVT NH-HSMM"
ABANDONED_GEOMETRIC_SHRINKAGE = (
    "Abandoned geometric-prior duration shrinkage"
)
UNCONSTRAINED = "Unconstrained SVT NH-HSMM"
COMPLETE_TERMINAL = "Completed-terminal SVT NH-HSMM"
ADAPTIVE_COMPLETE_TERMINAL = (
    "Stable-anchored completed-terminal SVT NH-HSMM"
)
HOMOGENEOUS = "Homogeneous HSMM Viterbi"
SHARED_ACCELERATION = "Shared-acceleration SVT NH-HSMM"
HARD_CLEAN = "Hard path NH-HSMM"
HARD_LOCF = "Hard path NH-HSMM + causal LOCF"
HARD_LINEAR = "Hard path NH-HSMM + causal trend"
GEOMETRIC = "Geometric HMM Viterbi"
WEIBULL = "Log-current Weibull AFT"
WEIBULL_LINEAR = "Current-linear Weibull AFT"
MATCHED_WEIBULL = "Fixed log-current endpoint Weibull AFT"
WIENER = "Wiener first-passage"
LEGACY_METHOD_NAMES = {
    "Censoring-aware segmental Viterbi NHHSMM": PROPOSED,
    "Direct-stable / Viterbi-later-state NHHSMM": ADAPTIVE,
    "Stable-anchored SVT NH-HSMM": ADAPTIVE,
    "Support-adaptive duration-regularized Viterbi NHHSMM": (
        ABANDONED_GEOMETRIC_SHRINKAGE
    ),
    "Deterministic threshold route (clean-trained)": HARD_CLEAN,
    "Deterministic threshold route + causal LOCF": HARD_LOCF,
    "Deterministic threshold route + causal trend": HARD_LINEAR,
    "Fixed persistent-threshold NH-HSMM": HARD_CLEAN,
    "Fixed persistent-threshold NH-HSMM + causal LOCF": HARD_LOCF,
    "Fixed persistent-threshold NH-HSMM + causal trend": HARD_LINEAR,
    "Weibull AFT": WEIBULL,
    "Matched-information log-current Weibull AFT": MATCHED_WEIBULL,
}
RETIRED_METHODS = {
    "Availability-adaptive censoring-aware Viterbi NHHSMM",
    ABANDONED_GEOMETRIC_SHRINKAGE,
}
EXTERNAL_BASELINES = (
    GEOMETRIC,
    MATCHED_WEIBULL,
    WIENER,
)
SIMULATION_COMPARATORS = {
    "hard_route": HARD_CLEAN,
    "unregularized": PROPOSED,
    "unconstrained": UNCONSTRAINED,
    "completed_terminal": COMPLETE_TERMINAL,
    "anchored_completed_terminal": ADAPTIVE_COMPLETE_TERMINAL,
    "homogeneous_hsmm": HOMOGENEOUS,
    "shared_acceleration": SHARED_ACCELERATION,
    "geometric": GEOMETRIC,
    "weibull": MATCHED_WEIBULL,
    "wiener": WIENER,
}
EVIDENCE_METHOD_FAMILIES = {
    "adaptive": ADAPTIVE,
    **SIMULATION_COMPARATORS,
}
CORE_CONFIRMATORY_COMPARATOR_FAMILIES = {
    "hard_route",
    "geometric",
    "weibull",
    "wiener",
}
PRIMARY_MECHANISM_COMPARATOR_FAMILIES = {
    "unregularized",
}
EXPLORATORY_MECHANISM_COMPARATOR_FAMILIES = {
    "unconstrained",
    "completed_terminal",
    "anchored_completed_terminal",
    "homogeneous_hsmm",
    "shared_acceleration",
}
HISTORICAL_AFT_METHODS = {
    WEIBULL,
    WEIBULL_LINEAR,
    MATCHED_WEIBULL,
    "Matched-information log-current Weibull AFT",
}
STATE_METHODS = (
    PROPOSED,
    ADAPTIVE,
    UNCONSTRAINED,
    COMPLETE_TERMINAL,
    ADAPTIVE_COMPLETE_TERMINAL,
    HOMOGENEOUS,
    SHARED_ACCELERATION,
    HARD_CLEAN,
    HARD_LOCF,
    HARD_LINEAR,
    GEOMETRIC,
)


def rebuild_thresholds(unit: UnitSequence, persistence: int) -> None:
    y = unit.frame["normalized_power"].to_numpy(dtype=float)
    thresholds = {
        name: make_threshold_evidence(y, name, level, target, persistence)
        for name, level, target in (
            ("L90", 0.9, 1),
            ("L80", 0.8, 2),
            ("T50", 0.5, 3),
        )
    }
    unit.thresholds = thresholds
    l80 = thresholds["L80"]
    unit.event = int(l80.event)
    unit.event_index = l80.event_index
    unit.event_low = l80.event_low
    unit.event_high = l80.event_high


def causal_trend_imputation(
    masked: UnitSequence,
    start_index: int,
    persistence: int,
) -> UnitSequence:
    """Extrapolate the primary channel using pre-outage observations only."""

    unit = copy.deepcopy(masked)
    start = int(np.clip(start_index, 0, len(unit.age)))
    if start >= len(unit.age):
        return unit
    y = unit.frame["normalized_power"].to_numpy(dtype=float)
    observed = np.flatnonzero(np.isfinite(y[:start]))
    if observed.size == 0:
        predicted = np.ones(len(unit.age) - start, dtype=float)
        slope = 0.0
    else:
        use = observed[-min(24, observed.size) :]
        ages = unit.age[use]
        values = y[use]
        slope = float(np.polyfit(ages, values, 1)[0]) if len(use) >= 3 and np.ptp(ages) > 0 else 0.0
        slope = min(slope, 0.0)
        predicted = np.clip(values[-1] + slope * (unit.age[start:] - ages[-1]), 0.01, 1.5)
    depth = 1.0 - predicted
    loss = np.full(len(predicted), max(-slope, 0.0), dtype=float)
    rows = unit.frame.index[start:]
    unit.frame.loc[rows, "normalized_power"] = predicted
    unit.frame.loc[rows, "degradation_depth"] = depth
    unit.frame.loc[rows, "loss_rate"] = loss
    rebuild_thresholds(unit, persistence)
    return unit


def fit_weibull_target(
    units: list[UnitSequence],
    target: str,
    current_reference: float,
    *,
    transform: str = "log_current",
    coefficient_bound: float = 8.0,
    coefficient_ridge: float = 0.0,
) -> dict[str, Any]:
    times: list[float] = []
    events: list[float] = []
    currents: list[float] = []
    for unit in units:
        evidence = unit.thresholds[target]
        if evidence.event and evidence.event_index is not None:
            index = int(evidence.event_index)
            events.append(1.0)
        else:
            index = (
                len(unit.age) - 1
                if evidence.censor_index is None
                else int(np.clip(evidence.censor_index, 0, len(unit.age) - 1))
            )
            events.append(0.0)
        times.append(float(unit.age[index]))
        currents.append(float(unit.current))
    observed_time = np.maximum(np.asarray(times, dtype=float), 1e-6)
    event = np.asarray(events, dtype=float)
    current_array = np.asarray(currents, dtype=float)
    if transform == "log_current":
        current_covariate = np.log(current_array / current_reference)
    elif transform == "current_linear":
        current_covariate = current_array - current_reference
    else:
        raise ValueError(
            "Weibull current transform must be 'log_current' or "
            "'current_linear'"
        )

    def objective(theta: np.ndarray) -> float:
        log_scale = theta[0] - theta[1] * current_covariate
        shape = math.exp(float(theta[2]))
        ratio = np.maximum(observed_time / np.exp(log_scale), 1e-12)
        log_pdf = math.log(shape) - log_scale + (shape - 1.0) * np.log(ratio) - ratio**shape
        log_survival = -(ratio**shape)
        negative_log_likelihood = -float(
            np.sum(event * log_pdf + (1.0 - event) * log_survival)
        )
        return negative_log_likelihood + float(
            coefficient_ridge * theta[1] * theta[1]
        )

    bounds = [
        (math.log(10.0), math.log(5000.0)),
        (0.0, float(coefficient_bound)),
        (math.log(0.2), math.log(10.0)),
    ]
    median_log_time = math.log(float(np.median(observed_time)))
    starts = [
        np.array([median_log_time, 0.0, math.log(1.0)]),
        np.array(
            [
                median_log_time,
                min(1.0, float(coefficient_bound)),
                math.log(2.0),
            ]
        ),
        np.array(
            [
                median_log_time,
                0.5 * float(coefficient_bound),
                math.log(2.0),
            ]
        ),
        np.array(
            [
                median_log_time,
                0.9 * float(coefficient_bound),
                math.log(4.0),
            ]
        ),
    ]
    candidates = [
        minimize(
            objective,
            start,
            method="L-BFGS-B",
            bounds=bounds,
        )
        for start in starts
    ]
    successful = [
        (index, candidate)
        for index, candidate in enumerate(candidates)
        if candidate.success and np.isfinite(candidate.fun)
    ]
    if not successful:
        messages = "; ".join(str(candidate.message) for candidate in candidates)
        raise RuntimeError(
            f"Weibull AFT failed for {target} from all fixed starts: {messages}"
        )
    selected_start, result = min(
        successful,
        key=lambda item: float(item[1].fun),
    )
    boundary_hits = [
        name
        for name, value, (lower, upper) in zip(
            ("intercept", "current_coefficient", "log_shape"),
            result.x,
            bounds,
        )
        if bool(
            np.isclose(value, lower, rtol=0.0, atol=1e-6)
            or np.isclose(value, upper, rtol=0.0, atol=1e-6)
        )
    ]
    return {
        "intercept": float(result.x[0]),
        "current_coefficient": float(result.x[1]),
        "shape": float(math.exp(float(result.x[2]))),
        "current_reference": float(current_reference),
        "current_transform": transform,
        "success": bool(result.success),
        "events": int(np.sum(event)),
        "censored": int(len(event) - np.sum(event)),
        "objective": float(result.fun),
        "iterations": int(result.nit),
        "starts_attempted": int(len(starts)),
        "successful_starts": int(len(successful)),
        "selected_start": int(selected_start),
        "coefficient_bound": float(coefficient_bound),
        "coefficient_ridge": float(coefficient_ridge),
        "boundary_hits": boundary_hits,
    }


def sample_weibull(
    fit: dict[str, Any],
    current: float,
    age: float,
    rng: np.random.Generator,
    samples: int,
) -> np.ndarray:
    transform = str(fit.get("current_transform", "log_current"))
    if transform == "log_current":
        current_covariate = math.log(
            current / float(fit["current_reference"])
        )
    elif transform == "current_linear":
        current_covariate = current - float(fit["current_reference"])
    else:
        raise ValueError(f"Unknown Weibull current transform: {transform}")
    scale = math.exp(
        float(fit["intercept"])
        - float(fit["current_coefficient"])
        * current_covariate
    )
    shape = float(fit["shape"])
    residual = rng.exponential(size=samples)
    total = scale * ((age / scale) ** shape + residual) ** (1.0 / shape)
    return np.maximum(total - age, 0.0)


def fit_wiener_reference(
    units: list[UnitSequence], current_reference: float
) -> dict[str, float]:
    """Fit the degradation-coordinate Wiener reference used in this analysis.

    Unit-level degradation slopes identify the current exponent, while
    one-step residual increments identify diffusion. Only training units are
    used. Condition updating at prediction time is handled separately from a
    causal prefix.
    """

    slope_rows: list[tuple[float, float]] = []
    residual_increments: list[float] = []
    for unit in units:
        depth = unit.frame["degradation_depth"].to_numpy(dtype=float)
        age = np.asarray(unit.age, dtype=float)
        observed = np.isfinite(depth) & np.isfinite(age)
        if np.sum(observed) < 5:
            continue
        x = age[observed]
        y = depth[observed]
        centered = x - float(x[0])
        design = np.column_stack([np.ones_like(centered), centered])
        beta, *_ = np.linalg.lstsq(design, y, rcond=None)
        slope = max(float(beta[1]), 1e-6)
        slope_rows.append((float(unit.current), slope))
        fitted = design @ beta
        residual = y - fitted
        if len(residual) > 1:
            dt = np.maximum(np.diff(x), 1e-6)
            residual_increments.extend(
                (np.diff(residual) / np.sqrt(dt)).tolist()
            )

    if not slope_rows:
        return {
            "base_drift": 1e-3,
            "current_exponent": 0.0,
            "sigma_increment": 0.0025,
            "current_reference": float(current_reference),
        }
    current = np.asarray([row[0] for row in slope_rows], dtype=float)
    slope = np.asarray([row[1] for row in slope_rows], dtype=float)
    if np.unique(np.round(current, 6)).size >= 2:
        covariate = np.log(current / current_reference)
        design = np.column_stack([np.ones_like(covariate), covariate])
        beta, *_ = np.linalg.lstsq(design, np.log(slope), rcond=None)
        base_drift = float(math.exp(float(beta[0])))
        exponent = float(np.clip(beta[1], 0.0, 5.0))
    else:
        base_drift = float(np.median(slope))
        exponent = 0.0
    sigma = (
        float(np.std(np.asarray(residual_increments), ddof=1))
        if len(residual_increments) > 1
        else 0.0025
    )
    return {
        "base_drift": max(base_drift, 1e-6),
        "current_exponent": exponent,
        "sigma_increment": max(sigma, 0.0025),
        "current_reference": float(current_reference),
    }


def sample_wiener_first_passage(
    unit: UnitSequence,
    fit: dict[str, float],
    target: str,
    rng: np.random.Generator,
    samples: int,
    *,
    recent_window_h: float = 60.0,
    max_steps: int = 1200,
) -> np.ndarray:
    """Sample a causal Wiener first-passage RUL from the observed prefix."""

    thresholds = {"L90": 0.10, "L80": 0.20, "T50": 0.50}
    if target not in thresholds:
        raise ValueError(f"Unknown Wiener first-passage target: {target}")
    depth = unit.frame["degradation_depth"].to_numpy(dtype=float)
    age = np.asarray(unit.age, dtype=float)
    observed = np.flatnonzero(np.isfinite(depth) & np.isfinite(age))
    if observed.size == 0:
        last_depth = 0.0
        recent_drift = float(fit["base_drift"])
    else:
        last_index = int(observed[-1])
        last_depth = float(depth[last_index])
        recent = observed[
            age[observed] >= age[last_index] - float(recent_window_h)
        ]
        if recent.size >= 5 and np.ptp(age[recent]) > 0:
            x = age[recent]
            y = depth[recent]
            design = np.column_stack([np.ones_like(x), x - float(x[0])])
            beta, *_ = np.linalg.lstsq(design, y, rcond=None)
            recent_drift = max(float(beta[1]), 1e-4)
        else:
            recent_drift = float(fit["base_drift"])
    remaining = thresholds[target] - last_depth
    if remaining <= 0:
        return np.zeros(samples, dtype=float)
    current_scale = max(
        0.25,
        math.exp(
            float(fit["current_exponent"])
            * math.log(
                max(float(unit.current), 1e-6)
                / float(fit["current_reference"])
            )
        ),
    )
    drift = max(recent_drift * current_scale, 1e-6)
    sigma = float(fit["sigma_increment"])
    level = np.full(samples, last_depth, dtype=float)
    passage = np.full(samples, float(max_steps), dtype=float)
    active = np.ones(samples, dtype=bool)
    for step in range(1, max_steps + 1):
        if not np.any(active):
            break
        count = int(np.sum(active))
        level[active] += drift + rng.normal(0.0, sigma, count)
        crossed = active & (level >= thresholds[target])
        passage[crossed] = float(step)
        active[crossed] = False
    return passage


def stable_anchored_svt_nhhsmm(
    nhhsmm: dict[str, Any],
    stable_route: dict[str, Any],
    target_support: dict[str, float],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Anchor the well-observed Stable dwell and decode later states by SVT.

    Only duration states declared eligible before evaluation can be anchored.
    An eligible state is replaced by its directly observed training-route
    estimate only when the associated transition support reaches the frozen
    minimum.  Sparse later states are never borrowed from a geometric HMM;
    their dwell laws, acceleration coefficients, and causal auxiliary effects
    remain those estimated by the right-censoring-aware segmental Viterbi
    objective.
    """

    minimum_support = float(
        cfg["model"].get("stable_anchor_min_support", 0.40)
    )
    eligible_states = [
        int(state)
        for state in cfg["model"].get("stable_anchor_states", [0])
    ]
    if not 0.0 <= minimum_support <= 1.0:
        raise ValueError("stable_anchor_min_support must lie in [0, 1]")
    transition_targets = {
        int(destination) - 1: target
        for target, destination in cfg["evaluation"]["transition_targets"].items()
    }
    states = int(nhhsmm["states"])
    selected: list[int] = []
    adaptive = copy.deepcopy(nhhsmm)
    for parameter in ("dur_mu", "dur_sigma", "alpha"):
        values = np.asarray(adaptive[parameter], dtype=float).copy()
        stable_values = np.asarray(stable_route[parameter], dtype=float)
        for state in eligible_states:
            if state < 0 or state >= states - 1:
                raise ValueError(
                    f"stable anchor state {state} is not a nonabsorbing state"
                )
            target = transition_targets.get(state)
            support = 0.0 if target is None else float(target_support[target])
            if support >= minimum_support:
                values[state] = stable_values[state]
                if state not in selected:
                    selected.append(state)
        adaptive[parameter] = values
    adaptive["stable_anchor"] = {
        "kind": "training-only stable-stage duration anchoring",
        "eligible_states": eligible_states,
        "selected_states": sorted(selected),
        "minimum_transition_support": minimum_support,
        "transition_support": {
            target: float(value) for target, value in target_support.items()
        },
        "later_state_estimator": (
            "right-censoring-aware constrained segmental Viterbi"
        ),
        "prediction_family": "explicit-duration lognormal NH-HSMM",
    }
    return adaptive


def censoring_survival_at(
    units: list[UnitSequence],
    target: str,
    origin_age: float,
    query_time: float,
    *,
    event_left_limit: bool = False,
    floor: float = 0.05,
) -> float:
    """Estimate training-fold censoring survival G(t) by Kaplan-Meier.

    Target events are censoring-KM censorings, while administrative endings
    are censoring-KM events. Units that already crossed the target at the
    prediction origin are outside the risk set.
    """

    times: list[float] = []
    censor_events: list[int] = []
    for unit in units:
        origin_index = first_index_at_or_after(unit.age, origin_age)
        actual_origin = float(unit.age[origin_index])
        evidence = unit.thresholds[target]
        if (
            evidence.event
            and evidence.event_index is not None
            and float(unit.age[int(evidence.event_index)]) <= actual_origin
        ):
            continue
        if evidence.event and evidence.event_index is not None:
            end_index = int(evidence.event_index)
            is_censoring = 0
        else:
            end_index = (
                len(unit.age) - 1
                if evidence.censor_index is None
                else int(np.clip(evidence.censor_index, 0, len(unit.age) - 1))
            )
            is_censoring = 1
        followup = float(unit.age[end_index]) - actual_origin
        if followup > 0:
            times.append(followup)
            censor_events.append(is_censoring)
    if not times:
        return 1.0
    time_array = np.asarray(times, dtype=float)
    censor_array = np.asarray(censor_events, dtype=int)
    survival = 1.0
    comparison = (
        (lambda value: value < query_time)
        if event_left_limit
        else (lambda value: value <= query_time)
    )
    for time_value in np.sort(np.unique(time_array)):
        if not comparison(float(time_value)):
            break
        at_risk = int(np.sum(time_array >= time_value))
        events = int(
            np.sum((time_array == time_value) & (censor_array == 1))
        )
        if at_risk > 0:
            survival *= 1.0 - events / at_risk
    return float(max(survival, floor))


def horizon_column(prefix: str, horizon: float) -> str:
    label = f"{float(horizon):g}".replace("-", "m").replace(".", "p")
    return f"{prefix}_{label}h"


def integrated_brier_curve(
    times: np.ndarray,
    contributions: np.ndarray,
) -> float:
    """Time-average an IPCW Brier contribution curve by trapezoidal quadrature."""

    grid = np.asarray(times, dtype=float)
    values = np.asarray(contributions, dtype=float)
    if grid.ndim != 1 or values.shape != grid.shape or grid.size < 2:
        raise ValueError("IBS grid and contributions must be aligned vectors")
    if grid[0] != 0.0 or np.any(np.diff(grid) <= 0):
        raise ValueError("IBS grid must start at zero and increase strictly")
    return float(np.trapezoid(values, grid) / grid[-1])


def evaluate_unit(
    unit: UnitSequence,
    state_models: dict[str, tuple[dict[str, Any], bool]],
    endpoint_models: dict[str, dict[str, dict[str, Any]]],
    wiener: dict[str, float] | None,
    target_support: dict[str, float],
    cfg: dict[str, Any],
    *,
    dataset: str,
    split_id: str,
    censoring: float | None,
    origins: list[float],
    outages: list[int],
    samples: int,
    censoring_reference: list[UnitSequence] | None = None,
) -> list[dict[str, Any]]:
    targets = {
        name: int(state)
        for name, state in cfg["evaluation"]["transition_targets"].items()
    }
    horizons = [float(value) for value in cfg["evaluation"]["reliability_horizons_h"]]
    ibs_tau = float(
        cfg["evaluation"].get(
            "ipcw_integration_tau_h",
            max(horizons),
        )
    )
    ibs_step = float(
        cfg["evaluation"].get("ipcw_integration_step_h", 5.0)
    )
    if ibs_tau <= 0 or ibs_step <= 0:
        raise ValueError("IPCW integration horizon and step must be positive")
    ibs_grid = np.arange(0.0, ibs_tau + 0.5 * ibs_step, ibs_step)
    if ibs_grid[-1] < ibs_tau:
        ibs_grid = np.r_[ibs_grid, ibs_tau]
    else:
        ibs_grid[-1] = ibs_tau
    indices = cfg["evaluation"]["primary_feature_indices"]
    persistence = int(cfg["data"]["persistence_points"])
    level = float(cfg["evaluation"]["interval_level"])
    lo_q = (1.0 - level) / 2.0
    hi_q = 1.0 - lo_q
    rows: list[dict[str, Any]] = []
    for target, target_state in targets.items():
        truth_index = None
        if dataset == "simulation" and unit.true_transition_indices is not None:
            truth_index = unit.true_transition_indices[target]
        elif unit.thresholds[target].event:
            truth_index = unit.thresholds[target].event_index
        for requested_origin in origins:
            origin_index = first_index_at_or_after(unit.age, requested_origin)
            origin_age = float(unit.age[origin_index])
            if dataset == "simulation":
                if truth_index is None:
                    continue
                event_age = float(truth_index)
                event_observed = 1
                followup = event_age - origin_age
            else:
                evidence = unit.thresholds[target]
                if evidence.event and evidence.event_index is not None:
                    event_age = float(unit.age[int(evidence.event_index)])
                    event_observed = 1
                    followup = event_age - origin_age
                else:
                    censor_index = (
                        len(unit.age) - 1
                        if evidence.censor_index is None
                        else int(
                            np.clip(
                                evidence.censor_index,
                                0,
                                len(unit.age) - 1,
                            )
                        )
                    )
                    event_age = math.nan
                    event_observed = 0
                    followup = float(unit.age[censor_index]) - origin_age
            if followup <= 0:
                continue
            clean_prefix = unit.prefix(origin_index)
            actual = followup if event_observed else math.nan
            weight_floor = float(
                cfg["evaluation"].get("ipcw_survival_floor", 0.05)
            )
            g_horizon = {
                horizon: (
                    1.0
                    if censoring_reference is None
                    else censoring_survival_at(
                        censoring_reference,
                        target,
                        origin_age,
                        horizon,
                        floor=weight_floor,
                    )
                )
                for horizon in horizons
            }
            g_ibs_grid = {
                horizon: (
                    1.0
                    if censoring_reference is None
                    else censoring_survival_at(
                        censoring_reference,
                        target,
                        origin_age,
                        float(horizon),
                        floor=weight_floor,
                    )
                )
                for horizon in ibs_grid
            }
            g_event = (
                1.0
                if not event_observed or censoring_reference is None
                else censoring_survival_at(
                    censoring_reference,
                    target,
                    origin_age,
                    followup,
                    event_left_limit=True,
                    floor=weight_floor,
                )
            )
            for outage in outages:
                start = max(0, len(clean_prefix.age) - int(outage)) if outage > 0 else len(clean_prefix.age)
                masked = mask_primary_observations(
                    clean_prefix, start, feature_indices=indices
                )
                trend = causal_trend_imputation(masked, start, persistence)
                predictions: dict[str, np.ndarray] = {}
                for method, (params, hard_route) in state_models.items():
                    prediction_unit = trend if method == HARD_LINEAR else masked
                    predictions[method] = sample_rul(
                        prediction_unit,
                        params,
                        keyed_rng(
                            int(cfg["project"]["seed"]),
                            "pilot-prediction",
                            dataset,
                            split_id,
                            unit.unit_id,
                            target,
                            origin_age,
                            outage,
                        ),
                        samples,
                        hard_route=hard_route,
                        target_state=target_state,
                    )
                support = float(target_support[target])
                for method, target_models in endpoint_models.items():
                    predictions[method] = sample_weibull(
                        target_models[target],
                        unit.current,
                        origin_age,
                        keyed_rng(
                            int(cfg["project"]["seed"]),
                            "pilot-prediction",
                            dataset,
                            split_id,
                            unit.unit_id,
                            target,
                            origin_age,
                            outage,
                            method,
                        ),
                        samples,
                    )
                if wiener is not None:
                    predictions[WIENER] = sample_wiener_first_passage(
                        masked,
                        wiener,
                        target,
                        keyed_rng(
                            int(cfg["project"]["seed"]),
                            "pilot-prediction",
                            dataset,
                            split_id,
                            unit.unit_id,
                            target,
                            origin_age,
                            outage,
                            WIENER,
                        ),
                        samples,
                    )
                for method, prediction in predictions.items():
                    lo, median, hi = np.quantile(prediction, [lo_q, 0.5, hi_q])
                    survival_probabilities = {
                        horizon: float(np.mean(prediction > horizon))
                        for horizon in horizons
                    }
                    brier_contributions: dict[float, float] = {}
                    for horizon in horizons:
                        survival_probability = survival_probabilities[horizon]
                        if event_observed and followup <= horizon:
                            contribution = survival_probability**2 / g_event
                        elif followup > horizon:
                            contribution = (
                                (1.0 - survival_probability) ** 2
                                / g_horizon[horizon]
                            )
                        else:
                            # Censored at or before this horizon: the standard
                            # IPCW estimating-equation contribution is zero.
                            contribution = 0.0
                        brier_contributions[horizon] = float(contribution)
                    ibs_contributions: list[float] = []
                    for horizon in ibs_grid:
                        survival_probability = float(
                            np.mean(prediction > horizon)
                        )
                        if event_observed and followup <= horizon:
                            contribution = survival_probability**2 / g_event
                        elif followup > horizon:
                            contribution = (
                                (1.0 - survival_probability) ** 2
                                / g_ibs_grid[horizon]
                            )
                        else:
                            contribution = 0.0
                        ibs_contributions.append(float(contribution))
                    ipcw_ibs = integrated_brier_curve(
                        ibs_grid,
                        np.asarray(ibs_contributions, dtype=float),
                    )
                    four_horizon_brier_mean = float(
                        np.mean(list(brier_contributions.values()))
                    )
                    row: dict[str, Any] = {
                            "dataset": dataset,
                            "split_id": split_id,
                            "unit_id": unit.unit_id,
                            "current_a": float(unit.current),
                            "censoring": censoring,
                            "target": target,
                            "origin_h": origin_age,
                            "outage_h": int(outage),
                            "method": method,
                            "training_event_fraction": support,
                            "adaptive_source": (
                                "stable-anchor-constrained-svt"
                                if method == ADAPTIVE
                                else ""
                            ),
                            "followup_h": followup,
                            "event_observed": int(event_observed),
                            "evaluation_status": (
                                "event_observed"
                                if event_observed
                                else "right_censored"
                            ),
                            "actual_rul_h": actual,
                            "p10_h": float(lo),
                            "p50_h": float(median),
                            "p90_h": float(hi),
                            "absolute_error_h": (
                                abs(float(median) - actual)
                                if event_observed
                                else math.nan
                            ),
                            "crps_h": (
                                empirical_crps(prediction, actual)
                                if event_observed
                                else math.nan
                            ),
                            "covered": (
                                int(lo <= actual <= hi)
                                if event_observed
                                else math.nan
                            ),
                            "ipcw_ibs": ipcw_ibs,
                            "four_horizon_brier_mean": (
                                four_horizon_brier_mean
                            ),
                            "ipcw_integration_tau_h": ibs_tau,
                            "ipcw_integration_step_h": ibs_step,
                            # Compatibility alias now points to the actual
                            # time-integrated IPCW Brier score.
                            "ibs": ipcw_ibs,
                        }
                    for horizon in horizons:
                        row[
                            horizon_column("survival_probability", horizon)
                        ] = survival_probabilities[horizon]
                        row[
                            horizon_column("ipcw_brier_contribution", horizon)
                        ] = brier_contributions[horizon]
                        row[
                            horizon_column("censoring_survival", horizon)
                        ] = g_horizon[horizon]
                    rows.append(row)
    return rows


def relative_gain(reference: float, proposed: float) -> float:
    return float((reference - proposed) / max(abs(reference), EPS))


def real_validation_splits(
    units: list[UnitSequence],
) -> list[
    tuple[str, str, list[UnitSequence], list[UnitSequence]]
]:
    """Return the prespecified unit-interpolation and current-extrapolation folds."""

    splits: list[
        tuple[str, str, list[UnitSequence], list[UnitSequence]]
    ] = []
    for held_unit in sorted(units, key=lambda unit: unit.unit_id):
        train = [
            unit for unit in units if unit.unit_id != held_unit.unit_id
        ]
        splits.append(
            (
                "real",
                f"LOOU-{held_unit.unit_id}",
                train,
                [held_unit],
            )
        )
    currents = sorted({round(unit.current, 1) for unit in units})
    for current in currents:
        train = [
            unit for unit in units if round(unit.current, 1) != current
        ]
        held = [
            unit for unit in units if round(unit.current, 1) == current
        ]
        splits.append(
            (
                "real_loco",
                f"LOCO-{current:.1f}A",
                train,
                held,
            )
        )
    return splits


# Exact segmental inference
# ------------------------------------------------------------------------
import math
import numpy as np
from numba import njit


@njit(cache=True)
def inference__lse(a, b):
    if a == -np.inf:
        return b
    if b == -np.inf:
        return a
    m = max(a, b)
    return m + math.log1p(math.exp(min(a, b) - m))


def inference_evidence_tables(unit, params, constrained):
    pass
    if params.get('environment',False) and (np.ptp(unit.temperature)>0 or np.ptp(unit.flow)>0):
        raise ValueError('Exact table inference requires covariates constant within each unit')
    k = int(params['states'])
    x = standardized_x(unit, params)
    if params.get('emission_type') == 'gaussian_diagonal':
        z = (x[:, None, :] - np.asarray(params['emission_mu'])[None, :, :]) / np.asarray(params['emission_scale'])[None, :, :]
        terms = -.5 * z*z - np.log(np.asarray(params['emission_scale']))[None, :, :] - .5*np.log(2*np.pi)
        em = float(params.get('emission_weight', 1.0)) * np.nansum(terms, axis=2)
    else:
        em = float(params.get('emission_weight', 1.0)) * student_logpdf_matrix(x, np.asarray(params['emission_mu']), np.asarray(params['emission_scale']), float(params['student_df']))
    em += endpoint_anchor_loglik(unit, params) + auxiliary_threshold_loglik(unit, params)
    ep = np.vstack((np.zeros((1, k)), np.cumsum(em, axis=0)))
    mask = constraint_mask(unit, k, int(params['risk_state']), constrained, params.get('hard_thresholds'))
    invalid = np.vstack((np.zeros((1, k), dtype=np.int64), np.cumsum(~mask, axis=0)))
    d = np.arange(1, len(unit.age) + 1, dtype=float)
    mass = np.zeros((k, len(d) + 1))
    survival = np.zeros_like(mass)
    for s in range(k - 1):
        if params.get('duration_type') == 'categorical':
            p = np.asarray(params['duration_pmf'])[s]
            if len(p) < len(d):
                raise ValueError('Duration support shorter than observed sequence')
            mass[s, 1:] = np.log(p[:len(d)])
            survival[s, 1:] = np.log(np.cumsum(p[::-1])[::-1][:len(d)])
        elif params.get('duration_type') == 'geometric':
            p = float(np.asarray(params['geometric_p'])[s])
            survival[s, 1:] = (d - 1) * np.log1p(-p)
            mass[s, 1:] = survival[s, 1:] + np.log(p)
        else:
            eta = duration_linear_predictor(params, s, unit.current, np.array([unit.temperature[0]]), np.array([unit.flow[0]]))[0]
            sig = float(np.asarray(params['dur_sigma'])[s])
            mass[s, 1:] = discrete_lognormal_logprob(d, eta, sig)
            survival[s, 1:] = discrete_lognormal_logsurvival(d, eta, sig)
    terminal = survival.copy() if params.get('terminal_duration_treatment', 'survival') == 'survival' else mass.copy()
    terminal[-1, :] = 0.0
    return ep, invalid, mass, survival, terminal


@njit(cache=True)
def inference__viterbi(ep, invalid, mass, terminal, cap):
    n, k = ep.shape[0] - 1, ep.shape[1]
    best = np.full((n + 1, k), -np.inf)
    second = np.full_like(best, -np.inf)
    prev = np.zeros((n + 1, k), dtype=np.int64)
    for end in range(1, n + 1):
        for s in range(k):
            if s == k - 1 and end != n:
                continue
            for d in range(1, (end if end == n else min(end, cap)) + 1):
                start = end - d
                if invalid[end, s] != invalid[start, s]:
                    continue
                if s == 0:
                    if start != 0:
                        continue
                    p1, p2 = 0.0, -np.inf
                else:
                    if start == 0:
                        continue
                    p1, p2 = best[start, s - 1], second[start, s - 1]
                score = ep[end, s] - ep[start, s] + (terminal[s, d] if end == n else mass[s, d])
                v1, v2 = p1 + score, p2 + score
                if v1 > best[end, s]:
                    second[end, s] = max(best[end, s], v2)
                    best[end, s] = v1
                    prev[end, s] = start
                else:
                    second[end, s] = max(second[end, s], v1, v2)
    s = np.argmax(best[n])
    top = best[n, s]
    runner = second[n, s]
    for j in range(k):
        if j != s:
            runner = max(runner, best[n, j])
    path = np.full(n, -1, dtype=np.int64)
    end = n
    if not np.isfinite(top):
        return path, top, runner
    while end > 0:
        start = prev[end, s]
        path[start:end] = s
        end, s = start, s - 1
    return path, top, runner


def inference_fast_viterbi(unit, params, constrained=True):
    transition = np.asarray(params['transition'])
    if any(abs(transition[s, s + 1] - 1.0) > 1e-12 for s in range(3)):
        raise ValueError('Fast inference requires adjacent ordered transitions of probability one')
    ep, invalid, mass, _, terminal = inference_evidence_tables(unit, params, constrained)
    result = inference__viterbi(ep, invalid, mass, terminal, int(params['max_duration']))
    if not np.isfinite(result[1]):
        raise RuntimeError(f'No feasible ordered path for {unit.unit_id}')
    return result


@njit(cache=True)
def inference__forward_backward(ep, invalid, mass, terminal, cap):
    n, k = ep.shape[0] - 1, ep.shape[1]
    forward = np.full((n + 1, k), -np.inf)
    backward = np.full((n + 1, k), -np.inf)
    for end in range(1, n + 1):
        for s in range(k):
            if s == k - 1 and end != n:
                continue
            total = -np.inf
            for d in range(1, (end if end == n else min(end, cap)) + 1):
                start = end - d
                if invalid[end, s] != invalid[start, s]:
                    continue
                incoming = 0.0 if s == 0 and start == 0 else (forward[start, s - 1] if s > 0 and start > 0 else -np.inf)
                total = inference__lse(total, incoming + ep[end, s] - ep[start, s] + (terminal[s, d] if end == n else mass[s, d]))
            forward[end, s] = total
    for start in range(n - 1, -1, -1):
        for s in range(k - 1, -1, -1):
            total = -np.inf
            for end in range(start + 1, n + 1):
                d = end - start
                if invalid[end, s] != invalid[start, s] or (end != n and (d > cap or s == k - 1)):
                    continue
                tail = 0.0 if end == n else backward[end, s + 1]
                total = inference__lse(total, ep[end, s] - ep[start, s] + (terminal[s, d] if end == n else mass[s, d]) + tail)
            backward[start, s] = total
    log_z = backward[0, 0]
    delta = np.zeros((n + 1, k))
    weights = np.zeros((k, n + 1, 2))
    if not np.isfinite(log_z):
        return log_z, delta[:-1], weights
    for s in range(k):
        for start in range(n):
            incoming = 0.0 if s == 0 and start == 0 else (forward[start, s - 1] if s > 0 and start > 0 else -np.inf)
            if not np.isfinite(incoming):
                continue
            for end in range(start + 1, n + 1):
                d = end - start
                if invalid[end, s] != invalid[start, s] or (end != n and (d > cap or s == k - 1)):
                    continue
                tail = 0.0 if end == n else backward[end, s + 1]
                log_w = incoming + ep[end, s] - ep[start, s] + (terminal[s, d] if end == n else mass[s, d]) + tail - log_z
                w = math.exp(min(log_w, 0.0))
                delta[start, s] += w
                delta[end, s] -= w
                weights[s, d, int(end < n)] += w
    occupancy = np.zeros((n, k))
    for s in range(k):
        value = 0.0
        for t in range(n):
            value += delta[t, s]
            occupancy[t, s] = max(value, 0.0)
    return log_z, occupancy, weights


def inference_forward_backward(unit, params, constrained=True):
    ep, invalid, mass, _, terminal = inference_evidence_tables(unit, params, constrained)
    z, gamma, weights = inference__forward_backward(ep, invalid, mass, terminal, int(params['max_duration']))
    if not np.isfinite(z):
        raise RuntimeError(f'No feasible sum-product path for {unit.unit_id}')
    return z, gamma, weights


@njit(cache=True)
def inference__filter(emission, mask, hazard, target):
    n, k = emission.shape
    post = np.zeros((k, n + 2))
    post[0, 1] = 1.0
    for t in range(1, n):
        nxt = np.zeros_like(post)
        for s in range(k):
            for age in range(1, t + 1):
                value = post[s, age]
                nxt[s, age + 1] += value * (1.0 - hazard[s, age])
                if s < k - 1:
                    nxt[s + 1, 1] += value * hazard[s, age]
        total = 0.0
        for s in range(k):
            factor = emission[t, s] if mask[t, s] and s < target else 0.0
            for age in range(1, n + 2):
                nxt[s, age] *= factor
                total += nxt[s, age]
        if total <= 0.0 or not np.isfinite(total):
            raise ValueError('Zero filtering mass; contradictory evidence or numerical underflow')
        post = nxt / total
    return post


def inference_fast_filter(unit, params, condition_event_free=True, survival_state=None):
    pass
    ep, invalid, mass, survival, _ = inference_evidence_tables(unit, params, bool(params.get('prediction_constraints', True)))
    logs = np.diff(ep, axis=0)
    emission = np.exp(logs - logs.max(axis=1, keepdims=True))
    mask = np.diff(invalid, axis=0) == 0
    hazard = np.zeros_like(mass)
    hazard[:-1, 1:] = np.clip(np.exp(mass[:-1, 1:] - survival[:-1, 1:]), 0.0, 1.0)
    target = (int(params['risk_state']) if survival_state is None else int(survival_state)) if condition_event_free else int(params['states'])
    if not mask[0, 0]:
        raise ValueError('Initial state incompatible with evidence')
    return inference__filter(emission, mask, hazard, target)


# Censoring-aware scoring
# ------------------------------------------------------------------------
import numpy as np
from scipy.optimize import minimize
from scipy.special import gamma, gammainc


def score_weibull_survival_crps(time, event, log_scale, shape):
    """Integral_0^time F^2 + event * Integral_time^infinity S^2.

Closed form via the lower incomplete gamma. No integration grid or tail cutoff.
"""
    t, e, ls = np.broadcast_arrays(np.asarray(time, float), np.asarray(event, float), np.asarray(log_scale, float))
    if shape <= 0 or np.any(t < 0) or np.any((e != 0) & (e != 1)):
        raise ValueError('Positive shape, nonnegative times and binary event required')
    scale = np.exp(ls)
    power = np.exp(np.clip(shape * (np.log(np.maximum(t, 1e-300)) - ls), -745, 700))
    power = np.where(t == 0, 0., power)
    total1 = scale * gamma(1. + 1. / shape)
    total2 = total1 / 2.**(1. / shape)
    first = total1 * gammainc(1. / shape, power)
    second = total2 * gammainc(1. / shape, 2. * np.minimum(power, 1e300))
    return np.maximum(t - 2. * first + (1. - e) * second + e * total2, 0.)


def score_minimize_survival_crps(times, events, design, bounds, starts, penalty=None):
    t, e, z = np.asarray(times), np.asarray(events), np.asarray(design)
    penalty = np.zeros(z.shape[1]) if penalty is None else np.asarray(penalty)
    # Divide the whole objective by a training-only time scale. This leaves the
    # minimizer unchanged and avoids tolerance depending on hours vs cycles.
    normalization = max(float(np.median(t)), .1)
    def objective(theta):
        score = score_weibull_survival_crps(t, e, theta[0] + z @ theta[1:-1], np.exp(theta[-1]))
        return float(np.mean(score) / normalization + np.sum(penalty * theta[1:-1]**2))
    results = [minimize(objective, start, method='L-BFGS-B', bounds=bounds,
                        options={'maxiter':500, 'ftol':1e-11}) for start in starts]
    valid = [(i, r) for i, r in enumerate(results) if r.success and np.isfinite(r.fun)]
    if not valid:
        raise RuntimeError('Survival-CRPS optimization failed: ' + '; '.join(str(r.message) for r in results))
    i, best = min(valid, key=lambda item:item[1].fun)
    return best.x, {'success':True, 'objective':best.fun, 'objective_time_normalization':normalization,
                   'events':int(e.sum()), 'censored':int(len(e)-e.sum()), 'selected_start':i,
                   'successful_starts':len(valid), 'iterations':best.nit, 'bounds':bounds,
                   'boundary_hits':[j for j,(x,(lo,hi)) in enumerate(zip(best.x,bounds))
                                    if lo != hi and (abs(x-lo)<1e-5 or abs(x-hi)<1e-5)],
                   'training_objective':'unweighted Survival-CRPS; not generally proper under censoring'}


def score_fit_survival_crps_aft(units, target, current_reference, bound=3.):
    t, e = [], []
    for u in units:
        ev = u.thresholds[target]
        index = ev.event_index if ev.event else ev.censor_index
        index = len(u.age)-1 if index is None else int(index)
        t.append(max(float(u.age[index]),1e-6)); e.append(ev.event)
    z = -np.log(np.array([u.current for u in units])/current_reference)[:,None]
    bounds=[(np.log(10.),np.log(5000.)),(0.,bound),(np.log(.2),np.log(10.))]
    intercept=np.log(np.median(t))
    starts=[[intercept,a,np.log(k)] for a,k in [(0,1),(min(1,bound),2),(.5*bound,2),(.9*bound,4)]]
    theta, diagnostics=score_minimize_survival_crps(t,e,z,bounds,starts)
    return {'intercept':theta[0], 'current_coefficient':theta[1], 'shape':np.exp(theta[2]),
            'current_reference':current_reference, 'current_transform':'log_current', **diagnostics}


# External HSMM comparisons
# ------------------------------------------------------------------------
import copy
import numpy as np
import pandas as pd
from scipy.optimize import brentq, minimize_scalar


def external_l2_probability_update(counts, kernel, penalty):
    counts=np.asarray(counts,float);kernel=np.asarray(kernel,float)
    if penalty == 0:
        p=np.maximum(counts,1e-12)
        return p/p.sum()
    def probabilities(multiplier):
        b=multiplier-2*penalty*kernel
        root=np.sqrt(b*b+8*penalty*counts)
        p=np.empty_like(b)
        positive=b>=0
        p[positive]=np.divide(2*counts[positive],root[positive]+b[positive],out=np.zeros(positive.sum()),where=(root[positive]+b[positive])>0)
        p[~positive]=(root[~positive]-b[~positive])/(4*penalty)
        return p
    lo=-2*penalty-1.;hi=counts.sum()+2*penalty+1.
    multiplier=brentq(lambda v:probabilities(v).sum()-1.,lo,hi,xtol=1e-11)
    p=np.maximum(probabilities(multiplier),1e-12)
    return p/p.sum()


def external_geometric_kernel(counts):
    d=np.arange(len(counts),dtype=float)
    def objective(lp):
        p=np.exp(lp);logq=np.log1p(-p)
        return -np.dot(counts,np.log(p)+d*logq-np.log(-np.expm1(len(d)*logq)))
    result=minimize_scalar(objective,bounds=(-12.,-.00001),method='bounded',options={'xatol':1e-9})
    p=np.exp(result.x);v=np.exp(np.log(p)+d*np.log1p(-p));return v/v.sum()


def external_expectation(units,params):
    m=np.asarray(params['duration_pmf']).shape[1]
    count=np.zeros((3,m));gammas=[];value=0.
    for u in units:
        z,gamma,w=inference_forward_backward(u,params,True)
        value+=z;gammas.append(gamma)
        for s in range(3):
            p=np.asarray(params['duration_pmf'])[s]
            surv=np.cumsum(p[::-1])[::-1]
            count[s,:len(u.age)]+=w[s,1:,1]
            censor=np.zeros(m);censor[:len(u.age)]=w[s,1:,0]
            count[s]+=p*np.cumsum(censor/np.maximum(surv,1e-300))
    return value,gammas,count


def external_gaussian_update(units,gammas,params):
    x=np.vstack([standardized_x(u,params) for u in units]);g=np.vstack(gammas)
    means=np.asarray(params['emission_mu']).copy();scales=np.asarray(params['emission_scale']).copy()
    for s in range(4):
        for j in range(x.shape[1]):
            ok=np.isfinite(x[:,j]);w=g[ok,s];v=x[ok,j]
            if w.sum()>1e-8:
                means[s,j]=np.average(v,weights=w)
                scales[s,j]=np.sqrt(max(np.average((v-means[s,j])**2,weights=w),1e-4))
    return means,scales


def external_fit_one(units,cfg,penalty,initial):
    params=copy.deepcopy(initial);trace=[];previous=-np.inf
    maxiter=int(cfg['model'].get('external_max_iterations',40))
    converged=False
    for iteration in range(maxiter+1):
        likelihood,gammas,counts=external_expectation(units,params)
        kernel=np.asarray(params['duration_kernel'])
        objective=likelihood-penalty*np.sum((np.asarray(params['duration_pmf'])[:3]-kernel)**2)
        trace.append({'iteration':iteration,'objective':objective,'log_likelihood':likelihood,'penalty':penalty,'accepted':True})
        if iteration and objective < previous-1e-6:
            # Kernel refitting is the paper's sequential update. Safeguard the
            # observed penalized objective instead of asserting monotonicity.
            params=accepted;trace[-1]['accepted']=False;break
        if iteration and (objective-previous)/max(abs(previous),1.) < 1e-6:
            converged=True;break
        if iteration==maxiter:break
        previous=objective;accepted=copy.deepcopy(params)
        params['emission_mu'],params['emission_scale']=external_gaussian_update(units,gammas,params)
        kernel=np.asarray([external_geometric_kernel(c) for c in counts])
        params['duration_kernel']=kernel
        params['duration_pmf'][:3]=np.asarray([external_l2_probability_update(c,k,penalty) for c,k in zip(counts,kernel)])
    likelihood,gammas,counts=external_expectation(units,params)
    # Eq. (2), shared lambda, excluding the last probability in each simplex.
    edf=float(3+np.sum(counts[:,:-1]/(counts[:,:-1]+penalty+1e-300))) if penalty else float(3*(counts.shape[1]-1))
    emission_df=2*4*np.asarray(params['emission_mu']).shape[1]
    params.update(converged=converged,convergence_reason='relative_objective_tolerance' if converged else ('rejected_update' if not trace[-1]['accepted'] else 'iteration_limit'),objective=likelihood,log_likelihood=likelihood,penalty=penalty,effective_duration_df=edf,aic=-2*likelihood+2*(emission_df+edf))
    return params,pd.DataFrame(trace)


def external_fit_external(units,cfg,method):
    paths=[threshold_path(u,4,2,nested_threshold_initialization=True) for u in units]
    params=make_initial_parameters(units,paths,cfg,False,'lognormal',False,'survival')
    m=max(600,4*max(len(u.age) for u in units));d=np.arange(1,m+1)
    p=np.zeros((4,m))
    for s in range(3):
        p[s]=np.exp(discrete_lognormal_logprob(d,np.asarray(params['dur_mu'])[s],np.asarray(params['dur_sigma'])[s]));p[s]=np.maximum(p[s],1e-12);p[s]/=p[s].sum()
    p[3]=1/m
    params.update(duration_type='categorical',duration_pmf=p,duration_kernel=np.asarray([external_geometric_kernel(v) for v in p[:3]]),emission_type='gaussian_diagonal',endpoint_anchor_weight=0.,prediction_constraints=True,max_duration=m,estimator=method,adapted_external=True)
    fits=[];traces=[]
    grid=[0.] if method=='himap_adapted' else [1.,10.,100.,1000.]
    for penalty in grid:
        fitted,trace=external_fit_one(units,cfg,penalty,params)
        trace['method']=method;fits.append(fitted);traces.append(trace)
    best=min(fits,key=lambda p:p['aic'])
    best['penalty_candidates']=[{'lambda':p['penalty'],'aic':p['aic'],'converged':p['converged']} for p in fits]
    return best,[inference_fast_viterbi(u,best,True)[0] for u in units],pd.concat(traces,ignore_index=True)


# Matched baseline and ablation configurations
# ------------------------------------------------------------------------
import copy
import time
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import gammaln


def model_weighted_emissions(units, gammas, params):
    x = np.vstack([standardized_x(u, params) for u in units])
    gamma = np.vstack(gammas)
    means = np.asarray(params['emission_mu']).copy()
    scales = np.asarray(params['emission_scale']).copy()
    nu = float(params['student_df'])
    for s in range(int(params['states'])):
        for j in range(x.shape[1]):
            ok = np.isfinite(x[:, j])
            values, w = x[ok, j], gamma[ok, s]
            if w.sum() < 1e-8:
                continue
            def objective(theta):
                mu, log_scale = theta
                scale = np.exp(log_scale)
                z = (values - mu) / scale
                value = np.sum(w * (log_scale + (nu + 1) / 2 * np.log1p(z*z/nu)))
                g_mu = np.sum(w * (-(nu + 1) * z / (nu + z*z) / scale))
                g_scale = np.sum(w * (1 - (nu + 1) * z*z / (nu + z*z)))
                return value, np.array([g_mu, g_scale])
            result = minimize(objective, [means[s,j], np.log(scales[s,j])], jac=True, method='L-BFGS-B', bounds=[(None,None),(-6.9,5.0)], options={'maxiter':60,'ftol':1e-9})
            means[s,j], scales[s,j] = result.x[0], np.exp(result.x[1])
    return means, scales


def model_expectation(units, params, constrained=True, unit_weights=None):
    objective = 0.0
    gamma = []
    records = []
    if unit_weights is None:
        unit_weights = np.ones(len(units))
    for u, uw in zip(units, unit_weights):
        z, occupancy, weights = inference_forward_backward(u, params, constrained)
        objective += uw * z
        gamma.append(occupancy * uw)
        for s in range(int(params['states'])-1):
            for completed in range(2):
                for d in np.flatnonzero(weights[s,:,completed] > 1e-12):
                    records.append({'state':s,'duration':int(d),'complete':completed,'weight':float(weights[s,d,completed]*uw),'current':u.current,'temperature':float(u.temperature[0]),'flow':float(u.flow[0])})
    return objective - duration_regularization(params), gamma, records


def model_fit_soft_em(units, cfg, *, interval_only=False, initial=None, unit_weights=None):
    paths = [threshold_path(u,4,2,nested_threshold_initialization=True) for u in units]
    params = copy.deepcopy(initial) if initial is not None else make_initial_parameters(units,paths,cfg,bool(cfg['model'].get('static_extra_covariates',False)),'lognormal',False,'survival')
    params['terminal_duration_treatment'] = 'survival'
    if interval_only:
        params['emission_weight'] = 0.0
        params['endpoint_anchor_weight'] = 0.0
    objective, gamma, records = model_expectation(units, params, True, unit_weights)
    trace = [{'iteration':0,'objective':objective,'accepted':True,'estimator':'interval_likelihood' if interval_only else 'soft_em'}]
    converged = False
    for iteration in range(1,int(cfg['model'].get('em_max_iterations',20))+1):
        candidate = fit_duration_parameters(units,paths,params,bool(params.get('environment',False)),False,float(cfg['model']['environment_ridge']),records)
        if not interval_only:
            candidate['emission_mu'],candidate['emission_scale'] = model_weighted_emissions(units,gamma,params)
        value, new_gamma, new_records = model_expectation(units,candidate,True,unit_weights)
        accepted = value >= objective - 1e-7
        trace.append({'iteration':iteration,'objective':value,'accepted':accepted,'duration_optimizer_success':candidate.get('duration_optimizer_success',False)})
        if not accepted:
            break
        improvement = (value-objective)/max(abs(objective),1)
        params,objective,gamma,records = candidate,value,new_gamma,new_records
        if improvement < float(cfg['model']['objective_tolerance']):
            converged = True
            break
    params['objective'],params['converged'] = objective,converged
    params['estimator'] = 'interval_likelihood' if interval_only else 'soft_em'
    params['convergence_reason'] = 'relative_objective_tolerance' if converged else ('rejected_update' if not trace[-1]['accepted'] else 'iteration_limit')
    decoded = [inference_fast_viterbi(u,params,True)[0] for u in units]
    return params,decoded,pd.DataFrame(trace)


def model_fixed_fit(units,cfg,terminal='survival'):
    paths=[threshold_path(u,4,2,nested_threshold_initialization=True) for u in units]
    params=make_initial_parameters(units,paths,cfg,bool(cfg['model'].get('static_extra_covariates',False)),'lognormal',False,terminal)
    params=update_parameters(units,paths,params,cfg)
    params['estimator']='fixed_segmentation'
    return params,paths,pd.DataFrame([{'iteration':0,'accepted':True,'objective':np.nan}])


def model_fit_matched_models(units,cfg,methods=None):
    """Fit shared-family comparators; soft EM also changes emission estimation."""
    requested = methods or cfg['revision']['methods']
    fits,diagnostics={},{}
    fit_specs={
      'fixed_survival':('fixed','survival',True,False,'lognormal'),
      'fixed_complete':('fixed','complete',True,False,'lognormal'),
      'svt_survival':('viterbi','survival',True,False,'lognormal'),
      'svt_complete':('viterbi','complete',True,False,'lognormal'),
      'unconstrained_survival':('viterbi','survival',False,False,'lognormal'),
      'unconstrained_complete':('viterbi','complete',False,False,'lognormal'),
      'shared_survival':('viterbi','survival',True,True,'lognormal'),
      'shared_complete':('viterbi','complete',True,True,'lognormal'),
      'geometric_survival':('viterbi','survival',True,False,'geometric'),
      'geometric_complete':('viterbi','complete',True,False,'geometric'),
      'soft_em':('soft','survival',True,False,'lognormal'),
      'interval_likelihood':('interval','survival',True,False,'lognormal')}
    prediction_specs={}
    for method in requested:
        hard=method.endswith('_hard')
        key=method[:-5] if hard else method
        prediction_specs[method]=(key,hard)
    for key in dict.fromkeys(k for k,_ in prediction_specs.values()):
        if key in ('himap_adapted', 'farcomeni_l2_adapted'):
            pass
            start=time.perf_counter()
            result=external_fit_external(units,cfg,key)
            fits[key]=result
            diagnostics[key]={'fit_seconds':time.perf_counter()-start,'terminal':'survival','constrained_training':True,'estimator':key,'shared_acceleration':False}
            continue
        kind,terminal,constrained,shared,duration=fit_specs[key]
        start=time.perf_counter()
        if kind=='fixed':
            result=model_fixed_fit(units,cfg,terminal)
        elif kind in ('soft','interval'):
            result=model_fit_soft_em(units,cfg,interval_only=kind=='interval')
        else:
            result=train_model(units,cfg,environment=bool(cfg['model'].get('static_extra_covariates',False)),constrained=constrained,duration_type=duration,homogeneous=duration=='geometric',terminal_duration_treatment=terminal,shared_acceleration=shared)
        params,paths,trace=result
        params['prediction_constraints']=True
        elapsed=time.perf_counter()-start
        fits[key]=(params,paths,trace)
        diagnostics[key]={'fit_seconds':elapsed,'terminal':terminal,'constrained_training':constrained,'estimator':kind,'shared_acceleration':shared}
    models={method:(fits[key][0],hard) for method,(key,hard) in prediction_specs.items()}
    return models,fits,diagnostics


# Xjtu
# ------------------------------------------------------------------------
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.io import loadmat


ROOT=Path(__file__).resolve().parents[1]


# Laser and simulation experiments
# ------------------------------------------------------------------------
import argparse
import concurrent.futures
import copy
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd


ROOT=Path(__file__).resolve().parents[1]


def experiment_dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(json_ready(value),indent=2,ensure_ascii=False),encoding='utf-8')


def experiment_strip_truth(unit):
    value=copy.deepcopy(unit)
    value.true_path=None;value.true_transition_indices=None;value.true_pace=None;value.true_event_index=None
    return value


def experiment_diagnostics_for_fit(units,params,paths,method,scenario,pace=0.0,multipliers=(1.,1.,1.)):
    path_rows=[];parameter_rows=[];terms=[]
    true_mu=np.log(np.array([55.,50.,36.])*np.array(multipliers))
    true_sigma=np.sqrt(.35**2+(pace*np.array([0.,1.,.1]))**2)
    for s in range(3) if params.get('duration_type') != 'categorical' else []:
        for parameter,true in [('dur_mu',true_mu[s]),('dur_sigma',true_sigma[s]),('alpha',[1.2,2.4,1.8][s])]:
            estimate=float(np.asarray(params[parameter])[s])
            comparable_truth=scenario.startswith('simulation') and scenario!='simulation_sparse_end'
            parameter_rows.append({'method':method,'state':s,'parameter':parameter,'estimate':estimate,'truth':true if comparable_truth else np.nan,'error':estimate-true if comparable_truth else np.nan})
    for u,path in zip(units,paths):
        anchors=endpoint_anchor_loglik(u,params)
        if params.get('emission_type')=='gaussian_diagonal':
            x=standardized_x(u,params);sc=np.asarray(params['emission_scale']);z=(x[:,None,:]-np.asarray(params['emission_mu'])[None,:,:])/sc[None,:,:]
            emission=np.nansum(-.5*z*z-np.log(sc)[None,:,:]-.5*np.log(2*np.pi),axis=2)
        else:
            emission=student_logpdf_matrix(standardized_x(u,params),np.asarray(params['emission_mu']),np.asarray(params['emission_scale']),params['student_df'])
        terms.append({'method':method,'unit_id':u.unit_id,'emission_log_score':float(emission[np.arange(len(path)),path].sum()*params.get('emission_weight',1.0)),'anchor_log_score':float(anchors[np.arange(len(path)),path].sum()),'segments':1+int(np.count_nonzero(np.diff(path)))})
        for target,s in [('L90',1),('L80',2),('T50',3)]:
            decoded=np.flatnonzero(path>=s)
            entry=int(decoded[0]) if len(decoded) else np.nan
            ev=u.thresholds[target]
            truth=np.nan if u.true_transition_indices is None else u.true_transition_indices[target]
            observed_truth=bool(np.isfinite(truth) and truth<len(path))
            path_rows.append({'method':method,'unit_id':u.unit_id,'target':target,'current':u.current,'decoded_entry':entry,'evidence_low':ev.event_low,'evidence_high':ev.event_high,'evidence_observed':ev.event,'latent_entry':truth,'latent_entry_observed':observed_truth,'decoded_entry_observed':bool(len(decoded)),'error':entry-truth if observed_truth and len(decoded) else np.nan,'true_in_interval':bool(ev.event and ev.event_low<=truth<=ev.event_high) if np.isfinite(truth) and ev.event else np.nan,'state_accuracy':float(np.mean(path==u.true_path)) if u.true_path is not None else np.nan})
    return path_rows,parameter_rows,terms


def experiment_run_task(task,cfg,out):
    task_id=task['id'];folder=Path(out)/'tasks'/task_id
    inputs=[]
    if not task['scenario'].startswith('simulation'):
        inputs=sorted((ROOT/'data').glob(cfg['data']['life_pattern']))+[ROOT/'data'/cfg['data']['telemetry_file']]
    input_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    fingerprint=hashlib.sha256((json.dumps(task,sort_keys=True)+json.dumps(cfg,sort_keys=True)+json.dumps(input_hashes,sort_keys=True)+''.join((ROOT/'scripts'/f).read_text(encoding='utf-8') for f in ['main_analysis.py'])).encode()).hexdigest()
    marker=folder/'completed.json'
    if marker.exists() and json.loads(marker.read_text())['fingerprint']==fingerprint:
        return {'id':task_id,'status':'cached'}
    start=time.perf_counter();folder.mkdir(parents=True,exist_ok=True)
    scenario=task['scenario']
    local=copy.deepcopy(cfg)
    local['model'].update(task.get('model_overrides',{}))
    local['data'].update(task.get('data_overrides',{}))
    if task.get('methods'):
        local['revision']['methods']=task['methods']
    pace=0.;multipliers=(1.,1.,1.)
    if scenario.startswith('simulation'):
        sim=local['simulation'];pace=0.0 if scenario in ('simulation_recovery','simulation_inspection_recovery') else float(sim['pace_heterogeneity'])
        fixed_end=scenario in ('simulation_fixed_end','simulation_sparse_end')
        length=480 if fixed_end else int(sim['sequence_length'])
        multipliers=(4.,8.,5.) if fixed_end else (1.,1.,1.)
        train=[];test=[]
        for role,count,destination in [('train',sim['train_units'],train),('test',sim['test_units'],test)]:
            for i in range(count):
                censor=task.get('censoring',0.0) if role=='train' and not fixed_end else 0.0
                current=[3.,3.5,4.,4.5][i%4]
                local_multipliers=tuple(v*(8. if current<=3.5 else 1.) for v in multipliers) if scenario=='simulation_sparse_end' else multipliers
                u=simulate_unit(keyed_rng(local['project']['seed'],task_id,role,i),f'{task_id}-{role}-{i:03}',length,current,sim['overlap'],sim['nonhomogeneity'],censor,pace,tuple(sim['censor_time_fraction_range']),local['data']['persistence_points'],local_multipliers)
                if scenario=='simulation_inspection_recovery':
                    # Dedicated statistical recovery experiment: the observable
                    # is an error-free state inspection every five time steps.
                    # It is distinct from noisy power-threshold proxy evidence.
                    for target in ['L90','L80','T50']:
                        old=u.thresholds[target];transition=u.true_transition_indices[target]
                        high=5*int(np.ceil(transition/5));observed=high<len(u.age)
                        low=max(1,high-4)
                        u.thresholds[target]=ThresholdEvidence(target,old.level,old.target_state,int(observed),low if observed else None,low if observed else None,high if observed else None,high if observed else 5*((len(u.age)-1)//5))
                    mid=u.thresholds['L80'];u.event=mid.event;u.event_index=mid.event_index;u.event_low=mid.event_low;u.event_high=mid.event_high
                destination.append(u)
        origins=[100,200,300] if fixed_end else sim['prediction_origins_h']
        dataset='simulation'
    else:
        _,_,units=build_dataset(ROOT,local)
        test=[u for u in units if u.unit_id in task['test_ids']]
        train=[u for u in units if u.unit_id not in task['test_ids']]
        origins=local['evaluation']['prediction_origins_h']
        dataset='real'
    drop=task.get('drop_features',[])
    if drop:
        train=copy.deepcopy(train);test=copy.deepcopy(test)
        for u in train+test:
            u.x[:,drop]=np.nan
    models,fits,fit_times=model_fit_matched_models([experiment_strip_truth(u) for u in train],local)
    support={t:float(np.mean([u.thresholds[t].event for u in train])) for t in ['L90','L80','T50']}
    endpoint={}
    aft_diagnostics=[]
    if task.get('aft',True):
        for bound in [3.0,12.0]:
            key=f'aft_bound{bound:g}'
            endpoint[key]={t:fit_weibull_target(train,t,local['data']['current_reference_a'],coefficient_bound=bound,coefficient_ridge=0.0) for t in support}
            for t,p in endpoint[key].items():
                aft_diagnostics.append({'method':key,'target':t,**p})
        endpoint['aft_survival_crps']={t:score_fit_survival_crps_aft(train,t,local['data']['current_reference_a']) for t in support}
        for t,p in endpoint['aft_survival_crps'].items():
            aft_diagnostics.append({'method':'aft_survival_crps','target':t,**p})
    predictions=[]
    prediction_start=time.perf_counter()
    for u in test:
        predictions.extend(evaluate_unit(u,models,endpoint,None,support,local,dataset=dataset,split_id=task_id,censoring=task.get('censoring'),origins=origins,outages=[0],samples=local['model']['prediction_samples'],censoring_reference=None if dataset=='simulation' else train))
    frame=pd.DataFrame(predictions)
    if frame.empty:
        raise RuntimeError(f'No eligible predictions in {task_id}')
    frame['scenario']=scenario
    frame['signed_error']=frame.p50_h-frame.actual_rul_h
    frame['squared_error']=frame.signed_error**2
    for tau in [50,100,150,200]:
        frame[f'events_within_{tau}']=frame.event_observed.eq(1)&frame.actual_rul_h.le(tau)
    frame.to_csv(folder/'predictions.csv',index=False)
    all_paths=[];all_parameters=[];all_terms=[];traces=[]
    for method,(params,paths,trace) in fits.items():
        pr,pa,te=experiment_diagnostics_for_fit(train,params,paths,method,scenario,pace,multipliers)
        all_paths.extend(pr);all_parameters.extend(pa);all_terms.extend(te)
        trace=trace.copy();trace['method']=method;traces.append(trace)
        experiment_dump(folder/'models'/f'{method}.json',params)
    pd.DataFrame(all_paths).to_csv(folder/'path_diagnostics.csv',index=False)
    pd.DataFrame(all_parameters,columns=['method','state','parameter','estimate','truth','error']).to_csv(folder/'parameter_diagnostics.csv',index=False)
    pd.DataFrame(all_terms).to_csv(folder/'score_components.csv',index=False)
    pd.concat(traces,ignore_index=True).to_csv(folder/'convergence.csv',index=False)
    experiment_dump(folder/'fit_diagnostics.json',fit_times)
    experiment_dump(folder/'aft_diagnostics.json',aft_diagnostics)
    experiment_dump(folder/'configuration.json',local)
    experiment_dump(folder/'training_support.json',{t:{str(current):sum(u.thresholds[t].event for u in train if u.current==current) for current in sorted({u.current for u in train})} for t in support})
    result={'id':task_id,'fingerprint':fingerprint,'input_hashes':input_hashes,'status':'completed','scenario':scenario,'train_units':len(train),'test_units':len(test),'prediction_rows':len(frame),'seconds':time.perf_counter()-start,'prediction_seconds':time.perf_counter()-prediction_start,'fit_times':fit_times}
    experiment_dump(marker,result)
    return result


def experiment_summarize(out):
    out=Path(out);files=list((out/'tasks').glob('*/predictions.csv'))
    if not files:return
    rows=pd.concat([pd.read_csv(f).assign(task_id=f.parent.name) for f in files],ignore_index=True)
    rows['design']=rows.task_id.str.extract(r'(LOOU|LOCO|BATTERY)',expand=False).fillna(rows.scenario)
    def agg(g):
        return pd.Series({'records':len(g),'events':g.event_observed.sum(),'crps':g.crps_h.mean(),'ibs':g.ibs.mean(),'mae':g.absolute_error_h.mean(),'rmse':np.sqrt(g.squared_error.mean()),'bias':g.signed_error.mean(),'coverage80':g.covered.mean(),'events_within150':g.events_within_150.sum()})
    target=rows.groupby(['scenario','design','method','target']).apply(agg,include_groups=False).reset_index()
    target.to_csv(out/'metrics_by_target.csv',index=False)
    target.groupby(['scenario','design','method'])[['crps','ibs','mae','rmse','bias','coverage80']].mean().reset_index().to_csv(out/'metrics_macro.csv',index=False)
    rows.groupby(['scenario','design','current_a','method','target']).apply(agg,include_groups=False).reset_index().to_csv(out/'metrics_by_current_target.csv',index=False)
    rows.to_csv(out/'predictions.csv',index=False)
    for name in ['path_diagnostics','parameter_diagnostics','score_components','convergence']:
        files=list((out/'tasks').glob(f'*/{name}.csv'))
        if files:pd.concat([pd.read_csv(f).assign(task_id=f.parent.name) for f in files],ignore_index=True).to_csv(out/f'{name}.csv',index=False)


def experiment_main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',default='data/settings/revision_round1.json')
    parser.add_argument('--mode',choices=['pilot','laser','simulation','recovery','sensitivity','summarize'],default='pilot')
    parser.add_argument('--replicates',type=int,default=100)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--output',default=None)
    args=parser.parse_args();cfg=load_config(ROOT/args.config)
    folder='inspection_recovery' if args.mode=='recovery' else args.mode
    out=ROOT/(args.output or f'outputs/revision_round1_v2/{folder}')
    if args.mode=='summarize':experiment_summarize(out);return
    tasks=[]
    if args.mode in ['pilot','simulation','recovery']:
        if args.mode=='pilot':
            cfg['simulation'].update(train_units=12,test_units=8)
            cfg['model'].update(max_iterations=8,multi_starts=2,em_max_iterations=8,prediction_samples=400)
        reps=1 if args.mode=='pilot' else args.replicates
        scenarios=['simulation_dropout'] if args.mode=='pilot' else ['simulation_inspection_recovery'] if args.mode=='recovery' else ['simulation_dropout','simulation_recovery','simulation_fixed_end']
        for scenario in scenarios:
            for censor in ([.2,.5,.8] if scenario=='simulation_dropout' else [.5] if scenario in ('simulation_recovery','simulation_inspection_recovery') else [0.]):
                for rep in range(reps):
                    tasks.append({'id':f'{scenario}-c{censor:.1f}-r{rep:03}','scenario':scenario,'censoring':censor})
    if args.mode in ['laser','sensitivity']:
        _,_,units=build_dataset(ROOT,cfg)
        splits=real_validation_splits(units)
        for _,name,train,test in splits:
            if args.mode=='laser':tasks.append({'id':name,'scenario':'laser','test_ids':[u.unit_id for u in test]})
            else:
                if not name.startswith('LOCO'):continue
                specs=[('original_prior',{'duration_alpha_prior_mean':1.8,'duration_alpha_prior_ridge':10.},{} ,[]),('original_anchor',{'endpoint_anchor_weight':.75}, {}, []),('no_power_derived',{}, {},[0,1,6]),('weak_penalty',{'current_acceleration_ridge':.035,'duration_alpha_pooling_ridge':.8,'duration_sigma_pooling_ridge':.6},{},[]),('reference15',{}, {'reference_age_h':15},[]),('reference25',{}, {'reference_age_h':25},[])]
                for label,model,data,dropped in specs:
                    tasks.append({'id':f'{label}-{name}','scenario':f'sensitivity_{label}','test_ids':[u.unit_id for u in test],'model_overrides':model,'data_overrides':data,'drop_features':dropped,'methods':['fixed_survival','fixed_complete','svt_survival','svt_complete'],'aft':False})
    experiment_dump(out/'plan.json',{'mode':args.mode,'configuration':cfg,'tasks':tasks,'environment':{'python':sys.version,'platform':platform.platform()}})
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures={executor.submit(experiment_run_task,task,cfg,str(out)):task['id'] for task in tasks}
        failed=[]
        for future in concurrent.futures.as_completed(futures):
            try:
                result=future.result();print(json.dumps({'id':result['id'],'status':result['status'],'seconds':result.get('seconds')},ensure_ascii=False),flush=True)
            except Exception as exc:
                import traceback
                failure={'id':futures[future],'error':str(exc),'traceback':traceback.format_exc()};failed.append(failure);print(json.dumps(failure),flush=True)
        experiment_dump(out/'run_status.json',{'tasks':len(tasks),'failures':failed,'completed':len(tasks)-len(failed)})
    experiment_summarize(out)
    experiment_dump(out/'summary_status.json',{'summary_complete':True,'failed_tasks':len(failed)})
    if failed:raise SystemExit(1)


# Adapter
# ------------------------------------------------------------------------
import argparse
import io
import json
import pickle
import re
import zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.io import loadmat

ROOT=Path(__file__).resolve().parents[1]
adapter_SOURCE=ROOT/'data/public_source'
adapter_DEST=ROOT/'data/cross_domain_candidates'


def adapter_source_directory(*patterns):
    matches=sorted({p for pattern in patterns for p in adapter_SOURCE.glob(pattern) if p.is_dir()})
    if len(matches)!=1:raise FileNotFoundError(f'Expected one dataset directory for {patterns}, found {matches}')
    return matches[0]


def adapter_prepare_hust():
    folder=adapter_DEST/'hust';folder.mkdir(parents=True,exist_ok=True)
    frames=[];records=[]
    with zipfile.ZipFile(adapter_source_directory('2022_HUST*')/'our_data.zip') as archive:
        for name in sorted(n for n in archive.namelist() if n.endswith('.pkl')):
            # Author-provided numerical archive. Its RUL labels are never read
            # into features: endpoints are independently reconstructed from dq.
            data=pickle.loads(archive.read(name));uid=next(iter(data));d=data[uid]
            if (folder/f'{uid}.csv').exists():
                g=pd.read_csv(folder/f'{uid}.csv')
            else:
                rows=[]
                for cycle in sorted(d['dq']):
                    row={'unit_id':uid,'cycle_index':cycle,'discharge_capacity':float(d['dq'][cycle])/1000}
                    # Uniform sparse measurement schedule, not a fraction of
                    # eventual life. First 20 cycles supply baseline covariates.
                    if cycle<=20 or cycle%10==0:
                        f=d['data'][cycle]
                        status=f['Status'].astype(str)
                        current=f['Current (mA)'].to_numpy(dtype=float)/1000
                        voltage=f['Voltage (V)'].to_numpy(dtype=float)
                        for k in range(4):
                            mask=status.eq(f'Constant current discharge_{k}').to_numpy()
                            row[f'discharge{k}_A']=float(np.median(np.abs(current[mask]))) if mask.any() else np.nan
                        for prefix,mask in [('charge',status.str.contains('charge')&~status.str.contains('discharge')),('discharge',status.str.contains('discharge'))]:
                            values=voltage[np.asarray(mask)]
                            row[f'{prefix}_mean_voltage']=float(np.mean(values)) if len(values) else np.nan
                            row[f'{prefix}_voltage_sd']=float(np.std(values)) if len(values) else np.nan
                    rows.append(row)
                g=pd.DataFrame(rows);g.to_csv(folder/f'{uid}.csv',index=False)
            if 'discharge0_A' not in g:
                # Source stages are numbered 0,1,2,3. Stage 0 varies between
                # cells; stage 3 is the common 2 C final discharge stage.
                g['discharge0_A']=np.nan
                for cycle in sorted(k for k in d['data'] if k<=20):
                    f=d['data'][cycle];mask=f['Status'].astype(str).eq('Constant current discharge_0')
                    value=float(np.median(np.abs(f.loc[mask,'Current (mA)'].to_numpy(dtype=float))))/1000
                    g.loc[g.cycle_index.eq(cycle),'discharge0_A']=value
                g.to_csv(folder/f'{uid}.csv',index=False)
            early=g[g.cycle_index.le(20)]
            record={'unit_id':uid,'records':len(g),'source_member':name}
            record.update({f'discharge{k}_A':early[f'discharge{k}_A'].median() for k in range(4)})
            records.append(record);frames.append(g)
            print(json.dumps({'dataset':'hust','cell':uid,'cycles':len(g)}),flush=True)
    pd.concat(frames,ignore_index=True).to_csv(folder/'cycle_summaries.csv',index=False)
    table=pd.DataFrame(records);table.to_csv(folder/'inventory.csv',index=False)
    return table


# HUST cross-domain extension
# ------------------------------------------------------------------------
import argparse
import concurrent.futures
import copy
import hashlib
import json
import math
import time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.model_selection import KFold


ROOT=Path(__file__).resolve().parents[1]
battery_STEP=10
battery_TARGETS={'L90':('Q95',.95,1),'L80':('Q90',.90,2),'T50':('Q85',.85,3)}


def battery_load_units(dataset):
    folder=ROOT/'data/cross_domain_candidates'/dataset
    frame=pd.read_csv(folder/'cycle_summaries.csv');meta=pd.read_csv(folder/'inventory.csv')
    duplicates=set(meta.loc[meta.unit_id.duplicated(False),'unit_id'])
    units=[];inventory=[]
    for uid,g in frame.groupby('unit_id',sort=True):
        reason=None
        if uid in duplicates:reason='Continuation alignment requires source reconciliation; all records of this physical cell excluded together'
        g=g[g.cycle_index.gt(0)].sort_values('cycle_index').copy()
        if len(g)<40:reason='Fewer than 40 recorded regular cycles'
        m=meta[meta.unit_id.eq(uid)].iloc[0]
        cov=[m.discharge0_A,m.discharge1_A,m.discharge2_A]
        if not np.all(np.isfinite(cov)) or cov[0]<=0:reason='Missing protocol covariates'
        if g.cycle_index.duplicated().any() and uid not in duplicates:reason='Repeated cycle index in source summary'
        inventory.append({'unit_id':uid,'included':reason is None,'reason':reason or 'all eligibility criteria met','recorded_cycles':len(g)})
        if reason:continue
        early=g.iloc[:20];qref=float(early.discharge_capacity.median())
        loss=1-g.discharge_capacity.to_numpy()/qref
        slope=causal_slope(loss,15)
        extra=g[['charge_mean_voltage','charge_voltage_sd','discharge_mean_voltage','discharge_voltage_sd']].to_numpy()
        extra=np.column_stack([extra,extra[:,0]-extra[:,2]])
        # Measurements at fixed cycle counts. No life-normalized time and no
        # smoothing/interpolation using future cycles. Pre-observation reference
        # is computed only from the first 20 regular cycles.
        x=np.column_stack([loss,slope,extra]);x[~np.isfinite(x)]=np.nan
        selected=np.flatnonzero((g.cycle_index.to_numpy()>=30)&(g.cycle_index.to_numpy()%battery_STEP==0))
        if not np.all(np.diff(g.cycle_index.to_numpy()[selected])==battery_STEP):
            raise ValueError(f'Irregular observation grid for {dataset}:{uid}; explicit missing-grid handling required')
        x=x[selected];ratio=1-loss[selected]
        evidence={key:make_threshold_evidence(ratio,key,threshold,state,2) for key,(_,threshold,state) in battery_TARGETS.items()}
        n=len(x);mid=evidence['L80']
        adapted=pd.DataFrame({'normalized_power':ratio,**{name:x[:,i] for i,name in enumerate(FEATURE_COLUMNS)}})
        u=UnitSequence(str(uid),float(cov[0]),np.arange(n,dtype=float),x,np.full(n,float(cov[1])),np.full(n,float(cov[2])),mid.event,mid.event_index,mid.event_low,mid.event_high,n-1,adapted,thresholds=evidence)
        units.append(u)
    return units,pd.DataFrame(inventory)


def battery_covariates(units):
    return np.array([[np.log(u.current),u.temperature[0],u.flow[0]] for u in units])


def battery_fit_protocol_aft(units,target,age_only=False,regularized=False,survival_crps=False):
    cov=battery_covariates(units);center=cov.mean(0);scale=np.maximum(cov.std(0),1e-4)
    # Keep log first-current in physical units, matching the HSMM coefficient.
    scale[0]=1.0
    z=(cov-center)/scale
    if age_only:z=np.zeros_like(z)
    observed=[];events=[]
    for u in units:
        e=u.thresholds[target];index=e.event_index if e.event else e.censor_index
        observed.append(max(float(u.age[int(index)]),.1));events.append(e.event)
    t=np.array(observed);event=np.array(events);lt=np.log(t)
    def objective(theta):
        logs=theta[0]+z@theta[1:4];shape=np.exp(theta[4]);v=np.clip(shape*(lt-logs),-700,500)
        nll=np.sum(np.exp(v)-event*(theta[4]+(shape-1)*lt-shape*logs))
        penalty=np.array([.35,2.,2.]) if regularized else np.zeros(3)
        return nll+np.sum(penalty*theta[1:4]**2)
    bounds=[(np.log(.1),np.log(10000))]+([(0,0)]*3 if age_only else [(-3,0),(-3,3),(-3,3)])+[(np.log(.2),np.log(30))]
    if survival_crps:
        starts=[[np.median(lt),0,0,0,np.log(shape)] for shape in [1,2,5,10]]
        theta,diagnostics=score_minimize_survival_crps(t,event,z,bounds,starts)
        return {'theta':theta,'center':center,'scale':scale,'age_only':age_only,'regularized':False,'training_units':len(units),**diagnostics}
    results=[minimize(objective,[np.median(lt),0,0,0,np.log(shape)],method='L-BFGS-B',bounds=bounds,options={'maxiter':400}) for shape in [1,2,5,10]]
    valid=[r for r in results if r.success and np.isfinite(r.fun)]
    if not valid:raise RuntimeError(f'Protocol AFT failed: {target}: {[str(r.message) for r in results]}')
    best=min(valid,key=lambda r:r.fun)
    return {'theta':best.x,'center':center,'scale':scale,'age_only':age_only,'regularized':regularized,'success':True,'objective':best.fun,'events':int(event.sum()),'training_units':len(units),'bounds':bounds}


def battery_per_unit_aft(fit,u):
    theta=np.asarray(fit['theta']);z=(battery_covariates([u])[0]-fit['center'])/fit['scale']
    if fit['age_only']:z[:]=0
    return {'intercept':float(theta[0]+z@theta[1:4]),'current_coefficient':0.,'current_reference':u.current,'current_transform':'log_current','shape':float(np.exp(theta[4]))}


def battery_run_fold(dataset,fold,test_ids,cfg,out):
    units,_=battery_load_units(dataset);train=[u for u in units if u.unit_id not in test_ids];test=[u for u in units if u.unit_id in test_ids]
    scoring_reference=train
    cutoff=cfg['revision'].get('training_cutoff_cycle')
    if cutoff is not None:
        train=[u.prefix(min(len(u.age)-1,int((cutoff-30)//battery_STEP))) for u in train]
    directory=Path(out)/'tasks'/f'{dataset}_fold{fold}'
    source_folder=ROOT/'data/cross_domain_candidates'/dataset
    data_hashes={name:hashlib.sha256((source_folder/name).read_bytes()).hexdigest() for name in ['cycle_summaries.csv','inventory.csv']}
    fingerprint=hashlib.sha256((json.dumps(cfg,sort_keys=True)+json.dumps(test_ids)+json.dumps(data_hashes,sort_keys=True)+''.join((ROOT/'scripts'/f).read_text(encoding='utf-8') for f in ['main_analysis.py'])).encode()).hexdigest()
    if (directory/'completed.json').exists() and json.loads((directory/'completed.json').read_text())['fingerprint']==fingerprint:return {'dataset':dataset,'fold':fold,'cached':True}
    directory.mkdir(parents=True,exist_ok=True);start=time.perf_counter()
    models,fits,timing=model_fit_matched_models([experiment_strip_truth(u) for u in train],cfg)
    aft={kind:{target:battery_fit_protocol_aft(train,target,kind=='aft_age',kind=='aft_protocol_regularized') for target in battery_TARGETS} for kind in ['aft_age','aft_protocol','aft_protocol_regularized']}
    aft['aft_survival_crps']={target:battery_fit_protocol_aft(train,target,survival_crps=True) for target in battery_TARGETS}
    support={t:np.mean([u.thresholds[t].event for u in train]) for t in battery_TARGETS}
    rows=[]
    for u in test:
        endpoint={kind:{t:battery_per_unit_aft(p,u) for t,p in targets.items()} for kind,targets in aft.items()}
        # Scoring describes the full-follow-up evaluation cohort. Artificially
        # truncating model training does not change the test censoring process.
        # This reference is used only inside score weights, never in forecasts.
        rows.extend(evaluate_unit(u,models,endpoint,None,support,cfg,dataset=dataset,split_id=f'{dataset}_fold{fold}',censoring=None,origins=[7,17,27,47,77],outages=[0],samples=800,censoring_reference=scoring_reference))
    frame=pd.DataFrame(rows);frame['scenario']=dataset;frame['signed_error']=frame.p50_h-frame.actual_rul_h;frame['squared_error']=frame.signed_error**2
    for tau in [50,100,150,200]:frame[f'events_within_{tau}']=frame.event_observed.eq(1)&frame.actual_rul_h.le(tau)
    frame.to_csv(directory/'predictions.csv',index=False)
    traces=[]
    for method,(p,paths,trace) in fits.items():
        experiment_dump(directory/'models'/f'{method}.json',p);traces.append(trace.assign(method=method))
    pd.concat(traces,ignore_index=True).to_csv(directory/'convergence.csv',index=False)
    experiment_dump(directory/'aft_parameters.json',aft);experiment_dump(directory/'fit_diagnostics.json',timing)
    experiment_dump(directory/'training_event_support.json',{t:{'observed_events':sum(u.thresholds[t].event for u in train),'training_cells':len(train)} for t in battery_TARGETS})
    result={'dataset':dataset,'fold':fold,'train_cells':len(train),'test_cells':len(test),'records':len(frame),'seconds':time.perf_counter()-start,'fingerprint':fingerprint,'data_hashes':data_hashes}
    experiment_dump(directory/'completed.json',result);return result


def battery_main():
    parser=argparse.ArgumentParser();parser.add_argument('--dataset',choices=['hust'],default='hust');parser.add_argument('--workers',type=int,default=3);parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--training-cutoff-cycle',type=int)
    parser.add_argument('--sigma-min',type=float,default=.3)
    parser.add_argument('--output-root',default='outputs/revision_round1_v2')
    args=parser.parse_args();cfg=load_config(ROOT/'data/settings/revision_round1.json')
    cfg['model'].update(static_extra_covariates=True,endpoint_anchor_weight=0.,multi_starts=3,max_duration=350)
    if not 0 < args.sigma_min < cfg['model']['duration_sigma_max']:raise ValueError('Invalid sigma lower bound')
    cfg['model']['duration_sigma_min']=args.sigma_min
    cfg['data'].update(persistence_points=2,current_reference_a=2.)
    cfg['evaluation'].update(ipcw_integration_tau_h=50,ipcw_integration_step_h=1,reliability_horizons_h=[10,25,50,75])
    cfg['revision']['methods']=['fixed_survival','svt_survival','fixed_complete','svt_complete','unconstrained_survival','shared_survival','soft_em','interval_likelihood']
    if args.training_cutoff_cycle is not None:
        if args.training_cutoff_cycle<100:raise ValueError('Training cutoff must be at least cycle 100')
        cfg['revision']['training_cutoff_cycle']=args.training_cutoff_cycle
    suffix='' if args.training_cutoff_cycle is None else f'_c{args.training_cutoff_cycle}'
    if args.sigma_min!=.3:suffix+=f'_sigma{args.sigma_min:g}'
    units,inventory=battery_load_units(args.dataset);out=ROOT/args.output_root/f'candidate_{args.dataset}{suffix}';out.mkdir(parents=True,exist_ok=True)
    inventory.to_csv(out/'cell_eligibility.csv',index=False)
    ids=np.array([u.unit_id for u in units]);splits=[(fold,ids[test].tolist()) for fold,(_,test) in enumerate(KFold(5,shuffle=True,random_state=20260903).split(ids),1)]
    plan={'dataset':args.dataset,'configuration':cfg,'cells':len(units),'folds':splits,'observations':'Every 10 cycles, starting at cycle 30; no interpolation; first 20 cycles used only for baseline reference','targets':battery_TARGETS,'persistence':'Two consecutive scheduled inspections at or below the threshold','absolute_prediction_cycles':[100,200,300,500,800],'time_unit_per_internal_step_cycles':battery_STEP,'cross_domain':'Refit on training cells in each battery fold; not zero-shot transfer','selection_status':'HUST is the sole selected exploratory domain extension; prior dataset screening remains in the internal archive','protocol_covariates':['log discharge I0','discharge I1','discharge I2'],'comparators':'Protocol AFT, regularized protocol AFT and age-only AFT are fitted on the same training cells; no endpoint leakage into online features'}
    experiment_dump(out/'plan.json',plan);print(json.dumps({'dataset':args.dataset,'eligible_cells':len(units)}),flush=True)
    if args.prepare_only:return
    failures=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        tasks={pool.submit(battery_run_fold,args.dataset,fold,test,cfg,str(out)):fold for fold,test in splits}
        for future in concurrent.futures.as_completed(tasks):
            try:print(json.dumps(future.result()),flush=True)
            except Exception as exc:
                import traceback
                failures.append({'fold':tasks[future],'error':str(exc),'traceback':traceback.format_exc()});print(json.dumps(failures[-1]),flush=True)
    experiment_dump(out/'run_status.json',{'tasks':5,'completed':5-len(failures),'failures':failures})
    if failures:raise SystemExit(1)
    experiment_summarize(out)
    metric=pd.read_csv(out/'metrics_macro.csv');metric[['crps','mae','rmse','bias']]*=battery_STEP;metric['time_unit']='cycles';metric.to_csv(out/'metrics_macro_cycles.csv',index=False)
    public=pd.read_csv(out/'predictions.csv');public['target']=public.target.map({k:v[0] for k,v in battery_TARGETS.items()});public['absolute_origin_cycle']=30+battery_STEP*public.origin_h
    for old,new in [('crps_h','crps_cycles'),('absolute_error_h','mae_cycles'),('actual_rul_h','actual_rul_cycles'),('p50_h','median_rul_cycles')]:public[new]=battery_STEP*public[old]
    public.to_csv(out/'predictions_with_cycle_labels.csv',index=False)
    print(metric[['method','crps','ibs','mae','coverage80']].to_string(index=False))


# Evidence
# ------------------------------------------------------------------------
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd


ROOT=Path(__file__).resolve().parents[1]
evidence_OUT=ROOT/'outputs/revision_round1_v2/evidence'
evidence_CONTRASTS=[
 ('segmentation_survival','fixed_survival','svt_survival'),
 ('segmentation_complete','fixed_complete','svt_complete'),
 ('filter_fixed_survival','fixed_survival_hard','fixed_survival'),
 ('filter_svt_survival','svt_survival_hard','svt_survival'),
 ('constraints_survival','unconstrained_survival','svt_survival'),
 ('constraints_complete','unconstrained_complete','svt_complete'),
 ('terminal_score','svt_survival','svt_complete'),
 ('soft_em_vs_viterbi','soft_em','svt_survival'),
 ('interval_vs_viterbi','interval_likelihood','svt_survival'),
 ('shared_acceleration','svt_survival','shared_survival'),
 ('aft_vs_viterbi','aft_bound3','svt_survival'),
 ('aft_objective','aft_bound3','aft_survival_crps')]


def evidence_cell_bootstrap(rows,draws=2000,contrasts=evidence_CONTRASTS,stratify_current=True):
    """Conditional, paired, current-stratified whole-unit bootstrap."""
    target_codes={t:i for i,t in enumerate(sorted(rows.target.unique()))}
    units=rows[['unit_id','current_a']].drop_duplicates().sort_values('unit_id')
    ids=list(units.unit_id);id_code={u:i for i,u in enumerate(ids)}
    rng=np.random.default_rng(202609033)
    weights=np.zeros((draws,len(ids)))
    strata=units.groupby('current_a') if stratify_current else [('all',units)]
    for _,g in strata:
        indexes=np.array([id_code[u] for u in g.unit_id])
        choices=rng.choice(indexes,size=(draws,len(indexes)),replace=True)
        for j in range(draws):np.add.at(weights[j],choices[j],1)
    output=[]
    for name,reference,candidate in contrasts:
        if not {reference,candidate}.issubset(rows.method.unique()):continue
        for metric in ['crps_h','ibs','absolute_error_h']:
            matrices=[]
            for method in [reference,candidate]:
                sums=np.zeros((len(ids),len(target_codes)));counts=np.zeros_like(sums)
                subset=rows[rows.method.eq(method)]
                for (uid,target),g in subset.groupby(['unit_id','target']):
                    x=g[metric].dropna();i,j=id_code[uid],target_codes[target]
                    sums[i,j]=x.sum();counts[i,j]=len(x)
                point=np.mean(np.divide(sums.sum(0),counts.sum(0),out=np.full(len(target_codes),np.nan),where=counts.sum(0)>0))
                denom=weights@counts
                boot=np.mean(np.divide(weights@sums,denom,out=np.full_like(denom,np.nan),where=denom>0),axis=1)
                matrices.append((point,boot))
            diff=matrices[0][1]-matrices[1][1];valid=diff[np.isfinite(diff)]
            output.append({'contrast':name,'reference':reference,'candidate':candidate,'metric':metric,'reference_score':matrices[0][0],'candidate_score':matrices[1][0],'gain':matrices[0][0]-matrices[1][0],'lo95':np.quantile(valid,.025),'hi95':np.quantile(valid,.975),'valid_bootstrap_draws':len(valid),'requested_draws':draws,'units':len(ids),'scope':'conditional on fitted fold models; paired whole units'+('; stratified by current' if stratify_current else '')})
    return pd.DataFrame(output)


def evidence_simulation_evidence():
    directory=ROOT/'outputs/revision_round1_v2/simulation'
    if not (directory/'run_status.json').exists():return
    status=json.loads((directory/'run_status.json').read_text())
    if status['failures']:raise RuntimeError('Do not summarize incomplete simulation as final evidence')
    frame=pd.read_csv(directory/'predictions.csv',usecols=['scenario','censoring','task_id','method','target','crps_h','ibs','absolute_error_h','squared_error','covered'])
    per=frame.groupby(['scenario','censoring','task_id','method','target'],dropna=False).agg(crps=('crps_h','mean'),ibs=('ibs','mean'),mae=('absolute_error_h','mean'),mse=('squared_error','mean'),coverage=('covered','mean')).reset_index()
    per['rmse']=np.sqrt(per.mse)
    macro=per.groupby(['scenario','censoring','task_id','method'],dropna=False)[['crps','ibs','mae','rmse','coverage']].mean().reset_index()
    macro.to_csv(evidence_OUT/'simulation_replicate_metrics.csv',index=False)
    summary=macro.groupby(['scenario','censoring','method'],dropna=False).agg(replicates=('task_id','nunique'),crps=('crps','mean'),ibs=('ibs','mean'),mae=('mae','mean'),rmse=('rmse','mean'),coverage=('coverage','mean')).reset_index()
    summary.to_csv(evidence_OUT/'simulation_metrics.csv',index=False)
    rng=np.random.default_rng(202609034);contrasts=[]
    for (scenario,censor),group in macro.groupby(['scenario','censoring'],dropna=False):
        for name,reference,candidate in evidence_CONTRASTS:
            for metric in ['crps','ibs','mae']:
                wide=group.pivot(index='task_id',columns='method',values=metric)
                if reference not in wide or candidate not in wide:continue
                delta=(wide[reference]-wide[candidate]).dropna().to_numpy()
                samples=delta[rng.integers(0,len(delta),size=(2000,len(delta)))].mean(1)
                contrasts.append({'scenario':scenario,'censoring':censor,'contrast':name,'reference':reference,'candidate':candidate,'metric':metric,'gain':delta.mean(),'lo95':np.quantile(samples,.025),'hi95':np.quantile(samples,.975),'replicates':len(delta)})
    pd.DataFrame(contrasts).to_csv(evidence_OUT/'simulation_paired_contrasts.csv',index=False)
    path=pd.read_csv(directory/'path_diagnostics.csv')
    meta=frame[['task_id','scenario','censoring']].drop_duplicates()
    path=path.merge(meta,on='task_id')
    path['absolute_error']=path.error.abs();path['squared_error']=path.error**2
    path.groupby(['scenario','censoring','method','target'],dropna=False).agg(known_latent_entries=('latent_entry_observed','sum'),decoded_entries=('decoded_entry_observed','sum'),paired_entries=('error','count'),onset_bias=('error','mean'),onset_mae=('absolute_error','mean'),onset_mse=('squared_error','mean'),state_accuracy=('state_accuracy','mean')).reset_index().to_csv(evidence_OUT/'simulation_path_recovery.csv',index=False)
    ev=path.drop_duplicates(['task_id','unit_id','target'])
    ev.groupby(['scenario','censoring','target'],dropna=False).agg(records=('unit_id','size'),confirmed_crossings=('evidence_observed','sum'),interval_coverage=('true_in_interval','mean')).reset_index().to_csv(evidence_OUT/'simulation_evidence_fidelity.csv',index=False)
    params=pd.read_csv(directory/'parameter_diagnostics.csv').merge(meta,on='task_id')
    params['squared_error']=params.error**2
    params.groupby(['scenario','censoring','method','state','parameter'],dropna=False).agg(estimate=('estimate','mean'),bias=('error','mean'),mse=('squared_error','mean'),replicates=('task_id','nunique')).reset_index().to_csv(evidence_OUT/'simulation_parameter_recovery.csv',index=False)


def evidence_candidate_evidence():
    tables=[]
    contrasts=[(r,r,'svt_survival') for r in ['aft_age','aft_protocol','aft_protocol_regularized','aft_survival_crps','fixed_survival','svt_complete','soft_em','interval_likelihood','unconstrained_survival']]
    for folder in sorted((ROOT/'outputs/revision_round1_v2').glob('candidate_hust*')):
        if not (folder/'predictions.csv').exists():continue
        rows=pd.read_csv(folder/'predictions.csv')
        table=evidence_cell_bootstrap(rows,contrasts=contrasts,stratify_current=False)
        table['dataset']=folder.name.removeprefix('candidate_')
        mask=table.metric.ne('ibs')
        table.loc[mask,['reference_score','candidate_score','gain','lo95','hi95']]*=10
        table['time_unit']='cycles';tables.append(table)
        unit=rows.groupby(['unit_id','method','target']).agg(crps=('crps_h','mean'),mae=('absolute_error_h','mean'),ibs=('ibs','mean')).reset_index()
        unit[['crps','mae']]*=10;unit.target=unit.target.map({'L90':'Q95','L80':'Q90','T50':'Q85'})
        unit.to_csv(evidence_OUT/f'{folder.name}_by_cell_target.csv',index=False)
    if tables:pd.concat(tables,ignore_index=True).to_csv(evidence_OUT/'candidate_paired_contrasts.csv',index=False)


def evidence_inspection_recovery_evidence():
    folder=ROOT/'outputs/revision_round1_v2/inspection_recovery'
    if not (folder/'summary_status.json').exists():return
    params=pd.read_csv(folder/'parameter_diagnostics.csv');params['squared_error']=params.error**2
    params.groupby(['method','state','parameter']).agg(estimate=('estimate','mean'),bias=('error','mean'),mse=('squared_error','mean'),replicates=('task_id','nunique')).reset_index().to_csv(evidence_OUT/'inspection_parameter_recovery.csv',index=False)
    paths=pd.read_csv(folder/'path_diagnostics.csv');paths['absolute_error']=paths.error.abs()
    paths.groupby(['method','target']).agg(onset_mae=('absolute_error','mean'),state_accuracy=('state_accuracy','mean'),observed_entries=('latent_entry_observed','sum'),paired_entries=('error','count'),interval_coverage=('true_in_interval','mean')).reset_index().to_csv(evidence_OUT/'inspection_path_recovery.csv',index=False)


def require_completed_outputs():
    """Do not calculate final contrasts until the required aggregates exist."""
    folders=['laser','simulation','inspection_recovery','sensitivity',
        'feature_sensitivity','candidate_hust','candidate_hust_c1000',
        'candidate_hust_c1500','candidate_hust_sigma0.05',
        'candidate_hust_c1000_sigma0.05']
    for dataset in folders:
        marker=ROOT/'outputs/revision_round1_v2'/dataset/(
            'metrics_macro_cycles.csv' if dataset.startswith('candidate_hust')
            else 'summary_status.json')
        if not marker.exists():raise RuntimeError(f'{dataset}: aggregate writing has not completed')
        if marker.suffix=='.json' and not json.loads(marker.read_text(encoding='utf8'))['summary_complete']:
            raise RuntimeError(f'{dataset}: aggregate summary is incomplete')

def evidence_main():
    require_completed_outputs()
    evidence_OUT.mkdir(parents=True,exist_ok=True)
    tables=[]
    for dataset in ['laser']:
        path=ROOT/f'outputs/revision_round1_v2/{dataset}/predictions.csv'
        if not path.exists():continue
        rows=pd.read_csv(path)
        for design,g in rows.groupby('design'):
            table=evidence_cell_bootstrap(g);table['dataset']=dataset;table['design']=design;tables.append(table)
        if dataset=='laser':
            origin=rows.groupby(['design','origin_h','target','method']).agg(records=('unit_id','size'),events=('event_observed','sum'),crps=('crps_h','mean'),ibs=('ibs','mean'),mae=('absolute_error_h','mean')).reset_index()
            origin.to_csv(evidence_OUT/'laser_by_origin_target.csv',index=False)
            # One decision at each eligible origin, not a longitudinal policy.
            policy=rows.copy();p=1-policy.survival_probability_100h
            event=policy.event_observed.eq(1)&policy.actual_rul_h.le(100)
            policy['act']=p>=.1
            policy['cost']=policy['act'].astype(float)+10*(~policy['act']&event)
            policy['missed_event']=(~policy['act']&event).astype(int)
            policy.groupby(['design','method','target']).agg(mean_cost=('cost','mean'),intervention_rate=('act','mean'),missed_events=('missed_event','sum'),records=('unit_id','size')).reset_index().to_csv(evidence_OUT/'laser_stylized_single_decision_cost.csv',index=False)
    if tables:pd.concat(tables,ignore_index=True).to_csv(evidence_OUT/'paired_application_contrasts.csv',index=False)
    evidence_simulation_evidence()
    evidence_candidate_evidence()
    evidence_inspection_recovery_evidence()
    note='''# Revision evidence definitions

All paired gains are reference minus candidate, so positive favors the candidate.
Application confidence intervals resample whole held-out units within their current
strata, using the same draw for both methods. They condition on the fitted fold
models and are not confidence intervals for transfer to arbitrary new stress levels.
Simulation contrasts pair methods within an independently generated replicate and
do not pool the three dropout levels into a single replicate count.

Battery targets are Q95, Q90 and Q85 of the reference capacity, and times are cycles.
L90/L80/T50 and column suffixes `_h` in shared machine-readable prediction files
are internal compatibility identifiers, not the battery's physical labels or units.
The paper-facing battery diagnostic tables use the correct Q labels.

HUST is the sole battery extension in these active summaries. Earlier dataset
screening and its descriptive results are archived under outputs/revision_round1.

The inspection example is a stylized one-decision calculation at 100 h on the
laser records, with intervention cost 1 and a missed event cost 10. All laser
records have sufficient follow-up at this horizon. It is not a validated maintenance
policy, and overlapping origins are not independent decisions or devices.
'''
    (evidence_OUT/'README.md').write_text(note,encoding='utf-8')
    print("Updated laser, simulation and HUST-only evidence")


# Diagnostic
# ------------------------------------------------------------------------
import argparse
import json
import platform
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd


ROOT=Path(__file__).resolve().parents[1]
diagnostic_OUT=ROOT/'outputs/revision_round1_v2/evidence'


def diagnostic_collect():
    rows=[]
    for dataset in ['laser','simulation','inspection_recovery','candidate_hust','candidate_hust_c1000','candidate_hust_c1500','candidate_hust_sigma0.05','candidate_hust_c1000_sigma0.05']:
        folder=ROOT/'outputs/revision_round1_v2'/dataset
        for file in folder.glob('tasks/*/models/*.json'):
            p=json.loads(file.read_text())
            rows.append({'dataset':dataset,'fold':file.parent.parent.name,'method':file.stem,'converged':p.get('converged'),'reason':p.get('convergence_reason'),'duration_optimizer_success':p.get('duration_optimizer_success'),'alpha_at_upper':int(np.isclose(np.asarray(p['alpha'])[:3],p.get('duration_alpha_max',3.)).sum()),'sigma_at_lower':int(np.isclose(np.asarray(p['dur_sigma'])[:3],p.get('duration_sigma_min',.3)).sum()),'objective':p.get('objective'),'gamma_norm':float(np.linalg.norm(p.get('gamma',[0,0])))})
    data=pd.DataFrame(rows);data.to_csv(diagnostic_OUT/'optimizer_diagnostics.csv',index=False)
    data.groupby(['dataset','method'],dropna=False).agg(fits=('fold','size'),converged=('converged','sum'),failed_duration_optimizer=('duration_optimizer_success',lambda x:(x==False).sum()),alpha_upper_hits=('alpha_at_upper','sum'),sigma_lower_hits=('sigma_at_lower','sum')).reset_index().to_csv(diagnostic_OUT/'optimizer_summary.csv',index=False)
    data.groupby(['dataset','method','reason'],dropna=False).size().reset_index(name='fits').to_csv(diagnostic_OUT/'convergence_reasons.csv',index=False)


def diagnostic_benchmark():
    cfg=load_config(ROOT/'data/settings/revision_round1.json');_,_,units=build_dataset(ROOT,cfg)
    train=units[1:];test=units[0].prefix(min(200,len(units[0].age)-1))
    methods=['fixed_survival','svt_survival','svt_complete','unconstrained_survival','shared_survival','geometric_survival','soft_em','interval_likelihood']
    # Compile/load and exercise inference and sampling once before clocking.
    warm,_,_=model_fit_matched_models(train,cfg,methods=['svt_survival'])
    sample_rul(test,warm['svt_survival'][0],np.random.default_rng(17),800,False,3)
    rows=[]
    for repeat in range(3):
        for method in methods:
            start=time.perf_counter();models,_,_=model_fit_matched_models(train,cfg,methods=[method]);fit_time=time.perf_counter()-start
            start=time.perf_counter()
            for i in range(20):sample_rul(test,models[method][0],np.random.default_rng(100+i),800,False,3)
            rows.append({'repeat':repeat,'method':method,'fit_seconds':fit_time,'prediction_seconds_per_800_draws':(time.perf_counter()-start)/20,'training_units':len(train),'prefix_points':len(test.age)})
        for bound in [3.,12.]:
            start=time.perf_counter();fits={t:fit_weibull_target(train,t,3.,coefficient_bound=bound) for t in ['L90','L80','T50']};elapsed=time.perf_counter()-start
            start=time.perf_counter()
            for i in range(20):sample_weibull(fits['T50'],test.current,float(test.age[-1]),np.random.default_rng(100+i),800)
            rows.append({'repeat':repeat,'method':f'aft_bound{bound:g}','fit_seconds':elapsed,'prediction_seconds_per_800_draws':(time.perf_counter()-start)/20,'training_units':len(train),'prefix_points':len(test.age)})
    pd.DataFrame(rows).to_csv(diagnostic_OUT/'warmed_runtime_repeats.csv',index=False)
    pd.DataFrame(rows).groupby('method').agg(fit_median_seconds=('fit_seconds','median'),prediction_median_seconds=('prediction_seconds_per_800_draws','median')).reset_index().to_csv(diagnostic_OUT/'warmed_runtime.csv',index=False)
    (diagnostic_OUT/'runtime_environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),'numpy':np.__version__,'protocol':'One sequential process, one excluded warm-up, 18 training units, three repeats. AFT training time covers all three targets; prediction time is for one target and 800 draws. Timing is descriptive, not a microbenchmark guarantee.'},indent=2))


# Feature
# ------------------------------------------------------------------------
from pathlib import Path
import numpy as np
import pandas as pd


ROOT=Path(__file__).resolve().parents[1]
feature_OUT=ROOT/'outputs/revision_round1_v2/evidence'

def feature_main():
    cfg=load_config(ROOT/'data/settings/revision_round1.json')
    _,_,units=build_dataset(ROOT,cfg)
    rows=[]
    for _,name,train,test in real_validation_splits(units):
        params=load_model(ROOT/'outputs/revision_round1_v2/laser/tasks'/name/'models/svt_survival.json')
        residuals=[]
        for u in train:
            path=segmental_viterbi(u,params,True)[0]
            x=standardized_x(u,params)
            residuals.append(x-np.asarray(params['emission_mu'])[path])
        frame=pd.DataFrame(np.vstack(residuals),columns=FEATURE_COLUMNS)
        correlation=frame.corr(min_periods=10)
        for j,a in enumerate(frame.columns):
            for b in frame.columns[j+1:]:
                rows.append({'fold':name,'feature_a':a,'feature_b':b,'correlation':correlation.loc[a,b],
                             'paired_observations':int(frame[[a,b]].dropna().shape[0])})
    table=pd.DataFrame(rows);table.to_csv(feature_OUT/'laser_training_residual_feature_correlations.csv',index=False)
    table.groupby(['feature_a','feature_b']).agg(fold_median=('correlation','median'),fold_min=('correlation','min'),fold_max=('correlation','max')).reset_index().to_csv(feature_OUT/'laser_residual_correlation_summary.csv',index=False)
    (feature_OUT/'feature_correlation_notes.md').write_text('Descriptive correlations of training observations after subtracting fitted state-specific emission locations. Missing pairs are omitted pairwise. No held-out observations or latent truth enter this diagnostic. Fold ranges are not confidence intervals: training folds overlap and time points are serially dependent. Large correlations qualify the diagonal emission working assumption; the no-power-derived-feature sensitivity provides a separate prediction comparison.\n',encoding='utf-8')
    print('Training-fold feature correlation diagnostic complete')


# Feature sensitivity
# ------------------------------------------------------------------------
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed


ROOT=Path(__file__).resolve().parents[1]

def feature_sensitivity_main():
    cfg=load_config(ROOT/'data/settings/revision_round1.json')
    _,_,units=build_dataset(ROOT,cfg)
    out=ROOT/'outputs/revision_round1_v2/feature_sensitivity'
    tasks=[{'id':'two_channels-'+name,'scenario':'sensitivity_two_channels','test_ids':[u.unit_id for u in test],
            'drop_features':[1,2,4,5,6],'methods':['fixed_survival','fixed_complete','svt_survival','svt_complete'],'aft':False}
           for _,name,train,test in real_validation_splits(units) if name.startswith('LOCO')]
    experiment_dump(out/'plan.json',{'configuration':cfg,'tasks':tasks,'retained_features':['degradation_depth','wavelength_shift_nm'],
                         'selection_rule':'One direct feature per physical signal source, chosen from the feature definitions; no test-score selection'})
    with ProcessPoolExecutor(max_workers=3) as pool:
        jobs=[pool.submit(experiment_run_task,t,cfg,str(out)) for t in tasks]
        for job in as_completed(jobs):print(job.result()['id'],flush=True)
    experiment_dump(out/'run_status.json',{'tasks':len(tasks),'completed':len(tasks),'failures':[]})
    experiment_summarize(out);experiment_dump(out/'summary_status.json',{'summary_complete':True,'failed_tasks':0})


# Comparison
# ------------------------------------------------------------------------
from pathlib import Path
import argparse,copy,concurrent.futures,json,traceback,hashlib


ROOT=Path(__file__).resolve().parents[1]

def comparison_main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['pilot','external','sparse'],required=True);p.add_argument('--workers',type=int,default=6);p.add_argument('--replicates',type=int,default=100)
    args=p.parse_args();cfg=load_config(ROOT/'data/settings/revision_round1.json')
    out=ROOT/'outputs/revision_completion'/args.mode
    tasks=[]
    if args.mode in ['external','pilot']:
        methods=['himap_adapted','farcomeni_l2_adapted'];cfg['revision']['methods']=methods
        if args.mode=='pilot':
            cfg['simulation'].update(train_units=12,test_units=8)
            cfg['model'].update(external_max_iterations=8,prediction_samples=400)
            tasks=[{'id':'external-pilot','scenario':'simulation_dropout','censoring':.5,'methods':methods,'aft':False}]
        else:
            for task in json.loads((ROOT/'outputs/revision_round1_v2/laser/plan.json').read_text())['tasks']:
                tasks.append({**task,'methods':methods,'aft':False})
            for task in json.loads((ROOT/'outputs/revision_round1_v2/simulation/plan.json').read_text())['tasks']:
                if task['scenario']=='simulation_dropout':tasks.append({**task,'methods':methods,'aft':False})
    else:
        cfg['revision']['methods']=['fixed_survival','svt_survival','svt_complete','shared_survival','soft_em']
        tasks=[{'id':f'simulation_sparse_end-r{r:03}','scenario':'simulation_sparse_end','censoring':0.} for r in range(args.replicates)]
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'scripts').glob('*.py')}
    cfg['revision']['completion_source_hashes']=hashes
    experiment_dump(out/'plan.json',{'mode':args.mode,'configuration':cfg,'tasks':tasks})
    failed=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        fs={pool.submit(experiment_run_task,t,cfg,str(out)):t['id'] for t in tasks}
        for f in concurrent.futures.as_completed(fs):
            try:
                r=f.result();print(json.dumps({k:r.get(k) for k in ['id','status','seconds']}),flush=True)
            except Exception as e:
                failed.append({'id':fs[f],'error':str(e),'traceback':traceback.format_exc()});print(json.dumps(failed[-1]),flush=True)
    experiment_dump(out/'run_status.json',{'tasks':len(tasks),'failures':failed,'completed':len(tasks)-len(failed)})
    experiment_summarize(out);experiment_dump(out/'summary_status.json',{'summary_complete':True,'failed_tasks':len(failed)})
    if failed:raise SystemExit(1)


# Calibration
# ------------------------------------------------------------------------
from pathlib import Path
import concurrent.futures,json,copy
import numpy as np
import pandas as pd


ROOT=Path(__file__).resolve().parents[1]
calibration_OUT=ROOT/'outputs/revision_completion/calibration'

def calibration_hersbach(observations,ensemble):
    y=np.asarray(observations,float);x=np.sort(np.asarray(ensemble,float),axis=1)
    if x.ndim!=2 or len(x)!=len(y):raise ValueError('Aligned observations and ensembles required')
    n,m=x.shape
    gaps=np.diff(x,axis=1)
    alpha=np.clip(y[:,None]-x[:,:-1],0,gaps).mean(0)
    beta=gaps.mean(0)-alpha
    g=np.r_[0.,alpha+beta,0.];o=np.r_[0.,np.divide(beta,g[1:-1],out=np.zeros(m-1),where=g[1:-1]>0),0.]
    # Tail corrections follow Hersbach's Heaviside frequencies. Unlike naive
    # rank-bin tails, these retain a nonzero potential-score contribution.
    o[0]=np.mean(y<=x[:,0]);o[-1]=np.mean(y<=x[:,-1])
    g[0]=np.maximum(x[:,0]-y,0).mean()/o[0] if o[0]>0 else 0.
    g[-1]=np.maximum(y-x[:,-1],0).mean()/(1-o[-1]) if o[-1]<1 else 0.
    p=np.arange(m+1)/m
    reliability=float(np.sum(g*(p-o)**2));potential=float(np.sum(g*o*(1-o)))
    uncertainty=float(np.mean(np.abs(y[:,None]-y[None,:]))/2)
    actual=float(np.mean([empirical_crps(a,b) for a,b in zip(x,y)]))
    if not np.isclose(reliability+potential,actual,rtol=1e-9,atol=1e-8):raise AssertionError('CRPS decomposition identity failed')
    return {'records':n,'crps':actual,'reliability':reliability,'resolution':uncertainty-potential,'uncertainty':uncertainty,'potential_crps':potential}

def calibration_rescore(task):
    global empirical_crps
    cfg=load_config(ROOT/'data/settings/revision_round1.json')
    _,_,units=build_dataset(ROOT,cfg)
    train=[u for u in units if u.unit_id not in task['test_ids']];test=[u for u in units if u.unit_id in task['test_ids']]
    folder=ROOT/'outputs/revision_round1_v2/laser/tasks'/task['id']
    ext=ROOT/'outputs/revision_completion/external/tasks'/task['id']
    keys=['fixed_survival','fixed_complete','svt_survival','svt_complete','shared_survival','shared_complete','soft_em','interval_likelihood']
    models={k:(load_model(folder/'models'/f'{k}.json'),False) for k in keys}
    models.update({k:(load_model(ext/'models'/f'{k}.json'),False) for k in ['himap_adapted','farcomeni_l2_adapted']})
    aft={}
    for p in json.loads((folder/'aft_diagnostics.json').read_text()):aft.setdefault(p['method'],{})[p['target']]=p
    support={t:np.mean([u.thresholds[t].event for u in train]) for t in ['L90','L80','T50']}
    saved=[];samples=[];allrows=[]
    original=empirical_crps
    def capture(prediction,actual):
        saved.append((np.asarray(prediction).copy(),actual));return original(prediction,actual)
    empirical_crps=capture
    for u in test:
        for origin,tau in [(100,350),(200,250),(300,150)]:
            local=copy.deepcopy(cfg);local['evaluation'].update(ipcw_integration_tau_h=tau,reliability_horizons_h=list(range(0,tau+1,5)))
            before=len(saved)
            rows=evaluate_unit(u,models,aft,None,support,local,dataset='real',split_id=task['id'],censoring=None,origins=[origin],outages=[0],samples=cfg['model']['prediction_samples'],censoring_reference=train)
            events=[r for r in rows if r['event_observed']]
            if len(events)!=len(saved)-before:raise AssertionError('Sample observer did not align with event records')
            for r,(forecast,truth) in zip(events,saved[before:]):
                assert truth==r['actual_rul_h']
                samples.append((r,forecast))
            allrows.extend(rows)
    empirical_crps=original
    df=pd.DataFrame(allrows);df['design']='LOCO' if task['id'].startswith('LOCO') else 'LOOU'
    path=calibration_OUT/'tasks'/task['id'];path.mkdir(parents=True,exist_ok=True)
    df.to_csv(path/'predictions.csv',index=False)
    meta=pd.DataFrame([r for r,_ in samples]) if samples else df.iloc[:0].copy()
    meta['design']=df.design.iloc[0];meta.to_csv(path/'sample_metadata.csv',index=False)
    np.savez_compressed(path/'forecast_samples.npz',forecasts=np.stack([s for _,s in samples]) if samples else np.empty((0,cfg['model']['prediction_samples'])))
    return task['id']

def calibration_main():
    calibration_OUT.mkdir(parents=True,exist_ok=True)
    tasks=json.loads((ROOT/'outputs/revision_round1_v2/laser/plan.json').read_text())['tasks']
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        for name in pool.map(calibration_rescore,tasks):print(name,flush=True)
    frames=[];metas=[];samples=[]
    for t in tasks:
        p=calibration_OUT/'tasks'/t['id'];frames.append(pd.read_csv(p/'predictions.csv'));metas.append(pd.read_csv(p/'sample_metadata.csv'));samples.append(np.load(p/'forecast_samples.npz')['forecasts'])
    df=pd.concat(frames,ignore_index=True);meta=pd.concat(metas,ignore_index=True);x=np.vstack(samples)
    df.to_csv(calibration_OUT/'predictions.csv',index=False)
    decompositions=[]
    for key,g in meta.groupby(['design','method','target']):
        result=calibration_hersbach(g.actual_rul_h,x[g.index]);decompositions.append(dict(zip(['design','method','target'],key))|result)
    decomp=pd.DataFrame(decompositions);decomp.to_csv(calibration_OUT/'crps_decomposition_by_target.csv',index=False)
    decomp.groupby(['design','method'])[['crps','reliability','resolution','uncertainty','potential_crps']].mean().reset_index().to_csv(calibration_OUT/'crps_decomposition_macro.csv',index=False)
    long=[]
    for key,g in df.groupby(['design','origin_h','target','method']):
        max_tau=int(g.ipcw_integration_tau_h.iloc[0])
        for tau in [150,200,250,300,350]:
            if tau>max_tau:continue
            grid=np.arange(0,tau+1,5)
            cols=[horizon_column('ipcw_brier_contribution',t) for t in grid]
            val=np.trapezoid(g[cols].to_numpy(),grid,axis=1)/tau
            long.append(dict(zip(['design','origin_h','target','method'],key))|{'tau':tau,'records':len(g),'events_within':int(((g.event_observed==1)&(g.followup_h<=tau)).sum()),'at_risk_at_tau':int((g.followup_h>tau).sum()),'ibs':float(val.mean()),'min_G':float(g[[horizon_column('censoring_survival',t) for t in grid]].min().min())})
    long=pd.DataFrame(long);long.to_csv(calibration_OUT/'long_horizon_ibs_by_target.csv',index=False)
    long.groupby(['design','origin_h','method','tau'])[['ibs','events_within','records','at_risk_at_tau','min_G']].agg({'ibs':'mean','events_within':'sum','records':'sum','at_risk_at_tau':'sum','min_G':'min'}).reset_index().to_csv(calibration_OUT/'long_horizon_ibs_macro.csv',index=False)
    (calibration_OUT/'completed.json').write_text(json.dumps({'folds':len(tasks),'records':len(df),'decomposition_identity_passed':True,'event_only_decomposition':True},indent=2))


# Baseline
# ------------------------------------------------------------------------
from pathlib import Path
import concurrent.futures,copy,json,time
import numpy as np
import pandas as pd


ROOT=Path(__file__).resolve().parents[1]
baseline_OUT=ROOT/'outputs/revision_initial_based/comparators'
def baseline_task_run(task):
    cfg=load_config(ROOT/'data/settings/revision_round1.json');tid=task['id'];scenario=task['scenario']
    out=baseline_OUT/'tasks'/tid;out.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()
    if scenario.startswith('simulation'):
        sim=cfg['simulation'];train=[];test=[]
        for role,number,destination in [('train',50,train),('test',50,test)]:
            for i in range(number):
                u=simulate_unit(keyed_rng(cfg['project']['seed'],tid,role,i),f'{tid}-{role}-{i:03}',sim['sequence_length'],[3.,3.5,4.,4.5][i%4],sim['overlap'],sim['nonhomogeneity'],task['censoring'] if role=='train' else 0.,sim['pace_heterogeneity'],tuple(sim['censor_time_fraction_range']),cfg['data']['persistence_points'],(1.,1.,1.))
                destination.append(u)
        dataset='simulation';origins=sim['prediction_origins_h'];folder=ROOT/'outputs/revision_round1_v2/simulation/tasks'/tid
    else:
        _,_,units=build_dataset(ROOT,cfg);train=[u for u in units if u.unit_id not in task['test_ids']];test=[u for u in units if u.unit_id in task['test_ids']]
        dataset='real';origins=cfg['evaluation']['prediction_origins_h'];folder=ROOT/'outputs/revision_round1_v2/laser/tasks'/tid
    support={t:float(np.mean([u.thresholds[t].event for u in train])) for t in ['L90','L80','T50']}
    fixed=load_model(folder/'models/fixed_survival.json');models={}
    for key in ['svt_survival','svt_complete']:
        fitted=load_model(folder/'models'/f'{key}.json')
        anchored=stable_anchored_svt_nhhsmm(fitted,fixed,support,cfg)
        models[key+'_substitution']=(anchored,False)
        experiment_dump(out/'models'/f'{key}_substitution.json',anchored)
    homogeneous,paths,trace=train_model([experiment_strip_truth(u) for u in train],cfg,environment=False,constrained=True,duration_type='lognormal',homogeneous=True,terminal_duration_treatment='survival')
    models['homogeneous_survival']=(homogeneous,False);experiment_dump(out/'models/homogeneous_survival.json',homogeneous)
    trace.to_csv(out/'convergence.csv',index=False)
    wiener=fit_wiener_reference([experiment_strip_truth(u) for u in train],cfg['data']['current_reference_a']);experiment_dump(out/'wiener.json',wiener)
    rows=[]
    for u in test:rows.extend(evaluate_unit(u,models,{},wiener,support,cfg,dataset=dataset,split_id=tid,censoring=task.get('censoring'),origins=origins,outages=[0],samples=cfg['model']['prediction_samples'],censoring_reference=None if dataset=='simulation' else train))
    df=pd.DataFrame(rows);df['scenario']=scenario;df['signed_error']=df.p50_h-df.actual_rul_h;df['squared_error']=df.signed_error**2
    for tau in [50,100,150,200]:df[f'events_within_{tau}']=df.event_observed.eq(1)&df.actual_rul_h.le(tau)
    df.to_csv(out/'predictions.csv',index=False)
    return {'task':tid,'seconds':round(time.perf_counter()-started,2),'rows':len(df)}
def baseline_main():
    tasks=json.loads((ROOT/'outputs/revision_round1_v2/laser/plan.json').read_text())['tasks']
    tasks += [t for t in json.loads((ROOT/'outputs/revision_round1_v2/simulation/plan.json').read_text())['tasks'] if t['scenario']=='simulation_dropout']
    experiment_dump(baseline_OUT/'plan.json',{'tasks':tasks})
    with concurrent.futures.ProcessPoolExecutor(max_workers=6) as pool:
        futures=[pool.submit(baseline_task_run,t) for t in tasks]
        for future in concurrent.futures.as_completed(futures):print(json.dumps(future.result()),flush=True)
    experiment_summarize(baseline_OUT);experiment_dump(baseline_OUT/'completed.json',{'completed_tasks':len(tasks)})


# Numerical coordinates for every manuscript plot
# ------------------------------------------------------------------------
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
plotdata_V=ROOT/'outputs/revision_round1_v2'
plotdata_Q=ROOT/'outputs/revision_initial_based'
plotdata_NAMES={'fixed_survival':'Fixed-S','fixed_complete':'Fixed-C','svt_survival':'SVT-S','svt_complete':'SVT-C','shared_survival':'Shared-S','soft_em':'Soft EM','interval_likelihood':'Interval ML','geometric_survival':'Geometric-S','unconstrained_survival':'Unconstrained-S','aft_bound3':'AFT (bound 3)','aft_survival_crps':'Score-trained AFT','homogeneous_survival':'Homogeneous-S','svt_survival_substitution':'SVT-S + substitution','svt_complete_substitution':'SVT-C + substitution','Wiener first-passage':'Wiener'}
plotdata_COLORS=['#0072B2','#D55E00','#009E73','#CC79A7','#E69F00','#56B4E9','#555555','#882255']
plotdata_PLOTS=[]

def plotdata_ci(v):
    v=np.asarray(v);rng=np.random.default_rng(603)
    return np.quantile(v[rng.integers(0,len(v),(2000,len(v)))].mean(1),[.025,.975])

def plotdata_series(x,y,label='',color=None,**kwargs):
    return dict(x=list(x),y=list(y),label=label,color=color,**kwargs)

def plotdata_add(name,xlabel='',ylabel='',items=None,**kwargs):
    item=dict(name=name,xlabel=xlabel,ylabel=ylabel,series=items or [],**kwargs)
    plotdata_PLOTS.append(item)
    return item

def plotdata_lines(data,x,y,methods,name,xlabel,ylabel,group='method',rep=False,nominal=False):
    items=[];ticks=None
    for k,method in enumerate(methods):
        g=data[data[group]==method].groupby(x)[y];a=g.mean()
        xx=np.arange(len(a)) if a.index.dtype==object else a.index
        if a.index.dtype==object:ticks=[list(xx),list(a.index)]
        item=plotdata_series(xx,a.values,plotdata_NAMES.get(method,method),plotdata_COLORS[k%8],kind='line',marker='o')
        if rep:
            bounds=np.array([plotdata_ci(z.values) for _,z in g])
            item.update(lower=bounds[:,0].tolist(),upper=bounds[:,1].tolist())
        items.append(item)
    plotdata_add(name,xlabel,ylabel,items,xticks=ticks,hline=.8 if nominal else None)

def plotdata_case_illustrations(out):
    """Calculate the prespecified retrospective examples, separately from plotting."""
    pass
    cfg=load_config(ROOT/'data/settings/revision_round1.json')
    raw,endpoints,units=build_dataset(ROOT,cfg)
    plan=json.loads((plotdata_V/'laser/plan.json').read_text(encoding='utf8'))
    eligible={u.unit_id for u in units if all(e.event for e in u.thresholds.values())}
    task=next(t for t in plan['tasks'] if t['id'].startswith('LOOU') and t['test_ids'][0] in eligible)
    laser=next(u for u in units if u.unit_id==task['test_ids'][0])
    ident='simulation_dropout-c0.5-r000';sim=cfg['simulation']
    synthetic=simulate_unit(keyed_rng(cfg['project']['seed'],ident,'test',0),f'{ident}-test-000',sim['sequence_length'],3.,sim['overlap'],sim['nonhomogeneity'],0.,sim['pace_heterogeneity'],tuple(sim['censor_time_fraction_range']),cfg['data']['persistence_points'])
    examples=[('Laser: first complete-endpoint unit',laser,plotdata_V/'laser/tasks'/task['id']),('Simulation: replicate 1, test unit 1',synthetic,plotdata_V/'simulation/tasks'/ident)]
    records=[];intervals={}
    for title,u,folder in examples:
        intervals[title]=[[float(u.age[e.event_low]),float(u.age[e.event_high])] for e in u.thresholds.values() if e.event]
        power=u.frame.normalized_power.to_numpy()
        for method in ['fixed_survival','unconstrained_survival','svt_survival']:
            model=load_model(folder/'models'/f'{method}.json')
            path=threshold_path(u,4,2,nested_threshold_initialization=True) if method=='fixed_survival' else segmental_viterbi(u,model,method!='unconstrained_survival')[0]
            records.extend({'example':title,'unit_id':u.unit_id,'age':age,'normalized_power':value,'method':method,'decoded_state':int(state),'true_state':int(u.true_path[i]) if u.true_path is not None else None} for i,(age,value,state) in enumerate(zip(u.age,power,path)))
    paths=pd.DataFrame(records)
    paths.to_csv(out/'representative_paths.csv',index=False)
    (out/'representative_intervals.json').write_text(json.dumps(intervals,indent=2),encoding='utf8')
    raw.to_csv(out/'real_trajectories.csv',index=False)
    endpoints.to_csv(out/'real_endpoint_records.csv',index=False)
    return paths,intervals,raw,endpoints

def plotdata_main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',default='outputs/plot_data/current')
    args=parser.parse_args()
    out=ROOT/args.output_dir;out.mkdir(parents=True,exist_ok=True)
    paths,intervals,raw,endpoints=plotdata_case_illustrations(out)
    pred=pd.read_csv(plotdata_V/'laser/predictions.csv')
    extra=pd.read_csv(plotdata_Q/'comparators/predictions.csv')
    pred=pd.concat([pred,extra.query("scenario=='laser'")],ignore_index=True)
    laser=pd.concat([pd.read_csv(plotdata_V/'laser/metrics_macro.csv'),pd.read_csv(plotdata_Q/'comparators/metrics_macro.csv').query("scenario=='laser'")])
    sim=pd.read_csv(plotdata_V/'evidence/simulation_replicate_metrics.csv').query("scenario=='simulation_dropout'")
    extra_sim=extra.query("scenario=='simulation_dropout'").groupby(['censoring','method','task_id','target']).agg(crps=('crps_h','mean'),ibs=('ibs','mean'),coverage=('covered','mean')).reset_index().groupby(['censoring','method','task_id'])[['crps','ibs','coverage']].mean().reset_index()
    sim=pd.concat([sim,extra_sim],ignore_index=True)
    sim.to_csv(plotdata_Q/'simulation_replicate_metrics.csv',index=False)
    sim.groupby(['censoring','method'])[['crps','ibs','coverage']].mean().reset_index().to_csv(plotdata_Q/'simulation_metrics.csv',index=False)
    methods=['fixed_survival','svt_survival','svt_complete','unconstrained_survival','homogeneous_survival','geometric_survival','aft_bound3','Wiener first-passage']
    evidence=pd.read_csv(plotdata_V/'evidence/simulation_evidence_fidelity.csv').query("scenario=='simulation_dropout'")
    evidence['support']=evidence.confirmed_crossings/evidence.records
    plotdata_lines(evidence,'censoring','support',['L90','L80','T50'],'figure_09a_transition_evidence_support','Dropout probability','Confirmed fraction',group='target')
    recovery=pd.read_csv(plotdata_V/'evidence/simulation_path_recovery.csv').query("scenario=='simulation_dropout' and method=='fixed_survival'")
    plotdata_lines(recovery,'censoring','onset_mae',['L90','L80','T50'],'figure_09b_transition_onset_error','Dropout probability','Onset MAE (h)',group='target')
    sp=pd.read_csv(plotdata_V/'simulation/predictions.csv').query("scenario=='simulation_dropout' and method=='svt_survival'")
    target_sim=sp.groupby(['censoring','task_id','target']).agg(crps=('crps_h','mean'),ibs=('ibs','mean'),coverage=('covered','mean')).reset_index()
    for code,y,label in [('a','crps','CRPS (h)'),('b','ibs','IBS'),('c','coverage','80% interval coverage')]:
        plotdata_lines(sim,'censoring',y,methods,f'fig5{code}_simulation_{y}','Dropout probability',label,rep=True,nominal=y=='coverage')
        plotdata_lines(target_sim,'censoring',y,['L90','L80','T50'],f'fig6{code}_transition_{y}','Dropout probability',label,group='target',rep=True,nominal=y=='coverage')
    wide=sim.pivot(index=['censoring','task_id'],columns='method',values='crps')
    gain=pd.concat([(wide[m]-wide.svt_survival).reset_index(name='gain').assign(method=m) for m in ['fixed_survival','geometric_survival','aft_bound3','Wiener first-passage','unconstrained_survival','homogeneous_survival']])
    plotdata_lines(gain,'censoring','gain',['fixed_survival','geometric_survival','aft_bound3','Wiener first-passage'],'figure_11_structural_benchmark_gains','Dropout probability','Comparator − SVT-S CRPS (h)',rep=True)
    plotdata_lines(sim,'censoring','crps',['svt_survival','svt_survival_substitution','svt_complete','svt_complete_substitution'],'figure_14a_terminal_scoring_crps','Dropout probability','CRPS (h)',rep=True)
    inter=(wide.svt_survival-wide.svt_survival_substitution)-(wide.svt_complete-wide.svt_complete_substitution)
    points=[]
    for c,g in inter.groupby(level=0):
        low,high=plotdata_ci(g);points.append(plotdata_series([c],[g.mean()],color=plotdata_COLORS[0],kind='errorbar',lower=[low],upper=[high]))
    plotdata_add('figure_14b_terminal_scoring_interaction','Dropout probability','Interaction in CRPS gain (h)',points,hline=0)
    plotdata_lines(gain,'censoring','gain',['fixed_survival','unconstrained_survival','homogeneous_survival','geometric_survival'],'figure_15a_simulation_ablation','Dropout probability','Comparator − SVT-S CRPS (h)',rep=True)
    plotdata_lines(laser,'design','crps',['svt_survival','fixed_survival','unconstrained_survival','homogeneous_survival','geometric_survival'],'figure_15b_laser_ablation','Validation design','Observed-event CRPS (h)')
    for design,code in [('LOOU','a'),('LOCO','b')]:
        items=[]
        for k,m in enumerate(['svt_survival','svt_complete','fixed_survival','shared_survival','geometric_survival','aft_bound3','Wiener first-passage','svt_complete_substitution']):
            a=laser[(laser.design==design)&(laser.method==m)].iloc[0]
            items.append(plotdata_series([a.crps],[a.ibs],plotdata_NAMES[m],plotdata_COLORS[k],kind='scatter',marker=['o','s','^','D','v','P','x','*'][k]))
        plotdata_add(f'fig9{code}_{design.lower()}_decision_map','Observed-event CRPS (h)','IBS (0–150 h)',items)
    target=pd.read_csv(plotdata_V/'laser/metrics_by_target.csv');tm=['svt_survival','svt_complete','aft_bound3']
    for design,prefix in [('LOOU','fig10'),('LOCO','fig14')]:
        for code,y,label in [('a','ibs','IBS'),('b','crps','CRPS (h)'),('c','coverage80','80% interval coverage')]:
            name=f'{prefix}{code}_'+('loco_' if design=='LOCO' else '')+'target_'+('coverage' if y=='coverage80' else y)
            plotdata_lines(target[target.design==design],'target',y,tm,name,'Target',label,nominal=y=='coverage80')
    for k,q in enumerate(['L90','L80','T50']):
        items=[];horizons=[50,100,150,200]
        for j,m in enumerate(tm):
            a=pred[(pred.design=='LOOU')&(pred.method==m)&(pred.target==q)]
            items.append(plotdata_series(horizons,[a[f'ipcw_brier_contribution_{h}h'].mean() for h in horizons],plotdata_NAMES[m],plotdata_COLORS[j],kind='line',marker='o'))
        plotdata_add(f'fig16{"abc"[k]}_{q.lower()}_horizon_brier','Remaining horizon (h)','Brier score',items)
        a=pred[(pred.design=='LOOU')&(pred.method=='svt_survival')&(pred.target==q)&pred.crps_h.notna()].sort_values(['origin_h','unit_id']).reset_index(drop=True)
        items=[]
        for j,(origin,marker) in enumerate([(100,'o'),(200,'s'),(300,'^')]):
            b=a[a.origin_h==origin]
            items.append(plotdata_series(b.index,b.p50_h-b.actual_rul_h,f'{origin} h origin',plotdata_COLORS[j],kind='errorbar',marker=marker,lower=(b.p10_h-b.actual_rul_h).tolist(),upper=(b.p90_h-b.actual_rul_h).tolist()))
        plotdata_add(f'fig11{"abc"[k]}_{q.lower()}_prediction_errors','Observed unit–origin record','RUL error and 80% interval (h)',items,hline=0)
    origins=pred[pred.design=='LOOU'].groupby(['method','origin_h','target']).agg(crps=('crps_h','mean'),ibs=('ibs','mean')).reset_index().groupby(['method','origin_h'])[['crps','ibs']].mean().reset_index()
    for code,y in [('a','crps'),('b','ibs')]:plotdata_lines(origins,'origin_h',y,tm,f'fig15{code}_origin_{y}','Prediction origin (h)','CRPS (h)' if y=='crps' else 'IBS')
    cols=[f'survival_probability_{h}h' for h in horizons]
    pv=pred[(pred.design=='LOOU')&(pred.method=='svt_survival')].pivot(index=['unit_id','origin_h'],columns='target',values=cols).dropna()
    items=[]
    for j,q in enumerate(['L90','L80','T50']):
        a=np.array([pv[(c,q)].values for c in cols]);low,high=np.quantile(a,[.25,.75],axis=1)
        items.append(plotdata_series(horizons,np.median(a,axis=1),q,plotdata_COLORS[j],kind='line',marker='o',lower=low.tolist(),upper=high.tolist()))
    plotdata_add('figure_22_ordered_reliability_profiles','Remaining horizon (h)','Probability of remaining before target',items,figsize=[7,3.4])
    sensitivity=pd.read_csv(plotdata_V/'sensitivity/metrics_macro.csv')
    sensitivity['setting']=sensitivity.scenario.str.replace('sensitivity_','').str.replace('_',' ')
    for code,y in [('a','ibs'),('b','crps')]:
        items=[]
        for j,m in enumerate(['fixed_survival','svt_survival','svt_complete']):
            a=sensitivity[sensitivity.method==m]
            items.append(plotdata_series(range(len(a)),a[y],plotdata_NAMES[m],plotdata_COLORS[j],kind='line',marker='o'))
        plotdata_add(f'fig12{code}_sensitivity_{y}',ylabel='IBS' if y=='ibs' else 'CRPS (h)',items=items,xticks=[list(range(len(a))),a.setting.tolist()],tick_rotation=35,figsize=[5.5,3.6])
    # Coordinates for the public-data comparison already include paired unit CIs.
    battery=pd.read_csv(plotdata_V/'evidence/candidate_paired_contrasts.csv')
    panels=[]
    labels=[('fixed_survival','Fixed-S'),('aft_age','Age-only AFT'),('aft_protocol','Unregularized protocol AFT'),('aft_protocol_regularized','Protocol AFT (regularized)'),('aft_survival_crps','Score-trained AFT'),('interval_likelihood','Interval ML'),('soft_em','Soft EM')]
    items=[]
    for i,(m,label) in enumerate(labels):
        r=battery[(battery.dataset=='hust')&(battery.reference==m)&(battery.metric=='crps_h')].iloc[0]
        items.append(plotdata_series([r.gain],[i],color=plotdata_COLORS[i%8],kind='horizontal_errorbar',lower=[r.lo95],upper=[r.hi95]))
    panels.append(dict(xlabel='Comparator CRPS minus SVT-S CRPS (cycles)',title='a  HUST: full training histories',series=items,yticks=[list(range(len(labels))),[x[1] for x in labels]],invert_y=True,vline=0))
    items=[]
    for j,(m,label) in enumerate([('svt_complete','SVT-C (completed)'),('aft_age','Age-only AFT')]):
        for i,dataset in enumerate(['hust_c1000','hust_c1500','hust']):
            r=battery[(battery.dataset==dataset)&(battery.reference==m)&(battery.metric=='crps_h')].iloc[0]
            items.append(plotdata_series([r.gain],[i+(j-.5)*.16],label if i==0 else '',plotdata_COLORS[j],kind='horizontal_errorbar',lower=[r.lo95],upper=[r.hi95]))
    panels.append(dict(xlabel='Comparator CRPS minus SVT-S CRPS (cycles)',title='b  Training observation budget',series=items,yticks=[[0,1,2],['Cycle 1,000','Cycle 1,500','Full history']],invert_y=True,vline=0))
    plotdata_add('figure_24_battery_cross_domain',panels=panels,shape=[1,2],figsize=[7.2,3.25],fontsize=7.5)
    traces=pd.read_csv(plotdata_V/'laser/convergence.csv').query("method=='svt_survival'")
    for design in ['LOOU','LOCO']:
        items=[]
        for i,((fold,start),g) in enumerate(traces[traces.task_id.str.startswith(design)].groupby(['task_id','start'])):
            g=g.sort_values('iteration')
            items.append(plotdata_series(g.iteration,g.objective-g.objective.iloc[0],color=plotdata_COLORS[i%8],kind='line'))
        objective_figure = {
            'LOOU': 'figure_06a_objective_trace_loou',
            'LOCO': 'figure_06b_objective_trace_loco',
        }[design]
        plotdata_add(objective_figure,'Update iteration','Objective increase from initialization',items)
    # Full-record path illustrations use calculated paths and their exact masks.
    panels=[None]*4
    for col,(example,g) in enumerate(paths.groupby('example',sort=False)):
        observed=g[g.method=='fixed_survival'].sort_values('age');spans=intervals[example]
        panels[col]=dict(title=f'{"ab"[col]}  {example}',series=[plotdata_series(observed.age,observed.normalized_power,color='#4E5F6B',kind='line')],ylabel='Normalized power' if col==0 else '',spans=spans,hlines=[.9,.8,.5],ylim=[0,1.08])
        items=[]
        for method,label,color,ls in [('fixed_survival','Fixed boundary','#888888','--'),('unconstrained_survival','Unconstrained','#B56B46','-.'),('svt_survival','Constrained segmental','#2878A5','-')]:
            a=g[g.method==method].sort_values('age')
            items.append(plotdata_series(a.age,a.decoded_state,label,color,kind='step',linestyle=ls))
        if observed.true_state.notna().any():items.append(plotdata_series(observed.age,observed.true_state,'Latent truth','#222222',kind='step',linestyle=':'))
        panels[col+2]=dict(title=f'{"cd"[col]}  Retrospective path illustration',series=items,spans=spans,xlabel='Time after reference (h)' if col==0 else 'Simulated time step',ylabel='Ordered state' if col==0 else '',yticks=[[0,1,2,3],[0,1,2,3]],ylim=[-.15,3.2])
    plotdata_add('figure_12_representative_paths',panels=panels,shape=[2,2],figsize=[7.2,4.2],fontsize=7.5)
    # Original observed-data panels remain reproducible from their exported data.
    items=[]
    currents=sorted(raw.current_a.unique())
    for unit,g in raw.groupby('unit_id',sort=False):
        current=g.current_a.iloc[0]
        items.append(plotdata_series(g.age_h,g.normalized_power,f'{current:.1f} A' if not any(s['label']==f'{current:.1f} A' for s in items) else '',plotdata_COLORS[currents.index(current)],kind='line'))
    plotdata_add('figure_07a_laser_power_trajectories','Time after reference (h)','Normalized power',items,hlines=[.9,.8,.5])
    items=[]
    for i,r in endpoints.iterrows():
        items.append(plotdata_series([0,r.censor_time_h],[i,i],color=plotdata_COLORS[currents.index(r.current_a)],kind='line'))
        for k,q in enumerate(['l90','l80','t50']):
            items.append(plotdata_series([r[f'event_time_{q}_h']],[i],q.upper() if i==0 else '',['#0063D0','#D9A441','#C83E36'][k],kind='scatter',marker=['o','s','^'][k] if r[f'event_{q}'] else 'x'))
    plotdata_add('figure_07b_laser_transition_timelines','Time after reference (h)','Unit',items)
    def convert(value):
        if isinstance(value,np.generic):return value.item()
        raise TypeError(type(value))
    (out/'plots.json').write_text(json.dumps({'schema':1,'description':'Coordinates, estimates and uncertainty already calculated; time units appear in each axis label.','plots':plotdata_PLOTS},ensure_ascii=False,indent=2,default=convert),encoding='utf8')
    print(f'Exported {len(plotdata_PLOTS)} quantitative panels or panel groups.')


def main():
    """Select a case; each case retains its explicit experiment options."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', choices=['laser', 'simulation', 'recovery',
        'sensitivity', 'battery', 'external', 'sparse', 'features',
        'feature-diagnostics', 'baselines', 'calibration', 'evidence',
        'diagnostics', 'prepare-battery', 'export-plots', 'smoke'])
    args = parser.parse_args(sys.argv[1:2])
    rest = sys.argv[2:]
    sys.argv = [sys.argv[0]] + rest
    if args.case in ['laser','simulation','recovery','sensitivity']:
        sys.argv += ['--mode', args.case]
        experiment_main()
    elif args.case in ['external','sparse']:
        sys.argv += ['--mode',args.case]
        comparison_main()
    elif args.case == 'battery': battery_main()
    elif args.case == 'features': feature_sensitivity_main()
    elif args.case == 'feature-diagnostics': feature_main()
    elif args.case == 'baselines': baseline_main()
    elif args.case == 'calibration': calibration_main()
    elif args.case == 'evidence': evidence_main()
    elif args.case == 'diagnostics':
        diagnostic_collect()
        if '--benchmark' in rest: diagnostic_benchmark()
    elif args.case == 'prepare-battery':
        p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True)
        global adapter_SOURCE
        adapter_SOURCE=p.parse_args(rest).source_root
        adapter_DEST.mkdir(parents=True,exist_ok=True)
        adapter_prepare_hust()
    elif args.case == 'export-plots': plotdata_main()
    elif args.case == 'smoke':
        p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True)
        out=ROOT/p.parse_args(rest).output_dir;out.mkdir(parents=True,exist_ok=True)
        cfg=load_config(ROOT/'data/settings/verification_fixture.json')
        u=simulate_unit(np.random.default_rng(32),'verification',12,3.5,1.,1.,0.)
        path=np.minimum(np.arange(12)//3,3)
        params=make_initial_parameters([u],[path],cfg,False,'lognormal',False)
        params['dur_mu']=np.log([3.,4.,3.,50.]);params['dur_sigma']=np.array([.65,.5,.8,.5])
        params['endpoint_anchor_weight']=0.
        # Separate workers exercise Windows serialization as well as inference.
        with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
            got=list(pool.map(_smoke_one,[(u,params,True),(u,params,False)]))
        dump={'schema':1,'plots':[{'name':'inference_verification',
            'xlabel':'Observation index','ylabel':'Decoded state',
            'series':[{'x':list(range(12)),'y':g[0].tolist(),'kind':'step',
                       'label':label,'color':color} for g,label,color in zip(got,
                       ['Constrained','Unconstrained'],['#172C6F','#278575'])]}]}
        (out/'plots.json').write_text(json.dumps(dump),encoding='utf8')
        (out/'scores.json').write_text(json.dumps([float(g[1]) for g in got]))
        print('Inference and independent plot-data export completed.')

def _smoke_one(args):
    return inference_fast_viterbi(*args)

if __name__ == '__main__':
    main()

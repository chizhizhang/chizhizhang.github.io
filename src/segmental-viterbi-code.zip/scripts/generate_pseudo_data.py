"""Generate pseudo feature trajectories from a fitted laser HSMM, not measured data."""
from pathlib import Path
import argparse, json, numpy as np, pandas as pd
FEATURES=['power_loss','loss_rate','electrothermal_load','wavelength_shift','bandwidth_shift','spectral_instability','conversion_efficiency']
def generate(model_path, output_path, seed=2605881, units=100, hours=550):
    p=json.loads(Path(model_path).read_text(encoding='utf8'))
    rng=np.random.default_rng(seed)
    mu=np.asarray(p['emission_mu']);scale=np.asarray(p['emission_scale'])
    center=np.asarray(p['feature_center']);standard=np.asarray(p['feature_scale'])
    rows=[];events=[]
    for i in range(units):
        current=[3.0,3.5,4.0,4.5][i%4]
        # The saved laser models have no auxiliary duration features.
        eta=np.asarray(p['dur_mu'])[:3]-np.asarray(p['alpha'])[:3]*np.log(current/p['current_reference'])
        durations=np.maximum(1,np.rint(rng.lognormal(eta,np.asarray(p['dur_sigma'])[:3]))).astype(int)
        entries=np.cumsum(durations)
        administrative_end=int(rng.integers(150,hours+1)) if i%3==0 else hours
        age=np.arange(administrative_end)
        states=np.searchsorted(entries,age,side='right')
        x=(mu[states]+rng.standard_t(p['student_df'],size=(len(age),7))*scale[states])*standard+center
        frame=pd.DataFrame(x,columns=FEATURES)
        frame.insert(0,'true_state',states);frame.insert(0,'age_h',age)
        frame.insert(0,'current_A',current);frame.insert(0,'pseudo_unit',f'pseudo-{i+1:03d}')
        rows.append(frame)
        e={'pseudo_unit':f'pseudo-{i+1:03d}','current_A':current,'observation_end_h':administrative_end-1}
        for name,t in zip(['L90','L80','T50'],entries):
            e[name+'_latent_entry_h']=int(t);e[name+'_latent_observed']=int(t<administrative_end)
        events.append(e)
    output_path=Path(output_path);output_path.mkdir(parents=True,exist_ok=True)
    pd.concat(rows,ignore_index=True).to_csv(output_path/'pseudo_feature_trajectories.csv',index=False,float_format='%.10g')
    pd.DataFrame(events).to_csv(output_path/'pseudo_latent_events.csv',index=False)
if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model',type=Path,default=root/'data/pseudo/fitted_laser_model.json')
    p.add_argument('--output',type=Path,default=root/'data/pseudo')
    p.add_argument('--seed',type=int,default=2605881)
    a=p.parse_args();generate(a.model,a.output,a.seed)

# Reproducing the manuscript

The two executable files are independent. main_analysis.py computes model fits,
predictions, comparison tables and plotting coordinates. generate_figures.py
reads those coordinates and the editable schematic SVGs. It never imports or
executes the analysis script, estimates parameters or resamples uncertainty.

Use Python 3.13 with NumPy, SciPy, pandas, Numba and scikit-learn for analysis.
Figure export additionally uses matplotlib, lxml, svgpathtools, Pillow, pypdf,
cairosvg and resvg-py. No GPU is required. Run commands from the extracted root.

    python scripts/main_analysis.py laser --workers 4
    python scripts/main_analysis.py simulation --replicates 100 --workers 4
    python scripts/main_analysis.py recovery --replicates 100 --workers 4
    python scripts/main_analysis.py sensitivity --workers 4
    python scripts/main_analysis.py features
    python scripts/main_analysis.py baselines
    python scripts/main_analysis.py external --workers 4
    python scripts/main_analysis.py sparse --replicates 100 --workers 4

Simulation includes 100 replicates at each of three dropout levels, 100 fixed-end
replicates and 100 additional recovery replicates. Error-free inspection recovery
is a separate case. Laser validation has 19 unit and four current holdouts.
External HSMM comparisons cover the 23 laser folds and 300 dropout replicates.

HUST is the single public-data extension. The supplied capacity summaries and
protocol metadata cover all 77 cells. Five whole-cell folds are used throughout.

    python scripts/main_analysis.py battery --workers 3
    python scripts/main_analysis.py battery --training-cutoff-cycle 1500 --workers 3
    python scripts/main_analysis.py battery --training-cutoff-cycle 1000 --workers 3
    python scripts/main_analysis.py battery --sigma-min .05 --workers 3
    python scripts/main_analysis.py battery --training-cutoff-cycle 1000 --sigma-min .05 --workers 3

The varying protocol covariates are discharge stages 0, 1 and 2; stage 3 is shared.
Cutoffs apply to training histories. Test follow-up is unchanged. Internal time
uses ten-cycle steps; the cycle-labeled summaries give the manuscript units.
Prepared inputs can also be rebuilt from an existing public download:

    python scripts/main_analysis.py prepare-battery --source-root PATH_TO_PUBLIC_DATA

After completing the experiments, calculate evidence and plotting coordinates:

    python scripts/main_analysis.py feature-diagnostics
    python scripts/main_analysis.py calibration
    python scripts/main_analysis.py evidence
    python scripts/main_analysis.py diagnostics --benchmark
    python scripts/main_analysis.py export-plots

The last command exports schema 1 plots.json and the prespecified path examples
under outputs/plot_data/current. It owns displayed means, contrasts and bootstrap
intervals. The 38 plot groups contain x/y coordinates, units in axis labels,
series identifiers, and lower/upper bounds when uncertainty is displayed.

    python scripts/generate_figures.py
    python scripts/generate_figures.py --only figure_24_battery_cross_domain
    python scripts/generate_figures.py --graphical-abstract-only

The default figure command regenerates all quantitative assets and exports the
six native schematic SVGs. It composes the three-column graphical abstract from
the native objects in Figures 1-3. The abstract is 3000 x 1200 pixels at 300 dpi,
with editable SVG and vector PDF outputs. Missing inputs cause an explicit error.

A small independent-process example can be run without measured laser records:

    python scripts/main_analysis.py smoke --output-dir outputs/example
    python scripts/generate_figures.py --input outputs/example/plots.json --output-dir figures/example --only figure_13a_transition_crps

The original measured laser records are available upon reasonable request and
are excluded from this code archive. Full laser refitting and recalculation of
raw-history illustrations require those records. The archive supplies computed
results, model parameters, public battery inputs and complete plotting data.
Plots can be reproduced immediately; simulations and the battery case can be
rerun from the included inputs. Per-task CSV duplicates are omitted where their
rows are already present in the corresponding aggregate CSV; saved model files
are retained. Model-generated pseudo-data and code are prepared for deposit in Zenodo at or
before final acceptance. See data/pseudo/README.md and run
python scripts/generate_pseudo_data.py to regenerate the illustrative pseudo-data.
No measured record is relabeled as synthetic. The archive DOI remains pending
until the actual deposit is completed.

The LaTeX archive compiles separately and has no dependency on the analysis or
figure-generation code. The response and submission documents have editable
Word sources in word_source.zip.


R2 changes are limited to citations, contribution wording and archive preparation.
The supplied numerical results are retained from R1.


## Personal website code release

This compact website package includes executable analysis/figure code, fitted-model
pseudo-data, public HUST prepared inputs, settings, native SVG assets and complete
plotting coordinates. It omits the large per-replicate model and result archive.
Full measured-laser refitting still requires the restricted measured records.
The manuscript results can be plotted directly from outputs/plot_data/current.
The complete code/results/pseudo-data deposit package is prepared separately for
Zenodo. No archive DOI has been issued for this release yet.

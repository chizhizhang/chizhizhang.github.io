# Laser pseudo-data

These are model-generated feature trajectories derived from an R1 fitted laser
SVT-S model. They are not measured device records and do not reproduce or replace
the manuscript's experimental results. No original laser CSV is included.
The source model and SHA-256 are recorded in provenance.json.

Regenerate from the extracted archive root with

    python scripts/generate_pseudo_data.py

The generator uses seed 2605881 and creates 100 independent units, equally
distributed across 3.0, 3.5, 4.0 and 4.5 A. It draws ordered lognormal residence
times using the saved covariate-dependent law and diagonal Student-t emissions
in standardized feature space, then reverses feature standardization. The
absorbing state remains active after its entry. Every third record has a randomly
shortened administrative observation window independent of the simulated dwell
times. Other records contain 550 hourly observations. These are illustrative
fitted-model draws, not a new validation experiment or a privacy guarantee.

pseudo_feature_trajectories.csv fields
- pseudo_unit is a newly generated identifier, with no link to measured units.
- current_A is assigned current in amperes.
- age_h is model age in hours after the reference time.
- true_state is the simulated state 0, 1, 2 or 3; unavailable in measured data.
- power_loss is normalized power loss, dimensionless.
- loss_rate is normalized loss per hour.
- electrothermal_load is the centered feature in the original feature units.
- wavelength_shift and bandwidth_shift are shifts in nanometers.
- spectral_instability is the original rolling spectral feature.
- conversion_efficiency is the dimensionless conversion feature.

All seven channels are independent draws conditional on state under the working
emission model. This can generate physically implausible individual values and
does not reconstruct internally consistent raw optical/electrical telemetry.

pseudo_latent_events.csv fields
- observation_end_h is the final observed model age.
- *_latent_entry_h is the sampled latent state-entry time, including entries
  beyond administrative follow-up.
- *_latent_observed records whether that latent entry occurs in the window.
These flags are not the noisy persistent-crossing operational masks. Use the
analysis code's threshold construction for operational evidence. Latent truth
must never be used as a measured label during fitting or prediction.

The original laser observations are available from the corresponding author
upon reasonable request. Full measured-laser refitting requires those records.
Simulations, public HUST inputs and archived plotting coordinates remain
available for the reproducibility workflow described in the root README.

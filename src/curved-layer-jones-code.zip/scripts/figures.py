#!/usr/bin/env python3
"""Publication figure generator for the curved layer Jones manuscript.

No mechanical or optical calculation is performed here. The script reads only
CSV/JSON tables written by ``main.py`` and exports publication-ready figure
panels in PNG and PDF. Method schematics are authored as SVG first and then
exported to PNG/PDF.

Run after ``python main.py --mode paper``::

    python figures.py

Every manuscript subfigure is exported as an independent PDF/PNG asset. The
LaTeX manuscript combines those assets with the subfigure environment; this
script keeps manuscript panels as independent files and lets LaTeX assemble them. Circular field
panels are square; ordinary charts and schematics use a wide canvas.
"""
from __future__ import annotations

import csv
import json
import math
import shutil
import string
import subprocess
import tempfile
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle
import matplotlib.tri as mtri
import numpy as np
from scipy.spatial import cKDTree
import svgwrite
import cairosvg

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_ROOT = ROOT / "outputs"
FIGURE_ROOT = ROOT / "figures"
FIGURE_ROOT.mkdir(parents=True, exist_ok=True)

# Publication palette from the supplied figure skill.
PAPER = "#FFFFFF"
INK = "#000000"
BLUE = "#0063D0"
SKY = "#0152AB"
NAVY = "#172C6F"
GREEN = "#278575"
SAND = "#F8E3B3"
GOLD = "#D9A441"
RED = "#C83E36"
GRAY = "#7A7A7A"
LIGHT = "#D8D8D8"

mpl.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Tinos", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "axes.linewidth": 0.9,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "savefig.dpi": 300,
    "figure.facecolor": PAPER,
    "axes.facecolor": PAPER,
    "text.color": INK,
    "axes.labelcolor": INK,
    "axes.edgecolor": INK,
    "xtick.color": INK,
    "ytick.color": INK,
    "legend.labelcolor": INK,
})


def _read_csv(name: str):
    path = OUTPUT_ROOT / name
    if not path.exists():
        raise FileNotFoundError(f"missing {path}; run main.py first")
    return np.genfromtxt(path, delimiter=",", names=True, dtype=None, encoding="utf-8")


def _load_summary() -> dict:
    path = OUTPUT_ROOT / "summary.json"
    if not path.exists():
        raise FileNotFoundError(f"missing {path}; run main.py first")
    return json.loads(path.read_text(encoding="utf-8"))


def _load_points(case: str):
    return _read_csv(f"{case}_stage_points.csv")


def _case_radius(summary: dict, case: str) -> float:
    return float(summary["cases"][case]["config"]["clear_radius_mm"])


def _save_panel(fig: plt.Figure, stem: str, *, fixed_canvas: bool = False) -> None:
    options = {} if fixed_canvas else {"bbox_inches": "tight", "pad_inches": 0.03}
    fig.savefig(FIGURE_ROOT / f"{stem}.pdf", **options)
    fig.savefig(FIGURE_ROOT / f"{stem}.png", dpi=300, **options)
    plt.close(fig)


def _wide_figure():
    # Source for a 0.48\textwidth panel.
    fig, ax = plt.subplots(figsize=(7.2, 4.05))
    fig.subplots_adjust(left=0.15, right=0.97, bottom=0.22, top=0.96)
    ax.tick_params(labelsize=20, width=0.9, length=4.5, colors=INK)
    ax.xaxis.label.set_size(23)
    ax.yaxis.label.set_size(23)
    return fig, ax


def _third_wide_figure():
    # Source for a 0.33\textwidth panel in a compact three-panel row.
    fig, ax = plt.subplots(figsize=(7.2, 4.05))
    fig.subplots_adjust(left=0.18, right=0.97, bottom=0.25, top=0.96)
    ax.tick_params(labelsize=27, width=1.0, length=5.5, colors=INK)
    ax.xaxis.label.set_size(31)
    ax.yaxis.label.set_size(31)
    return fig, ax


def _full_wide_figure():
    # Source for a single panel placed at 0.96\textwidth.
    fig, ax = plt.subplots(figsize=(7.2, 4.05))
    fig.subplots_adjust(left=0.12, right=0.98, bottom=0.18, top=0.97)
    ax.tick_params(labelsize=10.5, width=0.8, length=4, colors=INK)
    ax.xaxis.label.set_size(12.5)
    ax.yaxis.label.set_size(12.5)
    return fig, ax


def _square_figure():
    # Source for a 0.33\textwidth circular/scalar-field panel.
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    fig.subplots_adjust(left=0.18, right=0.76, bottom=0.17, top=0.96)
    ax.tick_params(labelsize=27, width=1.0, length=5.5, colors=INK)
    ax.xaxis.label.set_size(31)
    ax.yaxis.label.set_size(31)
    return fig, ax


def _tri_field(ax, x, y, values, *, limits=None, cmap="viridis", levels=31, extend="neither"):
    x = np.asarray(x, float); y = np.asarray(y, float); values = np.asarray(values, float)
    tri = mtri.Triangulation(x, y)
    finite = np.isfinite(values)
    if not np.any(finite):
        raise ValueError("field contains no finite values")
    if not np.all(finite):
        tri.set_mask(np.any(~finite[tri.triangles], axis=1))
        values = np.where(finite, values, 0.0)
    if limits is None:
        lo, hi = float(np.nanmin(values)), float(np.nanmax(values))
    else:
        lo, hi = map(float, limits)
    if math.isclose(lo, hi):
        hi = lo + 1.0
    lev = np.linspace(lo, hi, levels)
    return ax.tricontourf(tri, values, levels=lev, cmap=cmap, extend=extend)


def _format_pupil(ax, radius: float):
    ax.add_patch(Circle((0, 0), radius, fill=False, ec=INK, lw=1.2))
    lim = 1.035 * radius
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel(r"$x$ (mm)")
    ax.set_ylabel(r"$y$ (mm)")
    ax.grid(False)


def _add_colorbar(fig, ax, im, label: str, ticks=None):
    from matplotlib.ticker import MaxNLocator
    cb = fig.colorbar(im, ax=ax, fraction=0.060, pad=0.028, ticks=ticks)
    if ticks is None:
        cb.locator = MaxNLocator(nbins=5)
        cb.update_ticks()
    cb.ax.tick_params(labelsize=27, width=0.9, length=4, colors=INK)
    cb.set_label(label, fontsize=30, color=INK)
    cb.outline.set_linewidth(0.8)
    for lab in cb.ax.get_yticklabels():
        lab.set_color(INK)
    return cb


def _directors(ax, x, y, theta_deg, radius: float, spacing: float = 14.0):
    gx, gy = np.meshgrid(np.arange(-radius + spacing, radius, spacing),
                         np.arange(-radius + spacing, radius, spacing))
    grid = np.column_stack((gx.ravel(), gy.ravel()))
    grid = grid[np.hypot(grid[:, 0], grid[:, 1]) <= 0.90 * radius]
    tree = cKDTree(np.column_stack((x, y)))
    _, ids = tree.query(grid)
    theta = np.deg2rad(np.asarray(theta_deg)[ids])
    half = 0.046 * radius
    delta = half * np.column_stack((np.cos(theta), np.sin(theta)))
    segments = np.stack((grid - delta, grid + delta), axis=1)
    ax.add_collection(LineCollection(segments, colors=INK, linewidths=1.15, alpha=0.90, zorder=8))


# ---------- SVG helpers for Figs. 1 and 2 ----------
def _svg_text(dwg, text, x, y, *, size=58, anchor="middle", fill=INK, weight="normal", italic=False):
    style = "font-family:'Times New Roman','Tinos',serif;"
    if italic:
        style += "font-style:italic;"
    dwg.add(dwg.text(text, insert=(x, y), text_anchor=anchor, fill=fill,
                     font_size=size, font_weight=weight, style=style))


def _svg_math_text(dwg, text, x, y, *, size=58, anchor="middle", fill=INK, weight="normal", italic=False):
    """SVG math label using a STIX math face; prose remains Times New Roman/Tinos."""
    style = "font-family:'STIXGeneral','STIX Math',serif;"
    if italic:
        style += "font-style:italic;"
    dwg.add(dwg.text(text, insert=(x, y), text_anchor=anchor, fill=fill,
                     font_size=size, font_weight=weight, style=style))


def _svg_math_run(dwg, parts, x, y, *, size=58, anchor="middle", fill=INK, weight="normal"):
    """Draw simple math runs with real SVG sub/superscript positioning.

    ``parts`` contains ``(text, shift, scale)`` tuples, where shift is
    ``None``, ``"sub"``, or ``"super"``.  This keeps mathematical labels
    typographically distinct from prose without relying on Unicode subscript
    glyph coverage.
    """
    t = dwg.text("", insert=(x, y), text_anchor=anchor, fill=fill, font_size=size,
                 font_weight=weight, style="font-family:'STIXGeneral','STIX Math',serif;")
    for text, shift, scale in parts:
        kwargs = {"font_size": size * scale}
        if shift is not None:
            kwargs["baseline_shift"] = shift
        t.add(dwg.tspan(text, **kwargs))
    dwg.add(t)


def _svg_multiline(dwg, lines, x, y, *, size=54, anchor="middle", fill=INK, line=1.22, weight="normal"):
    t = dwg.text("", insert=(x, y), text_anchor=anchor, fill=fill, font_size=size,
                 font_weight=weight, style="font-family:'Times New Roman','Tinos',serif;")
    for i, s in enumerate(lines):
        t.add(dwg.tspan(s, x=[x], dy=[0 if i == 0 else size * line]))
    dwg.add(t)


def _svg_arrow_marker(dwg, color=INK, marker_id="arrow"):
    marker = dwg.marker(insert=(9, 4), size=(10, 8), orient="auto", id=marker_id)
    marker.add(dwg.path(d="M0,0 L10,4 L0,8 z", fill=color))
    dwg.defs.add(marker)
    return marker


def _new_svg(width: int, height: int):
    dwg = svgwrite.Drawing(size=(f"{width}px", f"{height}px"), viewBox=f"0 0 {width} {height}")
    dwg.add(dwg.rect((0, 0), (width, height), fill=PAPER))
    return dwg


def _export_svg(dwg, stem: str):
    svg_path = FIGURE_ROOT / f"{stem}.svg"
    dwg.saveas(svg_path)
    cairosvg.svg2pdf(url=str(svg_path), write_to=str(FIGURE_ROOT / f"{stem}.pdf"), background_color=PAPER)
    cairosvg.svg2png(url=str(svg_path), write_to=str(FIGURE_ROOT / f"{stem}.png"),
                     output_width=1920, background_color=PAPER)


def _lens_curves(width=1920, height=1080):
    xs = np.linspace(180, 1740, 100)
    xn = (xs - 960) / 780
    top = 300 + 115 * xn**2
    bottom = 800 - 70 * xn**2
    return xs, top, bottom


def figure1_method_panels():
    """Generate the three independent panels used by manuscript Fig. 1.

    Each panel is designed for placement at 0.96 text width.  Text is kept
    large enough to remain readable after journal scaling, and graphical
    objects carry most of the explanation.  Sampling counts are intentionally
    omitted because Table 1 and the convergence section give the exact depth.
    """
    # ------------------------------------------------------------------
    # (a) Sampling geometry in one coordinate system.
    # ------------------------------------------------------------------
    dwg = _new_svg(1920, 560)
    xs = np.linspace(100, 1820, 260)
    xn = (xs - 960.0) / 860.0
    top = 145.0 + 50.0 * xn**2
    bottom = 430.0 - 28.0 * xn**2
    poly = [(float(x), float(y)) for x, y in zip(xs, top)] + [
        (float(x), float(y)) for x, y in zip(xs[::-1], bottom[::-1])
    ]
    dwg.add(dwg.polygon(poly, fill="#FBFCFE", stroke=INK, stroke_width=6))

    # One FE layer is highlighted to make the path increment unambiguous.
    u0, u1 = 0.42, 0.57
    h0 = top + u0 * (bottom - top)
    h1 = top + u1 * (bottom - top)
    band = [(float(x), float(y)) for x, y in zip(xs, h0)] + [
        (float(x), float(y)) for x, y in zip(xs[::-1], h1[::-1])
    ]
    dwg.add(dwg.polygon(band, fill=SAND, stroke="none", opacity=0.78))

    # Swept FE surfaces.
    for u in np.linspace(0.12, 0.88, 7):
        yy = top + u * (bottom - top)
        dwg.add(dwg.polyline(
            points=[(float(x), float(y)) for x, y in zip(xs, yy)],
            fill="none", stroke=GREEN, stroke_width=3.2,
        ))

    # Representative HEX8 cell.
    x0, x1 = 500.0, 665.0
    c00 = (x0, float(np.interp(x0, xs, h0)))
    c10 = (x1, float(np.interp(x1, xs, h0)))
    c11 = (x1, float(np.interp(x1, xs, h1)))
    c01 = (x0, float(np.interp(x0, xs, h1)))
    dwg.add(dwg.polygon([c00, c10, c11, c01], fill="#FFF8E8", stroke=GOLD, stroke_width=5))
    for pt in (c00, c10, c11, c01):
        dwg.add(dwg.circle(pt, 7.5, fill=NAVY, stroke=PAPER, stroke_width=1.6))
    _svg_text(dwg, "one element layer", 582, 370, size=44, weight="bold")

    # Fixed pupil column and its samples.
    xcol = 1055.0
    yt = float(np.interp(xcol, xs, top)); yb = float(np.interp(xcol, xs, bottom))
    dwg.add(dwg.line((xcol, yt), (xcol, yb), stroke=BLUE, stroke_width=6, stroke_dasharray="18,10"))
    fixed_us = (0.16, 0.32, 0.50, 0.68, 0.84)
    for u in fixed_us:
        yy = yt + u * (yb - yt)
        dwg.add(dwg.circle((xcol, yy), 9, fill=BLUE, stroke=PAPER, stroke_width=2))

    # Refracted ray launched from the same entrance pupil coordinate.
    x_entry, x_exit = xcol, 1165.0
    y_entry = yt
    y_exit = float(np.interp(x_exit, xs, bottom))
    ray_marker = _svg_arrow_marker(dwg, RED, "fig1a_ray")
    ray = dwg.line((x_entry, y_entry), (x_exit, y_exit), stroke=RED, stroke_width=7)
    ray['marker-end'] = ray_marker.get_funciri(); dwg.add(ray)
    for u in fixed_us:
        px = x_entry + u * (x_exit - x_entry)
        py = y_entry + u * (y_exit - y_entry)
        s = 9
        dwg.add(dwg.polygon(
            [(px, py-s), (px+s, py), (px, py+s), (px-s, py)],
            fill=RED, stroke=PAPER, stroke_width=2,
        ))

    # Delta s_k along the highlighted refracted segment.
    def rp(u):
        return np.array([x_entry + u*(x_exit-x_entry), y_entry + u*(y_exit-y_entry)], float)
    pa, pb = rp(u0), rp(u1)
    vv = pb-pa; vv /= np.linalg.norm(vv); nn = np.array([-vv[1], vv[0]])
    aa, bb = pa - 38*nn, pb - 38*nn
    dwg.add(dwg.line(tuple(aa), tuple(bb), stroke=INK, stroke_width=3))
    for q in (aa, bb):
        dwg.add(dwg.line(tuple(q-11*nn), tuple(q+11*nn), stroke=INK, stroke_width=3))
    mm = 0.5*(aa+bb)
    _svg_text(dwg, "path increment", float(mm[0]+55), float(mm[1]+54), size=36, anchor="start")

    # Delta r at the exit.
    ydim = 485
    dwg.add(dwg.line((xcol, ydim), (x_exit, ydim), stroke=INK, stroke_width=3))
    dwg.add(dwg.line((xcol, ydim-12), (xcol, ydim+12), stroke=INK, stroke_width=3))
    dwg.add(dwg.line((x_exit, ydim-12), (x_exit, ydim+12), stroke=INK, stroke_width=3))
    _svg_math_text(dwg, "Δr", 0.5*(xcol+x_exit), 535, size=50, italic=True)

    # Direct labels with short leaders.  These are intentionally inside the panel
    # rather than in a detached legend so the geometry can be read at a glance.
    _svg_text(dwg, "entrance surface", 125, 58, size=44, anchor="start")
    dwg.add(dwg.line((430,64),(545,float(np.interp(545,xs,top))-5),stroke=INK,stroke_width=2.5))
    _svg_text(dwg, "swept layer surfaces", 125, 122, size=44, anchor="start")
    dwg.add(dwg.line((445,126),(600,float(np.interp(600,xs,top+0.23*(bottom-top)))),stroke=GREEN,stroke_width=3))
    _svg_text(dwg, "same entrance pupil point", 1245, 55, size=40, anchor="start")
    dwg.add(dwg.line((1225,63),(1075,y_entry+2),stroke=INK,stroke_width=2.5))
    _svg_text(dwg, "fixed pupil column", 1350, 130, size=44, anchor="start")
    dwg.add(dwg.line((1330,137),(1078,205),stroke=BLUE,stroke_width=3))
    _svg_text(dwg, "refracted ray", 1430, 236, size=44, anchor="start")
    dwg.add(dwg.line((1410,242),(1160,300),stroke=RED,stroke_width=3))
    _svg_text(dwg, "exit surface", 125, 505, size=44, anchor="start")
    dwg.add(dwg.line((370,498),(520,float(np.interp(520,xs,bottom))+2),stroke=INK,stroke_width=2.5))
    _export_svg(dwg, "Fig1a_sampling_geometry")

    # ------------------------------------------------------------------
    # (b) Common stress and polarization kernel.
    # ------------------------------------------------------------------
    dwg = _new_svg(1920, 540)
    flow = _svg_arrow_marker(dwg, INK, "fig1b_flow")
    stress_arrow = _svg_arrow_marker(dwg, RED, "fig1b_stress")

    # Left: one three-dimensional HEX8 stress sample.  The wireframe uses
    # nine visible solid edges and three hidden dashed edges so the projected
    # cube reads consistently as a 3-D cell rather than as two overlaid boxes.
    f = [(90,195),(385,195),(385,400),(90,400)]
    b = [(155,140),(450,140),(450,345),(155,345)]
    # Conventional oblique cube: the three edges meeting the rear lower-left
    # vertex are hidden. This gives 9 visible solid edges and 3 dashed edges.
    # The hidden edges are the rear-left vertical edge, the rear-bottom edge,
    # and the front-lower-left to rear-lower-left connector.
    visible_edges = [
        (f[0],f[1]),(f[1],f[2]),(f[2],f[3]),(f[3],f[0]),
        (f[0],b[0]),(f[1],b[1]),(f[2],b[2]),
        (b[0],b[1]),(b[1],b[2]),
    ]
    hidden_edges = [
        (f[3],b[3]),(b[3],b[0]),(b[3],b[2]),
    ]
    # Light face fill is purely structural; all explanatory text remains black.
    dwg.add(dwg.polygon([b[0],b[3],b[2],b[1]], fill="#F7F9FC", stroke="none"))
    dwg.add(dwg.polygon(f, fill=PAPER, stroke="none"))
    for a0,b0 in visible_edges:
        dwg.add(dwg.line(a0,b0,stroke=BLUE,stroke_width=5))
    for a0,b0 in hidden_edges:
        dwg.add(dwg.line(a0,b0,stroke=BLUE,stroke_width=4,stroke_dasharray="20,14"))
    for pt in f+b:
        dwg.add(dwg.circle(pt,7.5,fill=BLUE,stroke=PAPER,stroke_width=1.5))
    for p0,p1 in [((62,258),(118,258)),((420,258),(364,258)),((235,438),(235,382))]:
        ln=dwg.line(p0,p1,stroke=RED,stroke_width=5); ln['marker-end']=stress_arrow.get_funciri(); dwg.add(ln)
    _svg_math_text(dwg, "σ(x)", 270, 82, size=68, weight="bold")
    _svg_text(dwg, "three dimensional stress", 270, 472, size=43, weight="bold")
    _svg_text(dwg, "6 independent components", 270, 515, size=38)

    # Center: ray-normal plane and the local optical principal directions.
    cx,cy=900,285
    dwg.add(dwg.circle((cx,cy),130,fill="#F7FBF9",stroke=GREEN,stroke_width=6))
    ray=dwg.line((700,420),(815,330),stroke=GREEN,stroke_width=7); ray['marker-end']=flow.get_funciri(); dwg.add(ray)
    _svg_text(dwg, "ray direction", 650, 405, size=34, anchor="start")
    th=math.radians(30); u=np.array([math.cos(th),math.sin(th)]); v=np.array([-u[1],u[0]])
    p1=np.array([cx,cy])-105*u; p2=np.array([cx,cy])+105*u
    q1=np.array([cx,cy])-78*v; q2=np.array([cx,cy])+78*v
    dwg.add(dwg.line(tuple(p1),tuple(p2),stroke=RED,stroke_width=8))
    dwg.add(dwg.line(tuple(q1),tuple(q2),stroke=BLUE,stroke_width=6,stroke_dasharray="14,7"))
    _svg_text(dwg, "slow", float(p2[0]+16), float(p2[1]+5), size=40, anchor="start")
    _svg_text(dwg, "fast", float(q2[0]+15), float(q2[1]+4), size=40, anchor="start")
    _svg_text(dwg, "stress in ray frame", cx, 78, size=50, weight="bold")
    _svg_text(dwg, "ray normal plane", cx, 472, size=43, weight="bold")
    _svg_text(dwg, "principal stress → optical modes", cx, 515, size=38)

    # Right: Jones increments in entrance-to-exit order and the reported outputs.
    ybeam=285
    ln=dwg.line((1215,ybeam),(1810,ybeam),stroke=INK,stroke_width=4); ln['marker-end']=flow.get_funciri(); dwg.add(ln)
    centers=[1328,1465,1602]
    angles=[-18,12,-8]
    plate_labels=["first","kth","last"]
    for px,ang,jlab in zip(centers,angles,plate_labels):
        t0=math.radians(ang); uu=np.array([math.cos(t0),math.sin(t0)]); vv=np.array([-uu[1],uu[0]])
        c=np.array([px,ybeam]); hw,hh=42,92
        pts=[c-hw*uu-hh*vv,c+hw*uu-hh*vv,c+hw*uu+hh*vv,c-hw*uu+hh*vv]
        dwg.add(dwg.polygon([tuple(z) for z in pts],fill="#FFF8E8",stroke=GOLD,stroke_width=5))
        dwg.add(dwg.line(tuple(c-65*vv),tuple(c+65*vv),stroke=NAVY,stroke_width=3))
        _svg_text(dwg, jlab, px, 155, size=34, weight="bold")
    # This ellipse is intentional: it denotes the output polarization state.
    dwg.add(dwg.ellipse(center=(1740,ybeam),r=(72,30),fill="none",stroke=NAVY,stroke_width=7,transform="rotate(-24 1740 285)"))
    _svg_text(dwg, "ordered Jones updates", 1490, 78, size=50, weight="bold")
    _svg_text(dwg, "entrance → exit", 1490, 118, size=37)
    _svg_text(dwg, "polarization outputs", 1710, 405, size=37, weight="bold")
    _svg_text(dwg, "retardance | axis | ellipticity | OPD", 1680, 462, size=33)

    # Flow arrows between the three physical blocks.
    for x1,x2 in [(485,650),(1080,1190)]:
        ln=dwg.line((x1,285),(x2,285),stroke=INK,stroke_width=5); ln['marker-end']=flow.get_funciri(); dwg.add(ln)
    _export_svg(dwg, "Fig1b_stress_to_jones")

    # ------------------------------------------------------------------
    # (c) Controlled comparison sequence shown as physical states.
    # ------------------------------------------------------------------
    dwg = _new_svg(1920, 540)
    flow = _svg_arrow_marker(dwg, INK, "fig1c_flow")
    stages=[170,555,940,1325,1710]
    cy=255

    def lens_icon(cx, *, fixed=False, volume=False, ray=False, normal=False, dense=False):
        lx=np.linspace(cx-125,cx+125,50); xx=(lx-cx)/125
        tt=cy-82+15*xx**2; bb=cy+82-9*xx**2
        poly=[(float(x),float(y)) for x,y in zip(lx,tt)]+[(float(x),float(y)) for x,y in zip(lx[::-1],bb[::-1])]
        dwg.add(dwg.polygon(poly,fill="#FBFCFE",stroke=INK,stroke_width=4))
        for u in (0.33,0.66):
            yy=tt+u*(bb-tt)
            dwg.add(dwg.polyline([(float(x),float(y)) for x,y in zip(lx,yy)],fill="none",stroke=GREEN,stroke_width=2.5))
        if volume:
            # Highlight a local volume cell rather than replacing the lens by a cube.
            x0,x1=cx-62,cx+22
            y0=float(np.interp(x0,lx,tt+0.33*(bb-tt))); y1=float(np.interp(x1,lx,tt+0.33*(bb-tt)))
            y2=float(np.interp(x1,lx,tt+0.66*(bb-tt))); y3=float(np.interp(x0,lx,tt+0.66*(bb-tt)))
            dwg.add(dwg.polygon([(x0,y0),(x1,y1),(x1,y2),(x0,y3)],fill=SAND,stroke=GOLD,stroke_width=4))
        if fixed:
            dwg.add(dwg.line((cx,cy-86),(cx,cy+86),stroke=BLUE,stroke_width=6,stroke_dasharray="15,8"))
            for yy in (cy-48,cy,cy+48): dwg.add(dwg.circle((cx,yy),8,fill=BLUE,stroke=PAPER,stroke_width=1.5))
        if ray:
            x0,y0=cx-40,cy-86; x1,y1=cx+48,cy+86
            dwg.add(dwg.line((x0,y0),(x1,y1),stroke=RED,stroke_width=7))
            uu=np.linspace(0.14,0.86,7 if dense else 3)
            for u in uu:
                px=x0+u*(x1-x0); py=y0+u*(y1-y0)
                if dense:
                    dwg.add(dwg.circle((px,py),6.5,fill=GOLD,stroke=PAPER,stroke_width=1.2))
                else:
                    s=7.5
                    dwg.add(dwg.polygon([(px,py-s),(px+s,py),(px,py+s),(px-s,py)],fill=RED,stroke=PAPER,stroke_width=1.2))
            if normal:
                vv=np.array([x1-x0,y1-y0],float); vv/=np.linalg.norm(vv); nn=np.array([-vv[1],vv[0]])
                mid=np.array([(x0+x1)/2,(y0+y1)/2])
                # True circle marks the transverse section; the short line gives its local axis.
                dwg.add(dwg.circle(tuple(mid),27,fill="#F7FBF9",stroke=GREEN,stroke_width=5))
                a=mid-22*nn; b=mid+22*nn
                dwg.add(dwg.line(tuple(a),tuple(b),stroke=NAVY,stroke_width=4))

    lens_icon(stages[0],fixed=True)
    lens_icon(stages[1],fixed=True,volume=True)
    lens_icon(stages[2],volume=True,ray=True)
    lens_icon(stages[3],volume=True,ray=True,normal=True)
    lens_icon(stages[4],volume=True,ray=True,normal=True,dense=True)

    labels=["Curved layer","Volume control","Path control","Projection control","Fine reference"]
    details=[
        "fixed | swept planes",
        "fixed | volume interp.",
        "ray | global x,y",
        "ray | normal",
        "ray | normal | fine",
    ]
    for cx,label,detail in zip(stages,labels,details):
        _svg_text(dwg,label,cx,425,size=43,weight="bold")
        _svg_text(dwg,detail,cx,475,size=34)

    ops=["volume interpolation","refracted path","transverse projection","depth refinement"]
    for i,label in enumerate(ops):
        x1=stages[i]+138; x2=stages[i+1]-138
        ln=dwg.line((x1,cy),(x2,cy),stroke=INK,stroke_width=5); ln['marker-end']=flow.get_funciri(); dwg.add(ln)
        _svg_text(dwg,label,0.5*(x1+x2),118,size=40)
    _export_svg(dwg, "Fig1c_control_sequence")

def figure2_validation_panels(summary: dict):
    # (a) Common plan view. The load pattern is common; the green annulus is present only for mounted lenses.
    body_r = 80.0; clear_r = 75.0
    dwg = _new_svg(1920, 1920)
    cx = 960; cy = 1080; scale = 7.7
    R = body_r*scale; Rc = clear_r*scale
    dwg.add(dwg.circle((cx,cy), R, fill=SAND, stroke=INK, stroke_width=8))
    dwg.add(dwg.circle((cx,cy), Rc, fill="none", stroke=BLUE, stroke_width=8, stroke_dasharray="28,18"))
    # Mounted-lens support ring: dash-dot so it remains identifiable in grayscale.
    Rs = 78*scale
    support = dwg.circle((cx,cy), Rs, fill="none", stroke=GREEN, stroke_width=18)
    support.update({"stroke-dasharray":"38,14,8,14"}); dwg.add(support)
    marker = _svg_arrow_marker(dwg, RED, "r2plan")
    for deg in range(0,360,60):
        th = math.radians(deg); a0 = math.radians(deg-15); a1 = math.radians(deg+15)
        ro = R; ri = R-68
        pts=[(cx+ro*math.cos(a0),cy+ro*math.sin(a0)),(cx+ro*math.cos(a1),cy+ro*math.sin(a1)),
             (cx+ri*math.cos(a1),cy+ri*math.sin(a1)),(cx+ri*math.cos(a0),cy+ri*math.sin(a0))]
        dwg.add(dwg.polygon(pts, fill=GOLD, stroke=INK, stroke_width=2, opacity=.90))
        p0=(cx+(R+130)*math.cos(th),cy+(R+130)*math.sin(th)); p1=(cx+(R-25)*math.cos(th),cy+(R-25)*math.sin(th))
        ln=dwg.line(p0,p1,stroke=RED,stroke_width=10); ln['marker-end']=marker.get_funciri(); dwg.add(ln)
    # Two-row legend placed above the optic. Color and line style are redundant.
    y0=125
    dwg.add(dwg.line((150,y0),(285,y0),stroke=RED,stroke_width=10)); _svg_text(dwg,"12 N inward resultant",315,y0+14,size=72,anchor="start")
    dwg.add(dwg.line((150,y0+92),(285,y0+92),stroke=BLUE,stroke_width=8,stroke_dasharray="28,18")); _svg_text(dwg,"150 mm clear aperture",315,y0+106,size=72,anchor="start")
    ln=dwg.line((1060,y0),(1195,y0),stroke=GREEN,stroke_width=12,stroke_dasharray="38,14,8,14"); dwg.add(ln)
    _svg_multiline(dwg,["annular support","mounted lenses only"],1225,y0-16,size=70,anchor="start",line=1.03)
    dwg.add(dwg.rect((1060,y0+65),(135,52),fill=GOLD,stroke=INK,stroke_width=2)); _svg_text(dwg,"30° traction sector",1225,y0+108,size=70,anchor="start")
    # Diameter dimension.
    yd=1790
    dwg.add(dwg.line((cx-R,yd),(cx+R,yd),stroke=INK,stroke_width=5));
    dwg.add(dwg.line((cx-R,yd-28),(cx-R,yd+28),stroke=INK,stroke_width=5)); dwg.add(dwg.line((cx+R,yd-28),(cx+R,yd+28),stroke=INK,stroke_width=5))
    _svg_text(dwg,"160 mm body diameter",cx,1870,size=72)
    _export_svg(dwg,"Fig2a_loading_plan")

    # (b) Side-view comparison. Plate above, mounted lens below.
    dwg = _new_svg(1920, 1920)
    marker = _svg_arrow_marker(dwg, RED, "r2side")
    # Plate.
    _svg_text(dwg,"flat plate",230,165,size=74,anchor="start",weight="bold")
    x0,x1=260,1660; y0,y1=300,565
    dwg.add(dwg.rect((x0,y0),(x1-x0,y1-y0),fill=SAND,stroke=INK,stroke_width=7))
    dwg.add(dwg.rect((x0,y0),(45,y1-y0),fill=GOLD,stroke=INK,stroke_width=2)); dwg.add(dwg.rect((x1-45,y0),(45,y1-y0),fill=GOLD,stroke=INK,stroke_width=2))
    for p0,p1 in [((x0-130,(y0+y1)/2),(x0+15,(y0+y1)/2)),((x1+130,(y0+y1)/2),(x1-15,(y0+y1)/2))]:
        ln=dwg.line(p0,p1,stroke=RED,stroke_width=10); ln['marker-end']=marker.get_funciri(); dwg.add(ln)
    dwg.add(dwg.line((x0+80,(y0+y1)/2),(x1-80,(y0+y1)/2),stroke=INK,stroke_width=3,stroke_dasharray="18,12"))
    _svg_text(dwg,"distributed side traction; resultant through midplane",960,665,size=70)
    # Mounted lens.
    _svg_text(dwg,"mounted curved lens",230,865,size=74,anchor="start",weight="bold")
    xs=np.linspace(260,1660,120); xn=(xs-960)/700
    top=1000+72*xn**2; bot=1370-38*xn**2
    poly=[(float(x),float(y)) for x,y in zip(xs,top)]+[(float(x),float(y)) for x,y in zip(xs[::-1],bot[::-1])]
    dwg.add(dwg.polygon(poly,fill=SAND,stroke=INK,stroke_width=7))
    for xedge,side in [(285,1),(1635,-1)]:
        yt=np.interp(xedge,xs,top); yb=np.interp(xedge,xs,bot); ym=(yt+yb)/2; h=(yb-yt)*0.12
        dwg.add(dwg.rect((xedge-25,ym-h/2),(50,h),fill=GOLD,stroke=INK,stroke_width=2))
        p0=(xedge-130 if side==1 else xedge+130,ym); p1=(xedge+12 if side==1 else xedge-12,ym)
        ln=dwg.line(p0,p1,stroke=RED,stroke_width=10); ln['marker-end']=marker.get_funciri(); dwg.add(ln)
        dwg.add(dwg.rect((xedge-34,yb+12),(68,85),fill=GREEN,stroke=INK,stroke_width=2))
    dwg.add(dwg.line((360,1185),(1560,1185),stroke=INK,stroke_width=3,stroke_dasharray="18,12"))
    _svg_text(dwg,"axial fraction 0.44 to 0.56",960,1500,size=70)
    # Support annotation with line-style sample and material values.
    dwg.add(dwg.line((410,1615),(560,1615),stroke=GREEN,stroke_width=14,stroke_dasharray="38,14,8,14"))
    _svg_text(dwg,"support radius 78 mm | width 4 mm",590,1630,size=70,anchor="start")
    _svg_text(dwg,"rubber 2.6 mm | modulus 5 MPa | tangential/normal 0.3",960,1735,size=70)
    _svg_text(dwg,"25 mm center thickness",960,1815,size=70)
    _export_svg(dwg,"Fig2b_loading_section")


# ---------- Data figure panels ----------
def depth_panel(route: str, stem: str):
    data=_read_csv("route_depth_convergence.csv")
    fig,ax=_wide_figure()
    styles={
        "plate":(INK,"o",":"),
        "moderate":(BLUE,"s","-"),
        "high":(RED,"^","--"),
    }
    labels={"plate":"Plate","moderate":"Representative","high":"Greater curvature"}
    for case,(color,marker,ls) in styles.items():
        mask=(data["route"]==route)&(data["case"]==case)
        if not np.any(mask): continue
        q=data["samples_per_fe_layer"][mask].astype(float); y=data["retardance_rms_error_mrad"][mask].astype(float)
        order=np.argsort(q)
        ax.plot(q[order],np.maximum(y[order],1e-10),marker=marker,ms=8,lw=2.2,ls=ls,color=color,label=labels[case])
    ax.axhline(1e-3,color=INK,lw=1.5,ls=(0,(5,4)))
    ax.text(1.04,3.0e-4,"10$^{-3}$ mrad tolerance",fontsize=18,color=INK)
    ax.set_xscale("log",base=2); ax.set_yscale("log")
    ax.set_xticks([1,2,4],labels=["1","2","4"])
    ax.set_xlabel("Samples per finite element layer")
    ax.set_ylabel("RMS residual to fine reference (mrad)")
    ax.grid(True,which="both",lw=0.6,color=LIGHT)
    ax.legend(frameon=False,fontsize=18,loc="best",handlelength=2.6,borderaxespad=0.8,labelspacing=0.45)
    _save_panel(fig,stem)


def figure4_mesh():
    d=_read_csv("mesh_sensitivity.csv")
    fig,ax=_full_wide_figure()
    elements=d["elements"].astype(float)
    route=d["curved_layer_same_mesh_rms_residual_mrad"].astype(float)
    field=d["reference_field_difference_to_finest_mrad"].astype(float)
    xpos=np.arange(len(elements),dtype=float)
    ax.plot(xpos,route,"o-",color=BLUE,lw=2.3,ms=8,label="Curved layer residual")
    valid_ref=np.isfinite(field)
    ax.plot(xpos[valid_ref],field[valid_ref],"s--",color=RED,lw=2.3,ms=8,label="Reference difference to finest mesh")
    for x,y,l in zip(xpos,route,d["mesh"]):
        ax.annotate(str(l),(x,y),xytext=(0,10),textcoords="offset points",ha="center",fontsize=10.5,color=INK)
    ax.set_xticks(xpos,[f"{int(v):,}" for v in elements])
    ax.set_xlabel("HEX8 elements")
    ax.set_ylabel("Retardance RMS difference (mrad)")
    ax.grid(True,axis="y",lw=0.6,color=LIGHT)
    ax.legend(frameon=False,fontsize=10.5,loc="upper right",borderaxespad=0.8,labelspacing=0.45)
    _save_panel(fig,"Fig4_mesh_sensitivity")


def scalar_map_panel(x,y,val,r,stem,label,limits,cmap="viridis",directors=None,zero_contour=False):
    fig,ax=_square_figure()
    x=np.asarray(x,float); y=np.asarray(y,float); val=np.asarray(val,float)
    im=_tri_field(ax,x,y,val,limits=limits,cmap=cmap,levels=33)
    if zero_contour and np.nanmin(val) < 0 < np.nanmax(val):
        tri=mtri.Triangulation(x,y)
        ax.tricontour(tri,val,levels=[0.0],colors=INK,linewidths=1.8,linestyles="--",zorder=7)
    if directors is not None:
        _directors(ax,x,y,directors,r,spacing=12.0)
    _format_pupil(ax,r)
    _add_colorbar(fig,ax,im,label)
    _save_panel(fig,stem,fixed_canvas=True)



def cyclic_axis_map_panel(x, y, theta_deg, retardance_mrad, r, stem):
    """Plot the slow-axis director with the Mohr/Jones half-angle convention.

    A principal optical axis is unoriented: theta and theta + 180 degrees
    describe the same director.  The stress/Jones solvers therefore report
    theta on [-90, 90) degrees, while the doubled angle 2*theta occupies the
    full [-180, 180) circle.  To preserve that circular topology during
    interpolation, cos(2 theta) and sin(2 theta) are interpolated first and
    theta is reconstructed with one half of atan2. HSV supplies the cyclic
    hue. Large single headed arrows mark the displayed azimuth branch at
    selected pupil points and remain legible after reduction to 0.33 text width.
    """
    fig, ax = _square_figure()
    x=np.asarray(x,float); y=np.asarray(y,float); theta_deg=np.asarray(theta_deg,float)
    theta=np.deg2rad(theta_deg)
    tri=mtri.Triangulation(x,y)
    c=np.cos(2.0*theta); s=np.sin(2.0*theta)
    ic=mtri.LinearTriInterpolator(tri,c); is_=mtri.LinearTriInterpolator(tri,s)
    n=401
    gx=np.linspace(-r,r,n); gy=np.linspace(-r,r,n)
    X,Y=np.meshgrid(gx,gy)
    C=np.ma.asarray(ic(X,Y)); S=np.ma.asarray(is_(X,Y))
    mask=np.hypot(X,Y)>r
    mask |= np.ma.getmaskarray(C) | np.ma.getmaskarray(S)
    C=np.ma.array(C,mask=mask); S=np.ma.array(S,mask=mask)
    mag=np.sqrt(C*C+S*S)
    C=C/np.ma.maximum(mag,1e-12); S=S/np.ma.maximum(mag,1e-12)
    phi=0.5*np.arctan2(S,C)
    phi_deg=np.degrees(phi)
    cmap=mpl.colormaps['hsv']
    norm=mpl.colors.Normalize(vmin=-90.0,vmax=90.0)
    im=ax.pcolormesh(X,Y,phi_deg,cmap=cmap,norm=norm,shading='auto',rasterized=True)

    # The axis field is 180 degree periodic, while each glyph shows the
    # representative azimuth on the plotted [-90, 90) branch. A single large
    # head gives an immediate visual direction cue without duplicating the
    # symbol at both ends. Density and head size are set for the final 0.33
    # text-width panel, not for the full-size source image.
    from matplotlib.patches import Polygon
    spacing=18.5
    qx,qy=np.meshgrid(np.arange(-r+0.50*spacing,r,spacing),
                      np.arange(-r+0.50*spacing,r,spacing))
    q=np.column_stack((qx.ravel(),qy.ravel()))
    q=q[np.hypot(q[:,0],q[:,1])<=0.88*r]
    tree=cKDTree(np.column_stack((x,y)))
    _,ids=tree.query(q)
    th=np.deg2rad(theta_deg[ids])
    half=0.112*r
    head_len=0.080*r
    head_halfwidth=0.052*r
    shafts=[]
    triangles=[]
    for (qx0,qy0),ang in zip(q,th):
        u=np.array([np.cos(ang),np.sin(ang)])
        v=np.array([-u[1],u[0]])
        centre=np.array([qx0,qy0])
        p1=centre-half*u
        p2=centre+half*u
        shafts.append([p1,p2])
        base=p2-head_len*u
        triangles.append(np.vstack((p2,base+head_halfwidth*v,base-head_halfwidth*v)))
    shafts=np.asarray(shafts)
    ax.add_collection(LineCollection(shafts,colors='white',linewidths=6.6,zorder=8,capstyle='round'))
    ax.add_collection(LineCollection(shafts,colors=INK,linewidths=4.1,zorder=9,capstyle='round'))
    for tri_pts in triangles:
        ax.add_patch(Polygon(tri_pts,closed=True,facecolor=INK,edgecolor='white',
                             linewidth=1.9,joinstyle='round',zorder=10))

    _format_pupil(ax,r)
    cb=fig.colorbar(im,ax=ax,fraction=0.060,pad=0.028,ticks=[-90,-45,0,45,90])
    cb.ax.tick_params(labelsize=27,width=0.9,length=4,colors=INK)
    cb.set_label('Slow axis azimuth (deg)',fontsize=30,color=INK)
    cb.ax.set_yticklabels([r'$-90$',r'$-45$',r'$0$',r'$45$',r'$90$'])
    cb.outline.set_linewidth(0.8)
    for lab in cb.ax.get_yticklabels():
        lab.set_color(INK)
    _save_panel(fig,stem)

def figure5_plate(summary):
    d=_load_points("plate"); r=_case_radius(summary,"plate")
    x=d["x_mm"].astype(float); y=d["y_mm"].astype(float)
    ret=d["curved_layer_retardance_mrad"].astype(float); axis=d["curved_layer_slow_axis_deg"].astype(float)
    opd=d["curved_layer_opd_nm"].astype(float); opd=opd-np.mean(opd)
    vmax=max(.1,math.ceil(float(np.max(ret))*10)/10)
    scalar_map_panel(x,y,ret,r,"Fig5a_plate_retardance","Retardance (mrad)",(0,vmax),"viridis")
    cyclic_axis_map_panel(x,y,axis,ret,r,"Fig5b_plate_axis")
    lim=float(np.max(np.abs(opd)))
    scalar_map_panel(x,y,opd,r,"Fig5c_plate_opd","Piston removed OPD (nm)",(-lim,lim),"viridis",zero_contour=True)


def route_fields(case, summary, fig_no):
    """Reference and curved layer fields, each with its own contour range.

    The projection control is intentionally omitted from the main
    field comparison. Its role is diagnostic and it appears in the residual/
    control panels instead of being given equal visual status to the proposed
    curved layer approximation.
    """
    d = _load_points(case); r = _case_radius(summary, case)
    x = d["x_mm"].astype(float); y = d["y_mm"].astype(float)
    for letter, route, name in [
        ("a", "reference", "reference"),
        ("b", "curved_layer", "curved_layer"),
    ]:
        values = d[f"{route}_retardance_mrad"].astype(float)
        vmax = max(0.1, math.ceil(float(np.max(values))*10.0)/10.0)
        scalar_map_panel(
            x, y, values, r,
            f"Fig{fig_no}{letter}_{name}_retardance",
            "Retardance (mrad)", (0, vmax), "viridis"
        )


def figure7_residuals(summary):
    d=_load_points("moderate"); r=_case_radius(summary,"moderate")
    x=d["x_mm"].astype(float); y=d["y_mm"].astype(float)
    ref=d["reference_retardance_mrad"].astype(float)
    cr=np.abs(d["curved_layer_retardance_mrad"].astype(float)-ref)
    ctrl=np.abs(d["projection_control_retardance_mrad"].astype(float)-ref)
    ref_peak=max(float(np.max(ref)),1e-30)
    cr_pct=100.0*cr/ref_peak
    ctrl_pct=100.0*ctrl/ref_peak
    # Independent ranges expose the spatial structure of each control residual.
    # The colorbar and reported maxima carry magnitude; Table 5 carries RMS error.
    cr_max=max(1e-4, math.ceil(float(np.max(cr_pct))*100.0)/100.0)
    ctrl_max=max(1e-5, math.ceil(float(np.max(ctrl_pct))*10000.0)/10000.0)
    scalar_map_panel(x,y,cr_pct,r,"Fig7a_curved_layer_retardance_residual",
                     "Residual / reference peak (%)",(0,cr_max),"viridis")
    scalar_map_panel(x,y,ctrl_pct,r,"Fig7b_projection_control_retardance_residual",
                     "Residual / reference peak (%)",(0,ctrl_max),"viridis")
    opd=d["curved_layer_opd_nm"].astype(float)-d["reference_opd_nm"].astype(float); opd-=np.mean(opd)
    lim=max(float(np.max(np.abs(opd))),1e-12)
    scalar_map_panel(x,y,opd,r,"Fig7c_curved_layer_opd_residual",
                     "OPD residual (nm)",(-lim,lim),"viridis",zero_contour=True)


def figure8_agreement():
    d=_load_points("moderate"); radial=_read_csv("radial_profiles.csv")
    # radial
    fig,ax=_wide_figure()
    style={"reference":(INK,"-"),"curved_layer":(BLUE,"--")}
    labels={"reference":"Reference","curved_layer":"Curved layer"}
    for route,(color,ls) in style.items():
        mask=(radial["case"]=="moderate")&(radial["route"]==route)&(radial["point_count"].astype(int)>0)
        rr=radial["radius_mm"][mask].astype(float); mean=radial["mean_retardance_mrad"][mask].astype(float); sd=radial["standard_deviation_mrad"][mask].astype(float)
        order=np.argsort(rr); rr=rr[order]; mean=mean[order]; sd=sd[order]
        ax.plot(rr,mean,color=color,ls=ls,lw=2.6,label=labels[route])
        if route=="reference": ax.fill_between(rr,np.maximum(mean-sd,0),mean+sd,facecolor=LIGHT,edgecolor=GRAY,alpha=.35,hatch="///",linewidth=.5)
    ax.set_xlabel("Pupil radius (mm)"); ax.set_ylabel("Retardance (mrad)")
    ax.grid(True,lw=.6,color=LIGHT); ax.legend(frameon=False,fontsize=18,borderaxespad=0.8,labelspacing=0.45)
    _save_panel(fig,"Fig8a_radial_profile",fixed_canvas=True)
    # scatter
    fig,ax=_wide_figure()
    ref=d["reference_retardance_mrad"].astype(float); layer=d["curved_layer_retardance_mrad"].astype(float)
    vmax=max(float(np.max(ref)),float(np.max(layer)))
    ax.scatter(ref,layer,s=16,facecolors="none",edgecolors=BLUE,linewidths=.8,alpha=.72)
    ax.plot([0,vmax],[0,vmax],color=INK,lw=1.8,ls="--")
    ax.set_xlim(0,vmax*1.02); ax.set_ylim(0,vmax*1.02)
    ax.set_xlabel("Reference (mrad)"); ax.set_ylabel("Curved layer (mrad)")
    ax.grid(True,lw=.6,color=LIGHT)
    _save_panel(fig,"Fig8b_pointwise_agreement",fixed_canvas=True)


def figure9_zernike():
    d=_read_csv("zernike_coefficients.csv")
    labels=list(d["label"][d["route"]=="reference"])
    y=np.arange(len(labels),dtype=float)
    fig,ax=plt.subplots(figsize=(7.2,4.9))
    fig.subplots_adjust(left=.29,right=.985,bottom=.15,top=.80)
    height=0.30
    styles=[
        ("reference",INK,PAPER,"-","",+0.16,"Reference"),
        ("curved_layer",BLUE,SAND,"--","///",-0.16,"Curved layer"),
    ]
    for route,edge,face,ls,hatch,off,label in styles:
        vals=d["coefficient_nm"][d["route"]==route].astype(float)
        ax.barh(y+off,vals,height=height,align="center",
                facecolor=face,edgecolor=edge,linewidth=2.0,linestyle=ls,
                hatch=hatch,label=label,zorder=3)
    ax.axvline(0,color=INK,lw=1.1,ls=":",zorder=2)
    ax.set_yticks(y,labels=labels,fontsize=10.5)
    ax.invert_yaxis(); ax.tick_params(axis="x",labelsize=10.5,colors=INK)
    ax.set_xlabel("Piston removed OPD Zernike coefficient (nm)",fontsize=12.5)
    ax.grid(True,axis="x",lw=.6,color=LIGHT,zorder=0)
    ax.legend(frameon=False,fontsize=10.5,ncol=2,loc="lower center",
              bbox_to_anchor=(0.5,1.04),borderaxespad=0.0,handlelength=2.8,columnspacing=2.0)
    _save_panel(fig,"Fig9_zernike")


def figure11_residuals(summary):
    d=_load_points("high"); r=_case_radius(summary,"high"); x=d["x_mm"].astype(float); y=d["y_mm"].astype(float)
    ref=d["reference_retardance_mrad"].astype(float)
    cr=np.abs(d["curved_layer_retardance_mrad"].astype(float)-ref)
    br=np.abs(d["projection_control_retardance_mrad"].astype(float)-ref)
    diff=.5*np.degrees(np.arctan2(np.sin(2*np.deg2rad(d["curved_layer_slow_axis_deg"].astype(float)-d["reference_slow_axis_deg"].astype(float))),
                                 np.cos(2*np.deg2rad(d["curved_layer_slow_axis_deg"].astype(float)-d["reference_slow_axis_deg"].astype(float)))))
    weighted=np.abs(diff)*(ref/max(float(np.max(ref)),1e-30))
    lim=max(float(np.max(weighted)),1e-12)
    scalar_map_panel(x,y,cr,r,"Fig11a_curved_layer_retardance_residual","Absolute residual (mrad)",(0,float(np.max(cr))),"viridis")
    scalar_map_panel(x,y,br,r,"Fig11b_projection_control_retardance_residual","Absolute residual (mrad)",(0,float(np.max(br))),"viridis")
    scalar_map_panel(x,y,weighted,r,"Fig11c_weighted_axis_difference","Weighted axis diff. (deg)",(0,lim),"viridis")


def figure12_applicability(summary):
    p=_read_csv("applicability_points.csv"); b=_read_csv("applicability_binned.csv")
    for letter,case,stem in [
        ("a","moderate","Fig12a_representative_displacement"),
        ("b","high","Fig12b_greater_curvature_displacement"),
    ]:
        mask=p["case"]==case; r=_case_radius(summary,case)
        values=p["normalized_offset_percent"][mask].astype(float)
        vmax=max(float(np.max(values)),1e-12)
        scalar_map_panel(p["x_mm"][mask].astype(float),p["y_mm"][mask].astype(float),values,r,
                         stem,r"Offset / $r_{CA}$ (%)",(0,vmax),"viridis")
    fig,ax=_third_wide_figure()
    for case,color,marker,ls,label in [("moderate",BLUE,"s","-","Representative"),("high",RED,"^","--","Greater curvature")]:
        mask=b["case"]==case
        xx=b["offset_center_percent"][mask].astype(float); med=b["error_median_mrad"][mask].astype(float); q25=b["error_q25_mrad"][mask].astype(float); q75=b["error_q75_mrad"][mask].astype(float)
        ax.plot(xx,med,color=color,marker=marker,ms=10,lw=2.8,ls=ls,label=label)
        ax.fill_between(xx,q25,q75,facecolor=PAPER,edgecolor=color,alpha=.45,hatch="///",linewidth=.8)
    ax.set_xlabel(r"Offset / $r_{CA}$ (%)"); ax.set_ylabel("Residual (mrad)")
    ax.grid(True,lw=.6,color=LIGHT); ax.legend(frameon=False,fontsize=25,loc="upper left",handlelength=2.4,borderaxespad=0.8,labelspacing=0.45)
    _save_panel(fig,"Fig12c_geometric_indicator")


def flat_plate_audit_panels(summary):
    # Optional audit assets, also independent panels.
    if not (OUTPUT_ROOT/"plate_midplane_stress.csv").exists(): return
    s=_read_csv("plate_midplane_stress.csv"); duv=_read_csv("liu_duv_points.csv"); r=_case_radius(summary,"plate")
    sx=s["x_mm"].astype(float); sy=s["y_mm"].astype(float)
    scalar_map_panel(sx,sy,s["sxx_mpa"].astype(float),r,"Audit_flat_plate_a_sxx",r"$\sigma_{xx}$ (MPa)",(-.008,-.001),"viridis")
    scalar_map_panel(sx,sy,s["syy_mpa"].astype(float),r,"Audit_flat_plate_b_syy",r"$\sigma_{yy}$ (MPa)",(-.008,-.001),"viridis")
    scalar_map_panel(sx,sy,np.abs(s["sxy_mpa"].astype(float)),r,"Audit_flat_plate_c_sxy",r"$|\sigma_{xy}|$ (MPa)",(0,.0012),"viridis")
    x=duv["x_mm"].astype(float); y=duv["y_mm"].astype(float)
    scalar_map_panel(x,y,duv["phase632_rad"].astype(float),r,"Audit_flat_plate_d_632","Phase retardance (rad)",(0,.006),"viridis")
    scalar_map_panel(x,y,duv["phase248_rad"].astype(float),r,"Audit_flat_plate_e_248","Phase retardance (rad)",(0,.020),"viridis")
    scalar_map_panel(x,y,duv["phase193_rad"].astype(float),r,"Audit_flat_plate_f_193","Phase retardance (rad)",(0,.032),"viridis")



def write_manifest():
    rows=[]
    for p in sorted(FIGURE_ROOT.glob("*.png")):
        rows.append({"panel":p.stem,"png":p.name,"pdf":p.with_suffix(".pdf").name if p.with_suffix(".pdf").exists() else "","svg":p.with_suffix(".svg").name if p.with_suffix(".svg").exists() else ""})
    with (FIGURE_ROOT/"figure_panels_manifest.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["panel","png","pdf","svg"]); w.writeheader(); w.writerows(rows)


def main():
    summary=_load_summary()
    figure1_method_panels()
    figure2_validation_panels(summary)
    depth_panel("refracted_ray","Fig3a_refracted_depth")
    depth_panel("curved_layer","Fig3b_curved_layer_depth")
    figure4_mesh()
    figure5_plate(summary)
    route_fields("moderate",summary,6)
    figure7_residuals(summary)
    figure8_agreement()
    figure9_zernike()
    route_fields("high",summary,10)
    figure11_residuals(summary)
    figure12_applicability(summary)
    flat_plate_audit_panels(summary)
    write_manifest()
    print(f"wrote publication panels to {FIGURE_ROOT}")


if __name__ == "__main__":
    main()

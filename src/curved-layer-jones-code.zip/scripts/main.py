#!/usr/bin/env python3

"""Self-contained reproduction engine for the mounted-lens stress-birefringence study.

This file contains the COMPLETE numerical chain used by the reproduction:

    geometry -> swept HEX8 mesh -> 3-D linear-elastic FEA -> nodal stress recovery
    -> curved layer / controlled comparison / refracted ray Jones calculations
    -> plot-ready CSV/JSON tables

No external FE result, NPZ, CSV, mesh, or solver file is required.  NumPy and
SciPy are the only numerical dependencies.  ``figures.py`` is intentionally
separate and performs no physics; it only reads the tables written here.

Two run modes are provided:

    python main.py --mode quick     # development/audit run
    python main.py --mode paper     # manuscript-resolution meshes
    python main.py --self-test      # analytical FE + optical invariants

Flat plate comparison note:
The published Corning 7980 case supplies the 160 mm diameter, 25 mm thickness,
six equally spaced 12 N side loads, and figure scales, but not the raw finite
element mesh, circumferential contact width, or nodal field.  The implementation
therefore regularizes each resultant over a 30 degree circumferential sector and
uses only the constraints required to remove rigid body motion.  No optical
amplitude factor is fitted to the published fields; the comparison is limited to
field morphology and numerical scale.

Key numerical safeguards:
  * exact 2x2x2 Gauss integration for every HEX8 stiffness matrix;
  * sparse assembled 3-D elasticity solve with Jacobi-preconditioned CG;
  * exact total 12-N resultant for each of the six radial load sectors;
  * optional annular elastic support for mounted-lens cases;
  * Gauss-point stress extrapolation plus volume-weighted nodal recovery;
  * reference Jones depth selected from explicit self-convergence;
  * true per FE layer refracted ray midpoint quadrature and path lengths;
  * mapped-vs-generic HEX8 locator, geometry, and C6 symmetry audits;
  * all figure data exported from this calculation rather than hard coded.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import platform
import statistics
from dataclasses import dataclass, replace
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.interpolate import LinearNDInterpolator
from scipy.spatial import cKDTree
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_ROOT = ROOT / "outputs"


# ===== merged from model.py =====

from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class OpticalConfig:
    body_diameter_mm: float
    center_thickness_mm: float
    radius_top_mm: float
    radius_bottom_mm: float
    clear_radius_mm: float = 75.0
    aperture_pitch_mm: float = 3.0
    refractive_index: float = 1.457
    q11_per_pa: float = 0.38e-12
    q12_per_pa: float = 2.60e-12
    wavelength_nm: float = 632.8

    @classmethod
    def from_mapping(cls, values: dict) -> "OpticalConfig":
        return cls(
            body_diameter_mm=float(values["D"]),
            center_thickness_mm=float(values["t0"]),
            radius_top_mm=float(values["R1"]),
            radius_bottom_mm=float(values["R2"]),
            clear_radius_mm=float(values.get("r_ca_mm", 75.0)),
            aperture_pitch_mm=float(values.get("aperture_pitch_mm", 3.0)),
            refractive_index=float(values.get("n0", 1.457)),
            q11_per_pa=float(values.get("q11", 0.38e-12)),
            q12_per_pa=float(values.get("q12", 2.60e-12)),
            wavelength_nm=float(values.get("lambda_nm", 632.8)),
        )


@dataclass(frozen=True)
class SweptMesh:
    nodes_mm: np.ndarray
    base_quads: np.ndarray
    stress_mpa: np.ndarray
    config: OpticalConfig
    case_name: str

    def __post_init__(self) -> None:
        nodes = np.asarray(self.nodes_mm, dtype=float)
        quads = np.asarray(self.base_quads, dtype=np.int32)
        stress = np.asarray(self.stress_mpa, dtype=float)
        if nodes.ndim != 3 or nodes.shape[0] < 2 or nodes.shape[2] != 3:
            raise ValueError("nodes_mm must have shape (n_planes, n_base_nodes, 3)")
        if quads.ndim != 2 or quads.shape[1] != 4:
            raise ValueError("base_quads must have shape (n_cells, 4)")
        if stress.shape != (*nodes.shape[:2], 6):
            raise ValueError("stress_mpa must have shape (n_planes, n_base_nodes, 6)")
        if not np.isfinite(nodes).all() or not np.isfinite(stress).all():
            raise ValueError("mesh coordinates and nodal stresses must be finite")
        if quads.min(initial=0) < 0 or quads.max(initial=-1) >= nodes.shape[1]:
            raise ValueError("base_quads contains an invalid node index")
        object.__setattr__(self, "nodes_mm", nodes)
        object.__setattr__(self, "base_quads", quads)
        object.__setattr__(self, "stress_mpa", stress)

    @property
    def n_layers(self) -> int:
        return self.nodes_mm.shape[0] - 1

    @property
    def n_cells(self) -> int:
        return self.base_quads.shape[0]

    def element_nodes(self, cells: np.ndarray, layers: np.ndarray) -> np.ndarray:
        cells = np.asarray(cells, dtype=np.int32)
        layers = np.asarray(layers, dtype=np.int32)
        ids = self.base_quads[cells]
        bottom = self.nodes_mm[layers[:, None], ids]
        top = self.nodes_mm[(layers + 1)[:, None], ids]
        return np.concatenate((bottom, top), axis=1)

    def element_stress(self, cells: np.ndarray, layers: np.ndarray) -> np.ndarray:
        cells = np.asarray(cells, dtype=np.int32)
        layers = np.asarray(layers, dtype=np.int32)
        ids = self.base_quads[cells]
        bottom = self.stress_mpa[layers[:, None], ids]
        top = self.stress_mpa[(layers + 1)[:, None], ids]
        return np.concatenate((bottom, top), axis=1)




@dataclass(frozen=True)
class OpticalResult:
    x_mm: np.ndarray
    y_mm: np.ndarray
    retardance_rad: np.ndarray
    retardation_nm: np.ndarray
    opd_nm: np.ndarray
    slow_axis_rad: np.ndarray
    ellipticity_rad: np.ndarray
    path_length_mm: np.ndarray
    jones_matrix: np.ndarray
    elapsed_s: float
    locator: str
    steps: int
    direct_hits: int
    neighbor_hits: int
    generic_fallback_hits: int
    inverse_attempts: int
    newton_iterations: int
    evaluated_samples: int = 0

    def as_columns(self) -> dict[str, np.ndarray]:
        columns = {
            "x_mm": self.x_mm,
            "y_mm": self.y_mm,
            "delta_rad": self.retardance_rad,
            "delta_mrad": 1000.0 * self.retardance_rad,
            "retardation_nm": self.retardation_nm,
            "opd_nm": self.opd_nm,
            "slow_axis_rad": self.slow_axis_rad,
            "slow_axis_deg": np.rad2deg(self.slow_axis_rad),
            "ellipticity_rad": self.ellipticity_rad,
            "ellipticity_deg": np.rad2deg(self.ellipticity_rad),
            "path_length_mm": self.path_length_mm,
        }
        return columns

# ===== merged from hex8.py =====

import numpy as np


HEX8_SIGNS = np.array(
    [
        (-1.0, -1.0, -1.0),
        (1.0, -1.0, -1.0),
        (1.0, 1.0, -1.0),
        (-1.0, 1.0, -1.0),
        (-1.0, -1.0, 1.0),
        (1.0, -1.0, 1.0),
        (1.0, 1.0, 1.0),
        (-1.0, 1.0, 1.0),
    ],
    dtype=float,
)
QUAD4_SIGNS = HEX8_SIGNS[:4, :2]


def shape_hex8(natural: np.ndarray) -> np.ndarray:
    q = np.atleast_2d(np.asarray(natural, dtype=float))
    factors = 1.0 + q[:, None, :] * HEX8_SIGNS[None, :, :]
    return np.prod(factors, axis=2) / 8.0


def shape_gradient_hex8(natural: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    q = np.atleast_2d(np.asarray(natural, dtype=float))
    xi = q[:, 0, None]
    eta = q[:, 1, None]
    zeta = q[:, 2, None]
    a = HEX8_SIGNS[:, 0][None, :]
    b = HEX8_SIGNS[:, 1][None, :]
    c = HEX8_SIGNS[:, 2][None, :]
    values = 0.125 * (1.0 + a * xi) * (1.0 + b * eta) * (1.0 + c * zeta)
    gradients = np.empty((q.shape[0], 8, 3), dtype=float)
    gradients[:, :, 0] = 0.125 * a * (1.0 + b * eta) * (1.0 + c * zeta)
    gradients[:, :, 1] = 0.125 * b * (1.0 + a * xi) * (1.0 + c * zeta)
    gradients[:, :, 2] = 0.125 * c * (1.0 + a * xi) * (1.0 + b * eta)
    return values, gradients


def shape_quad4(natural: np.ndarray) -> np.ndarray:
    q = np.atleast_2d(np.asarray(natural, dtype=float))
    factors = 1.0 + q[:, None, :] * QUAD4_SIGNS[None, :, :]
    return np.prod(factors, axis=2) / 4.0


def shape_gradient_quad4(natural: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    q = np.atleast_2d(np.asarray(natural, dtype=float))
    xi = q[:, 0, None]
    eta = q[:, 1, None]
    a = QUAD4_SIGNS[:, 0][None, :]
    b = QUAD4_SIGNS[:, 1][None, :]
    values = 0.25 * (1.0 + a * xi) * (1.0 + b * eta)
    gradients = np.empty((q.shape[0], 4, 2), dtype=float)
    gradients[:, :, 0] = 0.25 * a * (1.0 + b * eta)
    gradients[:, :, 1] = 0.25 * b * (1.0 + a * xi)
    return values, gradients


def _bbox_seed(nodes: np.ndarray, points: np.ndarray) -> np.ndarray:
    minimum = nodes.min(axis=1)
    maximum = nodes.max(axis=1)
    span = np.maximum(maximum - minimum, 1.0e-12)
    return np.clip(2.0 * (points - 0.5 * (minimum + maximum)) / span, -1.25, 1.25)



def _solve3x3_batch(matrix: np.ndarray, rhs: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Analytic batched solve for 3x3 systems, avoiding LAPACK batch-state overhead.

    Returns (solution, nonsingular_mask) for A x = b.
    """
    A = np.asarray(matrix, dtype=float)
    b = np.asarray(rhs, dtype=float)
    c0, c1, c2 = A[:, :, 0], A[:, :, 1], A[:, :, 2]
    c1xc2 = np.cross(c1, c2)
    det = np.einsum("ij,ij->i", c0, c1xc2, optimize=True)
    scale = np.maximum(np.max(np.abs(A), axis=(1,2)), 1.0)
    good = np.isfinite(det) & (np.abs(det) > 1.0e-15 * scale**3)
    x = np.full_like(b, np.nan, dtype=float)
    if np.any(good):
        d = det[good]
        bg = b[good]; c0g=c0[good]; c1g=c1[good]; c2g=c2[good]
        x[good,0] = np.einsum("ij,ij->i", bg, np.cross(c1g,c2g), optimize=True) / d
        x[good,1] = np.einsum("ij,ij->i", c0g, np.cross(bg,c2g), optimize=True) / d
        x[good,2] = np.einsum("ij,ij->i", c0g, np.cross(c1g,bg), optimize=True) / d
    return x, good

def inverse_hex8_batch(
    nodes: np.ndarray,
    points: np.ndarray,
    *,
    seed: np.ndarray | None = None,
    max_iterations: int = 20,
    step_tolerance: float = 5.0e-13,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Full physical 3D inverse map for a batch of independent HEX8 elements."""
    xnodes = np.asarray(nodes, dtype=float)
    targets = np.asarray(points, dtype=float)
    if xnodes.shape != (targets.shape[0], 8, 3):
        raise ValueError("nodes must have shape (n_points, 8, 3)")
    natural = _bbox_seed(xnodes, targets) if seed is None else np.asarray(seed, dtype=float).copy()
    active = np.ones(targets.shape[0], dtype=bool)
    solved = np.zeros(targets.shape[0], dtype=bool)
    iterations = np.zeros(targets.shape[0], dtype=np.int16)
    for _ in range(max_iterations):
        ids = np.flatnonzero(active)
        if ids.size == 0:
            break
        iterations[ids] += 1
        values, gradients = shape_gradient_hex8(natural[ids])
        residual = np.einsum("ni,nij->nj", values, xnodes[ids], optimize=True) - targets[ids]
        jacobian = np.einsum("nia,nib->nab", gradients, xnodes[ids], optimize=True)
        update, nonsingular = _solve3x3_batch(np.swapaxes(jacobian, 1, 2), residual)
        if np.any(~nonsingular):
            active[ids[~nonsingular]] = False
        finite = nonsingular & np.isfinite(update).all(axis=1)
        bad = ids[~finite]
        active[bad] = False
        good_ids = ids[finite]
        if good_ids.size == 0:
            continue
        natural[good_ids] -= update[finite]
        converged = np.linalg.norm(update[finite], axis=1) <= step_tolerance
        solved[good_ids[converged]] = True
        active[good_ids[converged]] = False
    values = shape_hex8(natural)
    residual = np.linalg.norm(np.einsum("ni,nij->nj", values, xnodes, optimize=True) - targets, axis=1)
    solved |= np.isfinite(natural).all(axis=1) & np.isfinite(residual) & (residual <= 1.0e-10)
    return natural, residual, solved, iterations


def inverse_quad4_batch(
    nodes_xy: np.ndarray,
    points_xy: np.ndarray,
    *,
    max_iterations: int = 16,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    nodes = np.asarray(nodes_xy, dtype=float)
    targets = np.asarray(points_xy, dtype=float)
    natural = np.zeros((targets.shape[0], 2), dtype=float)
    active = np.ones(targets.shape[0], dtype=bool)
    solved = np.zeros(targets.shape[0], dtype=bool)
    for _ in range(max_iterations):
        ids = np.flatnonzero(active)
        if ids.size == 0:
            break
        values, gradients = shape_gradient_quad4(natural[ids])
        residual = np.einsum("ni,nij->nj", values, nodes[ids], optimize=True) - targets[ids]
        jacobian = np.einsum("nia,nib->nab", gradients, nodes[ids], optimize=True)
        try:
            update = np.linalg.solve(np.swapaxes(jacobian, 1, 2), residual[..., None]).squeeze(-1)
        except np.linalg.LinAlgError:
            break
        finite = np.isfinite(update).all(axis=1)
        active[ids[~finite]] = False
        good_ids = ids[finite]
        natural[good_ids] -= update[finite]
        converged = np.linalg.norm(update[finite], axis=1) <= 1.0e-12
        solved[good_ids[converged]] = True
        active[good_ids[converged]] = False
    values = shape_quad4(natural)
    residual = np.linalg.norm(np.einsum("ni,nij->nj", values, nodes, optimize=True) - targets, axis=1)
    scale = np.maximum(np.ptp(nodes, axis=1).max(axis=1), 1.0)
    solved |= np.isfinite(natural).all(axis=1) & (residual <= 1.0e-11 * scale)
    return natural, residual, solved


def accepted_hex8(
    natural: np.ndarray,
    residual: np.ndarray,
    nodes: np.ndarray,
    *,
    natural_tolerance: float = 2.0e-6,
) -> np.ndarray:
    span = np.maximum(np.ptp(nodes, axis=1).max(axis=1), 1.0e-12)
    return (
        np.isfinite(natural).all(axis=1)
        & (np.abs(natural).max(axis=1) <= 1.0 + natural_tolerance)
        & np.isfinite(residual)
        & (residual <= np.maximum(1.0e-9, 1.0e-9 * span))
    )


def interpolate_hex8(natural: np.ndarray, nodal_values: np.ndarray) -> np.ndarray:
    values = shape_hex8(natural)
    return np.einsum("ni,nij->nj", values, np.asarray(nodal_values), optimize=True)

# ===== merged from geometry.py =====

from dataclasses import dataclass
import math

import numpy as np



@dataclass(frozen=True)
class RayBundle:
    start_mm: np.ndarray
    direction: np.ndarray
    length_mm: np.ndarray
    exit_mm: np.ndarray


def spherical_sag(radius_xy: np.ndarray, radius_of_curvature: float) -> np.ndarray:
    radius_xy = np.asarray(radius_xy, dtype=float)
    curvature_radius = abs(float(radius_of_curvature))
    if curvature_radius <= 1.0e-15:
        return np.zeros_like(radius_xy)
    if np.any(radius_xy > curvature_radius):
        raise ValueError("surface radius of curvature is smaller than the sampled aperture radius")
    return curvature_radius - np.sqrt(np.maximum(curvature_radius**2 - radius_xy**2, 0.0))


def surface_heights(radius_xy: np.ndarray, config: OpticalConfig) -> tuple[np.ndarray, np.ndarray]:
    radius_xy = np.asarray(radius_xy, dtype=float)
    top_sag = spherical_sag(radius_xy, config.radius_top_mm)
    bottom_sag = spherical_sag(radius_xy, config.radius_bottom_mm)
    top = config.center_thickness_mm + (-top_sag if config.radius_top_mm >= 0.0 else top_sag)
    bottom = bottom_sag if config.radius_bottom_mm >= 0.0 else -bottom_sag
    return bottom, top


def _surface_slope(radius_xy: np.ndarray, radius_of_curvature: float, *, top: bool) -> np.ndarray:
    radius_xy = np.asarray(radius_xy, dtype=float)
    curvature_radius = abs(float(radius_of_curvature))
    if curvature_radius <= 1.0e-15:
        return np.zeros_like(radius_xy)
    denominator = np.sqrt(np.maximum(curvature_radius**2 - radius_xy**2, 1.0e-18))
    sag_slope = radius_xy / denominator
    if top:
        return -sag_slope if radius_of_curvature >= 0.0 else sag_slope
    return sag_slope if radius_of_curvature >= 0.0 else -sag_slope


def _upper_normal_into_air(x_mm: np.ndarray, y_mm: np.ndarray, slope: np.ndarray) -> np.ndarray:
    radial = np.hypot(x_mm, y_mm)
    dzdx = np.divide(slope * x_mm, radial, out=np.zeros_like(radial), where=radial > 1.0e-15)
    dzdy = np.divide(slope * y_mm, radial, out=np.zeros_like(radial), where=radial > 1.0e-15)
    normal = np.column_stack((-dzdx, -dzdy, np.ones_like(radial)))
    return normal / np.linalg.norm(normal, axis=1, keepdims=True)


def refract(
    incident: np.ndarray,
    normal_into_incident_medium: np.ndarray,
    n_incident: float,
    n_transmitted: float,
) -> tuple[np.ndarray, np.ndarray]:
    incident = np.asarray(incident, dtype=float)
    normal = np.asarray(normal_into_incident_medium, dtype=float)
    eta = float(n_incident) / float(n_transmitted)
    cosine = -np.sum(incident * normal, axis=1)
    discriminant = 1.0 - eta**2 * (1.0 - cosine**2)
    valid = discriminant >= -1.0e-13
    direction = np.full_like(incident, np.nan)
    if np.any(valid):
        root = np.sqrt(np.maximum(discriminant[valid], 0.0))
        direction[valid] = (
            eta * incident[valid]
            + (eta * cosine[valid] - root)[:, None] * normal[valid]
        )
        direction[valid] /= np.linalg.norm(direction[valid], axis=1, keepdims=True)
    return direction, valid


def trace_collimated_rays(x_mm: np.ndarray, y_mm: np.ndarray, config: OpticalConfig) -> RayBundle:
    x_mm = np.asarray(x_mm, dtype=float)
    y_mm = np.asarray(y_mm, dtype=float)
    radial = np.hypot(x_mm, y_mm)
    bottom, top = surface_heights(radial, config)
    normal = _upper_normal_into_air(x_mm, y_mm, _surface_slope(radial, config.radius_top_mm, top=True))
    incident = np.zeros((x_mm.size, 3), dtype=float)
    incident[:, 2] = -1.0
    direction, valid = refract(incident, normal, 1.0, config.refractive_index)
    if not np.all(valid):
        raise RuntimeError(f"entry refraction failed for {np.count_nonzero(~valid)} rays")
    start = np.column_stack((x_mm, y_mm, top))

    thickness = top - bottom
    lower = np.zeros_like(x_mm)
    upper = np.maximum(thickness / np.maximum(-direction[:, 2], 1.0e-12), 1.0e-6) * 1.6

    def signed_height(distance: np.ndarray) -> np.ndarray:
        points = start + direction * distance[:, None]
        lower_surface, _ = surface_heights(np.hypot(points[:, 0], points[:, 1]), config)
        return points[:, 2] - lower_surface

    bracket = signed_height(upper) <= 0.0
    for _ in range(20):
        if np.all(bracket):
            break
        upper[~bracket] *= 2.0
        bracket = signed_height(upper) <= 0.0
    if not np.all(bracket):
        raise RuntimeError(f"exit surface was not bracketed for {np.count_nonzero(~bracket)} rays")
    for _ in range(56):
        midpoint = 0.5 * (lower + upper)
        above = signed_height(midpoint) > 0.0
        lower[above] = midpoint[above]
        upper[~above] = midpoint[~above]
    exit_points = start + direction * upper[:, None]
    exit_radius = np.hypot(exit_points[:, 0], exit_points[:, 1])
    if np.any(exit_radius > 0.5 * config.body_diameter_mm + 1.0e-7):
        raise RuntimeError("one or more rays leave through the cylindrical side wall")
    return RayBundle(start, direction, upper, exit_points)


def aperture_grid(radius_mm: float, pitch_mm: float) -> tuple[np.ndarray, np.ndarray]:
    x: list[float] = []
    y: list[float] = []
    for radial in np.arange(0.0, radius_mm + 1.0e-12, pitch_mm):
        if radial <= 1.0e-15:
            x.append(0.0)
            y.append(0.0)
            continue
        raw = max(6, int(math.ceil(2.0 * math.pi * radial / pitch_mm)))
        count = int(6 * math.ceil(raw / 6))
        angle = 2.0 * math.pi * np.arange(count) / count
        x.extend((radial * np.cos(angle)).tolist())
        y.extend((radial * np.sin(angle)).tolist())
    return np.asarray(x), np.asarray(y)


def _disk_logical(points_xy: np.ndarray, radius_mm: float) -> tuple[np.ndarray, np.ndarray]:
    normalized = np.asarray(points_xy, dtype=float) / float(radius_mm)
    x = normalized[:, 0]
    y = normalized[:, 1]
    radial = np.hypot(x, y)
    angle = np.arctan2(y, x)
    u = np.zeros_like(x)
    v = np.zeros_like(y)
    right = (angle >= -0.25 * np.pi) & (angle < 0.25 * np.pi)
    top = (angle >= 0.25 * np.pi) & (angle < 0.75 * np.pi)
    left_top = angle >= 0.75 * np.pi
    left_bottom = angle < -0.75 * np.pi
    bottom = ~(right | top | left_top | left_bottom)
    u[right] = radial[right]
    v[right] = angle[right] * u[right] / (0.25 * np.pi)
    v[top] = radial[top]
    u[top] = (0.5 * np.pi - angle[top]) * v[top] / (0.25 * np.pi)
    u[left_top] = -radial[left_top]
    v[left_top] = (angle[left_top] - np.pi) * u[left_top] / (0.25 * np.pi)
    u[left_bottom] = -radial[left_bottom]
    v[left_bottom] = (angle[left_bottom] + np.pi) * u[left_bottom] / (0.25 * np.pi)
    v[bottom] = -radial[bottom]
    u[bottom] = -(angle[bottom] + 0.5 * np.pi) * v[bottom] / (0.25 * np.pi)
    return u, v


def _mesh_surface_height(mesh: SweptMesh, points_xy: np.ndarray, plane: int) -> np.ndarray:
    points = np.asarray(points_xy, dtype=float)
    side_nodes = int(round(np.sqrt(mesh.nodes_mm.shape[1])))
    side_cells = side_nodes - 1
    radius_mm = float(np.max(np.hypot(mesh.nodes_mm[0, :, 0], mesh.nodes_mm[0, :, 1])))
    u, v = _disk_logical(points, radius_mm)
    scale = 0.5 * side_cells
    ci = np.clip((u + 1.0) * scale, 0.0, np.nextafter(float(side_cells), 0.0))
    cj = np.clip((v + 1.0) * scale, 0.0, np.nextafter(float(side_cells), 0.0))
    col = np.floor(ci).astype(np.int32)
    row = np.floor(cj).astype(np.int32)
    cells = row * side_cells + col
    natural = np.full((points.shape[0], 2), np.nan)
    resolved = np.zeros(points.shape[0], dtype=bool)
    for dr, dc in ((0, 0), (0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1)):
        ids = np.flatnonzero(~resolved)
        if ids.size == 0:
            break
        candidate_col = col[ids] + dc
        candidate_row = row[ids] + dr
        valid = (
            (candidate_col >= 0)
            & (candidate_col < side_cells)
            & (candidate_row >= 0)
            & (candidate_row < side_cells)
        )
        if not np.any(valid):
            continue
        point_ids = ids[valid]
        candidate_cells = candidate_row[valid] * side_cells + candidate_col[valid]
        quad_ids = mesh.base_quads[candidate_cells]
        quad_xy = mesh.nodes_mm[plane, quad_ids, :2]
        q, residual, solved = inverse_quad4_batch(quad_xy, points[point_ids])
        accepted = solved & (np.abs(q).max(axis=1) <= 1.0 + 2.0e-6) & (residual <= 1.0e-8)
        hit = point_ids[accepted]
        cells[hit] = candidate_cells[accepted]
        natural[hit] = q[accepted]
        resolved[hit] = True
    if not np.all(resolved):
        raise LookupError(f"surface locator missed {np.count_nonzero(~resolved)} points")
    quad_ids = mesh.base_quads[cells]
    z = mesh.nodes_mm[plane, quad_ids, 2]
    return np.einsum("ni,ni->n", shape_quad4(natural), z, optimize=True)


def conform_ray_segments_to_mesh(mesh: SweptMesh, rays: RayBundle) -> RayBundle:
    """Intersect straight internal rays with the actual FE top and bottom faces."""

    def points(distance: np.ndarray) -> np.ndarray:
        return rays.start_mm + distance[:, None] * rays.direction

    def signed_top(distance: np.ndarray) -> np.ndarray:
        p = points(distance)
        return p[:, 2] - _mesh_surface_height(mesh, p[:, :2], -1)

    def signed_bottom(distance: np.ndarray) -> np.ndarray:
        p = points(distance)
        return p[:, 2] - _mesh_surface_height(mesh, p[:, :2], 0)

    def bisect(lower: np.ndarray, upper: np.ndarray, signed) -> np.ndarray:
        f_lower = signed(lower)
        f_upper = signed(upper)
        if np.any(f_lower < 0.0) or np.any(f_upper > 0.0):
            raise RuntimeError("FE surface intersection was not bracketed")
        for _ in range(48):
            midpoint = 0.5 * (lower + upper)
            above = signed(midpoint) > 0.0
            lower[above] = midpoint[above]
            upper[~above] = midpoint[~above]
        return 0.5 * (lower + upper)

    margin = np.full(rays.length_mm.shape, 0.5)
    entry_lower = -margin.copy()
    entry_upper = margin.copy()
    for _ in range(8):
        bad = (signed_top(entry_lower) < 0.0) | (signed_top(entry_upper) > 0.0)
        if not np.any(bad):
            break
        margin[bad] *= 2.0
        entry_lower[bad] = -margin[bad]
        entry_upper[bad] = margin[bad]
    entry = bisect(entry_lower, entry_upper, signed_top)

    margin[:] = 0.5
    exit_lower = rays.length_mm - margin
    exit_upper = rays.length_mm + margin
    for _ in range(8):
        bad = (signed_bottom(exit_lower) < 0.0) | (signed_bottom(exit_upper) > 0.0)
        if not np.any(bad):
            break
        margin[bad] *= 2.0
        exit_lower[bad] = rays.length_mm[bad] - margin[bad]
        exit_upper[bad] = rays.length_mm[bad] + margin[bad]
    exit_distance = bisect(exit_lower, exit_upper, signed_bottom)
    if np.any(exit_distance <= entry):
        raise RuntimeError("one or more FE-conforming ray segments have nonpositive length")
    start = points(entry)
    exit_points = points(exit_distance)
    return RayBundle(start, rays.direction.copy(), exit_distance - entry, exit_points)


def sample_ray_midpoints(rays: RayBundle, steps: int) -> np.ndarray:
    fractions = (np.arange(steps, dtype=float) + 0.5) / float(steps)
    return rays.start_mm[None, :, :] + (
        fractions[:, None, None] * rays.length_mm[None, :, None] * rays.direction[None, :, :]
    )

# ===== merged from optics.py =====

from dataclasses import dataclass
import math

import numpy as np



@dataclass(frozen=True)
class JonesState:
    retardance_rad: np.ndarray
    retardation_nm: np.ndarray
    opd_nm: np.ndarray
    axis_rad: np.ndarray
    ellipticity_rad: np.ndarray
    matrix: np.ndarray


def transverse_basis(direction: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    direction = np.asarray(direction, dtype=float)
    seed_x = np.array((1.0, 0.0, 0.0))
    seed_y = np.array((0.0, 1.0, 0.0))
    first = seed_x - np.sum(direction * seed_x, axis=1, keepdims=True) * direction
    use_y = np.linalg.norm(first, axis=1) < 1.0e-10
    first[use_y] = seed_y - np.sum(direction[use_y] * seed_y, axis=1, keepdims=True) * direction[use_y]
    first /= np.linalg.norm(first, axis=1, keepdims=True)
    second = np.cross(direction, first)
    second /= np.linalg.norm(second, axis=1, keepdims=True)
    return first, second


def rotate_voigt_to_ray(stress_mpa: np.ndarray, direction: np.ndarray) -> np.ndarray:
    stress = np.asarray(stress_mpa, dtype=float)
    tensor = np.zeros((stress.shape[0], 3, 3), dtype=float)
    tensor[:, 0, 0] = stress[:, 0]
    tensor[:, 1, 1] = stress[:, 1]
    tensor[:, 2, 2] = stress[:, 2]
    tensor[:, 0, 1] = tensor[:, 1, 0] = stress[:, 3]
    tensor[:, 1, 2] = tensor[:, 2, 1] = stress[:, 4]
    tensor[:, 0, 2] = tensor[:, 2, 0] = stress[:, 5]
    first, second = transverse_basis(direction)
    transform = np.stack((first, second, direction), axis=2)
    return np.einsum("pji,pjk,pkl->pil", transform, tensor, transform, optimize=True)


def _wrap_axis(angle: np.ndarray) -> np.ndarray:
    """Wrap an unoriented optical axis to [-pi/2, pi/2).

    The physical director is pi-periodic.  Equivalently, the doubled angle
    2*theta occupies the full [-pi, pi) circle used by the Mohr/Jones
    half-angle relation.
    """
    return (np.asarray(angle) + 0.5 * math.pi) % math.pi - 0.5 * math.pi


def stress_optic_state(ray_stress_mpa: np.ndarray, config: OpticalConfig) -> tuple[np.ndarray, ...]:
    stress = np.asarray(ray_stress_mpa, dtype=float)
    sx = stress[:, 0, 0]
    sy = stress[:, 1, 1]
    shear = stress[:, 0, 1]
    mean = 0.5 * (sx + sy)
    radius = np.hypot(0.5 * (sx - sy), shear)
    sigma_1 = mean + radius
    sigma_2 = mean - radius
    theta_1 = 0.5 * np.arctan2(2.0 * shear, sx - sy)
    sigma_z = stress[:, 2, 2]
    half_n3 = 0.5 * config.refractive_index**3
    dn_1 = -half_n3 * (
        config.q11_per_pa * sigma_1 * 1.0e6
        + config.q12_per_pa * (sigma_2 + sigma_z) * 1.0e6
    )
    dn_2 = -half_n3 * (
        config.q11_per_pa * sigma_2 * 1.0e6
        + config.q12_per_pa * (sigma_1 + sigma_z) * 1.0e6
    )
    first_is_slow = dn_1 >= dn_2
    theta_slow = _wrap_axis(np.where(first_is_slow, theta_1, theta_1 + 0.5 * math.pi))
    dn_slow = np.where(first_is_slow, dn_1, dn_2)
    dn_fast = np.where(first_is_slow, dn_2, dn_1)
    dn_mean = 0.5 * (dn_1 + dn_2)
    return dn_slow, dn_fast, dn_mean, theta_slow


def integrate_jones(
    sampled_stress_mpa: np.ndarray,
    rays: RayBundle,
    config: OpticalConfig,
    *,
    projection_direction: np.ndarray | None = None,
) -> JonesState:
    """Integrate ordered linear-retarder increments on a declared transverse basis.

    ``rays.direction`` controls the physical path length. ``projection_direction``
    controls the stress and Jones transverse frame.  They are identical for the
    refracted ray calculation. Keeping them separate permits controlled hybrid
    calculations that isolate path sampling from transverse-frame projection.
    """
    samples = np.asarray(sampled_stress_mpa, dtype=float)
    steps, ray_count = samples.shape[:2]
    basis_direction = rays.direction if projection_direction is None else np.asarray(
        projection_direction, dtype=float
    )
    if basis_direction.shape != (ray_count, 3):
        raise ValueError("projection_direction must have shape (n_rays, 3)")
    norms = np.linalg.norm(basis_direction, axis=1, keepdims=True)
    if np.any(norms <= 1.0e-14):
        raise ValueError("projection directions must be nonzero")
    basis_direction = basis_direction / norms
    repeated_direction = np.broadcast_to(
        basis_direction, (steps, ray_count, 3)
    ).reshape(-1, 3)
    ray_stress = rotate_voigt_to_ray(samples.reshape(-1, 6), repeated_direction)
    dn_slow, dn_fast, dn_mean, theta = stress_optic_state(ray_stress, config)
    dn_slow = dn_slow.reshape(steps, ray_count)
    dn_fast = dn_fast.reshape(steps, ray_count)
    dn_mean = dn_mean.reshape(steps, ray_count)
    theta = theta.reshape(steps, ray_count)
    ds_m = rays.length_mm * 1.0e-3 / float(steps)
    wavelength_m = config.wavelength_nm * 1.0e-9

    jones = np.zeros((ray_count, 2, 2), dtype=complex)
    jones[:, 0, 0] = 1.0
    jones[:, 1, 1] = 1.0
    for step in range(steps):
        c = np.cos(theta[step])
        s = np.sin(theta[step])
        slow_phase = np.exp(1j * 2.0 * math.pi * dn_slow[step] * ds_m / wavelength_m)
        fast_phase = np.exp(1j * 2.0 * math.pi * dn_fast[step] * ds_m / wavelength_m)
        increment = np.empty_like(jones)
        increment[:, 0, 0] = c * c * slow_phase + s * s * fast_phase
        increment[:, 0, 1] = c * s * (slow_phase - fast_phase)
        increment[:, 1, 0] = increment[:, 0, 1]
        increment[:, 1, 1] = s * s * slow_phase + c * c * fast_phase
        jones = np.einsum("pij,pjk->pik", increment, jones, optimize=True)

    determinant = jones[:, 0, 0] * jones[:, 1, 1] - jones[:, 0, 1] * jones[:, 1, 0]
    determinant_sqrt = np.sqrt(np.abs(determinant)) * np.exp(0.5j * np.angle(determinant))
    normalized = jones / determinant_sqrt[:, None, None]
    trace = normalized[:, 0, 0] + normalized[:, 1, 1]
    flip = np.real(trace) < 0.0
    normalized[flip] *= -1.0
    trace = normalized[:, 0, 0] + normalized[:, 1, 1]
    retardance = 2.0 * np.arccos(np.clip(np.real(trace) / 2.0, 0.0, 1.0))

    eigenvalues, eigenvectors = np.linalg.eig(normalized)
    phases = np.angle(eigenvalues)
    slow_index = np.argmax(phases, axis=1)
    slow_vector = eigenvectors[np.arange(ray_count), :, slow_index]
    first, second = transverse_basis(basis_direction)
    global_x = slow_vector[:, 0] * first[:, 0] + slow_vector[:, 1] * second[:, 0]
    global_y = slow_vector[:, 0] * first[:, 1] + slow_vector[:, 1] * second[:, 1]
    projected_norm = np.sqrt(np.abs(global_x) ** 2 + np.abs(global_y) ** 2)
    global_x = np.divide(global_x, projected_norm, out=np.zeros_like(global_x), where=projected_norm > 1.0e-14)
    global_y = np.divide(global_y, projected_norm, out=np.zeros_like(global_y), where=projected_norm > 1.0e-14)
    stokes_1 = np.abs(global_x) ** 2 - np.abs(global_y) ** 2
    stokes_2 = 2.0 * np.real(global_x * np.conj(global_y))
    axis = _wrap_axis(0.5 * np.arctan2(stokes_2, stokes_1))
    # All three Stokes components must be formed from the same normalized
    # aperture-plane representation.  Mixing local-basis S3 with projected
    # S1 and S2 changes the reported ellipticity for oblique rays.
    stokes_3 = -2.0 * np.imag(global_x * np.conj(global_y))
    ellipticity = 0.5 * np.arcsin(np.clip(stokes_3, -1.0, 1.0))
    degenerate = (retardance < 1.0e-10) | (projected_norm <= 1.0e-14)
    axis[degenerate] = 0.0
    ellipticity[degenerate] = 0.0

    retardation_nm = retardance / (2.0 * math.pi) * config.wavelength_nm
    opd_nm = np.sum(dn_mean * ds_m[None, :] / wavelength_m * config.wavelength_nm, axis=0)
    return JonesState(retardance, retardation_nm, opd_nm, axis, ellipticity, normalized)


def jones_operator_distance(first: np.ndarray, second: np.ndarray) -> np.ndarray:
    """Principal polarization-operator distance, invariant to common phase."""
    a = np.asarray(first, dtype=complex)
    b = np.asarray(second, dtype=complex)
    if a.shape != b.shape or a.ndim != 3 or a.shape[1:] != (2, 2):
        raise ValueError("Jones arrays must share shape (n, 2, 2)")
    relative = np.einsum("nij,nkj->nik", a, np.conj(b), optimize=True)
    determinant = relative[:, 0, 0] * relative[:, 1, 1] - relative[:, 0, 1] * relative[:, 1, 0]
    relative /= (
        np.sqrt(np.abs(determinant)) * np.exp(0.5j * np.angle(determinant))
    )[:, None, None]
    scalar = 0.5 * np.real(relative[:, 0, 0] + relative[:, 1, 1])
    vector_z = 0.5 * np.imag(relative[:, 0, 0] - relative[:, 1, 1])
    vector_norm = np.sqrt(
        vector_z * vector_z
        + 0.5 * (np.abs(relative[:, 0, 1]) ** 2 + np.abs(relative[:, 1, 0]) ** 2)
    )
    return 2.0 * np.arctan2(vector_norm, np.abs(scalar))

# ===== merged from locators.py =====

from dataclasses import dataclass

import numpy as np
from scipy.spatial import cKDTree



@dataclass(frozen=True)
class LocatedPoints:
    cells: np.ndarray
    layers: np.ndarray
    natural: np.ndarray
    direct_hits: int
    neighbor_hits: int
    generic_fallback_hits: int
    inverse_attempts: int
    newton_iterations: int


class _ExactLocator:
    def __init__(self, mesh: SweptMesh):
        self.mesh = mesh

    def interpolate_stress(self, located: LocatedPoints) -> np.ndarray:
        nodal = self.mesh.element_stress(located.cells, located.layers)
        return interpolate_hex8(located.natural, nodal)

    def _try_candidates(
        self,
        points: np.ndarray,
        candidate_cells: np.ndarray,
        candidate_layers: np.ndarray,
        *,
        seed: np.ndarray | None = None,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        nodes = self.mesh.element_nodes(candidate_cells, candidate_layers)
        natural, residual, converged, iterations = inverse_hex8_batch(nodes, points, seed=seed)
        return natural, converged & accepted_hex8(natural, residual, nodes), iterations


class GenericHex8Locator(_ExactLocator):
    """Center-tree search followed by the full physical HEX8 inverse map."""

    def __init__(self, mesh: SweptMesh, *, candidate_count: int = 32):
        super().__init__(mesh)
        cell = np.tile(np.arange(mesh.n_cells, dtype=np.int32), mesh.n_layers)
        layer = np.repeat(np.arange(mesh.n_layers, dtype=np.int32), mesh.n_cells)
        nodes = mesh.element_nodes(cell, layer)
        self._cells = cell
        self._layers = layer
        self._minimum = nodes.min(axis=1)
        self._maximum = nodes.max(axis=1)
        self._tree = cKDTree(nodes.mean(axis=1))
        self._candidate_count = min(int(candidate_count), cell.size)

    def locate(self, points: np.ndarray) -> LocatedPoints:
        targets = np.asarray(points, dtype=float)
        _, candidates = self._tree.query(targets, k=self._candidate_count, workers=1)
        if candidates.ndim == 1:
            candidates = candidates[:, None]
        cells = np.full(targets.shape[0], -1, dtype=np.int32)
        layers = np.full_like(cells, -1)
        natural = np.full((targets.shape[0], 3), np.nan)
        unresolved = np.ones(targets.shape[0], dtype=bool)
        inverse_attempts = 0
        newton_iterations = 0
        for rank in range(candidates.shape[1]):
            ids = np.flatnonzero(unresolved)
            if ids.size == 0:
                break
            element = candidates[ids, rank]
            bbox = np.all(targets[ids] >= self._minimum[element] - 1.0e-9, axis=1) & np.all(
                targets[ids] <= self._maximum[element] + 1.0e-9, axis=1
            )
            if not np.any(bbox):
                continue
            point_ids = ids[bbox]
            element = element[bbox]
            q, accepted, iterations = self._try_candidates(
                targets[point_ids], self._cells[element], self._layers[element]
            )
            inverse_attempts += point_ids.size
            newton_iterations += int(iterations.sum())
            hit_ids = point_ids[accepted]
            hit_element = element[accepted]
            cells[hit_ids] = self._cells[hit_element]
            layers[hit_ids] = self._layers[hit_element]
            natural[hit_ids] = q[accepted]
            unresolved[hit_ids] = False
        if np.any(unresolved):
            raise LookupError(f"generic locator missed {np.count_nonzero(unresolved)} points")
        return LocatedPoints(
            cells, layers, natural, targets.shape[0], 0, 0, inverse_attempts, newton_iterations
        )


class TopologyHex8Locator(_ExactLocator):
    """Logical cell nomination with exact physical inversion and guarded rescue."""

    def __init__(self, mesh: SweptMesh, *, mapped_seed: bool = False):
        super().__init__(mesh)
        side_nodes = int(round(np.sqrt(mesh.nodes_mm.shape[1])))
        if side_nodes * side_nodes != mesh.nodes_mm.shape[1]:
            raise ValueError("topology locator requires a structured square-to-disk base grid")
        self._side_cells = side_nodes - 1
        expected = np.empty_like(mesh.base_quads)
        row = 0
        for j in range(self._side_cells):
            for i in range(self._side_cells):
                node = j * side_nodes + i
                expected[row] = (node, node + 1, node + 1 + side_nodes, node + side_nodes)
                row += 1
        if not np.array_equal(expected, mesh.base_quads):
            raise ValueError("base-quadrilateral ordering is not the declared structured topology")
        self._radius_mm = float(np.max(np.hypot(mesh.nodes_mm[0, :, 0], mesh.nodes_mm[0, :, 1])))
        self._mapped_seed = bool(mapped_seed)
        self._generic_guard = GenericHex8Locator(mesh)

    def _base_logical(self, points_xy: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        normalized = np.asarray(points_xy, dtype=float) / self._radius_mm
        x = normalized[:, 0]
        y = normalized[:, 1]
        radial = np.hypot(x, y)
        angle = np.arctan2(y, x)
        u = np.zeros_like(x)
        v = np.zeros_like(y)
        right = (angle >= -0.25 * np.pi) & (angle < 0.25 * np.pi)
        top = (angle >= 0.25 * np.pi) & (angle < 0.75 * np.pi)
        left_top = angle >= 0.75 * np.pi
        left_bottom = angle < -0.75 * np.pi
        bottom = ~(right | top | left_top | left_bottom)
        u[right] = radial[right]
        v[right] = angle[right] * u[right] / (0.25 * np.pi)
        v[top] = radial[top]
        u[top] = (0.5 * np.pi - angle[top]) * v[top] / (0.25 * np.pi)
        u[left_top] = -radial[left_top]
        v[left_top] = (angle[left_top] - np.pi) * u[left_top] / (0.25 * np.pi)
        u[left_bottom] = -radial[left_bottom]
        v[left_bottom] = (angle[left_bottom] + np.pi) * u[left_bottom] / (0.25 * np.pi)
        v[bottom] = -radial[bottom]
        u[bottom] = -(angle[bottom] + 0.5 * np.pi) * v[bottom] / (0.25 * np.pi)
        return u, v, radial

    def _nominate(self, points: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        targets = np.asarray(points, dtype=float)
        u, v, radial = self._base_logical(targets[:, :2])
        scale = 0.5 * self._side_cells
        continuous_i = np.clip((u + 1.0) * scale, 0.0, np.nextafter(float(self._side_cells), 0.0))
        continuous_j = np.clip((v + 1.0) * scale, 0.0, np.nextafter(float(self._side_cells), 0.0))
        column = np.floor(continuous_i).astype(np.int32)
        row = np.floor(continuous_j).astype(np.int32)
        cells = row * self._side_cells + column
        cells[radial > 1.0 + 1.0e-7] = -1

        radius = np.hypot(targets[:, 0], targets[:, 1])
        lower, upper = surface_heights(radius, self.mesh.config)
        fraction = np.divide(
            targets[:, 2] - lower,
            upper - lower,
            out=np.full(targets.shape[0], np.nan),
            where=np.abs(upper - lower) > 1.0e-12,
        )
        valid_layer = np.isfinite(fraction) & (fraction >= -1.0e-7) & (fraction <= 1.0 + 1.0e-7)
        continuous_k = np.clip(
            fraction * self.mesh.n_layers,
            0.0,
            np.nextafter(float(self.mesh.n_layers), 0.0),
        )
        layers = np.floor(continuous_k).astype(np.int32)
        layers[~valid_layer] = -1
        seed = np.column_stack(
            (
                2.0 * (continuous_i - column) - 1.0,
                2.0 * (continuous_j - row) - 1.0,
                2.0 * (continuous_k - np.maximum(layers, 0)) - 1.0,
            )
        )
        return cells, layers, np.clip(seed, -1.0, 1.0)

    def locate(self, points: np.ndarray) -> LocatedPoints:
        targets = np.asarray(points, dtype=float)
        cells, layers, mapped_seed = self._nominate(targets)
        natural = np.full((targets.shape[0], 3), np.nan)
        direct = np.zeros(targets.shape[0], dtype=bool)
        neighbor = np.zeros(targets.shape[0], dtype=bool)
        inverse_attempts = 0
        newton_iterations = 0

        candidate_ids = np.flatnonzero((cells >= 0) & (layers >= 0))
        if candidate_ids.size:
            seed = mapped_seed[candidate_ids] if self._mapped_seed else None
            q, accepted, iterations = self._try_candidates(
                targets[candidate_ids], cells[candidate_ids], layers[candidate_ids], seed=seed
            )
            inverse_attempts += candidate_ids.size
            newton_iterations += int(iterations.sum())
            hit = candidate_ids[accepted]
            natural[hit] = q[accepted]
            direct[hit] = True

        unresolved = ~direct
        offsets = [
            (dl, dr, dc)
            for dl in (0, -1, 1)
            for dr in (0, -1, 1)
            for dc in (0, -1, 1)
            if (dl, dr, dc) != (0, 0, 0)
        ]
        for layer_offset, row_offset, column_offset in offsets:
            ids = np.flatnonzero(unresolved & (cells >= 0) & (layers >= 0))
            if ids.size == 0:
                break
            column = cells[ids] % self._side_cells + column_offset
            row = cells[ids] // self._side_cells + row_offset
            candidate_layer = layers[ids] + layer_offset
            valid = (
                (column >= 0)
                & (column < self._side_cells)
                & (row >= 0)
                & (row < self._side_cells)
                & (candidate_layer >= 0)
                & (candidate_layer < self.mesh.n_layers)
            )
            if not np.any(valid):
                continue
            point_ids = ids[valid]
            candidate_cell = (row[valid] * self._side_cells + column[valid]).astype(np.int32)
            candidate_layer = candidate_layer[valid].astype(np.int32)
            candidate_seed = None
            if self._mapped_seed:
                candidate_seed = mapped_seed[point_ids].copy()
                candidate_seed[:, 0] -= 2.0 * column_offset
                candidate_seed[:, 1] -= 2.0 * row_offset
                candidate_seed[:, 2] -= 2.0 * layer_offset
            q, accepted, iterations = self._try_candidates(
                targets[point_ids], candidate_cell, candidate_layer, seed=candidate_seed
            )
            inverse_attempts += point_ids.size
            newton_iterations += int(iterations.sum())
            hit = point_ids[accepted]
            cells[hit] = candidate_cell[accepted]
            layers[hit] = candidate_layer[accepted]
            natural[hit] = q[accepted]
            neighbor[hit] = True
            unresolved[hit] = False

        fallback_count = int(np.count_nonzero(unresolved))
        if fallback_count:
            fallback = self._generic_guard.locate(targets[unresolved])
            ids = np.flatnonzero(unresolved)
            cells[ids] = fallback.cells
            layers[ids] = fallback.layers
            natural[ids] = fallback.natural
            inverse_attempts += fallback.inverse_attempts
            newton_iterations += fallback.newton_iterations
        return LocatedPoints(
            cells,
            layers,
            natural,
            int(np.count_nonzero(direct)),
            int(np.count_nonzero(neighbor)),
            fallback_count,
            inverse_attempts,
            newton_iterations,
        )


class MappedTopologyHex8Locator(TopologyHex8Locator):
    """Topology nomination plus a geometry-derived Newton seed and exact acceptance."""

    def __init__(self, mesh: SweptMesh):
        super().__init__(mesh, mapped_seed=True)

# ===== merged from layered.py =====

from dataclasses import dataclass
from time import perf_counter

import numpy as np
from scipy.spatial import cKDTree



@dataclass(frozen=True)
class PlaneSamplingMap:
    """Fixed in-plane QUAD4 interpolation map for the swept FE planes."""

    cells: np.ndarray
    natural: np.ndarray
    weights: np.ndarray
    build_elapsed_s: float
    inverse_attempts: int

    @classmethod
    def build(
        cls,
        mesh: SweptMesh,
        x_mm: np.ndarray,
        y_mm: np.ndarray,
        *,
        candidate_count: int = 16,
    ) -> "PlaneSamplingMap":
        started = perf_counter()
        points = np.column_stack((np.asarray(x_mm, dtype=float), np.asarray(y_mm, dtype=float)))
        quad_xy = mesh.nodes_mm[0, mesh.base_quads, :2]
        tree = cKDTree(quad_xy.mean(axis=1))
        count = min(int(candidate_count), mesh.n_cells)
        _, candidates = tree.query(points, k=count, workers=1)
        if candidates.ndim == 1:
            candidates = candidates[:, None]

        cells = np.full(points.shape[0], -1, dtype=np.int32)
        natural = np.full((points.shape[0], 2), np.nan)
        unresolved = np.ones(points.shape[0], dtype=bool)
        attempts = 0
        quad_min = quad_xy.min(axis=1)
        quad_max = quad_xy.max(axis=1)
        for rank in range(candidates.shape[1]):
            ids = np.flatnonzero(unresolved)
            if ids.size == 0:
                break
            candidate = candidates[ids, rank]
            inside_box = np.all(points[ids] >= quad_min[candidate] - 1.0e-9, axis=1) & np.all(
                points[ids] <= quad_max[candidate] + 1.0e-9, axis=1
            )
            if not np.any(inside_box):
                continue
            point_ids = ids[inside_box]
            candidate = candidate[inside_box]
            q, residual, solved = inverse_quad4_batch(quad_xy[candidate], points[point_ids])
            attempts += point_ids.size
            accepted = solved & (np.abs(q).max(axis=1) <= 1.0 + 2.0e-6) & (residual <= 1.0e-8)
            hit = point_ids[accepted]
            cells[hit] = candidate[accepted]
            natural[hit] = q[accepted]
            unresolved[hit] = False
        if np.any(unresolved):
            raise LookupError(f"plane sampler missed {np.count_nonzero(unresolved)} aperture points")
        return cls(cells, natural, shape_quad4(natural), perf_counter() - started, attempts)

    def sample_planes(self, mesh: SweptMesh) -> np.ndarray:
        node_ids = mesh.base_quads[self.cells]
        nodal = mesh.stress_mpa[:, node_ids, :]
        return np.einsum("pi,kpij->kpj", self.weights, nodal, optimize=True)

    def sample_plane_heights(self, mesh: SweptMesh) -> np.ndarray:
        node_ids = mesh.base_quads[self.cells]
        nodal_z = mesh.nodes_mm[:, node_ids, 2]
        return np.einsum("pi,kpi->kp", self.weights, nodal_z, optimize=True)


@dataclass(frozen=True)
class CurvedLayerContext:
    mesh: SweptMesh
    x_mm: np.ndarray
    y_mm: np.ndarray
    plane_map: PlaneSamplingMap
    plane_stress_mpa: np.ndarray
    plane_heights_mm: np.ndarray

    @classmethod
    def build(cls, mesh: SweptMesh, x_mm: np.ndarray, y_mm: np.ndarray) -> "CurvedLayerContext":
        plane_map = PlaneSamplingMap.build(mesh, x_mm, y_mm)
        return cls(
            mesh=mesh,
            x_mm=np.asarray(x_mm, dtype=float).copy(),
            y_mm=np.asarray(y_mm, dtype=float).copy(),
            plane_map=plane_map,
            plane_stress_mpa=plane_map.sample_planes(mesh),
            plane_heights_mm=plane_map.sample_plane_heights(mesh),
        )


def _sample_optical_layers(context: CurvedLayerContext, steps: int) -> np.ndarray:
    """Sample the swept planes in physical propagation order, from top to bottom."""
    if steps <= 0:
        raise ValueError("steps must be positive")
    fractions = (np.arange(steps, dtype=float) + 0.5) / float(steps)
    position = (1.0 - fractions) * context.mesh.n_layers
    lower = np.floor(position).astype(np.int32)
    lower = np.clip(lower, 0, context.mesh.n_layers - 1)
    blend = position - lower
    return (
        (1.0 - blend)[:, None, None] * context.plane_stress_mpa[lower]
        + blend[:, None, None] * context.plane_stress_mpa[lower + 1]
    )


def fixed_column_rays(context: CurvedLayerContext) -> RayBundle:
    """Return the vertical pupil columns used by the curved layer route."""
    bottom = context.plane_heights_mm[0]
    top = context.plane_heights_mm[-1]
    length = top - bottom
    if np.any(length <= 0.0):
        raise RuntimeError("the swept FE mesh contains nonpositive local thickness")
    direction = np.zeros((context.x_mm.size, 3), dtype=float)
    direction[:, 2] = -1.0
    start = np.column_stack((context.x_mm, context.y_mm, top))
    exit_points = np.column_stack((context.x_mm, context.y_mm, bottom))
    return RayBundle(start, direction, length, exit_points)


def evaluate_curved_layers(context: CurvedLayerContext, *, steps: int) -> OpticalResult:
    """Evaluate the curved layer approximation with corrected ordering and Jones extraction."""
    started = perf_counter()
    sampled_stress = _sample_optical_layers(context, steps)
    rays = fixed_column_rays(context)
    state = integrate_jones(sampled_stress, rays, context.mesh.config)
    elapsed = perf_counter() - started
    return OpticalResult(
        x_mm=context.x_mm.copy(),
        y_mm=context.y_mm.copy(),
        retardance_rad=state.retardance_rad,
        retardation_nm=state.retardation_nm,
        opd_nm=state.opd_nm,
        slow_axis_rad=state.axis_rad,
        ellipticity_rad=state.ellipticity_rad,
        path_length_mm=rays.length_mm.copy(),
        jones_matrix=state.matrix,
        elapsed_s=elapsed,
        locator="curved_layer_quad4",
        steps=steps,
        direct_hits=context.x_mm.size,
        neighbor_hits=0,
        generic_fallback_hits=0,
        inverse_attempts=context.plane_map.inverse_attempts,
        newton_iterations=0,
        evaluated_samples=int(context.x_mm.size * steps),
    )

# ===== merged from workflow.py =====

from dataclasses import dataclass
from time import perf_counter

import numpy as np



@dataclass(frozen=True)
class EvaluationContext:
    mesh: SweptMesh
    x_mm: np.ndarray
    y_mm: np.ndarray
    rays: RayBundle
    generic: GenericHex8Locator
    topology: TopologyHex8Locator
    mapped: MappedTopologyHex8Locator

    @classmethod
    def build(cls, mesh: SweptMesh) -> "EvaluationContext":
        x_mm, y_mm = aperture_grid(mesh.config.clear_radius_mm, mesh.config.aperture_pitch_mm)
        # Optical geometry is defined by the analytic entrance/exit surfaces.
        # The swept FE mesh conforms to those surfaces at its nodes; the
        # geometry audit below quantifies the small bilinear FE-face mismatch.
        rays = trace_collimated_rays(x_mm, y_mm, mesh.config)
        return cls(
            mesh,
            x_mm,
            y_mm,
            rays,
            GenericHex8Locator(mesh),
            TopologyHex8Locator(mesh),
            MappedTopologyHex8Locator(mesh),
        )


def _subset_rays(rays: RayBundle, ids: np.ndarray) -> RayBundle:
    return RayBundle(
        rays.start_mm[ids],
        rays.direction[ids],
        rays.length_mm[ids],
        rays.exit_mm[ids],
    )


def _select_locator(context: EvaluationContext, name: str):
    selected = {
        "generic": context.generic,
        "topology": context.topology,
        "mapped": context.mapped,
    }.get(name)
    if selected is None:
        raise ValueError("locator must be 'generic', 'topology', or 'mapped'")
    return selected


def _evaluate_ids(
    context: EvaluationContext,
    ids: np.ndarray,
    *,
    locator: str,
    steps: int,
    rays_override: RayBundle | None = None,
    projection_direction: np.ndarray | None = None,
) -> OpticalResult:
    if steps <= 0:
        raise ValueError("steps must be positive")
    ids = np.asarray(ids, dtype=np.int32)
    selected = _select_locator(context, locator)
    rays = _subset_rays(context.rays, ids) if rays_override is None else rays_override
    if rays.start_mm.shape != (ids.size, 3):
        raise ValueError("rays_override must contain one ray for each selected aperture point")
    start_time = perf_counter()
    sample_points = sample_ray_midpoints(rays, steps)
    flat_points = sample_points.reshape(-1, 3)
    located = selected.locate(flat_points)
    stress = selected.interpolate_stress(located).reshape(steps, ids.size, 6)
    state = integrate_jones(
        stress,
        rays,
        context.mesh.config,
        projection_direction=projection_direction,
    )
    elapsed = perf_counter() - start_time
    return OpticalResult(
        x_mm=context.x_mm[ids].copy(),
        y_mm=context.y_mm[ids].copy(),
        retardance_rad=state.retardance_rad,
        retardation_nm=state.retardation_nm,
        opd_nm=state.opd_nm,
        slow_axis_rad=state.axis_rad,
        ellipticity_rad=state.ellipticity_rad,
        path_length_mm=rays.length_mm.copy(),
        jones_matrix=state.matrix,
        elapsed_s=elapsed,
        locator=locator,
        steps=steps,
        direct_hits=direct_hits,
        neighbor_hits=neighbor_hits,
        generic_fallback_hits=generic_fallback_hits,
        inverse_attempts=inverse_attempts,
        newton_iterations=newton_iterations,
        evaluated_samples=int(ids.size * steps),
    )


def evaluate(context: EvaluationContext, *, locator: str, steps: int) -> OpticalResult:
    return _evaluate_ids(
        context,
        np.arange(context.x_mm.size, dtype=np.int32),
        locator=locator,
        steps=steps,
    )


def evaluate_on_rays(
    context: EvaluationContext,
    rays: RayBundle,
    *,
    locator: str,
    steps: int,
    projection_direction: np.ndarray | None = None,
) -> OpticalResult:
    """Evaluate a controlled path and transverse-frame combination on the full pupil."""
    ray_count = context.x_mm.size
    if rays.start_mm.shape != (ray_count, 3):
        raise ValueError("custom rays must share the context aperture grid")
    if projection_direction is not None and np.asarray(projection_direction).shape != (ray_count, 3):
        raise ValueError("projection_direction must have shape (n_rays, 3)")
    return _evaluate_ids(
        context,
        np.arange(ray_count, dtype=np.int32),
        locator=locator,
        steps=steps,
        rays_override=rays,
        projection_direction=projection_direction,
    )

# ===== merged from analysis.py =====

import math

import numpy as np



def rms(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    return float(np.sqrt(np.mean(values * values)))


def axis_difference_rad(candidate: np.ndarray, reference: np.ndarray) -> np.ndarray:
    difference = np.asarray(candidate, dtype=float) - np.asarray(reference, dtype=float)
    return 0.5 * np.arctan2(np.sin(2.0 * difference), np.cos(2.0 * difference))


def _correlation(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if np.std(first) <= 1.0e-15 or np.std(second) <= 1.0e-15:
        return float("nan")
    return float(np.corrcoef(first, second)[0, 1])


def _top_fraction_jaccard(candidate: np.ndarray, reference: np.ndarray, fraction: float = 0.10) -> float:
    candidate = np.asarray(candidate, dtype=float)
    reference = np.asarray(reference, dtype=float)
    scale = max(float(np.max(np.abs(candidate))), float(np.max(np.abs(reference))), 1.0e-30)
    tolerance = 1.0e-9 * scale
    candidate_quantized = np.round(candidate / tolerance) * tolerance
    reference_quantized = np.round(reference / tolerance) * tolerance
    threshold_candidate = np.quantile(candidate_quantized, 1.0 - fraction)
    threshold_reference = np.quantile(reference_quantized, 1.0 - fraction)
    set_candidate = candidate_quantized >= threshold_candidate
    set_reference = reference_quantized >= threshold_reference
    union = np.count_nonzero(set_candidate | set_reference)
    return float(np.count_nonzero(set_candidate & set_reference) / max(union, 1))


def comparison_metrics(candidate: OpticalResult, reference: OpticalResult) -> dict[str, float]:
    if candidate.x_mm.shape != reference.x_mm.shape or not np.allclose(candidate.x_mm, reference.x_mm):
        raise ValueError("candidate and reference must share the same aperture points")
    retardance_error = candidate.retardance_rad - reference.retardance_rad
    reference_rms = rms(reference.retardance_rad)
    opd_error = candidate.opd_nm - reference.opd_nm
    opd_error -= np.mean(opd_error)
    reference_opd = reference.opd_nm - np.mean(reference.opd_nm)
    candidate_opd = candidate.opd_nm - np.mean(candidate.opd_nm)

    # Retardance-squared weighting suppresses the physically ill-conditioned
    # orientation at vanishing retardance without creating an arbitrary hole
    # in the pupil.  Every point remains in the weighted RMS.
    axis_error_all = axis_difference_rad(candidate.slow_axis_rad, reference.slow_axis_rad)
    weights_all = reference.retardance_rad ** 2
    weight_sum = float(np.sum(weights_all))
    weighted_axis_rms = (
        math.sqrt(float(np.sum(weights_all * axis_error_all**2) / weight_sum))
        if weight_sum > 0.0 else float("nan")
    )
    floor = 1.0e-7
    mask = reference.retardance_rad >= floor
    axis_error = axis_error_all[mask]
    return {
        "retardance_rms_error_mrad": 1.0e3 * rms(retardance_error),
        "retardance_max_abs_error_mrad": 1.0e3 * float(np.max(np.abs(retardance_error))),
        "retardance_relative_rms_percent": 100.0 * rms(retardance_error) / max(reference_rms, 1.0e-30),
        "retardance_correlation": _correlation(candidate.retardance_rad, reference.retardance_rad),
        "retardance_top10_jaccard": _top_fraction_jaccard(candidate.retardance_rad, reference.retardance_rad),
        "opd_piston_removed_rms_error_nm": rms(opd_error),
        "opd_piston_removed_max_abs_error_nm": float(np.max(np.abs(opd_error))),
        "opd_correlation": _correlation(candidate_opd, reference_opd),
        "axis_weighted_rms_error_deg": math.degrees(weighted_axis_rms),
        "axis_p95_abs_error_deg": float(np.percentile(np.abs(np.degrees(axis_error)), 95.0)),
        "axis_mask_floor_mrad": 1.0e3 * floor,
        "axis_mask_points": int(np.count_nonzero(mask)),
        "ellipticity_rms_error_deg": math.degrees(rms(candidate.ellipticity_rad - reference.ellipticity_rad)),
    }


def radial_profile(x_mm: np.ndarray, y_mm: np.ndarray, values: np.ndarray, bin_width_mm: float = 5.0):
    radius = np.hypot(x_mm, y_mm)
    edges = np.arange(0.0, float(np.max(radius)) + bin_width_mm + 1.0e-12, bin_width_mm)
    index = np.clip(np.digitize(radius, edges) - 1, 0, edges.size - 2)
    center = 0.5 * (edges[:-1] + edges[1:])
    mean = np.full(center.shape, np.nan)
    standard_deviation = np.full(center.shape, np.nan)
    count = np.zeros(center.shape, dtype=int)
    for i in range(center.size):
        selected = values[index == i]
        count[i] = selected.size
        if selected.size:
            mean[i] = np.mean(selected)
            standard_deviation[i] = np.std(selected)
    return center, mean, standard_deviation, count


def zernike_fit(x_mm: np.ndarray, y_mm: np.ndarray, values: np.ndarray, n_max: int = 6):
    radius = np.hypot(x_mm, y_mm)
    rho = radius / float(np.max(radius))
    phi = np.arctan2(y_mm, x_mm)
    modes: list[tuple[int, int]] = []
    columns: list[np.ndarray] = []
    for n in range(n_max + 1):
        for m in range(-n, n + 1, 2):
            modes.append((n, m))
            columns.append(_zernike(n, m, rho, phi))
    design = np.column_stack(columns)
    coefficients, *_ = np.linalg.lstsq(design, np.asarray(values, dtype=float), rcond=None)
    reconstruction = design @ coefficients
    return modes, coefficients, reconstruction, rms(np.asarray(values) - reconstruction)


def _zernike(n: int, m: int, rho: np.ndarray, phi: np.ndarray) -> np.ndarray:
    absolute_m = abs(m)
    radial = np.zeros_like(rho, dtype=float)
    for s in range((n - absolute_m) // 2 + 1):
        coefficient = (
            (-1) ** s
            * math.factorial(n - s)
            / (
                math.factorial(s)
                * math.factorial((n + absolute_m) // 2 - s)
                * math.factorial((n - absolute_m) // 2 - s)
            )
        )
        radial += coefficient * rho ** (n - 2 * s)
    if m < 0:
        return radial * np.sin(absolute_m * phi)
    if m > 0:
        return radial * np.cos(absolute_m * phi)
    return radial


# ============================================================================
# Corrected production overrides and standalone analysis driver
# ============================================================================


def spherical_sag(radius_xy: np.ndarray, radius_of_curvature: float) -> np.ndarray:
    """Unsigned spherical sag magnitude.

    Mathematical flat surfaces are represented by ``R=+/-inf``.  ``R=0`` is
    accepted only for backward compatibility with the earlier NPZ metadata.
    """
    radius_xy = np.asarray(radius_xy, dtype=float)
    radius_value = float(radius_of_curvature)
    if (not np.isfinite(radius_value)) or abs(radius_value) <= 1.0e-15:
        return np.zeros_like(radius_xy)
    curvature_radius = abs(radius_value)
    if np.any(radius_xy > curvature_radius + 1.0e-12):
        raise ValueError(
            "surface radius of curvature is smaller than the sampled radial coordinate"
        )
    return curvature_radius - np.sqrt(np.maximum(curvature_radius**2 - radius_xy**2, 0.0))


def _surface_slope(radius_xy: np.ndarray, radius_of_curvature: float, *, top: bool) -> np.ndarray:
    radius_xy = np.asarray(radius_xy, dtype=float)
    radius_value = float(radius_of_curvature)
    if (not np.isfinite(radius_value)) or abs(radius_value) <= 1.0e-15:
        return np.zeros_like(radius_xy)
    curvature_radius = abs(radius_value)
    denominator = np.sqrt(np.maximum(curvature_radius**2 - radius_xy**2, 1.0e-18))
    sag_slope = radius_xy / denominator
    if top:
        return -sag_slope if radius_value >= 0.0 else sag_slope
    return sag_slope if radius_value >= 0.0 else -sag_slope


@dataclass(frozen=True)
class LayerQuadrature:
    """Precomputed midpoint quadrature through the actual swept FE layers."""

    points_mm: np.ndarray          # (n_layers*q, n_rays, 3), propagation order
    ds_mm: np.ndarray              # (n_layers*q, n_rays)
    boundaries_mm: np.ndarray      # (n_layers+1, n_rays), distance from ray entry
    samples_per_layer: int
    build_elapsed_s: float


def ray_layer_boundaries(mesh: SweptMesh, rays: RayBundle) -> np.ndarray:
    """Intersect straight rays with the analytic swept layer surfaces.

    The generated FE mesh uses the same normalized fractions through the thickness
    at every in-plane node.  Optical transport is defined by the analytic lens
    surfaces; an interior layer at fraction f therefore uses
    z_f(x,y)=z_bottom(x,y)+f[z_top(x,y)-z_bottom(x,y)].  Samples are then
    located exactly in the physical HEX8 mesh.  This avoids repeatedly solving
    millions of QUAD4 surface inversions while preserving the declared optical
    geometry; FE-vs-analytic surface mismatch is reported separately.
    """
    nrays = rays.start_mm.shape[0]
    n = mesh.n_layers
    boundaries = np.empty((n + 1, nrays), dtype=float)
    boundaries[0] = 0.0
    boundaries[-1] = rays.length_mm

    def points(distance: np.ndarray) -> np.ndarray:
        return rays.start_mm + distance[:, None] * rays.direction

    previous = np.zeros(nrays, dtype=float)
    for out_index, plane in enumerate(range(n - 1, 0, -1), start=1):
        fraction = float(plane) / float(n)  # 0=bottom, 1=top
        lower = previous.copy()
        upper = rays.length_mm.copy()

        def signed(distance: np.ndarray) -> np.ndarray:
            p = points(distance)
            bottom, top = surface_heights(np.hypot(p[:, 0], p[:, 1]), mesh.config)
            zsurf = bottom + fraction * (top - bottom)
            return p[:, 2] - zsurf

        fl = signed(lower)
        fu = signed(upper)
        if np.any(fl < -2.0e-9) or np.any(fu > 2.0e-9):
            raise RuntimeError(f"analytic swept plane {plane} was not bracketed along all rays")
        for _ in range(40):
            mid = 0.5 * (lower + upper)
            above = signed(mid) > 0.0
            lower[above] = mid[above]
            upper[~above] = mid[~above]
        hit = 0.5 * (lower + upper)
        if np.any(hit <= previous - 1.0e-10):
            raise RuntimeError("non-monotone analytic swept-plane intersections")
        boundaries[out_index] = hit
        previous = hit
    if np.any(np.diff(boundaries, axis=0) <= 0.0):
        raise RuntimeError("one or more ray/layer segment lengths are nonpositive")
    return boundaries


def build_layer_quadrature(
    mesh: SweptMesh,
    rays: RayBundle,
    samples_per_layer: int,
    *,
    boundaries: np.ndarray | None = None,
) -> LayerQuadrature:
    q = int(samples_per_layer)
    if q <= 0:
        raise ValueError("samples_per_layer must be a positive integer")
    started = perf_counter()
    if boundaries is None:
        boundaries = ray_layer_boundaries(mesh, rays)
    else:
        boundaries = np.asarray(boundaries, dtype=float)
        if boundaries.shape != (mesh.n_layers + 1, rays.start_mm.shape[0]):
            raise ValueError("boundaries must have shape (n_layers+1, n_rays)")
    n_layers, nrays = mesh.n_layers, rays.start_mm.shape[0]
    points = np.empty((n_layers * q, nrays, 3), dtype=float)
    ds = np.empty((n_layers * q, nrays), dtype=float)
    row = 0
    for layer in range(n_layers):
        start_d = boundaries[layer]
        end_d = boundaries[layer + 1]
        segment = end_d - start_d
        for local in range(q):
            alpha = (local + 0.5) / q
            distance = start_d + alpha * segment
            points[row] = rays.start_mm + distance[:, None] * rays.direction
            ds[row] = segment / q
            row += 1
    return LayerQuadrature(points, ds, boundaries, q, perf_counter() - started)


def integrate_jones(
    sampled_stress_mpa: np.ndarray,
    rays: RayBundle,
    config: OpticalConfig,
    *,
    projection_direction: np.ndarray | None = None,
    ds_mm: np.ndarray | None = None,
) -> JonesState:
    """Integrate ordered stress-optic Jones increments.

    ``rays.direction`` gives the physical propagation direction.  The optional
    ``projection_direction`` selects the transverse stress/Jones frame for the
    controlled refracted-global diagnostic.  ``ds_mm`` may contain the true
    path length of every quadrature increment; if omitted, equal arclength
    increments are used for backward compatibility.
    """
    samples = np.asarray(sampled_stress_mpa, dtype=float)
    steps, ray_count = samples.shape[:2]
    basis_direction = rays.direction if projection_direction is None else np.asarray(
        projection_direction, dtype=float
    )
    if basis_direction.shape != (ray_count, 3):
        raise ValueError("projection_direction must have shape (n_rays, 3)")
    norms = np.linalg.norm(basis_direction, axis=1, keepdims=True)
    if np.any(norms <= 1.0e-14):
        raise ValueError("projection directions must be nonzero")
    basis_direction = basis_direction / norms
    repeated_direction = np.broadcast_to(basis_direction, (steps, ray_count, 3)).reshape(-1, 3)
    ray_stress = rotate_voigt_to_ray(samples.reshape(-1, 6), repeated_direction)
    dn_slow, dn_fast, dn_mean, theta = stress_optic_state(ray_stress, config)
    dn_slow = dn_slow.reshape(steps, ray_count)
    dn_fast = dn_fast.reshape(steps, ray_count)
    dn_mean = dn_mean.reshape(steps, ray_count)
    theta = theta.reshape(steps, ray_count)

    if ds_mm is None:
        ds_mm_array = np.broadcast_to(
            rays.length_mm[None, :] / float(steps), (steps, ray_count)
        ).copy()
    else:
        ds_mm_array = np.asarray(ds_mm, dtype=float)
        if ds_mm_array.shape != (steps, ray_count):
            raise ValueError("ds_mm must have shape (steps, n_rays)")
        if np.any(ds_mm_array <= 0.0):
            raise ValueError("all Jones path increments must be positive")
    ds_m = ds_mm_array * 1.0e-3
    wavelength_m = config.wavelength_nm * 1.0e-9

    jones = np.zeros((ray_count, 2, 2), dtype=complex)
    jones[:, 0, 0] = 1.0
    jones[:, 1, 1] = 1.0
    for step in range(steps):
        c = np.cos(theta[step])
        s = np.sin(theta[step])
        slow_phase = np.exp(1j * 2.0 * math.pi * dn_slow[step] * ds_m[step] / wavelength_m)
        fast_phase = np.exp(1j * 2.0 * math.pi * dn_fast[step] * ds_m[step] / wavelength_m)
        increment = np.empty_like(jones)
        increment[:, 0, 0] = c * c * slow_phase + s * s * fast_phase
        increment[:, 0, 1] = c * s * (slow_phase - fast_phase)
        increment[:, 1, 0] = increment[:, 0, 1]
        increment[:, 1, 1] = s * s * slow_phase + c * c * fast_phase
        jones = np.einsum("pij,pjk->pik", increment, jones, optimize=True)

    determinant = jones[:, 0, 0] * jones[:, 1, 1] - jones[:, 0, 1] * jones[:, 1, 0]
    determinant_sqrt = np.sqrt(np.abs(determinant)) * np.exp(0.5j * np.angle(determinant))
    normalized = jones / determinant_sqrt[:, None, None]
    trace = normalized[:, 0, 0] + normalized[:, 1, 1]
    flip = np.real(trace) < 0.0
    normalized[flip] *= -1.0
    trace = normalized[:, 0, 0] + normalized[:, 1, 1]
    # Numerical clip only: the physical branch is fixed by common-phase removal.
    retardance = 2.0 * np.arccos(np.clip(np.real(trace) / 2.0, 0.0, 1.0))

    eigenvalues, eigenvectors = np.linalg.eig(normalized)
    phases = np.angle(eigenvalues)
    slow_index = np.argmax(phases, axis=1)
    slow_vector = eigenvectors[np.arange(ray_count), :, slow_index]
    first, second = transverse_basis(basis_direction)
    global_x = slow_vector[:, 0] * first[:, 0] + slow_vector[:, 1] * second[:, 0]
    global_y = slow_vector[:, 0] * first[:, 1] + slow_vector[:, 1] * second[:, 1]
    projected_norm = np.sqrt(np.abs(global_x) ** 2 + np.abs(global_y) ** 2)
    global_x = np.divide(global_x, projected_norm, out=np.zeros_like(global_x), where=projected_norm > 1.0e-14)
    global_y = np.divide(global_y, projected_norm, out=np.zeros_like(global_y), where=projected_norm > 1.0e-14)
    s1 = np.abs(global_x) ** 2 - np.abs(global_y) ** 2
    s2 = 2.0 * np.real(global_x * np.conj(global_y))
    s3 = -2.0 * np.imag(global_x * np.conj(global_y))
    axis = _wrap_axis(0.5 * np.arctan2(s2, s1))
    ellipticity = 0.5 * np.arcsin(np.clip(s3, -1.0, 1.0))
    degenerate = (retardance < 1.0e-10) | (projected_norm <= 1.0e-14)
    axis[degenerate] = 0.0
    ellipticity[degenerate] = 0.0

    retardation_nm = retardance / (2.0 * math.pi) * config.wavelength_nm
    opd_nm = np.sum(dn_mean * ds_m * 1.0e9, axis=0)
    return JonesState(retardance, retardation_nm, opd_nm, axis, ellipticity, normalized)


def _finalize_accumulated_jones(
    jones: np.ndarray,
    opd_nm: np.ndarray,
    basis_direction: np.ndarray,
    config: OpticalConfig,
) -> JonesState:
    """Extract the same principal outputs used by ``integrate_jones``."""
    determinant = jones[:, 0, 0] * jones[:, 1, 1] - jones[:, 0, 1] * jones[:, 1, 0]
    determinant_sqrt = np.sqrt(np.abs(determinant)) * np.exp(0.5j * np.angle(determinant))
    normalized = jones / determinant_sqrt[:, None, None]
    trace = normalized[:, 0, 0] + normalized[:, 1, 1]
    flip = np.real(trace) < 0.0
    normalized[flip] *= -1.0
    trace = normalized[:, 0, 0] + normalized[:, 1, 1]
    retardance = 2.0 * np.arccos(np.clip(np.real(trace) / 2.0, 0.0, 1.0))

    eigenvalues, eigenvectors = np.linalg.eig(normalized)
    phases = np.angle(eigenvalues)
    slow_index = np.argmax(phases, axis=1)
    slow_vector = eigenvectors[np.arange(jones.shape[0]), :, slow_index]
    first, second = transverse_basis(basis_direction)
    global_x = slow_vector[:, 0] * first[:, 0] + slow_vector[:, 1] * second[:, 0]
    global_y = slow_vector[:, 0] * first[:, 1] + slow_vector[:, 1] * second[:, 1]
    projected_norm = np.sqrt(np.abs(global_x) ** 2 + np.abs(global_y) ** 2)
    global_x = np.divide(global_x, projected_norm, out=np.zeros_like(global_x), where=projected_norm > 1.0e-14)
    global_y = np.divide(global_y, projected_norm, out=np.zeros_like(global_y), where=projected_norm > 1.0e-14)
    s1 = np.abs(global_x) ** 2 - np.abs(global_y) ** 2
    s2 = 2.0 * np.real(global_x * np.conj(global_y))
    s3 = -2.0 * np.imag(global_x * np.conj(global_y))
    axis = _wrap_axis(0.5 * np.arctan2(s2, s1))
    ellipticity = 0.5 * np.arcsin(np.clip(s3, -1.0, 1.0))
    degenerate = (retardance < 1.0e-10) | (projected_norm <= 1.0e-14)
    axis[degenerate] = 0.0
    ellipticity[degenerate] = 0.0
    retardation_nm = retardance / (2.0 * math.pi) * config.wavelength_nm
    return JonesState(retardance, retardation_nm, opd_nm, axis, ellipticity, normalized)


def evaluate_quadrature(
    context: EvaluationContext,
    quadrature: LayerQuadrature,
    *,
    locator: str = "mapped",
    projection_direction: np.ndarray | None = None,
) -> OpticalResult:
    """Evaluate a refracted/fixed-column quadrature in a streaming manner.

    Streaming one optical increment at a time prevents deep reference runs from
    allocating and repeatedly inverting very large batched arrays.  It is
    mathematically identical to accumulating the same ordered local Jones
    matrices after precomputing every stress sample.
    """
    started = perf_counter()
    selected = MappedTopologyHex8Locator(context.mesh) if locator == "mapped" else (TopologyHex8Locator(context.mesh) if locator == "topology" else GenericHex8Locator(context.mesh))
    nrays = context.x_mm.size
    basis_direction = context.rays.direction if projection_direction is None else np.asarray(projection_direction, dtype=float)
    if basis_direction.shape != (nrays, 3):
        raise ValueError("projection_direction must have shape (n_rays, 3)")
    norms = np.linalg.norm(basis_direction, axis=1, keepdims=True)
    if np.any(norms <= 1.0e-14):
        raise ValueError("projection directions must be nonzero")
    basis_direction = basis_direction / norms

    jones = np.zeros((nrays, 2, 2), dtype=complex)
    jones[:, 0, 0] = 1.0
    jones[:, 1, 1] = 1.0
    opd_nm = np.zeros(nrays, dtype=float)
    wavelength_m = context.mesh.config.wavelength_nm * 1.0e-9

    direct_hits = neighbor_hits = generic_fallback_hits = 0
    inverse_attempts = newton_iterations = 0
    for step in range(quadrature.points_mm.shape[0]):
        located = selected.locate(quadrature.points_mm[step])
        stress = selected.interpolate_stress(located)
        ray_stress = rotate_voigt_to_ray(stress, basis_direction)
        dn_slow, dn_fast, dn_mean, theta = stress_optic_state(ray_stress, context.mesh.config)
        ds_m = quadrature.ds_mm[step] * 1.0e-3
        c = np.cos(theta); ss = np.sin(theta)
        slow_phase = np.exp(1j * 2.0 * math.pi * dn_slow * ds_m / wavelength_m)
        fast_phase = np.exp(1j * 2.0 * math.pi * dn_fast * ds_m / wavelength_m)
        increment = np.empty_like(jones)
        increment[:, 0, 0] = c*c*slow_phase + ss*ss*fast_phase
        increment[:, 0, 1] = c*ss*(slow_phase-fast_phase)
        increment[:, 1, 0] = increment[:, 0, 1]
        increment[:, 1, 1] = ss*ss*slow_phase + c*c*fast_phase
        jones = np.einsum("pij,pjk->pik", increment, jones, optimize=True)
        opd_nm += dn_mean * ds_m * 1.0e9
        direct_hits += located.direct_hits
        neighbor_hits += located.neighbor_hits
        generic_fallback_hits += located.generic_fallback_hits
        inverse_attempts += located.inverse_attempts
        newton_iterations += located.newton_iterations

    state = _finalize_accumulated_jones(jones, opd_nm, basis_direction, context.mesh.config)
    elapsed = perf_counter() - started
    return OpticalResult(
        x_mm=context.x_mm.copy(),
        y_mm=context.y_mm.copy(),
        retardance_rad=state.retardance_rad,
        retardation_nm=state.retardation_nm,
        opd_nm=state.opd_nm,
        slow_axis_rad=state.axis_rad,
        ellipticity_rad=state.ellipticity_rad,
        path_length_mm=context.rays.length_mm.copy(),
        jones_matrix=state.matrix,
        elapsed_s=elapsed,
        locator=locator,
        steps=quadrature.points_mm.shape[0],
        direct_hits=direct_hits,
        neighbor_hits=neighbor_hits,
        generic_fallback_hits=generic_fallback_hits,
        inverse_attempts=inverse_attempts,
        newton_iterations=newton_iterations,
        evaluated_samples=int(quadrature.points_mm.shape[0] * nrays),
    )


def build_curved_layer_context_timed(
    mesh: SweptMesh, x_mm: np.ndarray, y_mm: np.ndarray
) -> tuple[CurvedLayerContext, dict[str, float]]:
    t0 = perf_counter()
    plane_map = PlaneSamplingMap.build(mesh, x_mm, y_mm)
    map_wall = perf_counter() - t0
    t1 = perf_counter()
    plane_stress = plane_map.sample_planes(mesh)
    stress_wall = perf_counter() - t1
    t2 = perf_counter()
    plane_heights = plane_map.sample_plane_heights(mesh)
    height_wall = perf_counter() - t2
    context = CurvedLayerContext(
        mesh=mesh,
        x_mm=np.asarray(x_mm, dtype=float).copy(),
        y_mm=np.asarray(y_mm, dtype=float).copy(),
        plane_map=plane_map,
        plane_stress_mpa=plane_stress,
        plane_heights_mm=plane_heights,
    )
    return context, {
        "plane_map_geometry_s": map_wall,
        "plane_stress_preprocess_s": stress_wall,
        "plane_height_preprocess_s": height_wall,
        "curved_preprocess_total_s": map_wall + stress_wall + height_wall,
    }


def sample_curved_per_fe_layer(
    context: CurvedLayerContext, samples_per_layer: int
) -> tuple[np.ndarray, np.ndarray]:
    """Sample every swept FE layer in physical top-to-bottom order."""
    q = int(samples_per_layer)
    if q <= 0:
        raise ValueError("samples_per_layer must be positive")
    n = context.mesh.n_layers
    nrays = context.x_mm.size
    stress = np.empty((n * q, nrays, 6), dtype=float)
    ds = np.empty((n * q, nrays), dtype=float)
    row = 0
    for propagation_layer in range(n):
        upper_plane = n - propagation_layer
        lower_plane = upper_plane - 1
        upper_h = context.plane_heights_mm[upper_plane]
        lower_h = context.plane_heights_mm[lower_plane]
        thickness = upper_h - lower_h
        if np.any(thickness <= 0.0):
            raise RuntimeError("nonpositive local swept-layer thickness")
        for local in range(q):
            alpha = (local + 0.5) / q
            stress[row] = (
                (1.0 - alpha) * context.plane_stress_mpa[upper_plane]
                + alpha * context.plane_stress_mpa[lower_plane]
            )
            ds[row] = thickness / q
            row += 1
    return stress, ds


def evaluate_curved_layerwise(
    context: CurvedLayerContext, *, samples_per_layer: int
) -> OpticalResult:
    started = perf_counter()
    sampled_stress, ds_mm = sample_curved_per_fe_layer(context, samples_per_layer)
    rays = fixed_column_rays(context)
    state = integrate_jones(sampled_stress, rays, context.mesh.config, ds_mm=ds_mm)
    elapsed = perf_counter() - started
    return OpticalResult(
        x_mm=context.x_mm.copy(),
        y_mm=context.y_mm.copy(),
        retardance_rad=state.retardance_rad,
        retardation_nm=state.retardation_nm,
        opd_nm=state.opd_nm,
        slow_axis_rad=state.axis_rad,
        ellipticity_rad=state.ellipticity_rad,
        path_length_mm=rays.length_mm.copy(),
        jones_matrix=state.matrix,
        elapsed_s=elapsed,
        locator="curved_layer_quad4",
        steps=context.mesh.n_layers * int(samples_per_layer),
        direct_hits=context.x_mm.size,
        neighbor_hits=0,
        generic_fallback_hits=0,
        inverse_attempts=context.plane_map.inverse_attempts,
        newton_iterations=0,
        evaluated_samples=int(context.x_mm.size * context.mesh.n_layers * int(samples_per_layer)),
    )


def evaluate_custom_rays_layerwise(
    context: EvaluationContext,
    rays: RayBundle,
    quadrature: LayerQuadrature,
    *,
    locator: str = "mapped",
    projection_direction: np.ndarray | None = None,
) -> OpticalResult:
    if rays.start_mm.shape != context.rays.start_mm.shape:
        raise ValueError("custom rays must share the full common pupil")
    started = perf_counter()
    selected = _select_locator(context, locator)
    flat_points = quadrature.points_mm.reshape(-1, 3)
    located = selected.locate(flat_points)
    nrays = context.x_mm.size
    stress = selected.interpolate_stress(located).reshape(quadrature.points_mm.shape[0], nrays, 6)
    state = integrate_jones(
        stress,
        rays,
        context.mesh.config,
        projection_direction=projection_direction,
        ds_mm=quadrature.ds_mm,
    )
    elapsed = perf_counter() - started
    return OpticalResult(
        context.x_mm.copy(), context.y_mm.copy(), state.retardance_rad,
        state.retardation_nm, state.opd_nm, state.axis_rad, state.ellipticity_rad,
        rays.length_mm.copy(), state.matrix, elapsed, locator,
        quadrature.points_mm.shape[0], located.direct_hits, located.neighbor_hits,
        located.generic_fallback_hits, located.inverse_attempts, located.newton_iterations,
        int(flat_points.shape[0]),
    )


def _repeat(callable_, repeats: int, warmup: bool = True):
    if warmup:
        callable_()
    results, times = [], []
    for _ in range(int(repeats)):
        result = callable_()
        results.append(result)
        times.append(float(result.elapsed_s))
    return results[-1], float(statistics.median(times)), times


def _timing_record(median: float, times: list[float]) -> dict[str, object]:
    return {
        "median": float(median),
        "q25": float(np.quantile(times, 0.25)),
        "q75": float(np.quantile(times, 0.75)),
        "minimum": float(np.min(times)),
        "maximum": float(np.max(times)),
        "runs": [float(v) for v in times],
    }


def _write_dict_rows(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _write_stage_points(path: Path, routes: dict[str, OpticalResult]) -> None:
    reference = routes["reference"]
    names = list(routes)
    header = ["x_mm", "y_mm"]
    for name in names:
        header.extend([
            f"{name}_retardance_mrad", f"{name}_retardation_nm", f"{name}_opd_nm",
            f"{name}_slow_axis_deg", f"{name}_ellipticity_deg",
        ])
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        for i in range(reference.x_mm.size):
            row = [float(reference.x_mm[i]), float(reference.y_mm[i])]
            for name in names:
                r = routes[name]
                row.extend([
                    1.0e3 * float(r.retardance_rad[i]), float(r.retardation_nm[i]),
                    float(r.opd_nm[i]), math.degrees(float(r.slow_axis_rad[i])),
                    math.degrees(float(r.ellipticity_rad[i])),
                ])
            writer.writerow(row)



def comparison_metrics(candidate: OpticalResult, reference: OpticalResult) -> dict[str, float]:
    """Robust common-grid metrics used by all exported tables."""
    if candidate.x_mm.shape != reference.x_mm.shape or not np.allclose(candidate.x_mm, reference.x_mm):
        raise ValueError("candidate and reference must share the same aperture points")
    if not np.allclose(candidate.y_mm, reference.y_mm):
        raise ValueError("candidate and reference must share the same aperture points")
    retardance_error = candidate.retardance_rad - reference.retardance_rad
    reference_rms = rms(reference.retardance_rad)
    opd_error = candidate.opd_nm - reference.opd_nm
    opd_error = opd_error - np.mean(opd_error)
    reference_opd = reference.opd_nm - np.mean(reference.opd_nm)
    candidate_opd = candidate.opd_nm - np.mean(candidate.opd_nm)

    axis_error_all = axis_difference_rad(candidate.slow_axis_rad, reference.slow_axis_rad)
    weights_all = reference.retardance_rad ** 2
    weight_sum = float(np.sum(weights_all))
    weighted_axis_rms = (
        math.sqrt(float(np.sum(weights_all * axis_error_all**2) / weight_sum))
        if weight_sum > 0.0 else float("nan")
    )
    floor = 1.0e-7
    mask = reference.retardance_rad >= floor
    axis_error = axis_error_all[mask]
    axis_p95 = (
        float(np.percentile(np.abs(np.degrees(axis_error)), 95.0))
        if axis_error.size else float("nan")
    )

    return {
        "retardance_rms_error_mrad": 1.0e3 * rms(retardance_error),
        "retardance_max_abs_error_mrad": 1.0e3 * float(np.max(np.abs(retardance_error))),
        "retardance_relative_rms_percent": 100.0 * rms(retardance_error) / max(reference_rms, 1.0e-30),
        "retardance_correlation": _correlation(candidate.retardance_rad, reference.retardance_rad),
        "retardance_top10_jaccard": _top_fraction_jaccard(candidate.retardance_rad, reference.retardance_rad),
        "opd_piston_removed_rms_error_nm": rms(opd_error),
        "opd_piston_removed_max_abs_error_nm": float(np.max(np.abs(opd_error))),
        "opd_correlation": _correlation(candidate_opd, reference_opd),
        "axis_weighted_rms_error_deg": math.degrees(weighted_axis_rms) if np.isfinite(weighted_axis_rms) else float("nan"),
        "axis_p95_abs_error_deg": axis_p95,
        "axis_mask_floor_mrad": 1.0e3 * floor,
        "axis_mask_points": int(np.count_nonzero(mask)),
        "ellipticity_rms_error_deg": math.degrees(rms(candidate.ellipticity_rad - reference.ellipticity_rad)),
    }


def _reference_choice(
    results_by_q: dict[int, OpticalResult],
    *,
    retardance_tolerance_mrad: float,
    opd_tolerance_nm: float,
) -> tuple[int, list[dict[str, float]]]:
    q_fine = max(results_by_q)
    fine = results_by_q[q_fine]
    rows = []
    chosen = q_fine
    for q in sorted(results_by_q):
        metrics = comparison_metrics(results_by_q[q], fine)
        rows.append({"samples_per_fe_layer": q, **metrics})
        if (
            q < q_fine
            and metrics["retardance_rms_error_mrad"] <= retardance_tolerance_mrad
            and metrics["opd_piston_removed_rms_error_nm"] <= opd_tolerance_nm
            and chosen == q_fine
        ):
            chosen = q
    return chosen, rows


def _safe_reference_metrics(reference: OpticalResult) -> dict[str, float]:
    return comparison_metrics(reference, reference)


def _locator_equivalence(
    context: EvaluationContext,
    quadrature: LayerQuadrature,
    *,
    max_rays: int = 128,
) -> dict[str, float]:
    # Deterministic pupil subset; use all per-layer midpoints for those rays.
    nrays = context.x_mm.size
    ids = np.linspace(0, nrays - 1, min(max_rays, nrays), dtype=int)
    points = quadrature.points_mm[:, ids].reshape(-1, 3)
    mapped_loc = context.mapped.locate(points)
    generic_loc = context.generic.locate(points)
    mapped_stress = context.mapped.interpolate_stress(mapped_loc)
    generic_stress = context.generic.interpolate_stress(generic_loc)
    difference = mapped_stress - generic_stress
    return {
        "checked_rays": int(ids.size),
        "checked_samples": int(points.shape[0]),
        "stress_component_max_abs_mpa": float(np.max(np.abs(difference))),
        "stress_component_rms_mpa": float(np.sqrt(np.mean(difference**2))),
        "mapped_generic_same_cell_fraction": float(np.mean(
            (mapped_loc.cells == generic_loc.cells) & (mapped_loc.layers == generic_loc.layers)
        )),
    }


def _symmetry_error_60(x: np.ndarray, y: np.ndarray, values: np.ndarray) -> dict[str, float]:
    """Interpolation-based 60-degree scalar-field rotation diagnostic."""
    points = np.column_stack((x, y))
    interpolator = LinearNDInterpolator(points, values, fill_value=np.nan)
    angle = math.pi / 3.0
    xr = np.cos(angle) * x - np.sin(angle) * y
    yr = np.sin(angle) * x + np.cos(angle) * y
    rotated = np.asarray(interpolator(xr, yr), dtype=float)
    valid = np.isfinite(rotated) & np.isfinite(values)
    if not np.any(valid):
        return {"valid_points": 0, "rms_difference": float("nan"), "normalized_rms": float("nan")}
    diff = rotated[valid] - values[valid]
    rms_diff = float(np.sqrt(np.mean(diff**2)))
    scale = float(np.sqrt(np.mean(np.asarray(values[valid], dtype=float) ** 2)))
    return {
        "valid_points": int(np.count_nonzero(valid)),
        "rms_difference": rms_diff,
        "normalized_rms": rms_diff / max(scale, 1.0e-30),
    }


def _geometry_audit(mesh: SweptMesh, x: np.ndarray, y: np.ndarray, layer_context: CurvedLayerContext) -> dict[str, float]:
    radial = np.hypot(x, y)
    analytic_bottom, analytic_top = surface_heights(radial, mesh.config)
    fe_bottom = layer_context.plane_heights_mm[0]
    fe_top = layer_context.plane_heights_mm[-1]
    thickness = fe_top - fe_bottom
    return {
        "min_fe_vertical_thickness_mm": float(np.min(thickness)),
        "max_fe_vertical_thickness_mm": float(np.max(thickness)),
        "max_abs_top_surface_fe_minus_analytic_mm": float(np.max(np.abs(fe_top - analytic_top))),
        "max_abs_bottom_surface_fe_minus_analytic_mm": float(np.max(np.abs(fe_bottom - analytic_bottom))),
    }


def _radial_rows(case: str, routes: dict[str, OpticalResult], bin_width_mm: float = 5.0) -> list[dict]:
    rows = []
    for route, result in routes.items():
        center, mean, sd, count = radial_profile(result.x_mm, result.y_mm, 1.0e3 * result.retardance_rad, bin_width_mm)
        for r, m, s, n in zip(center, mean, sd, count):
            rows.append({
                "case": case, "route": route, "radius_mm": float(r),
                "mean_retardance_mrad": float(m), "standard_deviation_mrad": float(s),
                "point_count": int(n),
            })
    return rows


def _zernike_rows(case: str, routes: dict[str, OpticalResult]) -> list[dict]:
    selected = {
        (1, -1): "Tilt y", (1, 1): "Tilt x", (2, -2): "Astigmatism 45",
        (2, 0): "Defocus", (2, 2): "Astigmatism 0", (3, -3): "Trefoil y",
        (3, 3): "Trefoil x", (3, -1): "Coma y", (3, 1): "Coma x",
        (4, 0): "Primary spherical",
    }
    rows = []
    for route in ("reference", "curved_layer", "projection_control"):
        result = routes[route]
        opd = result.opd_nm - np.mean(result.opd_nm)
        modes, coefficients, _, residual_rms = zernike_fit(result.x_mm, result.y_mm, opd, n_max=6)
        lookup = dict(zip(modes, coefficients))
        for order, (mode, label) in enumerate(selected.items()):
            rows.append({
                "case": case, "route": route, "order": order, "n": mode[0], "m": mode[1],
                "label": label, "coefficient_nm": float(lookup[mode]),
                "fit_residual_rms_nm": float(residual_rms),
            })
    return rows


def _applicability_rows(case: str, mesh: SweptMesh, context: EvaluationContext, curved: OpticalResult, reference: OpticalResult):
    lateral = np.linalg.norm(context.rays.exit_mm[:, :2] - context.rays.start_mm[:, :2], axis=1)
    normalized = lateral / mesh.config.clear_radius_mm
    error = np.abs(1.0e3 * (curved.retardance_rad - reference.retardance_rad))
    rho = float(spearmanr(normalized, error).statistic)
    point_rows = []
    for i in range(context.x_mm.size):
        point_rows.append({
            "case": case, "x_mm": float(context.x_mm[i]), "y_mm": float(context.y_mm[i]),
            "lateral_offset_mm": float(lateral[i]),
            "normalized_offset_percent": 100.0 * float(normalized[i]),
            "absolute_retardance_error_mrad": float(error[i]), "spearman_rho": rho,
        })
    edges = np.linspace(0.0, float(np.max(normalized)) + 1.0e-12, 11)
    index = np.clip(np.digitize(normalized, edges) - 1, 0, edges.size - 2)
    bin_rows = []
    for i in range(edges.size - 1):
        mask = index == i
        if not np.any(mask):
            continue
        vals, offs = error[mask], normalized[mask]
        bin_rows.append({
            "case": case, "offset_center_percent": 100.0 * float(np.mean(offs)),
            "error_median_mrad": float(np.median(vals)),
            "error_q25_mrad": float(np.quantile(vals, 0.25)),
            "error_q75_mrad": float(np.quantile(vals, 0.75)),
            "count": int(vals.size), "spearman_rho": rho,
        })
    return point_rows, bin_rows



# ===== self-contained 3-D HEX8 finite-element solver =====

from scipy.sparse import bsr_matrix, diags
from scipy.sparse.linalg import LinearOperator, cg, spsolve


@dataclass(frozen=True)
class FEMCaseSpec:
    name: str
    n_xy: int
    n_layers: int
    radius_top_mm: float
    radius_bottom_mm: float
    support_mode: str
    body_diameter_mm: float = 160.0
    center_thickness_mm: float = 25.0
    clear_radius_mm: float = 75.0
    aperture_pitch_mm: float = 3.0
    young_modulus_pa: float = 72.0e9
    poisson_ratio: float = 0.17
    sector_count: int = 6
    sector_force_n: float = 12.0
    sector_width_deg: float = 30.0
    # Liu only states six 12-N side loads at equally spaced circumferential
    # positions.  A 30-degree equivalent distributed patch is the nominal reconstruction
    # assumption, not a value reported by Liu.  The paper gives six equally
    # spaced 12-N side loads but no circumferential contact footprint.  The
    # 30-degree nominal width leaves an equal 30-degree unloaded gap between
    # neighboring load sectors.  It is a fixed reconstruction assumption, not
    # a value reported by Liu et al.; no optical amplitude fit is applied.
    load_z_fraction_min: float = 0.0
    load_z_fraction_max: float = 1.0
    support_radius_mm: float = 78.0
    support_width_mm: float = 4.0
    support_thickness_mm: float = 2.6
    support_modulus_pa: float = 5.0e6
    support_tangential_ratio: float = 0.3
    refractive_index: float = 1.457
    q11_per_pa: float = 0.38e-12
    q12_per_pa: float = 2.60e-12
    wavelength_nm: float = 632.8

    @property
    def optical_config(self) -> OpticalConfig:
        return OpticalConfig(
            body_diameter_mm=self.body_diameter_mm,
            center_thickness_mm=self.center_thickness_mm,
            radius_top_mm=self.radius_top_mm,
            radius_bottom_mm=self.radius_bottom_mm,
            clear_radius_mm=self.clear_radius_mm,
            aperture_pitch_mm=self.aperture_pitch_mm,
            refractive_index=self.refractive_index,
            q11_per_pa=self.q11_per_pa,
            q12_per_pa=self.q12_per_pa,
            wavelength_nm=self.wavelength_nm,
        )


@dataclass(frozen=True)
class StructuralResult:
    mesh: SweptMesh
    displacement_m: np.ndarray
    force_n: np.ndarray
    solve_residual: float
    cg_iterations: int
    mesh_generation_s: float
    assembly_s: float
    load_s: float
    solve_s: float
    stress_recovery_s: float
    support_nodes: int
    fixed_dofs: tuple[int, ...]
    sector_resultants_n: tuple[float, ...]
    max_displacement_um: float


_LOCAL_NODE_OFFSETS = np.array(
    [(0,0,0),(1,0,0),(1,1,0),(0,1,0),(0,0,1),(1,0,1),(1,1,1),(0,1,1)],
    dtype=np.int8,
)
_GAUSS_1D = (-1.0 / math.sqrt(3.0), 1.0 / math.sqrt(3.0))
_GAUSS_POINTS = tuple((x,y,z) for z in _GAUSS_1D for y in _GAUSS_1D for x in _GAUSS_1D)


def _concentric_square_to_disk(u: np.ndarray, v: np.ndarray, radius_mm: float) -> tuple[np.ndarray, np.ndarray]:
    """Forward map paired exactly with TopologyHex8Locator._base_logical()."""
    u = np.asarray(u, dtype=float)
    v = np.asarray(v, dtype=float)
    radial = np.maximum(np.abs(u), np.abs(v))
    angle = np.zeros_like(radial)
    nonzero = radial > 1.0e-15
    right = (u >= 0.0) & (np.abs(u) >= np.abs(v)) & nonzero
    top = (v > 0.0) & (np.abs(v) > np.abs(u)) & nonzero
    left = (u < 0.0) & (np.abs(u) >= np.abs(v)) & nonzero
    bottom = (v < 0.0) & (np.abs(v) > np.abs(u)) & nonzero
    angle[right] = 0.25 * math.pi * v[right] / u[right]
    angle[top] = 0.5 * math.pi - 0.25 * math.pi * u[top] / v[top]
    lt = left & (v >= 0.0)
    lb = left & (v < 0.0)
    angle[lt] = math.pi + 0.25 * math.pi * v[lt] / u[lt]
    angle[lb] = -math.pi + 0.25 * math.pi * v[lb] / u[lb]
    angle[bottom] = -0.5 * math.pi - 0.25 * math.pi * u[bottom] / v[bottom]
    return radius_mm * radial * np.cos(angle), radius_mm * radial * np.sin(angle)


def _generate_structured_swept_mesh(spec: FEMCaseSpec) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[int,int,int]]:
    n = int(spec.n_xy)
    nz = int(spec.n_layers)
    logical = np.linspace(-1.0, 1.0, n + 1)
    uu, vv = np.meshgrid(logical, logical, indexing="xy")
    body_radius = 0.5 * spec.body_diameter_mm
    x, y = _concentric_square_to_disk(uu, vv, body_radius)
    radial = np.hypot(x, y)
    bottom, top = surface_heights(radial, spec.optical_config)
    if np.any(top - bottom <= 0.0):
        raise ValueError(f"{spec.name}: nonpositive optical/mechanical thickness in generated mesh")
    fraction = np.linspace(0.0, 1.0, nz + 1)[:, None, None]
    z = bottom[None, :, :] + fraction * (top - bottom)[None, :, :]
    nodes_by_plane = np.stack(
        (np.broadcast_to(x, z.shape), np.broadcast_to(y, z.shape), z), axis=-1
    ).reshape(nz + 1, (n + 1) ** 2, 3)
    nodes_flat = nodes_by_plane.reshape(-1, 3)
    nx = n + 1
    base_count = nx * nx
    conn = np.empty((n * n * nz, 8), dtype=np.int32)
    row = 0
    for k in range(nz):
        layer0 = k * base_count
        layer1 = (k + 1) * base_count
        for j in range(n):
            for i in range(n):
                a = layer0 + j * nx + i
                b = layer1 + j * nx + i
                conn[row] = (a, a+1, a+1+nx, a+nx, b, b+1, b+1+nx, b+nx)
                row += 1
    base_quads = np.empty((n*n, 4), dtype=np.int32)
    row = 0
    for j in range(n):
        for i in range(n):
            a = j * nx + i
            base_quads[row] = (a, a+1, a+1+nx, a+nx)
            row += 1
    return nodes_by_plane, nodes_flat, conn, (nx, nx, nz + 1)


def _elasticity_matrix(E: float, nu: float) -> np.ndarray:
    lam = E * nu / ((1.0 + nu) * (1.0 - 2.0 * nu))
    mu = E / (2.0 * (1.0 + nu))
    return np.array([
        [lam+2*mu, lam, lam, 0, 0, 0],
        [lam, lam+2*mu, lam, 0, 0, 0],
        [lam, lam, lam+2*mu, 0, 0, 0],
        [0, 0, 0, mu, 0, 0],
        [0, 0, 0, 0, mu, 0],
        [0, 0, 0, 0, 0, mu],
    ], dtype=float)


def _hex8_grad_nat(xi: float, eta: float, zeta: float) -> np.ndarray:
    a, b, c = HEX8_SIGNS.T
    out = np.empty((8, 3), dtype=float)
    out[:,0] = 0.125 * a * (1.0 + b*eta) * (1.0 + c*zeta)
    out[:,1] = 0.125 * b * (1.0 + a*xi) * (1.0 + c*zeta)
    out[:,2] = 0.125 * c * (1.0 + a*xi) * (1.0 + b*eta)
    return out


def _hex8_shape_at(xi: float, eta: float, zeta: float) -> np.ndarray:
    a, b, c = HEX8_SIGNS.T
    return 0.125 * (1.0 + a*xi) * (1.0 + b*eta) * (1.0 + c*zeta)


def _build_B(grad_xyz: np.ndarray) -> np.ndarray:
    m = grad_xyz.shape[0]
    B = np.zeros((m, 6, 24), dtype=float)
    for a in range(8):
        gx, gy, gz = grad_xyz[:,a,0], grad_xyz[:,a,1], grad_xyz[:,a,2]
        p = 3*a
        B[:,0,p] = gx
        B[:,1,p+1] = gy
        B[:,2,p+2] = gz
        B[:,3,p] = gy; B[:,3,p+1] = gx
        B[:,4,p+1] = gz; B[:,4,p+2] = gy
        B[:,5,p] = gz; B[:,5,p+2] = gx
    return B


def _element_stiffness_batch(coords_m: np.ndarray, D: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    m = coords_m.shape[0]
    ke = np.zeros((m, 24, 24), dtype=float)
    volume = np.zeros(m, dtype=float)
    for gp in _GAUSS_POINTS:
        G = _hex8_grad_nat(*gp)
        jac = np.einsum("eip,iq->epq", coords_m, G, optimize=True)
        det = np.linalg.det(jac)
        if np.any(det <= 0.0):
            raise ValueError(f"invalid HEX8 Jacobian: minimum det(J)={det.min():.6e}")
        inv_jac = np.linalg.inv(jac)
        grad = np.einsum("iq,eqp->eip", G, inv_jac, optimize=True)
        B = _build_B(grad)
        ke += np.einsum("eai,ab,ebj,e->eij", B, D, B, det, optimize=True)
        volume += det
    return ke, volume


def _assemble_structured_stiffness(nodes_mm: np.ndarray, conn: np.ndarray, dims: tuple[int,int,int], E: float, nu: float, batch: int = 384):
    """Assemble a block-CSR matrix without a huge scalar COO staging array."""
    nodes_m = np.asarray(nodes_mm, dtype=float) * 1.0e-3
    n_nodes = nodes_m.shape[0]
    blocks = np.zeros((n_nodes, 27, 3, 3), dtype=float)
    D = _elasticity_matrix(E, nu)
    for start in range(0, conn.shape[0], batch):
        elements = conn[start:start+batch]
        ke, _ = _element_stiffness_batch(nodes_m[elements], D)
        blk = ke.reshape(elements.shape[0], 8, 3, 8, 3).transpose(0,1,3,2,4)
        for a in range(8):
            rows = elements[:,a]
            for b in range(8):
                delta = _LOCAL_NODE_OFFSETS[b] - _LOCAL_NODE_OFFSETS[a]
                code = int((delta[2]+1)*9 + (delta[1]+1)*3 + (delta[0]+1))
                np.add.at(blocks[:,code], rows, blk[:,a,b])
    nx, ny, nz = dims
    nxy = nx * ny
    ids = np.arange(n_nodes, dtype=np.int64)
    kk = ids // nxy
    rem = ids - kk*nxy
    jj = rem // nx
    ii = rem - jj*nx
    neighbor = np.empty((n_nodes,27), dtype=np.int32)
    valid = np.empty((n_nodes,27), dtype=bool)
    code = 0
    for dz in (-1,0,1):
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                i2, j2, k2 = ii+dx, jj+dy, kk+dz
                ok = (i2>=0)&(i2<nx)&(j2>=0)&(j2<ny)&(k2>=0)&(k2<nz)
                valid[:,code] = ok
                neighbor[:,code] = np.where(ok, k2*nxy + j2*nx + i2, 0).astype(np.int32)
                code += 1
    counts = valid.sum(axis=1)
    indptr = np.r_[0, np.cumsum(counts)].astype(np.int64)
    data = blocks[valid]
    indices = neighbor[valid]
    matrix = bsr_matrix((data, indices, indptr), shape=(3*n_nodes,3*n_nodes), blocksize=(3,3)).tocsr()
    matrix.sum_duplicates(); matrix.sort_indices()
    return matrix


def _side_faces(n: int, nz: int) -> np.ndarray:
    nx = n + 1
    base = nx * nx
    faces: list[tuple[int,int,int,int]] = []
    for k in range(nz):
        for j in range(n):
            a0 = k*base + j*nx
            a1 = (k+1)*base + j*nx
            faces.append((a0, a0+nx, a1+nx, a1))
            a0 += n; a1 += n
            faces.append((a0, a1, a1+nx, a0+nx))
        for i in range(n):
            a0 = k*base + i
            a1 = (k+1)*base + i
            faces.append((a0, a1, a1+1, a0+1))
            a0 += n*nx; a1 += n*nx
            faces.append((a0, a0+1, a1+1, a1))
    return np.asarray(faces, dtype=np.int32)


def _quad_areas_m2(points_m: np.ndarray) -> np.ndarray:
    first = 0.5*np.linalg.norm(np.cross(points_m[:,1]-points_m[:,0], points_m[:,2]-points_m[:,0]), axis=1)
    second = 0.5*np.linalg.norm(np.cross(points_m[:,2]-points_m[:,0], points_m[:,3]-points_m[:,0]), axis=1)
    return first + second


def _six_sector_load(nodes_mm: np.ndarray, spec: FEMCaseSpec) -> tuple[np.ndarray, tuple[float,...]]:
    """Apply six finite-width radial traction sectors with partial-face overlap.

    Liu et al. report six equally spaced 12-N side loads but not the
    circumferential contact width.  ``sector_width_deg`` is therefore an
    explicit equivalent-load reconstruction parameter.  Boundary faces that
    straddle a sector edge receive only their angular overlap fraction; this
    removes the step changes produced by centroid-only face selection and
    makes the width sensitivity much less mesh dependent.
    """
    faces = _side_faces(spec.n_xy, spec.n_layers)
    points_m = nodes_mm[faces] * 1.0e-3
    area = _quad_areas_m2(points_m)
    angle_nodes = np.arctan2(points_m[:, :, 1], points_m[:, :, 0])
    zmin, zmax = float(nodes_mm[:, 2].min()) * 1.0e-3, float(nodes_mm[:, 2].max()) * 1.0e-3
    zspan = max(zmax - zmin, 1.0e-15)
    frac_nodes = (points_m[:, :, 2] - zmin) / zspan
    face_z_lo = frac_nodes.min(axis=1)
    face_z_hi = frac_nodes.max(axis=1)
    face_z_span = np.maximum(face_z_hi - face_z_lo, 1.0e-12)
    z_overlap = np.maximum(0.0, np.minimum(face_z_hi, spec.load_z_fraction_max) - np.maximum(face_z_lo, spec.load_z_fraction_min))
    axial_fraction = np.clip(z_overlap / face_z_span, 0.0, 1.0)

    force = np.zeros((nodes_mm.shape[0], 3), dtype=float)
    resultants: list[float] = []
    half_width = math.radians(0.5 * spec.sector_width_deg)
    for sector in range(spec.sector_count):
        center = 2.0 * math.pi * sector / spec.sector_count
        rel = np.angle(np.exp(1j * (angle_nodes - center)))
        # Unwrap each narrow side face about its circular mean before
        # computing overlap with [-half_width, +half_width].
        rel_center = np.angle(np.mean(np.exp(1j * rel), axis=1))
        rel_unwrapped = np.empty_like(rel)
        for a in range(4):
            rel_unwrapped[:, a] = rel_center + np.angle(np.exp(1j * (rel[:, a] - rel_center)))
        lo = rel_unwrapped.min(axis=1)
        hi = rel_unwrapped.max(axis=1)
        span = np.maximum(hi - lo, 1.0e-12)
        overlap = np.maximum(0.0, np.minimum(hi, half_width) - np.maximum(lo, -half_width))
        angular_fraction = np.clip(overlap / span, 0.0, 1.0)
        weights = area * angular_fraction * axial_fraction
        mask = weights > 0.0
        if not np.any(mask):
            raise RuntimeError(f"{spec.name}: no side faces selected for load sector {sector}")
        selected = faces[mask]
        local = spec.sector_force_n * weights[mask] / weights[mask].sum()
        direction = -np.array((math.cos(center), math.sin(center), 0.0))
        for a in range(4):
            np.add.at(force, selected[:, a], 0.25 * local[:, None] * direction[None, :])
        resultants.append(float(spec.sector_force_n))
    return force.reshape(-1), tuple(resultants)


def _bottom_surface_faces(n: int) -> np.ndarray:
    nx=n+1
    faces=np.empty((n*n,4),dtype=np.int32)
    row=0
    for j in range(n):
        for i in range(n):
            a=j*nx+i
            faces[row]=(a,a+1,a+1+nx,a+nx)
            row+=1
    return faces


def _annular_support_springs(nodes_mm: np.ndarray, spec: FEMCaseSpec) -> tuple[np.ndarray,int]:
    faces = _bottom_surface_faces(spec.n_xy)
    p = nodes_mm[faces]*1.0e-3
    c = p.mean(axis=1)
    r_mm = 1.0e3*np.hypot(c[:,0],c[:,1])
    half=0.5*spec.support_width_mm
    selected=(r_mm >= spec.support_radius_mm-half)&(r_mm <= spec.support_radius_mm+half)
    area=_quad_areas_m2(p[selected])
    ids=faces[selected]
    tributary=np.zeros(nodes_mm.shape[0],dtype=float)
    for a in range(4):
        np.add.at(tributary,ids[:,a],0.25*area)
    active=tributary>0
    kn_area=spec.support_modulus_pa/(spec.support_thickness_mm*1e-3)
    kz=kn_area*tributary
    kt=spec.support_tangential_ratio*kz
    diag_spring=np.zeros(3*nodes_mm.shape[0],dtype=float)
    diag_spring[0::3]=kt;diag_spring[1::3]=kt;diag_spring[2::3]=kz
    return diag_spring,int(np.count_nonzero(active))


def _minimal_pin_dofs(spec: FEMCaseSpec) -> tuple[int,...]:
    n=spec.n_xy; nx=n+1; mid=n//2
    # Bottom plane: A fixes translation; B and C remove rotations.  Because the
    # six applied resultants are self-balanced, reactions at these pins should
    # be numerical stabilization rather than the physical loading mechanism.
    A=mid*nx+mid
    B=mid*nx+n
    C=n*nx+mid
    return (3*A,3*A+1,3*A+2,3*B+1,3*B+2,3*C+2)


def _recover_nodal_stress(nodes_mm: np.ndarray, conn: np.ndarray, displacement: np.ndarray, E: float, nu: float, batch: int=384) -> np.ndarray:
    nodes_m=nodes_mm*1e-3
    D=_elasticity_matrix(E,nu)
    n_nodes=nodes_mm.shape[0]
    accum=np.zeros((n_nodes,6),dtype=float)
    weights=np.zeros(n_nodes,dtype=float)
    shape_gp=np.array([_hex8_shape_at(*gp) for gp in _GAUSS_POINTS])
    extrap=np.linalg.inv(shape_gp)
    u_nodes=displacement.reshape(-1,3)
    for start in range(0,conn.shape[0],batch):
        elements=conn[start:start+batch]
        coords=nodes_m[elements]
        ue=u_nodes[elements].reshape(elements.shape[0],24)
        gp_stress=[]
        volume=np.zeros(elements.shape[0],dtype=float)
        for gp in _GAUSS_POINTS:
            G=_hex8_grad_nat(*gp)
            jac=np.einsum("eip,iq->epq",coords,G,optimize=True)
            det=np.linalg.det(jac)
            inv=np.linalg.inv(jac)
            grad=np.einsum("iq,eqp->eip",G,inv,optimize=True)
            B=_build_B(grad)
            strain=np.einsum("eij,ej->ei",B,ue,optimize=True)
            gp_stress.append(strain@D.T)
            volume+=det
        gp_stress=np.stack(gp_stress,axis=1)
        element_nodal=np.einsum("ng,egc->enc",extrap,gp_stress,optimize=True)
        for a in range(8):
            np.add.at(accum,elements[:,a],element_nodal[:,a]*volume[:,None])
            np.add.at(weights,elements[:,a],volume)
    recovered=np.divide(accum,weights[:,None],out=np.zeros_like(accum),where=weights[:,None]>0)
    # Pa -> MPa; order is xx,yy,zz,xy,yz,xz, identical to optical kernel.
    return recovered*1.0e-6


def solve_structural_case(spec: FEMCaseSpec, *, cg_rtol: float=1e-8, cg_maxiter: int=6000, batch: int=384) -> StructuralResult:
    t0=perf_counter()
    nodes_by_plane,nodes_flat,conn,dims=_generate_structured_swept_mesh(spec)
    mesh_generation_s=perf_counter()-t0
    t0=perf_counter()
    K=_assemble_structured_stiffness(nodes_flat,conn,dims,spec.young_modulus_pa,spec.poisson_ratio,batch=batch)
    assembly_s=perf_counter()-t0
    t0=perf_counter()
    force,resultants=_six_sector_load(nodes_flat,spec)
    support_nodes=0
    fixed: tuple[int,...]=()
    if spec.support_mode=="annular_springs":
        spring_diag,support_nodes=_annular_support_springs(nodes_flat,spec)
        K=K+diags(spring_diag,0,format="csr")
    elif spec.support_mode=="minimal_pins":
        fixed=_minimal_pin_dofs(spec)
    else:
        raise ValueError(f"unknown support mode {spec.support_mode!r}")
    load_s=perf_counter()-t0
    all_free=np.ones(K.shape[0],dtype=bool)
    if fixed:
        all_free[np.asarray(fixed,dtype=int)]=False
    Kf=K[all_free][:,all_free]
    ff=force[all_free]
    # Node-block Jacobi preconditioner.  Elasticity couples the three
    # displacement components at each node strongly; inverting each 3x3
    # diagonal block is substantially more effective than scalar Jacobi while
    # preserving a simple, reproducible SPD preconditioner.  For pinned cases
    # the block action is restricted to the free-DOF subspace.
    n_nodes = nodes_flat.shape[0]
    ids = np.arange(n_nodes, dtype=np.int64)
    diag_blocks = np.empty((n_nodes, 3, 3), dtype=float)
    for aa in range(3):
        for bb in range(3):
            diag_blocks[:, aa, bb] = K[3*ids + aa, 3*ids + bb].A1
    # Tiny diagonal regularization is only a numerical guard for an accidental
    # singular local block; it is far below the physical stiffness scale.
    block_scale = np.maximum(np.max(np.abs(diag_blocks), axis=(1,2)), 1.0)
    diag_blocks[:,0,0] += 1.0e-14 * block_scale
    diag_blocks[:,1,1] += 1.0e-14 * block_scale
    diag_blocks[:,2,2] += 1.0e-14 * block_scale
    inv_blocks = np.linalg.inv(diag_blocks)
    free_ids = np.flatnonzero(all_free)
    def block_jacobi(x):
        full = np.zeros(3*n_nodes, dtype=float)
        full[free_ids] = x
        y = np.einsum("nij,nj->ni", inv_blocks, full.reshape(n_nodes,3), optimize=True).reshape(-1)
        return y[free_ids]
    M=LinearOperator(Kf.shape,matvec=block_jacobi,dtype=float)
    iterations=0
    def callback(_):
        nonlocal iterations
        iterations+=1
    t0=perf_counter()
    uf,info=cg(Kf,ff,rtol=cg_rtol,atol=0.0,maxiter=cg_maxiter,M=M,callback=callback)
    if info!=0:
        # Direct fallback is retained only for small audit meshes.  Manuscript
        # meshes are expected to converge with the node-block Jacobi CG solve.
        if Kf.shape[0] <= 30000:
            uf=spsolve(Kf,ff)
            info=0
        else:
            raise RuntimeError(f"{spec.name}: block-Jacobi CG failed to converge, info={info}")
    solve_s=perf_counter()-t0
    residual=float(np.linalg.norm(Kf@uf-ff)/max(np.linalg.norm(ff),1e-30))
    displacement=np.zeros(K.shape[0],dtype=float)
    displacement[all_free]=uf
    t0=perf_counter()
    stress_flat=_recover_nodal_stress(nodes_flat,conn,displacement,spec.young_modulus_pa,spec.poisson_ratio,batch=batch)
    stress_s=perf_counter()-t0
    stress_by_plane=stress_flat.reshape(spec.n_layers+1,(spec.n_xy+1)**2,6)
    # Build the exact structured QUAD4 connectivity consumed by the optical code.
    base_quads=np.empty((spec.n_xy*spec.n_xy,4),dtype=np.int32)
    nx=spec.n_xy+1;row=0
    for j in range(spec.n_xy):
        for i in range(spec.n_xy):
            a=j*nx+i;base_quads[row]=(a,a+1,a+1+nx,a+nx);row+=1
    mesh=SweptMesh(nodes_by_plane,base_quads,stress_by_plane,spec.optical_config,spec.name)
    max_um=1e6*float(np.max(np.linalg.norm(displacement.reshape(-1,3),axis=1)))
    return StructuralResult(mesh,displacement,force,residual,iterations,mesh_generation_s,assembly_s,load_s,solve_s,stress_s,support_nodes,fixed,resultants,max_um)


def _paper_specs(mode: str) -> tuple[dict[str,FEMCaseSpec],dict[str,FEMCaseSpec]]:
    if mode=="paper":
        # Final manuscript setting: 36x36x8 = 10,368 HEX8 for each primary
        # case. The representative refinement sequence remains fully
        # self-contained and ends at the same mesh used for the main result.
        primary={
            "plate":FEMCaseSpec("plate",36,8,np.inf,np.inf,"minimal_pins"),
            "moderate":FEMCaseSpec("moderate",36,8,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "high":FEMCaseSpec("high",36,8,100.0,-80.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
        }
        sequence={
            "coarse":FEMCaseSpec("moderate_coarse",24,4,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "baseline":FEMCaseSpec("moderate_baseline",30,6,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "fine":FEMCaseSpec("moderate_fine",33,7,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "finest":primary["moderate"],
        }
    elif mode=="quick":
        primary={
            "plate":FEMCaseSpec("plate",24,6,np.inf,np.inf,"minimal_pins"),
            "moderate":FEMCaseSpec("moderate",24,6,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "high":FEMCaseSpec("high",24,6,100.0,-80.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
        }
        sequence={
            "coarse":FEMCaseSpec("moderate_coarse",12,3,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "baseline":FEMCaseSpec("moderate_baseline",18,4,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
            "fine":primary["moderate"],
            "finest":FEMCaseSpec("moderate_finest",30,8,500.0,-300.0,"annular_springs", load_z_fraction_min=0.44, load_z_fraction_max=0.56),
        }
    else:
        raise ValueError("mode must be 'quick' or 'paper'")
    return primary,sequence

def _structural_rows(case: str, spec: FEMCaseSpec, result: StructuralResult) -> dict:
    mesh=result.mesh
    mid=mesh.n_layers//2
    xy=mesh.nodes_mm[mid,:,:2]
    mask=np.hypot(xy[:,0],xy[:,1])<=mesh.config.clear_radius_mm+1e-12
    st=mesh.stress_mpa[mid,mask]
    return {
        "case":case,"n_xy":spec.n_xy,"layers":spec.n_layers,
        "nodes":int(mesh.nodes_mm.shape[0]*mesh.nodes_mm.shape[1]),
        "elements":int(mesh.n_layers*mesh.n_cells),"support_mode":spec.support_mode,
        "support_nodes":result.support_nodes,"fixed_dofs":len(result.fixed_dofs),
        "mesh_generation_s":result.mesh_generation_s,"assembly_s":result.assembly_s,"load_support_s":result.load_s,"solve_s":result.solve_s,
        "stress_recovery_s":result.stress_recovery_s,
        "fea_total_s":result.mesh_generation_s+result.assembly_s+result.load_s+result.solve_s+result.stress_recovery_s,
        "cg_iterations":result.cg_iterations,
        "linear_relative_residual":result.solve_residual,"max_displacement_um":result.max_displacement_um,
        "sxx_min_clear_mpa":float(np.min(st[:,0])),"sxx_max_clear_mpa":float(np.max(st[:,0])),
        "syy_min_clear_mpa":float(np.min(st[:,1])),"syy_max_clear_mpa":float(np.max(st[:,1])),
        "abs_sxy_max_clear_mpa":float(np.max(np.abs(st[:,3]))),
        "load_sector_count":spec.sector_count,"load_each_n":spec.sector_force_n,
        "load_sector_width_deg":spec.sector_width_deg,
        "load_z_fraction_min":spec.load_z_fraction_min,"load_z_fraction_max":spec.load_z_fraction_max,
    }


def _liu_stress_rows(mesh: SweptMesh) -> list[dict]:
    mid=mesh.n_layers//2
    xy=mesh.nodes_mm[mid,:,:2]
    m=np.hypot(xy[:,0],xy[:,1])<=mesh.config.clear_radius_mm+1e-12
    s=mesh.stress_mpa[mid,m]
    # Targets are read from Liu Fig. 2 colorbars only, not raw data.
    return [
        {"quantity":"sigma_x minimum","liu_figure_scale":-8.0e-3,"unit":"MPa","present":float(np.min(s[:,0])),"basis":"Liu Fig. 2(a) colorbar"},
        {"quantity":"sigma_y minimum","liu_figure_scale":-8.0e-3,"unit":"MPa","present":float(np.min(s[:,1])),"basis":"Liu Fig. 2(b) colorbar"},
        {"quantity":"abs(tau_xy) maximum","liu_figure_scale":12.0e-4,"unit":"MPa","present":float(np.max(np.abs(s[:,3]))),"basis":"Liu Fig. 2(c) colorbar"},
    ]

def _fused_silica_refractive_index(wavelength_nm: float) -> float:
    """Malitson Sellmeier refractive index for fused silica."""
    wavelength_um = float(wavelength_nm) * 1.0e-3
    wavelength_sq = wavelength_um * wavelength_um
    b = (0.6961663, 0.4079426, 0.8974794)
    c_sq = (0.0684043**2, 0.1162414**2, 9.896161**2)
    n_sq = 1.0 + sum(B * wavelength_sq / (wavelength_sq - C) for B, C in zip(b, c_sq))
    return math.sqrt(n_sq)


def _stress_optic_dispersion_ratio(wavelength_nm: float, reference_nm: float = 632.8) -> float:
    """Priestley dispersion ratio R(lambda)/R(lambda0) for fused silica.

    The relation reproduces the reported rise of the stress optic coefficient
    from about 35 nm/cm/MPa near 633 nm to about 43 at 248 nm and 53 at 193 nm.
    """
    wavelength = float(wavelength_nm)
    reference = float(reference_nm)
    pole_1_nm = 121.5
    pole_2_nm = 6900.0
    n_ref = _fused_silica_refractive_index(reference)
    n = _fused_silica_refractive_index(wavelength)
    return (
        (n_ref / n)
        * (wavelength**2 / reference**2)
        * ((reference**2 - pole_1_nm**2) / (wavelength**2 - pole_1_nm**2))
        * ((wavelength**2 - pole_2_nm**2) / (reference**2 - pole_2_nm**2))
    )


def _duv_curved_layer_result(layered: CurvedLayerContext, wavelength_nm: float) -> OpticalResult:
    """Recompute flat-plate Jones propagation at a DUV wavelength.

    The mechanical stress field and local principal directions are unchanged.
    The differential photoelastic response is scaled with the fused-silica
    stress-optic dispersion before the ordered Jones product is recomputed.
    """
    base = layered.mesh.config
    ratio = _stress_optic_dispersion_ratio(wavelength_nm, base.wavelength_nm)
    refractive_index = _fused_silica_refractive_index(wavelength_nm)
    q_mean = 0.5 * (base.q11_per_pa + base.q12_per_pa)
    # R = n^3 |q11-q12| / 2.  The Priestley ratio already describes
    # R(lambda)/R(lambda0), so remove the additional n^3 change when mapping
    # that ratio back to the q11-q12 difference used by the Jones kernel.
    q_diff = (base.q11_per_pa - base.q12_per_pa) * ratio * (base.refractive_index / refractive_index)**3
    cfg = OpticalConfig(
        body_diameter_mm=base.body_diameter_mm,
        center_thickness_mm=base.center_thickness_mm,
        radius_top_mm=base.radius_top_mm,
        radius_bottom_mm=base.radius_bottom_mm,
        clear_radius_mm=base.clear_radius_mm,
        aperture_pitch_mm=base.aperture_pitch_mm,
        refractive_index=refractive_index,
        q11_per_pa=q_mean + 0.5 * q_diff,
        q12_per_pa=q_mean - 0.5 * q_diff,
        wavelength_nm=float(wavelength_nm),
    )
    sampled_stress, ds_mm = sample_curved_per_fe_layer(layered, 1)
    rays = fixed_column_rays(layered)
    started = perf_counter()
    state = integrate_jones(sampled_stress, rays, cfg, ds_mm=ds_mm)
    elapsed = perf_counter() - started
    return OpticalResult(
        x_mm=layered.x_mm.copy(), y_mm=layered.y_mm.copy(),
        retardance_rad=state.retardance_rad, retardation_nm=state.retardation_nm,
        opd_nm=state.opd_nm, slow_axis_rad=state.axis_rad,
        ellipticity_rad=state.ellipticity_rad, path_length_mm=rays.length_mm.copy(),
        jones_matrix=state.matrix, elapsed_s=elapsed, locator="curved_layer_quad4",
        steps=layered.mesh.n_layers, direct_hits=layered.x_mm.size,
        neighbor_hits=0, generic_fallback_hits=0,
        inverse_attempts=layered.plane_map.inverse_attempts, newton_iterations=0,
        evaluated_samples=int(layered.x_mm.size * layered.mesh.n_layers),
    )


def _liu_duv_point_rows(curved632: OpticalResult, duv248: OpticalResult, duv193: OpticalResult) -> list[dict]:
    """Pointwise flat-plate phase fields at 632.8, 248, and 193 nm."""
    return [
        {"x_mm":float(x),"y_mm":float(y),"phase632_rad":float(a),"phase248_rad":float(b),"phase193_rad":float(c)}
        for x,y,a,b,c in zip(curved632.x_mm, curved632.y_mm,
                             curved632.retardance_rad, duv248.retardance_rad, duv193.retardance_rad)
    ]


def _liu_rows(plate_routes: dict[str, OpticalResult], duv248: OpticalResult, duv193: OpticalResult) -> list[dict]:
    """Figure-scale comparison to Liu Zhifan et al. (2021)."""
    curved = plate_routes["curved_layer"]
    max632_mrad = 1.0e3 * float(np.max(curved.retardance_rad))
    p95_mrad = 1.0e3 * float(np.percentile(curved.retardance_rad, 95.0))
    opd_pv = float(np.ptp(curved.opd_nm))
    max248 = float(np.max(duv248.retardance_rad))
    max193 = float(np.max(duv193.retardance_rad))
    return [
        {
            "quantity": "632.8 nm simulated retardance",
            "liu_basis": "Fig. 3 colorbar/figure only; upper labelled scale about 6 mrad",
            "liu_value": 6.0, "liu_unit": "mrad (approx figure scale)",
            "present_value": max632_mrad, "present_aux": p95_mrad,
            "present_aux_label": "95th percentile (mrad)",
            "comparison_type": "scale/morphology only",
        },
        {
            "quantity": "632.8 nm measured retardance",
            "liu_basis": "Fig. 5 colorbar reaches 8e-3 rad",
            "liu_value": 8.0, "liu_unit": "mrad",
            "present_value": max632_mrad, "present_aux": p95_mrad,
            "present_aux_label": "95th percentile (mrad)",
            "comparison_type": "scale only; present result is numerical",
        },
        {
            "quantity": "632.8 nm wavefront/OPD scale",
            "liu_basis": "Fig. 4 colorbar reaches 0.688 nm",
            "liu_value": 0.688, "liu_unit": "nm",
            "present_value": opd_pv, "present_aux": float("nan"),
            "present_aux_label": "", "comparison_type": "scale only",
        },
        {
            "quantity": "248 nm phase retardance",
            "liu_basis": "Fig. 6/text: maximum not exceeding 0.020 rad",
            "liu_value": 0.020, "liu_unit": "rad",
            "present_value": max248, "present_aux": float("nan"),
            "present_aux_label": "", "comparison_type": "wavelength-dependent stress-optic recomputation",
        },
        {
            "quantity": "193 nm phase retardance",
            "liu_basis": "Fig. 7/text: maximum not exceeding 0.032 rad",
            "liu_value": 0.032, "liu_unit": "rad",
            "present_value": max193, "present_aux": float("nan"),
            "present_aux_label": "", "comparison_type": "wavelength-dependent stress-optic recomputation",
        },
    ]


def _plate_midplane_stress_rows(layered: CurvedLayerContext) -> list[dict]:
    plane = layered.mesh.n_layers // 2
    stress = layered.plane_stress_mpa[plane]
    rows = []
    for i in range(layered.x_mm.size):
        rows.append({
            "x_mm": float(layered.x_mm[i]), "y_mm": float(layered.y_mm[i]),
            "sxx_mpa": float(stress[i, 0]), "syy_mpa": float(stress[i, 1]),
            "szz_mpa": float(stress[i, 2]), "sxy_mpa": float(stress[i, 3]),
            "syz_mpa": float(stress[i, 4]), "sxz_mpa": float(stress[i, 5]),
            "fe_plane_index": int(plane),
        })
    return rows


def _transverse_anisotropy_gradient_p95(layered: CurvedLayerContext) -> float:
    """P95 lateral gradient of (sigma_xx-sigma_yy, 2 sigma_xy) on pupil columns."""
    stress, _ = sample_curved_per_fe_layer(layered, 1)
    anisotropy = np.stack((stress[:, :, 0] - stress[:, :, 1], 2.0 * stress[:, :, 3]), axis=-1)
    pitch = layered.mesh.config.aperture_pitch_mm
    xy = np.column_stack((layered.x_mm, layered.y_mm))
    grid = {tuple(np.rint(point / pitch).astype(int)): i for i, point in enumerate(xy)}
    gradients = []
    for i, point in enumerate(xy):
        ix, iy = np.rint(point / pitch).astype(int)
        neighbors = [grid.get((ix - 1, iy)), grid.get((ix + 1, iy)),
                     grid.get((ix, iy - 1)), grid.get((ix, iy + 1))]
        if any(j is None for j in neighbors):
            continue
        left, right, down, up = neighbors
        dx = (anisotropy[:, right] - anisotropy[:, left]) / (2.0 * pitch)
        dy = (anisotropy[:, up] - anisotropy[:, down]) / (2.0 * pitch)
        gradients.extend(np.sqrt(np.sum(dx * dx + dy * dy, axis=-1)).tolist())
    return float(np.percentile(gradients, 95.0))


def _state_as_result(template: OpticalResult, state: JonesState) -> OpticalResult:
    return replace(template, retardance_rad=state.retardance_rad,
                   retardation_nm=state.retardation_nm, opd_nm=state.opd_nm,
                   slow_axis_rad=state.axis_rad, ellipticity_rad=state.ellipticity_rad,
                   jones_matrix=state.matrix)


def run_revision_checks(saved: dict, primary_specs: dict, args: argparse.Namespace) -> None:
    """Export focused controls requested in the 614756 review round."""
    curvature_rows = []
    curvature_cases = [
        ("moderate", 500.0, -300.0),
        ("intermediate_1", 350.0, -250.0),
        ("intermediate_2", 250.0, -180.0),
        ("intermediate_3", 180.0, -130.0),
        ("high", 100.0, -80.0),
    ]
    for name, top_radius, bottom_radius in curvature_cases:
        if name in saved:
            record = saved[name]
            mesh, context, layered = record["mesh"], record["context"], record["layered"]
            reference, curved = record["routes"]["reference"], record["routes"]["curved_layer"]
        else:
            spec = replace(primary_specs["moderate"], name=name,
                           radius_top_mm=top_radius, radius_bottom_mm=bottom_radius)
            mesh = solve_structural_case(spec, cg_rtol=args.fea_rtol,
                                         cg_maxiter=args.fea_maxiter, batch=args.fea_batch).mesh
            context = EvaluationContext.build(mesh)
            layered, _ = build_curved_layer_context_timed(mesh, context.x_mm, context.y_mm)
            reference = evaluate_quadrature(context, build_layer_quadrature(mesh, context.rays, 4))
            curved = evaluate_curved_layerwise(layered, samples_per_layer=1)
        offset = np.linalg.norm(context.rays.exit_mm[:, :2] - context.rays.start_mm[:, :2], axis=1)
        metrics = comparison_metrics(curved, reference)
        curvature_rows.append({
            "case": name, "R1_mm": top_radius, "R2_mm": bottom_radius,
            "max_lateral_offset_mm": float(np.max(offset)),
            "max_lateral_offset_percent_CA": float(100.0 * np.max(offset) / mesh.config.clear_radius_mm),
            "stress_anisotropy_gradient_p95_mpa_per_mm": _transverse_anisotropy_gradient_p95(layered),
            "retardance_rms_residual_mrad": metrics["retardance_rms_error_mrad"],
            "retardance_relative_rms_percent": metrics["retardance_relative_rms_percent"],
            "retardance_max_abs_residual_mrad": metrics["retardance_max_abs_error_mrad"],
        })
        print(f"revision curvature {name}: relative RMS {metrics['retardance_relative_rms_percent']:.3f}%", flush=True)
    _write_dict_rows(OUTPUT_ROOT / "revision_curvature_sensitivity.csv", curvature_rows)

    width_rows = []
    baseline_reference = saved["moderate"]["routes"]["reference"]
    for width in (20.0, 30.0, 40.0):
        if width == 30.0:
            reference = baseline_reference
            curved = saved["moderate"]["routes"]["curved_layer"]
        else:
            spec = replace(primary_specs["moderate"], name=f"moderate_width_{int(width)}",
                           sector_width_deg=width)
            mesh = solve_structural_case(spec, cg_rtol=args.fea_rtol,
                                         cg_maxiter=args.fea_maxiter, batch=args.fea_batch).mesh
            context = EvaluationContext.build(mesh)
            layered, _ = build_curved_layer_context_timed(mesh, context.x_mm, context.y_mm)
            reference = evaluate_quadrature(context, build_layer_quadrature(mesh, context.rays, 4))
            curved = evaluate_curved_layerwise(layered, samples_per_layer=1)
        width_rows.append({
            "sector_width_deg": width,
            "reference_change_from_30deg_rms_mrad": comparison_metrics(reference, baseline_reference)["retardance_rms_error_mrad"],
            "curved_layer_rms_residual_mrad": comparison_metrics(curved, reference)["retardance_rms_error_mrad"],
            "curved_layer_relative_rms_percent": comparison_metrics(curved, reference)["retardance_relative_rms_percent"],
        })
    _write_dict_rows(OUTPUT_ROOT / "revision_traction_width_sensitivity.csv", width_rows)

    path_rows = []
    surface_rows = []
    jaccard_rows = []
    for name in ("moderate", "high"):
        record = saved[name]
        mesh, context, layered = record["mesh"], record["context"], record["layered"]
        routes = record["routes"]
        vertical_rays = fixed_column_rays(layered)
        vertical_boundaries = layered.plane_heights_mm[-1][None, :] - layered.plane_heights_mm[::-1]
        vertical_quad = build_layer_quadrature(mesh, vertical_rays, 1, boundaries=vertical_boundaries)
        global_z = np.zeros_like(context.rays.direction)
        global_z[:, 2] = -1.0
        hybrid_state = integrate_jones(record["sampled_q1"], context.rays, mesh.config,
                                       projection_direction=global_z, ds_mm=vertical_quad.ds_mm)
        hybrid = _state_as_result(routes["refracted_global"], hybrid_state)
        history = comparison_metrics(hybrid, routes["fixed_volume"])
        length = comparison_metrics(routes["refracted_global"], hybrid)
        hybrid_reference = comparison_metrics(hybrid, routes["reference"])
        path_rows.append({
            "case": name,
            "refracted_stress_vertical_ds_to_reference_rms_mrad": hybrid_reference["retardance_rms_error_mrad"],
            "fixed_to_refracted_stress_vertical_ds_rms_mrad": history["retardance_rms_error_mrad"],
            "vertical_to_refracted_ds_same_stress_rms_mrad": length["retardance_rms_error_mrad"],
            "fixed_to_refracted_stress_vertical_ds_opd_rms_nm": history["opd_piston_removed_rms_error_nm"],
            "vertical_to_refracted_ds_same_stress_opd_rms_nm": length["opd_piston_removed_rms_error_nm"],
            "max_path_length_change_mm": float(np.max(np.abs(context.rays.length_mm - vertical_rays.length_mm))),
        })
        fe_rays = conform_ray_segments_to_mesh(mesh, context.rays)
        fe_context = replace(context, rays=fe_rays)
        fe_quad = build_layer_quadrature(mesh, fe_rays, 4)
        fe_reference = evaluate_quadrature(fe_context, fe_quad)
        geometry_effect = comparison_metrics(fe_reference, routes["reference"])
        surface_rows.append({
            "case": name,
            "max_analytic_fe_path_length_difference_mm": float(np.max(np.abs(fe_rays.length_mm - context.rays.length_mm))),
            "retardance_rms_difference_mrad": geometry_effect["retardance_rms_error_mrad"],
            "retardance_max_abs_difference_mrad": geometry_effect["retardance_max_abs_error_mrad"],
            "opd_piston_removed_rms_difference_nm": geometry_effect["opd_piston_removed_rms_error_nm"],
        })
        for fraction in (0.05, 0.10, 0.20):
            jaccard_rows.append({"case": name, "top_fraction_percent": 100.0 * fraction,
                                 "jaccard": _top_fraction_jaccard(routes["curved_layer"].retardance_rad,
                                                                  routes["reference"].retardance_rad, fraction)})
    _write_dict_rows(OUTPUT_ROOT / "revision_path_length_control.csv", path_rows)
    _write_dict_rows(OUTPUT_ROOT / "revision_surface_mismatch.csv", surface_rows)
    _write_dict_rows(OUTPUT_ROOT / "revision_jaccard_sensitivity.csv", jaccard_rows)




# Primary and mesh-study case specifications are generated internally by _paper_specs().



def run_self_tests() -> None:
    # 1. Flat sag must support both mathematical infinity and legacy zero.
    r = np.array([0.0, 20.0, 75.0])
    assert np.allclose(spherical_sag(r, np.inf), 0.0)
    assert np.allclose(spherical_sag(r, 0.0), 0.0)

    # 2. Hydrostatic stress has zero retardance.
    cfg = OpticalConfig(160.0, 25.0, np.inf, np.inf)
    rays = RayBundle(
        np.array([[0.0, 0.0, 25.0]]), np.array([[0.0, 0.0, -1.0]]),
        np.array([25.0]), np.array([[0.0, 0.0, 0.0]])
    )
    p = 1.234
    stress = np.array([[[p, p, p, 0.0, 0.0, 0.0]]])
    state = integrate_jones(stress, rays, cfg, ds_mm=np.array([[25.0]]))
    if abs(float(state.retardance_rad[0])) > 1.0e-12:
        raise AssertionError("hydrostatic stress produced nonzero retardance")

    # 3. Uniform uniaxial stress agrees with analytical local birefringence.
    sx = 1.0
    uni = np.array([[[sx, 0.0, 0.0, 0.0, 0.0, 0.0]]])
    state = integrate_jones(uni, rays, cfg, ds_mm=np.array([[25.0]]))
    ray_tensor = rotate_voigt_to_ray(uni.reshape(-1, 6), np.array([[0.0, 0.0, -1.0]]))
    dns, dnf, _, _ = stress_optic_state(ray_tensor, cfg)
    expected = 2.0 * math.pi * abs(float(dns[0] - dnf[0])) * 0.025 / (cfg.wavelength_nm * 1e-9)
    if not math.isclose(float(state.retardance_rad[0]), expected, rel_tol=1e-10, abs_tol=1e-12):
        raise AssertionError("uniform uniaxial Jones result disagrees with analytic retardance")
    # 4. Mohr-circle half-angle / eigenvector equivalence.  The principal
    # stress direction theta = 0.5*atan2(2*tau, sx-sy) must agree, modulo pi,
    # with the eigenvector of the larger transverse principal stress.
    rng = np.random.default_rng(20260817)
    for _ in range(256):
        sx_t, sy_t, tau_t = rng.normal(size=3)
        tensor2 = np.array([[sx_t, tau_t], [tau_t, sy_t]], dtype=float)
        vals, vecs = np.linalg.eigh(tensor2)
        principal_vec = vecs[:, int(np.argmax(vals))]
        theta_eig = math.atan2(float(principal_vec[1]), float(principal_vec[0]))
        theta_mohr = 0.5 * math.atan2(2.0 * tau_t, sx_t - sy_t)
        director_error = 0.5 * math.atan2(
            math.sin(2.0 * (theta_mohr - theta_eig)),
            math.cos(2.0 * (theta_mohr - theta_eig)),
        )
        if abs(director_error) > 1.0e-12:
            raise AssertionError("Mohr half-angle principal-axis test failed")

    # 5. HEX8 affine patch test.  An affine displacement field must
    # reproduce its constant engineering strain at every Gauss point.
    cube=np.array([
        [0,0,0],[1,0,0],[1,1,0],[0,1,0],
        [0,0,1],[1,0,1],[1,1,1],[0,1,1],
    ],dtype=float)
    ex,ey,ez,gxy=1.2e-5,-0.7e-5,0.4e-5,0.9e-5
    disp=np.zeros((8,3),dtype=float)
    disp[:,0]=ex*cube[:,0]+0.5*gxy*cube[:,1]
    disp[:,1]=ey*cube[:,1]+0.5*gxy*cube[:,0]
    disp[:,2]=ez*cube[:,2]
    target=np.array([ex,ey,ez,gxy,0.0,0.0])
    for gp in _GAUSS_POINTS:
        G=_hex8_grad_nat(*gp)
        jac=cube.T@G
        grad=G@np.linalg.inv(jac)
        B=_build_B(grad[None,:,:])[0]
        got=B@disp.reshape(-1)
        if not np.allclose(got,target,rtol=1e-11,atol=1e-13):
            raise AssertionError("HEX8 affine patch test failed")

    # 6. Tiny 3-D FE plate: six sector loads are self-balanced and the
    # recovered clear-aperture stress must be finite and compressive.
    spec=FEMCaseSpec("selftest_plate",6,2,np.inf,np.inf,"minimal_pins")
    structural=solve_structural_case(spec,cg_rtol=1e-8,cg_maxiter=2000,batch=128)
    if structural.solve_residual > 2e-8:
        raise AssertionError("structural self-test did not reach the requested residual")
    if not np.isfinite(structural.mesh.stress_mpa).all():
        raise AssertionError("structural self-test produced non-finite stress")
    print("self-test: PASS (Mohr half-angle/eigenvector + HEX8 affine patch + assembled FEA, flat sag, hydrostatic invariant, uniaxial optical check)")


def _optical_result_from_sampled_stress(
    context: EvaluationContext,
    quadrature: LayerQuadrature,
    stress_mpa: np.ndarray,
    *,
    rays: RayBundle | None = None,
    projection_direction: np.ndarray | None = None,
    sampling_elapsed_s: float = 0.0,
    locator_label: str = "mapped-batch",
) -> tuple[OpticalResult, float]:
    rays_used = context.rays if rays is None else rays
    t0 = perf_counter()
    state = integrate_jones(
        stress_mpa,
        rays_used,
        context.mesh.config,
        projection_direction=projection_direction,
        ds_mm=quadrature.ds_mm,
    )
    jones_s = perf_counter() - t0
    result = OpticalResult(
        x_mm=context.x_mm.copy(),
        y_mm=context.y_mm.copy(),
        retardance_rad=state.retardance_rad,
        retardation_nm=state.retardation_nm,
        opd_nm=state.opd_nm,
        slow_axis_rad=state.axis_rad,
        ellipticity_rad=state.ellipticity_rad,
        path_length_mm=rays_used.length_mm.copy(),
        jones_matrix=state.matrix,
        elapsed_s=float(sampling_elapsed_s + jones_s),
        locator=locator_label,
        steps=int(quadrature.points_mm.shape[0]),
        direct_hits=0,
        neighbor_hits=0,
        generic_fallback_hits=0,
        inverse_attempts=0,
        newton_iterations=0,
        evaluated_samples=int(quadrature.points_mm.shape[0] * context.x_mm.size),
    )
    return result, jones_s


def _sample_named_quadratures_once(
    mesh: SweptMesh,
    named_quadratures: list[tuple[str, LayerQuadrature]],
) -> tuple[dict[str, np.ndarray], dict[str, float]]:
    """Sample several quadratures in one fresh mapped-HEX8 location pass.

    A single combined pass avoids cumulative allocator/solver overhead from
    repeatedly rebuilding very large Newton batches during convergence studies.
    The returned sampling time is allocated to individual sets in proportion to
    their number of physical sample points; the total measured pass is also
    exported so the timing decomposition remains auditable.
    """
    if not named_quadratures:
        return {}, {"total_sampling_s": 0.0, "total_samples": 0}
    counts = [int(q.points_mm.shape[0] * q.points_mm.shape[1]) for _, q in named_quadratures]
    flat = np.concatenate([q.points_mm.reshape(-1, 3) for _, q in named_quadratures], axis=0)
    locator = MappedTopologyHex8Locator(mesh)
    t0 = perf_counter()
    stress_flat = np.empty((flat.shape[0], 6), dtype=float)
    direct_hits = neighbor_hits = generic_fallback_hits = 0
    inverse_attempts = newton_iterations = 0
    # Keep each Newton batch bounded.  The manuscript-resolution curved lens
    # can contain >6e5 optical stress samples in the combined convergence pass;
    # a few 2e5-point chunks avoid allocator thrashing without changing the
    # exact physical inverse mapping.
    chunk_size = 8192
    for start in range(0, flat.shape[0], chunk_size):
        stop = min(start + chunk_size, flat.shape[0])
        located = locator.locate(flat[start:stop])
        stress_flat[start:stop] = locator.interpolate_stress(located)
        direct_hits += located.direct_hits
        neighbor_hits += located.neighbor_hits
        generic_fallback_hits += located.generic_fallback_hits
        inverse_attempts += located.inverse_attempts
        newton_iterations += located.newton_iterations
    elapsed = perf_counter() - t0
    out: dict[str, np.ndarray] = {}
    offset = 0
    for (name, q), count in zip(named_quadratures, counts):
        out[name] = stress_flat[offset:offset+count].reshape(q.points_mm.shape[0], q.points_mm.shape[1], 6)
        offset += count
    stats = {
        "total_sampling_s": float(elapsed),
        "total_samples": int(flat.shape[0]),
        "direct_hits": int(direct_hits),
        "neighbor_hits": int(neighbor_hits),
        "generic_fallback_hits": int(generic_fallback_hits),
        "inverse_attempts": int(inverse_attempts),
        "newton_iterations": int(newton_iterations),
        "sampling_s_per_sample": float(elapsed / max(flat.shape[0], 1)),
    }
    return out, stats


def _simple_locator_audit(
    context: EvaluationContext,
    quadrature: LayerQuadrature,
    mapped_stress: np.ndarray,
    *,
    max_rays: int = 96,
) -> dict[str, float]:
    nrays = context.x_mm.size
    ids = np.linspace(0, nrays - 1, min(max_rays, nrays), dtype=int)
    points = quadrature.points_mm[:, ids].reshape(-1, 3)
    generic = GenericHex8Locator(context.mesh)
    gloc = generic.locate(points)
    gstress = generic.interpolate_stress(gloc)
    mstress = mapped_stress[:, ids].reshape(-1, 6)
    diff = mstress - gstress
    return {
        "checked_rays": int(ids.size),
        "checked_samples": int(points.shape[0]),
        "stress_component_max_abs_mpa": float(np.max(np.abs(diff))),
        "stress_component_rms_mpa": float(np.sqrt(np.mean(diff**2))),
    }


def run_analysis(args: argparse.Namespace) -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    q_grid = tuple(sorted(set(int(v) for v in args.reference_q.split(",") if int(v) > 0)))
    if not q_grid:
        raise ValueError("reference-q must contain positive integers")
    fine_q = max(q_grid)
    primary_specs, mesh_specs = _paper_specs(args.mode)

    summary: dict[str, object] = {
        "reference_policy": {
            "candidate_samples_per_fe_layer": list(q_grid),
            "final_reference_samples_per_fe_layer": int(fine_q),
            "retardance_tolerance_mrad": args.reference_ret_tol_mrad,
            "opd_tolerance_nm": args.reference_opd_tol_nm,
            "note": "final baseline uses the finest q; smaller q values are convergence diagnostics",
        },
        "timing_policy": {
            "sampling": "one combined mapped-HEX8 sampling pass per case; route sampling shares are allocated by sample count",
            "jones": "measured directly from pre-sampled stress arrays",
            "direct_route": "one untimed warmup followed by median wall time for the prepared optical route",
            "end_to_end": "structural solve + route-specific context/preparation + prepared optical route; reported separately from prepared-route timing",
            "repeats": int(args.timing_repeats),
            "note": "timings are implementation- and hardware-specific",
        },
        "software": {
            "python": platform.python_version(), "numpy": np.__version__,
            "scipy": __import__("scipy").__version__, "platform": platform.platform(),
        },
        "fea_policy": {
            "solver": "3-D small-displacement linear elasticity, swept HEX8, 2x2x2 Gauss, node-block Jacobi PCG",
            "stress_recovery": "Gauss stress extrapolation to element nodes followed by volume-weighted patch averaging",
            "flat_plate_comparison": "six source-derived 12 N radial resultants; 30 degree circumferential regularization because the source does not publish contact width; no fitted optical amplitude factor",
            "mode": args.mode,
        },
        "cases": {},
    }

    metric_rows: list[dict] = []
    convergence_rows: list[dict] = []
    depth_rows: list[dict] = []
    comparison_rows: list[dict] = []
    timing_rows: list[dict] = []
    radial_rows: list[dict] = []
    zernike_rows: list[dict] = []
    applicability_points: list[dict] = []
    applicability_bins: list[dict] = []
    symmetry_rows: list[dict] = []
    geometry_rows: list[dict] = []
    locator_rows: list[dict] = []
    structural_rows: list[dict] = []
    mesh_rows: list[dict] = []
    saved: dict[str, dict[str, object]] = {}
    structural_cache: dict[tuple, StructuralResult] = {}

    def key(spec: FEMCaseSpec) -> tuple:
        return (spec.n_xy, spec.n_layers, spec.radius_top_mm, spec.radius_bottom_mm,
                spec.support_mode, spec.sector_width_deg, spec.load_z_fraction_min, spec.load_z_fraction_max)

    def get_structural(spec: FEMCaseSpec) -> StructuralResult:
        k = key(spec)
        if k not in structural_cache:
            print(f"FEA {spec.name}: {spec.n_xy}x{spec.n_xy}x{spec.n_layers} HEX8 ...", flush=True)
            structural_cache[k] = solve_structural_case(
                spec, cg_rtol=args.fea_rtol, cg_maxiter=args.fea_maxiter, batch=args.fea_batch
            )
        return structural_cache[k]

    # Representative mesh study using the same final reference q.
    if not args.skip_mesh_study:
        mesh_results={}
        for level,spec in mesh_specs.items():
            structural=get_structural(spec); mesh=structural.mesh
            if not any(r["case"]==spec.name for r in structural_rows): structural_rows.append(_structural_rows(spec.name,spec,structural))
            context=EvaluationContext.build(mesh); layered,_=build_curved_layer_context_timed(mesh,context.x_mm,context.y_mm)
            b=ray_layer_boundaries(mesh,context.rays); q=build_layer_quadrature(mesh,context.rays,fine_q,boundaries=b)
            sampled,stats=_sample_named_quadratures_once(mesh,[("ref",q)])
            ref,_=_optical_result_from_sampled_stress(context,q,sampled["ref"],sampling_elapsed_s=stats["total_sampling_s"])
            curved=evaluate_curved_layerwise(layered,samples_per_layer=1)
            mesh_results[level]=(mesh,ref,curved)
        finest_ref=mesh_results["finest"][1]
        for level,spec in mesh_specs.items():
            mesh,ref,curved=mesh_results[level]
            mesh_rows.append({
                "mesh":level.capitalize(),"nodes":int(mesh.nodes_mm.shape[0]*mesh.nodes_mm.shape[1]),"elements":int(mesh.n_layers*mesh.n_cells),"layers":mesh.n_layers,
                "reference_field_difference_to_finest_mrad":(
                    None if level == "finest" else comparison_metrics(ref,finest_ref)["retardance_rms_error_mrad"]
                ),
                "curved_layer_same_mesh_rms_residual_mrad":comparison_metrics(curved,ref)["retardance_rms_error_mrad"],
            })


    for case, spec in primary_specs.items():
        structural = get_structural(spec)
        mesh = structural.mesh
        structural_rows.append(_structural_rows(case, spec, structural))
        t0=perf_counter()
        context = EvaluationContext.build(mesh)
        context_build_s=perf_counter()-t0
        layered, curved_prep = build_curved_layer_context_timed(mesh, context.x_mm, context.y_mm)
        geometry = _geometry_audit(mesh, context.x_mm, context.y_mm, layered)
        geometry_rows.append({"case": case, **geometry})

        # Analytic swept-layer boundaries are geometric and reused by all q.
        t0 = perf_counter()
        refracted_boundaries = ray_layer_boundaries(mesh, context.rays)
        boundary_s = perf_counter() - t0
        ref_quads = {}
        quad_build_s = {}
        for q in q_grid:
            t0=perf_counter()
            ref_quads[q] = build_layer_quadrature(mesh, context.rays, q, boundaries=refracted_boundaries)
            quad_build_s[q] = perf_counter()-t0
        vertical_rays = fixed_column_rays(layered)
        # Preserve the exact swept-plane boundaries used by the curved layer
        # route so the volume control changes stress interpolation only.
        vertical_boundaries = layered.plane_heights_mm[-1][None, :] - layered.plane_heights_mm[::-1]
        vertical_quad = build_layer_quadrature(mesh, vertical_rays, 1, boundaries=vertical_boundaries)

        named = [(f"ref_q{q}", ref_quads[q]) for q in q_grid] + [("vertical_q1", vertical_quad)]
        sampled, sampling_stats = _sample_named_quadratures_once(mesh, named)
        per_sample = sampling_stats["sampling_s_per_sample"]

        ref_results: dict[int, OpticalResult] = {}
        ref_jones_times: dict[int, float] = {}
        for q in q_grid:
            quad = ref_quads[q]
            allocated_sampling = per_sample * quad.points_mm.shape[0] * quad.points_mm.shape[1]
            result, jtime = _optical_result_from_sampled_stress(
                context, quad, sampled[f"ref_q{q}"],
                sampling_elapsed_s=allocated_sampling,
            )
            ref_results[q] = result
            ref_jones_times[q] = jtime

        reference = ref_results[fine_q]
        projection_control = ref_results[min(q_grid)] if min(q_grid) == 1 else ref_results[q_grid[0]]
        if 1 not in ref_results:
            raise ValueError("reference-q must include q=1 because q=1 defines the projection control")
        projection_control = ref_results[1]
        selected_q, ref_rows = _reference_choice(
            ref_results,
            retardance_tolerance_mrad=args.reference_ret_tol_mrad,
            opd_tolerance_nm=args.reference_opd_tol_nm,
        )
        for row in ref_rows:
            row.update({"case": case, "fine_q": fine_q, "selected_q": selected_q})
            convergence_rows.append(row)
            depth_rows.append({"case": case, "route": "refracted_ray", **row})

        curved_by_q: dict[int, OpticalResult] = {}
        for q in q_grid:
            cq = evaluate_curved_layerwise(layered, samples_per_layer=q)
            curved_by_q[q] = cq
            depth_rows.append({
                "case": case, "route": "curved_layer", "samples_per_fe_layer": q,
                **comparison_metrics(cq, reference),
            })
        curved = curved_by_q[1]

        global_z = np.zeros_like(context.rays.direction); global_z[:,2] = -1.0
        refracted_global, rg_jones_s = _optical_result_from_sampled_stress(
            context, ref_quads[1], sampled["ref_q1"],
            projection_direction=global_z,
            sampling_elapsed_s=per_sample * ref_quads[1].points_mm.shape[0] * context.x_mm.size,
        )
        fixed_volume, fv_jones_s = _optical_result_from_sampled_stress(
            context, vertical_quad, sampled["vertical_q1"],
            rays=vertical_rays, projection_direction=global_z,
            sampling_elapsed_s=per_sample * vertical_quad.points_mm.shape[0] * context.x_mm.size,
        )
        routes = {
            "reference": reference, "curved_layer": curved, "fixed_volume": fixed_volume,
            "refracted_global": refracted_global, "projection_control": projection_control,
        }
        saved[case] = {
            "mesh": mesh, "context": context, "layered": layered, "routes": routes,
            "selected_q": selected_q, "fine_q": fine_q, "sampled_q1": sampled["ref_q1"],
        }
        _write_stage_points(OUTPUT_ROOT / f"{case}_stage_points.csv", routes)

        for route, result in routes.items():
            metric_rows.append({
                "case": case, "route": route, "steps": result.steps,
                "samples_per_fe_layer": result.steps / mesh.n_layers,
                "runtime_s": result.elapsed_s, **comparison_metrics(result, reference),
            })

        stages = [
            ("curved_layer", "Fixed column", "Swept planes", "Global x-y", curved),
            ("fixed_volume", "Fixed column", "HEX8 volume", "Global x-y", fixed_volume),
            ("refracted_global", "Refracted", "HEX8 volume", "Global x-y", refracted_global),
            ("projection_control", "Refracted", "HEX8 volume", "Ray normal", projection_control),
            ("reference", "Refracted", "HEX8 volume", "Ray normal", reference),
        ]
        previous = None
        for index, (stage, path_name, sampling_name, frame, result) in enumerate(stages):
            row = {
                "case": case, "stage_index": index, "stage": stage, "path": path_name,
                "stress_sampling": sampling_name, "transverse_frame": frame, "steps": result.steps,
                **{f"to_reference_{k}": v for k,v in comparison_metrics(result, reference).items()},
            }
            if previous is None:
                row.update({"incremental_retardance_rms_mrad":0.0,"incremental_opd_rms_nm":0.0,"incremental_axis_weighted_rms_deg":0.0})
            else:
                inc = comparison_metrics(result, previous)
                row.update({
                    "incremental_retardance_rms_mrad":inc["retardance_rms_error_mrad"],
                    "incremental_opd_rms_nm":inc["opd_piston_removed_rms_error_nm"],
                    "incremental_axis_weighted_rms_deg":inc["axis_weighted_rms_error_deg"],
                })
            comparison_rows.append(row); previous=result

        # Timing has two complementary views. Component timing comes from the
        # shared combined sampling pass. Direct timing re-executes the complete
        # prepared optical route (FEA excluded) and reports a median after one
        # warmup. This is the timing used for route speed ratios in the paper.
        ref_sampling = per_sample * reference.evaluated_samples
        projection_sampling = per_sample * projection_control.evaluated_samples
        vertical_sampling = per_sample * fixed_volume.evaluated_samples

        def _median_direct(fn, repeats: int) -> tuple[float,float,float]:
            fn()  # untimed warmup
            vals=[]
            for _ in range(max(1,int(repeats))):
                t=perf_counter(); fn(); vals.append(perf_counter()-t)
            arr=np.asarray(vals,dtype=float)
            return float(np.median(arr)), float(np.quantile(arr,0.25)), float(np.quantile(arr,0.75))

        direct_ref=_median_direct(lambda: evaluate_quadrature(context,ref_quads[fine_q],locator="mapped"),args.timing_repeats)
        direct_projection=_median_direct(lambda: evaluate_quadrature(context,ref_quads[1],locator="mapped"),args.timing_repeats)
        direct_layer=_median_direct(lambda: evaluate_curved_layerwise(layered,samples_per_layer=1),args.timing_repeats)
        direct_map={"reference":direct_ref,"projection_control":direct_projection,"curved_layer":direct_layer}
        structural_total_s=(structural.mesh_generation_s+structural.assembly_s+structural.load_s+structural.solve_s+structural.stress_recovery_s)
        route_preparation_s={
            "reference":context_build_s+boundary_s+quad_build_s[fine_q],
            "projection_control":context_build_s+boundary_s+quad_build_s[1],
            "curved_layer":context_build_s+curved_prep["curved_preprocess_total_s"],
        }

        base_rows=[
            {"case":case,"route":"reference","sampling_s":ref_sampling,"jones_s":ref_jones_times[fine_q],"preprocess_s":boundary_s,"total_component_s":boundary_s+ref_sampling+ref_jones_times[fine_q]},
            {"case":case,"route":"projection_control","sampling_s":projection_sampling,"jones_s":ref_jones_times[1],"preprocess_s":boundary_s,"total_component_s":boundary_s+projection_sampling+ref_jones_times[1]},
            {"case":case,"route":"curved_layer","sampling_s":0.0,"jones_s":curved.elapsed_s,"preprocess_s":curved_prep["curved_preprocess_total_s"],"total_component_s":curved_prep["curved_preprocess_total_s"]+curved.elapsed_s},
            {"case":case,"route":"fixed_volume","sampling_s":vertical_sampling,"jones_s":fv_jones_s,"preprocess_s":0.0,"total_component_s":vertical_sampling+fv_jones_s},
            {"case":case,"route":"refracted_global","sampling_s":projection_sampling,"jones_s":rg_jones_s,"preprocess_s":boundary_s,"total_component_s":boundary_s+projection_sampling+rg_jones_s},
        ]
        for tr in base_rows:
            if tr["route"] in direct_map:
                med,q25,q75=direct_map[tr["route"]]
                prep=route_preparation_s[tr["route"]]
                tr.update({
                    "direct_median_s":med,"direct_q25_s":q25,"direct_q75_s":q75,
                    "structural_total_s":structural_total_s,"context_and_route_preparation_s":prep,
                    "end_to_end_median_s":structural_total_s+prep+med,
                })
            else:
                tr.update({"direct_median_s":float("nan"),"direct_q25_s":float("nan"),"direct_q75_s":float("nan"),
                           "structural_total_s":structural_total_s,"context_and_route_preparation_s":float("nan"),"end_to_end_median_s":float("nan")})
            timing_rows.append(tr)

        radial_rows.extend(_radial_rows(case, {k:routes[k] for k in ("reference","curved_layer","projection_control")}))
        if case == "moderate": zernike_rows.extend(_zernike_rows(case, routes))
        if case in ("moderate","high"):
            p_rows,b_rows = _applicability_rows(case, mesh, context, curved, reference)
            applicability_points.extend(p_rows); applicability_bins.extend(b_rows)
        for route in ("reference","curved_layer","projection_control"):
            result=routes[route]
            sr=_symmetry_error_60(result.x_mm,result.y_mm,result.retardance_rad)
            so=_symmetry_error_60(result.x_mm,result.y_mm,result.opd_nm-np.mean(result.opd_nm))
            symmetry_rows.append({
                "case":case,"route":route,
                "retardance_c6_valid_points":sr["valid_points"],"retardance_c6_rms_rad":sr["rms_difference"],"retardance_c6_normalized_rms":sr["normalized_rms"],
                "opd_c6_valid_points":so["valid_points"],"opd_c6_rms_nm":so["rms_difference"],"opd_c6_normalized_rms":so["normalized_rms"],
            })
        loc_audit = _simple_locator_audit(context, ref_quads[1], sampled["ref_q1"])
        locator_rows.append({"case":case,**loc_audit})

        case_summary = {
            "fea": _structural_rows(case,spec,structural),
            "config": {
                "body_diameter_mm":mesh.config.body_diameter_mm,"center_thickness_mm":mesh.config.center_thickness_mm,
                "radius_top_mm":mesh.config.radius_top_mm,"radius_bottom_mm":mesh.config.radius_bottom_mm,
                "clear_radius_mm":mesh.config.clear_radius_mm,"wavelength_nm":mesh.config.wavelength_nm,
                "n0":mesh.config.refractive_index,"q11_per_pa":mesh.config.q11_per_pa,"q12_per_pa":mesh.config.q12_per_pa,
            },
            "rays":int(context.x_mm.size),"fe_nodes":int(mesh.nodes_mm.shape[0]*mesh.nodes_mm.shape[1]),
            "fe_elements":int(mesh.n_layers*mesh.n_cells),"fe_layers":int(mesh.n_layers),
            "reference_selected_samples_per_fe_layer":int(selected_q),"reference_fine_samples_per_fe_layer":int(fine_q),
            "sampling_pass":sampling_stats,
            "timing": {
                "structural_total_s": structural_total_s,
                "context_build_s": context_build_s,
                "curved_preprocess_s": curved_prep["curved_preprocess_total_s"],
                "refracted_boundary_s": boundary_s,
                "quadrature_build_q1_s": quad_build_s[1],
                "quadrature_build_fineq_s": quad_build_s[fine_q],
                "prepared_layer_s": direct_layer[0],
                "prepared_projection_control_s": direct_projection[0],
                "prepared_reference_s": direct_ref[0],
                "projection_control_over_layer": direct_projection[0]/direct_layer[0],
                "fine_reference_over_layer": direct_ref[0]/direct_layer[0],
                "end_to_end_layer_s": structural_total_s+route_preparation_s["curved_layer"]+direct_layer[0],
                "end_to_end_projection_control_s": structural_total_s+route_preparation_s["projection_control"]+direct_projection[0],
                "end_to_end_reference_s": structural_total_s+route_preparation_s["reference"]+direct_ref[0],
            },
            "curved_layer_vs_reference":comparison_metrics(curved,reference),
            "projection_control_vs_reference":comparison_metrics(projection_control,reference),
            "geometry_audit":geometry,"locator_audit":loc_audit,
        }
        summary["cases"][case] = case_summary
        print(f"{case}: qfine={fine_q}, curved RMS={case_summary['curved_layer_vs_reference']['retardance_rms_error_mrad']:.6g} mrad, projection control RMS={case_summary['projection_control_vs_reference']['retardance_rms_error_mrad']:.6g} mrad", flush=True)

    if args.mode == "paper" and fine_q == 4:
        run_revision_checks(saved, primary_specs, args)

    # Liu scale/morphology outputs.
    if "plate" in saved:
        plate=saved["plate"]
        duv248 = _duv_curved_layer_result(plate["layered"], 248.0)
        duv193 = _duv_curved_layer_result(plate["layered"], 193.0)
        _write_dict_rows(OUTPUT_ROOT/"liu_benchmark.csv",_liu_rows(plate["routes"], duv248, duv193))
        _write_dict_rows(OUTPUT_ROOT/"liu_stress_scale.csv",_liu_stress_rows(plate["mesh"]))
        _write_dict_rows(OUTPUT_ROOT/"liu_duv_points.csv",_liu_duv_point_rows(plate["routes"]["curved_layer"], duv248, duv193))
        _write_dict_rows(OUTPUT_ROOT/"plate_midplane_stress.csv",_plate_midplane_stress_rows(plate["layered"]))

    _write_dict_rows(OUTPUT_ROOT/"comparison_metrics.csv",metric_rows)
    _write_dict_rows(OUTPUT_ROOT/"reference_convergence.csv",convergence_rows)
    _write_dict_rows(OUTPUT_ROOT/"route_depth_convergence.csv",depth_rows)
    _write_dict_rows(OUTPUT_ROOT/"control_metrics.csv",comparison_rows)
    _write_dict_rows(OUTPUT_ROOT/"timing.csv",timing_rows)
    _write_dict_rows(OUTPUT_ROOT/"radial_profiles.csv",radial_rows)
    _write_dict_rows(OUTPUT_ROOT/"zernike_coefficients.csv",zernike_rows)
    _write_dict_rows(OUTPUT_ROOT/"applicability_points.csv",applicability_points)
    _write_dict_rows(OUTPUT_ROOT/"applicability_binned.csv",applicability_bins)
    _write_dict_rows(OUTPUT_ROOT/"mesh_sensitivity.csv",mesh_rows)
    _write_dict_rows(OUTPUT_ROOT/"symmetry_audit.csv",symmetry_rows)
    _write_dict_rows(OUTPUT_ROOT/"geometry_audit.csv",geometry_rows)
    _write_dict_rows(OUTPUT_ROOT/"locator_equivalence.csv",locator_rows)
    _write_dict_rows(OUTPUT_ROOT/"structural_audit.csv",structural_rows)
    (OUTPUT_ROOT/"summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding="utf-8")
    print(f"wrote plot-ready tables to {OUTPUT_ROOT}", flush=True)

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="FEA and curved layer Jones calculation")
    parser.add_argument("--self-test", action="store_true", help="run analytical FE/optical invariants and exit")
    parser.add_argument("--mode", choices=("quick","paper"), default="paper", help="quick audit meshes or manuscript-resolution meshes")
    parser.add_argument("--fea-rtol", type=float, default=1.0e-8, help="relative residual target for the structural CG solve")
    parser.add_argument("--fea-maxiter", type=int, default=6000)
    parser.add_argument("--fea-batch", type=int, default=384, help="HEX8 assembly/recovery batch size")
    parser.add_argument("--skip-mesh-study", action="store_true", help="skip the additional representative lens mesh sequence")
    parser.add_argument("--timing-repeats", type=int, default=3, help="direct optical-route timing repeats after one warmup")
    parser.add_argument(
        "--reference-q", default="1,2,4",
        help="candidate true midpoint samples per swept FE layer for reference convergence",
    )
    parser.add_argument("--reference-ret-tol-mrad", type=float, default=1.0e-3)
    parser.add_argument("--reference-opd-tol-nm", type=float, default=1.0e-4)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_tests()
        return
    run_analysis(args)


if __name__ == "__main__":
    main()

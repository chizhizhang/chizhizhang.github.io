# Rapid stress birefringence mapping in mounted curved lenses with a curved layer Jones approximation

Self-contained finite-element and Jones-optics numerical engine, with separate figure generation.
No external mesh or measured stress field is required for analysis.

    python -m pip install -r requirements.txt
    python scripts/main.py --self-test
    python scripts/main.py --mode quick
    python scripts/main.py --mode paper
    python scripts/figures.py

Run from the extracted root. The paper mode uses manuscript-resolution meshes and may be expensive.
The archived outputs/ tables can be used directly for figure generation.
The controlled comparison with the published flat-plate example is limited by unavailable original mesh/contact data; see the analysis source for the modeling assumptions.

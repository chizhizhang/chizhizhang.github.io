# Frozen synthetic observation-boundary protocol

Protocol recorded before execution. This bounded simulation tests observation and confirmation conventions, not the ordered endpoint pipeline, actual devices, physical failures, generalization, or decision utility. It is supplemental mechanism illustration only.

## Scientific question and fairness review

How do inspection spacing, measurement noise and administrative observation termination affect first registered threshold crossing under two transparent conventions? Both receive exactly the same observations, fixed known baseline 1, threshold 0.8 and clock. Latent crossing time is generated independently of either algorithm. No tuning, data-driven scenario selection, synthetic expert labels or actual-archive calibration is used. All factorial scenarios and null findings are exported. The prior fairness audit is `fairness_design.md`.

## Data generation

Seed 20260911. There are 400 independent replication cohorts of 100 independent synthetic units. For each cohort, latent crossing times T are uniform on [150,1350] arbitrary time units. Latent response is max(0, 1 - 0.2*t/T), so the known continuous crossing of 0.8 occurs at T. Baseline 1 is fixed and never estimated. Observed response is latent response plus independent normal noise of standard deviation 0 or 0.03. The time-zero baseline is exactly 1. This generator is a mathematical illustration and is not fitted to an engineering degradation process.

Factorial scenarios: regular inspection spacing 25, 100 or 300 time units; administrative termination 600, 900 or 1200; observation noise 0 or 0.03. The terminal time is always included. All schedules are subsets of a 25-unit master grid, and common generated noise is reused at shared inspections. Termination is administrative and independent of T. Paired scenario comparisons therefore have common latent cohorts; informative censoring is not modeled.

## Two operators

First registered crossing: first observed response at or below 0.8; if absent, C.

Confirmed-interior/terminal convention: use the same first crossing time if at least one later observed response is at or below 0.8, OR if the first crossing is the last observation; otherwise U (unresolved interior crossing). This reproduces the confirmation exception relevant to the manuscript but not its early-loss or baseline logic. U is distinct from C and is never silently relabeled a negative. Later confirmation need not be consecutive. Both operators return the same first-crossing time whenever both return an event. Under noiseless monotone observations they must be identical; this is a required negative control.

## Metrics and uncertainty

Export each replication/scenario/operator: latent crossings by administrative termination; registered events; C and U fractions over all 100 units; signed registered-event fraction minus latent-crossing fraction (a descriptive difference with U reported separately); false registered events before latent crossing would occur within follow-up; missed latent events; and mean signed registered time minus latent T among true crossings that receive a registered event. Timing summaries are selection-conditional; export their support counts. Also export first-crossing terminal-only events, unresolved interior crossings, and paired operator event-fraction difference. No method is labeled more accurate overall, as operators answer different confirmation questions.

Aggregate all 18 scenarios, retaining both operators. For each metric report mean across replications and Monte Carlo standard error SD/sqrt(400), with mean +/- 1.96 MCSE. These intervals quantify simulation precision, not prediction intervals, archive confidence intervals, or parameter uncertainty. Event-time errors are in arbitrary time units, not hours. All seeds/configuration and paired summaries are exported. No plotting and no changes to manuscript source.

## Acceptance and interpretation

Require equal generated inputs per operator, complete factorial output, no U/C conflation, exact noiseless operator equality, exact common-event registered-time equality, and fractions summing to one. All scenarios must remain in output regardless of direction. Conclusions are limited to sampling/confirmation behavior in the specified synthetic generator. If redundant for the manuscript, retain the simulation as an audit artifact rather than adding a weak main-text contribution.

Source-traceable reliability endpoint construction
Analysis code and shareable data, version 1

The package includes a synthetic example, aggregate numerical results, the
rule definitions and the two simulation analyses. The example workbook
collects the synthetic observations and the paired VCSEL summaries.
The data holder controls access to the historical VCSEL workbooks and
record-level exports. Those inputs are required for a full archive replay.

Run the synthetic example and the early-reference simulation from this folder.
The expected results are in evidence/. The analysis was tested with Python 3.13.

    python -m pip install -r scripts/requirements.txt
    python -B scripts/ress_revision_checks.py --example-only --output replay
    python -B -c "import sys; sys.path.insert(0, 'scripts'); from main import run_observation_simulation; run_observation_simulation()"

The final command regenerates the inspection and confirmation simulation.

For the battery example, obtain the Battery Data Set archive from NASA PCoE.
https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

    python -B scripts/main.py --stage external_validation --external-nasa-archive PATH_TO_NASA_ZIP
    python -B scripts/main.py --stage system_artifacts

For the independent short VCSEL example, obtain Data.zip from the source
deposit and supply its path. The expected result is in evidence/.
https://doi.org/10.6084/m9.figshare.31021633.v1

    python -B scripts/ress_revision_checks.py --example-only --public-laser-archive PATH_TO_VCSEL_ZIP --output replay

In the controlled workspace, run the complete numerical analysis with its
approved inputs before running the revision checks and source-cell audit.

    python -B scripts/main.py --external-nasa-archive PATH_TO_NASA_ZIP
    python -B scripts/ress_revision_checks.py
    python -B scripts/ress_rmst_factorial_sensitivity.py
    python -B scripts/audit_source_cells.py

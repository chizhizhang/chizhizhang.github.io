"""Factor early-reference and registration-time effects on archived crossing RMST.

This exploratory RESS extension reads frozen endpoint exports; it neither
reconstructs raw workbooks nor fits a physical failure-time model. The four
cells retain the same paired devices, threshold and source groups.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "outputs" / "analysis" / "early_rule_endpoint_transitions.csv"
ENSEMBLE_INPUT = ROOT / "outputs" / "analysis" / "reliability_dataset_all_definitions.csv"
OUT = ROOT / "outputs" / "ress_upgrade_20260925" / "rmst_extension"
TAU_H = 6000.0
N_BOOTSTRAP = 20_000
SEED = 20260925
REFERENCE_SCENARIOS = {
    "maximum": "frozen_max_reference_100h_240h",
    "median": "median_reference_100h_240h",
}


def km_summary(times: np.ndarray, events: np.ndarray, horizon: float) -> dict[str, float | int | None]:
    """Compute a product-limit curve, median and restricted integral directly."""
    times = np.asarray(times, dtype=float)
    events = np.asarray(events, dtype=int)
    if len(times) == 0 or len(times) != len(events) or not np.all(np.isfinite(times)):
        raise ValueError("Invalid nonempty time/event vectors")
    if np.any(times <= 0) or np.any(~np.isin(events, [0, 1])):
        raise ValueError("Times must be positive and events binary")

    event_times, counts = np.unique(times[events == 1], return_counts=True)
    sorted_times = np.sort(times)
    at_risk = len(times) - np.searchsorted(sorted_times, event_times, side="left")
    factors = 1.0 - counts / at_risk
    survival_after = np.cumprod(factors)
    reached = np.flatnonzero(survival_after <= 0.5)
    median = float(event_times[reached[0]]) if len(reached) else None

    through = event_times <= horizon
    relevant_times = event_times[through]
    relevant_after = survival_after[through]
    boundary_times = np.concatenate(([0.0], relevant_times, [horizon]))
    levels = np.concatenate(([1.0], relevant_after))
    rmst = float(np.sum(np.diff(boundary_times) * levels))
    survival = float(relevant_after[-1]) if len(relevant_after) else 1.0
    return {
        "n": int(len(times)),
        "events": int(events.sum()),
        "observed_at_horizon": int(np.sum(times >= horizon)),
        "survival_at_horizon": survival,
        "rmst_h": rmst,
        "km_median_h": median,
    }


def prepare() -> tuple[dict[str, pd.DataFrame], list[str]]:
    raw = pd.read_csv(INPUT, keep_default_na=False, encoding="utf-8-sig")
    expected = set(REFERENCE_SCENARIOS.values())
    selected = raw.loc[raw["scenario"].isin(expected)].copy()
    if set(selected["scenario"]) != expected:
        raise ValueError("Missing one of the two registered early-reference scenarios")
    for scenario, group in selected.groupby("scenario"):
        if group["device_uid"].duplicated().any() or len(group) != 104:
            raise ValueError(f"Scenario has missing or duplicate devices: {scenario}")

    by_reference = {
        label: selected.loc[selected["scenario"].eq(scenario)].set_index("device_uid")
        for label, scenario in REFERENCE_SCENARIOS.items()
    }
    if set(by_reference["maximum"].index) != set(by_reference["median"].index):
        raise ValueError("Reference scenarios contain different device IDs")
    common = sorted(
        set(by_reference["maximum"].index[by_reference["maximum"]["endpoint_state"].ne("NA")])
        & set(by_reference["median"].index[by_reference["median"]["endpoint_state"].ne("NA")])
    )
    excluded = sorted(set(by_reference["maximum"].index) - set(common))
    by_reference = {key: value.loc[common].copy() for key, value in by_reference.items()}
    if not by_reference["maximum"]["file_id"].equals(by_reference["median"]["file_id"]):
        raise ValueError("Paired source IDs disagree")

    for label, group in by_reference.items():
        group["first_time_h"] = pd.to_numeric(group["analysis_time_h"], errors="raise")
        group["event"] = pd.to_numeric(group["event_observed"], errors="raise").astype(int)
        group["confirmation_time_h"] = pd.to_numeric(
            group["event_confirmation_time_h"].replace("", np.nan), errors="coerce"
        ).where(group["event"].eq(1), group["first_time_h"])
        if group.loc[group["event"].eq(1), "confirmation_time_h"].isna().any():
            raise ValueError(f"Missing confirmation time for {label} event")
        if (group["confirmation_time_h"] < group["first_time_h"]).any():
            raise ValueError(f"Confirmation precedes first support for {label}")
        if not group["endpoint_state"].isin(["E", "R", "C"]).all():
            raise ValueError(f"Unexpected assessable state for {label}")
    return by_reference, excluded


def cell(by_reference: dict[str, pd.DataFrame], reference: str, timing: str, indices: np.ndarray) -> dict:
    group = by_reference[reference].iloc[indices]
    column = "first_time_h" if timing == "first_support" else "confirmation_time_h"
    result = km_summary(group[column].to_numpy(), group["event"].to_numpy(), TAU_H)
    return {"reference": reference, "timing": timing, **result}


def contrasts(cells: list[dict]) -> dict[str, float]:
    values = {(row["reference"], row["timing"]): row["rmst_h"] for row in cells}
    ref_first = values["median", "first_support"] - values["maximum", "first_support"]
    ref_confirm = values["median", "confirmation"] - values["maximum", "confirmation"]
    time_max = values["maximum", "confirmation"] - values["maximum", "first_support"]
    time_med = values["median", "confirmation"] - values["median", "first_support"]
    return {
        "reference_effect_first_support_h": ref_first,
        "reference_effect_confirmation_h": ref_confirm,
        "timing_effect_maximum_h": time_max,
        "timing_effect_median_h": time_med,
        "interaction_h": ref_confirm - ref_first,
    }


def evaluate(by_reference: dict[str, pd.DataFrame], indices: np.ndarray) -> tuple[list[dict], dict]:
    cells = [
        cell(by_reference, reference, timing, indices)
        for reference in REFERENCE_SCENARIOS
        for timing in ("first_support", "confirmation")
    ]
    return cells, contrasts(cells)


def baseline_stability() -> pd.DataFrame:
    data = pd.read_csv(ENSEMBLE_INPUT, keep_default_na=False, encoding="utf-8-sig")
    result = []
    expected = {"p0_best_available", "p0_early_median5", "p0_meta", "p0_post_stabilization"}
    for threshold, group in data.groupby("failure_threshold_ratio"):
        if set(group["p0_definition"]) != expected:
            raise ValueError("Four operational baseline definitions not present")
        assessed = group.pivot(index="device_uid", columns="p0_definition", values="assessable")
        event = group.pivot(index="device_uid", columns="p0_definition", values="event_observed")
        if assessed.shape != (104, 4) or event.shape != (104, 4):
            raise ValueError("Incomplete operational-baseline matrix")
        common = assessed.astype(str).eq("True").all(axis=1)
        discordant = event.loc[common].astype(int).nunique(axis=1).gt(1)
        result.append(
            {
                "threshold_ratio": float(threshold),
                "devices_total": 104,
                "common_assessable": int(common.sum()),
                "binary_discordant_on_common_cohort": int(discordant.sum()),
                "binary_stable_on_common_cohort": int(common.sum() - discordant.sum()),
            }
        )
    return pd.DataFrame(result).sort_values("threshold_ratio", ascending=False)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    by_reference, excluded = prepare()
    all_indices = np.arange(len(by_reference["maximum"]))
    cells, full_contrasts = evaluate(by_reference, all_indices)
    pd.DataFrame(cells).to_csv(OUT / "factorial_cells.csv", index=False)

    source = by_reference["maximum"]["file_id"].to_numpy()
    sources = sorted(set(source))
    omitted = []
    for source_id in sources:
        indices = np.flatnonzero(source != source_id)
        subcells, subcontrasts = evaluate(by_reference, indices)
        omitted.append(
            {
                "omitted_source": source_id,
                "n_remaining": len(indices),
                "min_observed_at_horizon": min(row["observed_at_horizon"] for row in subcells),
                **subcontrasts,
            }
        )
    pd.DataFrame(omitted).to_csv(OUT / "source_omission.csv", index=False)

    rng = np.random.default_rng(SEED)
    source_indices = {label: np.flatnonzero(source == label) for label in sources}
    bootstrap = []
    for draw in range(N_BOOTSTRAP):
        sampled = rng.choice(sources, size=len(sources), replace=True)
        indices = np.concatenate([source_indices[item] for item in sampled])
        subcells, subcontrasts = evaluate(by_reference, indices)
        bootstrap.append(
            {
                "draw": draw,
                "supported_to_horizon": int(min(row["observed_at_horizon"] for row in subcells) > 0),
                **subcontrasts,
            }
        )
    bootstrap_frame = pd.DataFrame(bootstrap)
    bootstrap_frame.to_csv(OUT / "paired_source_bootstrap.csv", index=False)
    valid = bootstrap_frame.loc[bootstrap_frame["supported_to_horizon"].eq(1)]
    intervals = {
        key: {
            "point_h": float(value),
            "p2_5_h": float(np.percentile(valid[key], 2.5)),
            "p97_5_h": float(np.percentile(valid[key], 97.5)),
        }
        for key, value in full_contrasts.items()
    }
    stable = baseline_stability()
    stable.to_csv(OUT / "operational_baseline_stability.csv", index=False)

    summary = {
        "analysis_label": "exploratory_posthoc_method_extension",
        "horizon_h": TAU_H,
        "paired_devices": len(all_indices),
        "excluded_nonassessable_device_ids": excluded,
        "sources": sources,
        "bootstrap_draws": N_BOOTSTRAP,
        "bootstrap_supported_draws": len(valid),
        "cell_summaries": cells,
        "contrasts": intervals,
        "all_source_omissions_supported": bool((pd.DataFrame(omitted)["min_observed_at_horizon"] > 0).all()),
        "baseline_stability": stable.to_dict(orient="records"),
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

"""Reproduce the revision checks without replacing the frozen endpoint rules."""

from __future__ import annotations

import argparse
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np
import pandas as pd
from scipy.optimize import linprog, minimize

from ress_endpoint_analysis import BASE, MEDIAN


def km_rmst(time, event, horizon):
    survival, area, previous = 1.0, 0.0, 0.0
    for current in np.unique(time[time < horizon]):
        area += survival * (current - previous)
        survival *= 1 - np.count_nonzero((time == current) & event) / np.count_nonzero(time >= current)
        previous = current
    return area + survival * (horizon - previous)


def turnbull_rmst(lower, upper, horizon):
    """Fit mass on maximal intersections and bound within-interval placement.

    Each observation is (L, U], including (0, U] and (L, infinity).
    Strictly dominated membership patterns carry zero likelihood-maximizing mass.
    """
    edges = np.unique(np.r_[0., lower, upper])
    candidates = (lower[:, None] < edges[None, 1:]) & (edges[None, 1:] <= upper[:, None])
    contains = candidates.T
    maximal = np.array([
        column.any() and not np.any(
            np.all(contains >= column, axis=1) & np.any(contains > column, axis=1)
        )
        for column in contains
    ])
    left, right = edges[:-1][maximal], edges[1:][maximal]
    design = candidates[:, maximal].astype(float)
    if not design.any(axis=1).all():
        raise ValueError("Invalid interval-censoring bounds")
    def objective(mass):
        probability = np.maximum(design @ mass, 1e-15)
        return -np.log(probability).mean(), -(design.T @ (1. / probability)) / len(lower)

    fit = minimize(objective, np.full(len(left), 1. / len(left)), jac=True,
                   method="SLSQP", bounds=[(0., 1.)] * len(left),
                   constraints={"type": "eq", "fun": lambda mass: mass.sum() - 1.,
                                "jac": lambda mass: np.ones_like(mass)},
                   options={"ftol": 1e-13, "maxiter": 2000})
    if not fit.success or np.max(-objective(fit.x)[1]) > 1 + 1e-5:
        raise RuntimeError(f"Turnbull likelihood optimality check failed: {fit.message}")
    # Include all mass vectors with the fitted observation probabilities.
    equalities = np.vstack([design, np.ones(len(left))])
    low, high = [linprog(coef, A_eq=equalities, b_eq=equalities @ fit.x, method="highs")
                 for coef in (np.minimum(left, horizon), -np.minimum(right, horizon))]
    if not low.success or not high.success:
        raise RuntimeError("Cannot bracket the restricted mean on the fitted support")
    return low.fun, -high.fun


def first_crossing(time, low):
    """Retain a supported or terminal low, and mark an isolated interior low."""
    idx = np.flatnonzero(low)
    if not len(idx):
        return float(time[-1]), "C"
    first = idx[0]
    if len(idx) > 1 or first == len(time) - 1:
        return float(time[first]), "E"
    return float(time[first]), "NA"


def archive_checks(inputs, output):
    analysis = inputs / "analysis"
    transitions = pd.read_csv(analysis / "early_rule_endpoint_transitions.csv", keep_default_na=False)
    main = pd.read_csv(analysis / "reliability_dataset_main.csv").set_index("device_uid")
    devices = pd.read_csv(inputs / "processed/device_table.csv").set_index("device_uid")
    visits = pd.read_csv(inputs / "processed/measurement_table.csv")
    visits["time"] = visits.exposure_hours.fillna(visits.calendar_hours)
    visits["power"] = visits.endpoint_power_mW.fillna(visits.power_mW)
    visits = visits.dropna(subset=["time", "power"]).sort_values(["time", "measurement_time", "source_cell"])
    traces = {uid: rows for uid, rows in visits.groupby("device_uid")}
    pairs = {
        name: transitions[transitions.scenario.eq(scenario)].set_index("device_uid")
        for name, scenario in [("maximum", BASE), ("median", MEDIAN)]
    }
    common = pairs["maximum"].index.intersection(pairs["median"].index)
    common = [uid for uid in common if all(frame.at[uid, "endpoint_state"] != "NA" for frame in pairs.values())]
    interval_rows, clearance_rows, confirmation_rows, cluster_rows, cohort_rows = [], [], [], [], []
    for name, frame in pairs.items():
        frame = frame.loc[common]
        bounds = []
        for uid, row in frame.iterrows():
            last = float(row.analysis_time_h)
            if not row.event_observed:
                bounds.append((last, np.inf))
                continue
            name_prefix = "" if name == "maximum" else "sensitivity_median_reference_"
            inherited = bool(devices.at[uid, name_prefix + "early_failure_flag"])
            reference = (
                devices.at[uid, name_prefix + "provisional_early_reference_mW"]
                if inherited else float(row.p0_mW)
            )
            trace = traces[uid]
            eligible = trace if inherited else trace[trace.time >= float(row.p0_reference_time_h) - 1e-6]
            assert ((eligible.time.sub(last).abs() <= 1e-6) & (eligible.power / reference <= .8)).any(), uid
            above = eligible[(eligible.time < last - 1e-6) & (eligible.power / reference > .8)]
            bounds.append((float(above.time.max()) if len(above) else 0.0, last))
            if name == "maximum":
                later = trace[trace.time > last + 1e-6].power / reference
                clearance_rows.append({"device": uid, **{
                    f"margin_{margin:.2f}": bool((later > .8 + margin).any())
                    for margin in (.01, .03, .05)
                }})
        lower, upper = np.array(bounds).T
        time = frame.analysis_time_h.astype(float).to_numpy()
        event = frame.event_observed.astype(bool).to_numpy()
        tb_low, tb_high = turnbull_rmst(lower, upper, 6000.)
        interval_rows.append(dict(
            reference=name, n=len(frame), events=int(event.sum()), left_censored=int(((lower == 0) & event).sum()),
            median_bracket_h=np.median((upper - lower)[event]), km_h=km_rmst(time, event, 6000.),
            turnbull_low_h=tb_low, turnbull_high_h=tb_high,
            censoring_low_h=np.minimum(lower, 6000.).mean(), censoring_high_h=np.minimum(upper, 6000.).mean(),
        ))
        delays = pd.to_numeric(frame.event_confirmation_time_h, errors="coerce").to_numpy() - time
        if not np.isfinite(delays[event]).all() or (delays[event] < -1e-6).any():
            raise ValueError("Registered event lacks a valid confirmation or terminal time")
        confirmed = time.copy()
        confirmed[event] += delays[event]
        interval_rows[-1]["km_confirmation_h"] = km_rmst(confirmed, event, 6000.)
        for window in (100, 240, 500):
            unresolved = event & (delays > window)
            confirmation_rows.append(dict(reference=name, window_h=window, kept=int((event & ~unresolved).sum()),
                                          unresolved=int(unresolved.sum()), censored=int((~event).sum())))
        for uid, (lo, hi) in zip(frame.index, bounds):
            cohort_rows.append(dict(reference=name, device_uid=uid, file_id=frame.at[uid, "file_id"],
                                    lower_h=lo, upper_h=hi))
    for temperature, group in main[main.include_temperature_stratified.eq(1)].groupby("temperature_group"):
        for removed in ["none", *sorted(group.file_id.unique())]:
            remaining = group[group.file_id.ne(removed)]
            time = remaining.analysis_time_h.to_numpy()
            event = remaining.event_observed.astype(bool).to_numpy()
            cluster_rows.append(dict(temperature=temperature, omitted=removed, n=len(time), events=int(event.sum()),
                                     sources=remaining.file_id.nunique(),
                                     rmst_1200_h=(km_rmst(time, event, 1200.)
                                                  if len(time) and time.max() >= 1200. else np.nan)))
    pd.DataFrame(interval_rows).to_csv(output / "interval_and_censoring.csv", index=False)
    pd.DataFrame(cohort_rows).to_csv(output / "inspection_brackets_internal.csv", index=False)
    clearance = pd.DataFrame(clearance_rows).drop(columns="device")
    assert clearance["margin_0.03"].sum() == main.event_status.eq("failure_observed_with_recovery").sum()
    clearance.sum().rename("R_states").to_csv(output / "clearance_margins.csv")
    pd.DataFrame(confirmation_rows).to_csv(output / "confirmation_windows.csv", index=False)
    pd.DataFrame(cluster_rows).to_csv(output / "temperature_source_deletion.csv", index=False)

    # A conditional target uses only prefix data to establish both fixed references.
    # A device with no later visit is retained and censored at the landmark.
    landmark_rows = []
    for uid, track in traces.items():
        prefix = track[track.time <= 240.]
        follow = track[track.time > 240.]
        early = prefix[prefix.power > 0].power.iloc[:3].to_numpy()
        if len(early) < 3:
            continue
        references = {"maximum": np.max(early), "median": np.median(early)}
        if (prefix.power <= .8 * max(references.values())).any():
            continue
        for name, reference in references.items():
            later = follow.time.to_numpy() - 240.
            low = later[follow.power.to_numpy() <= .8 * reference]
            event = bool(len(low))
            time = low[0] if event else (later[-1] if len(later) else 0.)
            landmark_rows.append(dict(device=uid, reference=name, time=time, event=event,
                                      prefix_gap_h=240. - prefix.time.max()))
    landmark = pd.DataFrame(landmark_rows)
    summary = []
    for reference, frame in landmark.groupby("reference"):
        summary.append(dict(reference=reference, n=len(frame), events=frame.event.sum(),
                            no_later_inspection=frame.time.eq(0).sum(),
                            median_prefix_gap_h=frame.prefix_gap_h.median(), max_prefix_gap_h=frame.prefix_gap_h.max(),
                            rmst_5760_h=km_rmst(frame.time.to_numpy(), frame.event.to_numpy(), 5760.)))
    pd.DataFrame(summary).to_csv(output / "landmark_240h.csv", index=False)

    passport = pd.read_csv(analysis / "reliability_evidence_passport.csv").set_index("device_uid")
    features = passport[["passport_component_" + name for name in (
        "four_state_definition_change", "qx1_substitution", "qx2_transient_handling", "time_review_fraction",
        "low_rule_confidence", "zero_power_evidence", "rule_review_flag", "main_endpoint_nonassessable",
    )]]
    scores = features @ [30, 10, 5, 10, 10, 5, 10, 5]
    assert np.allclose(scores, passport.decision_vulnerability_score, atol=.0051)
    priority = pd.DataFrame(dict(registered=scores, equal=features.sum(axis=1),
                                 state_half=features @ [15, 10, 5, 10, 10, 5, 10, 5],
                                 without_pattern_confidence=features @ [30, 10, 5, 10, 0, 5, 10, 5]))
    budget = int(np.ceil(.2 * len(priority)))
    original = set(priority.registered.sort_index().nlargest(budget, keep="first").index)
    rows = [dict(weights=name, spearman=score.corr(scores, method="spearman"), budget=budget,
                 top_overlap=len(original.intersection(score.sort_index().nlargest(budget, keep="first").index)))
            for name, score in priority.items()]
    pd.DataFrame(rows).to_csv(output / "review_weights.csv", index=False)
    shadow = pd.read_csv(analysis / "quality_rule_shadow_replay.csv")
    numeric = shadow[shadow.shadow_rule_id.eq("QX-1")]
    numeric = numeric.assign(score=pd.to_numeric(numeric.shadow_candidate_score, errors="coerce"))
    pd.DataFrame([
        dict(automatic_limit=limit, candidates=int(numeric.score.le(limit).sum()),
             matches=int((numeric.score.le(limit) & np.isclose(numeric.shadow_proposed_analysis_value_mW,
                         numeric.curated_value, rtol=0, atol=1e-9)).sum()))
        for limit in (.30, .45, .60, .75)
    ]).to_csv(output / "qx1_scores.csv", index=False)

    batteries = pd.read_csv(analysis / "nasa_battery_external_device_summary.csv")
    batteries["binary_change"] = batteries.t80_naive_crossing_cycle.notna() ^ batteries.t70_naive_crossing_cycle.notna()
    batteries["state_change"] = batteries.t80_governed_state.ne(batteries.t70_governed_state)
    both = batteries.t80_naive_crossing_cycle.notna() & batteries.t70_naive_crossing_cycle.notna()
    batteries["cycle_shift"] = (batteries.t70_naive_crossing_cycle - batteries.t80_naive_crossing_cycle).where(both)
    batteries.groupby("batch").agg(n=("battery_id", "size"), binary=("binary_change", "sum"),
        state=("state_change", "sum"), both=("cycle_shift", "count"), median_shift=("cycle_shift", "median"),
        routed=("fixed_review_flag", "sum")).to_csv(output / "battery_threshold_by_batch.csv")
    batteries[["binary_change", "state_change", "cycle_shift"]].describe().to_csv(output / "battery_threshold_overall.csv")


def reference_simulation(output):
    """Compare early reference choices against a known post-stabilization scale."""
    rng = np.random.default_rng(20261121)
    time = np.arange(0., 1201., 25.)
    truth = rng.uniform(300., 900., size=(400, 100))
    noise = rng.normal(0., .03, size=(*truth.shape, len(time)))
    latent = 1. - .2 * np.maximum(time - 50., 0.) / (truth[:, :, None] - 50.)
    rows = []
    for name, sd_multiplier, peak in [("noise", 1., 0.), ("peak", 0., .12), ("peak_and_noise", 1., .12)]:
        observed = latent + sd_multiplier * noise
        observed[:, :, 0] += peak
        early = observed[:, :, :3]
        for reference, scale in [
            ("known", np.ones_like(truth)), ("maximum", early.max(axis=2)), ("median", np.median(early, axis=2))
        ]:
            low = observed[:, :, 3:] <= .8 * scale[:, :, None]
            event = low.any(axis=2)
            registered = time[3:][low.argmax(axis=2)]
            error = np.where(event, registered - truth, np.nan)
            cohort_mean = np.nanmean(error, axis=1)
            rows.append(dict(scenario=name, reference=reference, registered=event.mean(),
                             conditional_bias=cohort_mean.mean(), mc_se=cohort_mean.std(ddof=1) / np.sqrt(len(truth)),
                             scale_bias=(scale - 1.).mean()))
    pd.DataFrame(rows).to_csv(output / "reference_simulation.csv", index=False)


def example(output):
    """A representative input with no private measurements or identifiers."""
    visits = pd.DataFrame({
        "source_cell": ["B2", "B3", "B4", "B5", "B6", "B7"],
        "exposure_h": [0., 20., 50., 100., 160., 220.],
        "power": [1.15, 1.00, 1.00, .89, .90, .86],
    })
    visits.to_csv(output / "synthetic_source_cells.csv", index=False)
    rows = []
    for name, reference in [("maximum", visits.power.iloc[:3].max()), ("median", visits.power.iloc[:3].median())]:
        follow = visits.iloc[3:]
        low = follow.power.to_numpy() <= .8 * reference
        time, state = first_crossing(follow.exposure_h.to_numpy(), low)
        hit = follow.loc[follow.exposure_h.eq(time), "source_cell"].item()
        lows = follow.loc[low, "source_cell"].tolist()
        rows.append(dict(reference=name, reference_cells="B2|B3|B4", reference_value=reference, threshold=.8,
                         state=state, time_h=time, supporting_cell=hit, confirmation_cell=lows[1] if len(lows) > 1 else ""))
    pd.DataFrame(rows).to_csv(output / "synthetic_endpoint_trace.csv", index=False)


def public_laser_check(archive, output):
    """Apply frozen reference and endpoint operators to the published 168 h traces."""
    from main import run_clean, run_events

    with ZipFile(archive) as bundle, bundle.open("sfig3/data.csv") as handle:
        visits = pd.read_csv(handle)
    # The repository's plot groups exactly five consecutive rows per trajectory.
    if len(visits) != 140 or not np.all(visits.Time.to_numpy().reshape(28, 5) == visits.Time.iloc[:5].to_numpy()):
        raise ValueError("Unexpected format in the published short VCSEL archive")
    ids = np.repeat(np.arange(1, 29), 5)
    power = visits.Power / visits.Power.groupby(ids).transform("first")
    measurements = pd.DataFrame(dict(device_uid=ids, source_cell=[f"B{row:03d}" for row in range(2, 142)],
                                     power_mW=power, power_raw=power, is_zero_power=0, measurement_time="",
                                     exposure_hours=visits.Time, calendar_hours=visits.Time))
    devices = pd.DataFrame({name: "" for name in (
        "source_column", "device_id_raw", "position", "batch", "laser_type",
        "aging_temperature_raw", "aging_current_raw", "p0_meta_mW")}, index=np.arange(28))
    devices = devices.assign(device_uid=np.arange(1, 29), file_id="P01", sheet="sfig3",
                             source_file="public-sfig3", aging_temperature_C=85.)
    rows = []
    with TemporaryDirectory(prefix="ress_public_laser_") as temporary:
        stage = Path(temporary)
        devices.to_csv(stage / "device_table_raw_extracted.csv", index=False)
        measurements.to_csv(stage / "measurement_table_raw_extracted.csv", index=False)
        run_clean(["--input-dir", str(stage)])
        frozen = pd.read_csv(stage / "device_table.csv")
        for reference in ("maximum", "median"):
            chosen = frozen.copy()
            if reference == "median":
                prefix = "sensitivity_median_reference_"
                for column in frozen.columns:
                    if column.startswith(prefix):
                        chosen[column.removeprefix(prefix)] = frozen[column]
            chosen.to_csv(stage / "device_table.csv", index=False)
            run_events(["--input-dir", str(stage), "--output-dir", str(stage)])
            compiled = pd.read_csv(stage / "event_table_exploratory.csv")
            main_rows = compiled[compiled.p0_definition.eq("p0_best_available")
                                 & compiled.failure_threshold_ratio.eq(.8)]
            assert len(main_rows) == 28
            rows.append(dict(reference=reference, n=len(main_rows),
                             censored=int(main_rows.event_status.eq("right_censored").sum()),
                             nonassessable=int(main_rows.event_status.isin(
                                 ["p0_missing_or_nonpositive", "no_valid_measurements",
                                  "transient_or_measurement_issue"]).sum()),
                             max_followup_h=visits.Time.max(), minimum_ratio=main_rows.min_ratio.min()))
    pd.DataFrame(rows).to_csv(output / "public_laser_replay.csv", index=False)


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, default=root / "outputs")
    parser.add_argument("--output", type=Path, default=root / "outputs/revision_checks")
    parser.add_argument("--example-only", action="store_true")
    parser.add_argument("--public-laser-archive", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    reference_simulation(args.output)
    example(args.output)
    if args.public_laser_archive:
        public_laser_check(args.public_laser_archive, args.output)
    if not args.example_only:
        archive_checks(args.inputs, args.output)


if __name__ == "__main__":
    main()

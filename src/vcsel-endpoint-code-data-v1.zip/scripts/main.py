"""Run the complete QAES-VCSEL numerical workflow from one standalone file.

This file intentionally embeds every analysis stage so the final review script has
no sibling imports or hidden source dependencies. It writes numerical outputs and
non-graphical review manifests only; figure generation is isolated in
generate_figures.py.
"""

from __future__ import annotations

import argparse
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


def inherited_inspection_pair(numeric: list[dict[str, Any]], threshold: float,
                              cap_h: float) -> tuple[int, int] | None:
    """Select the first low and its first threshold-specific confirmation."""
    lows = [index for index, row in enumerate(numeric)
            if row["t"] <= cap_h + 1e-9 and row["ratio"] <= threshold]
    if len(lows) >= 2:
        return lows[0], lows[1]
    if lows and lows[0] == len(numeric) - 1:
        return lows[0], lows[0]
    return None


@contextmanager
def isolated_argv(program: str, arguments: list[str]) -> Iterator[None]:
    """Prevent one embedded stage's argparse parser from seeing another stage's options."""
    previous = sys.argv
    sys.argv = [program, *arguments]
    try:
        yield
    finally:
        sys.argv = previous


def run_extract(stage_args: list[str]) -> None:
    """Rebuild immutable long-form source tables directly from data/*.xlsx."""
    with isolated_argv("extract", stage_args):
        import argparse
        import csv
        import re
        from collections import Counter, defaultdict
        from dataclasses import dataclass
        from datetime import date, datetime, timedelta
        from pathlib import Path
        from typing import Any
        
        import openpyxl
        from openpyxl.utils import get_column_letter
        from openpyxl.utils.datetime import from_excel
        
        
        LABEL_BATCH = "\u5916\u5ef6\u7247\u6279\u6b21"
        LABEL_DEVICE = "\u6fc0\u5149\u5668\u7f16\u53f7"
        LABEL_POSITION = "\u4f4d\u7f6e\u7f16\u53f7"
        LABEL_AGING_TEMP = "\u8001\u5316\u6e29\u5ea6"
        LABEL_LASER_TYPE = "\u6fc0\u5149\u5668\u7c7b\u578b"
        LABEL_OVEN = "\u8001\u5316\u70d8\u7bb1"
        LABEL_AGING_CURRENT = "\u8001\u5316\u7535\u6d41"
        LABEL_INITIAL_VOLTAGE = "\u521d\u59cb\u7535\u538b"
        LABEL_INITIAL_POWER = "\u521d\u59cb\u529f\u7387"
        LABEL_START_DATE = "\u5f00\u59cb\u65e5\u671f"
        LABEL_END_DATE = "\u7ed3\u675f\u65e5\u671f"
        LABEL_DATE_TIME = "\u65e5\u671f\u65f6\u95f4"
        LABEL_TEST_TEMP = "\u6d4b\u8bd5\u529f\u7387\u6e29\u5ea6"
        
        STOP_TOKENS = ["OFF", "\u505c\u6b62", "\u5173\u95ed", "\u5173\u673a"]
        ON_TOKENS = ["ON", "\u5f00\u542f", "\u6253\u5f00"]
        APPROX_TOKENS = ["\u5927\u7ea6", "\u7ea6", "\u65e0\u51c6\u786e"]
        
        
        @dataclass
        class LabelHit:
            row: int
            col: int
            nonempty_after: int
            text: str
        
        
        def norm(value: Any) -> str:
            return "" if value is None else str(value).strip()
        
        
        def parse_float(value: Any) -> float | None:
            if value is None:
                return None
            if isinstance(value, bool):
                return None
            if isinstance(value, (int, float)):
                return float(value)
            s = norm(value).replace(",", "")
            if not s:
                return None
            try:
                return float(s)
            except ValueError:
                return None
        
        
        def parse_first_number(value: Any) -> float | None:
            number = parse_float(value)
            if number is not None:
                return number
            m = re.search(r"[-+]?\d+(?:\.\d+)?", norm(value))
            return float(m.group(0)) if m else None
        
        
        def parse_datetime(value: Any) -> tuple[datetime | None, str]:
            if value is None or value == "":
                return None, ""
            if isinstance(value, datetime):
                if value.hour == 0 and value.minute == 0 and value.second == 0:
                    return value, "datetime_midnight"
                if value.minute == 0 and value.second == 0:
                    return value, "datetime_round_hour"
                return value, "datetime"
            if isinstance(value, date):
                return datetime(value.year, value.month, value.day), "date_only"
            if isinstance(value, (int, float)) and 20000 <= float(value) <= 60000:
                try:
                    dt = from_excel(value)
                    return dt, "excel_serial"
                except Exception:
                    return None, ""
        
            s = norm(value)
            if not s:
                return None, ""
            s = (
                s.replace("\u5e74", "-")
                .replace("\u6708", "-")
                .replace("\u65e5", "")
                .replace("/", "-")
                .replace(".", "-")
            )
            s = re.sub(r"\s+", " ", s).strip()
            for fmt, precision in [
                ("%Y-%m-%d %H:%M:%S", "datetime"),
                ("%Y-%m-%d %H:%M", "datetime"),
                ("%Y-%m-%d", "date_only"),
            ]:
                try:
                    dt = datetime.strptime(s, fmt)
                    if precision == "datetime" and dt.hour == 0 and dt.minute == 0 and dt.second == 0:
                        precision = "datetime_midnight"
                    elif precision == "datetime" and dt.minute == 0 and dt.second == 0:
                        precision = "datetime_round_hour"
                    return dt, precision
                except ValueError:
                    pass
            return None, ""
        
        
        def iso(dt: datetime | None) -> str:
            return "" if dt is None else dt.isoformat(sep=" ", timespec="minutes")
        
        
        def label_hits(rows: list[tuple[Any, ...]], label: str) -> list[LabelHit]:
            hits: list[LabelHit] = []
            for r_idx, row in enumerate(rows, start=1):
                for c_idx, value in enumerate(row, start=1):
                    text = norm(value)
                    if label in text:
                        nonempty_after = sum(1 for item in row[c_idx:] if item not in (None, ""))
                        hits.append(LabelHit(r_idx, c_idx, nonempty_after, text))
            return hits
        
        
        def choose_label_hit(
            rows: list[tuple[Any, ...]],
            label: str,
            min_nonempty_after: int = 0,
            exclude_regex: str | None = None,
        ) -> LabelHit | None:
            hits = label_hits(rows, label)
            if exclude_regex:
                rx = re.compile(exclude_regex)
                hits = [hit for hit in hits if not rx.search(hit.text)]
            hits = [hit for hit in hits if hit.nonempty_after >= min_nonempty_after]
            if not hits:
                return None
            return sorted(hits, key=lambda hit: (hit.nonempty_after, hit.row), reverse=True)[0]
        
        
        def first_metadata_value(rows: list[tuple[Any, ...]], label: str, max_rows: int = 20) -> str:
            for row in rows[:max_rows]:
                for idx, value in enumerate(row):
                    if label in norm(value):
                        for next_value in row[idx + 1 : idx + 6]:
                            if next_value not in (None, ""):
                                return norm(next_value)
            return ""
        
        
        def parse_temperature(raw_value: str, fallback: str = "") -> tuple[str, str]:
            text = raw_value or fallback
            numbers = re.findall(r"[-+]?\d+(?:\.\d+)?", text)
            unique = sorted(set(numbers), key=numbers.index)
            if len(unique) == 1:
                return unique[0], "single"
            if len(unique) > 1:
                return "", "ambiguous"
            return "", "missing"
        
        
        def row_value(rows: list[tuple[Any, ...]], hit: LabelHit | None, col: int) -> Any:
            if hit is None or hit.row - 1 >= len(rows):
                return None
            row = rows[hit.row - 1]
            return row[col - 1] if col - 1 < len(row) else None
        
        
        def values_after_label(rows: list[tuple[Any, ...]], hit: LabelHit) -> list[tuple[int, Any]]:
            row = rows[hit.row - 1]
            return [(col, value) for col, value in enumerate(row[hit.col:], start=hit.col + 1) if value not in (None, "")]
        
        
        def event_from_row(row: tuple[Any, ...]) -> tuple[str, datetime | None, str, str]:
            raw = " ".join(norm(value) for value in row[:4] if value not in (None, ""))
            upper = raw.upper()
            state = ""
            if any(token in upper for token in STOP_TOKENS):
                state = "off"
            if any(token in upper for token in ON_TOKENS):
                state = "on"
            if not state:
                return "", None, "", raw
        
            event_time = None
            precision = ""
            for value in row[:4]:
                event_time, precision = parse_datetime(value)
                if event_time:
                    break
            return state, event_time, precision, raw
        
        
        def build_off_intervals(events: list[dict[str, str]]) -> list[dict[str, Any]]:
            intervals: list[dict[str, Any]] = []
            open_off: dict[str, str] | None = None
            for event in sorted(events, key=lambda item: item["event_time"] or ""):
                event_time, _ = parse_datetime(event["event_time"])
                if not event_time:
                    continue
                raw_upper = event["raw_event"].upper()
                if event["oven_state"] == "off":
                    if "OFF" in raw_upper:
                        open_off = event
                    else:
                        intervals.append(
                            {
                                "start": event_time,
                                "end": event_time + timedelta(hours=24),
                                "method": "stop_day_24h",
                            }
                        )
                elif event["oven_state"] == "on" and open_off is not None:
                    start, _ = parse_datetime(open_off["event_time"])
                    if start and event_time > start:
                        intervals.append({"start": start, "end": event_time, "method": "off_on_pair"})
                    open_off = None
            if open_off is not None:
                start, _ = parse_datetime(open_off["event_time"])
                if start:
                    intervals.append({"start": start, "end": None, "method": "open_off_unsubtracted"})
            return intervals
        
        
        def off_hours_between(start: datetime | None, end: datetime | None, intervals: list[dict[str, Any]]) -> float | None:
            if start is None or end is None or end < start:
                return None
            total = 0.0
            for interval in intervals:
                off_start = interval["start"]
                off_end = interval["end"]
                if off_end is None:
                    continue
                left = max(start, off_start)
                right = min(end, off_end)
                if right > left:
                    total += (right - left).total_seconds() / 3600
            return total
        
        
        def make_device_uid(file_id: str, sheet: str, col: int) -> str:
            safe_sheet = re.sub(r"\s+", "_", sheet)
            return f"{file_id}::{safe_sheet}::{get_column_letter(col)}"
        
        
        def first_measurement_time_for_col(
            rows: list[tuple[Any, ...]],
            date_hit: LabelHit,
            col: int,
        ) -> tuple[datetime | None, str]:
            for row in rows[date_hit.row :]:
                measurement_time, precision = parse_datetime(row[date_hit.col - 1] if date_hit.col - 1 < len(row) else None)
                if measurement_time is None:
                    continue
                if col - 1 < len(row) and row[col - 1] not in (None, ""):
                    return measurement_time, f"first_measurement_fallback_{precision}"
            return None, ""
        
        
        def extract_workbook(fp: Path, file_id: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
            workbook = openpyxl.load_workbook(fp, read_only=True, data_only=True)
            device_rows: list[dict[str, Any]] = []
            measurement_rows: list[dict[str, Any]] = []
            oven_rows: list[dict[str, Any]] = []
            quality_rows: list[dict[str, Any]] = []
        
            for ws in workbook.worksheets:
                if ws.max_row is None or ws.max_column is None:
                    try:
                        ws.calculate_dimension(force=True)
                    except UnboundLocalError:
                        continue
                if (ws.max_row or 0) <= 1 and (ws.max_column or 0) <= 1:
                    continue
                rows = list(ws.iter_rows(values_only=True))
        
                device_hit = choose_label_hit(rows, LABEL_DEVICE, min_nonempty_after=1)
                fallback_position = False
                if device_hit is None:
                    device_hit = choose_label_hit(rows, LABEL_POSITION, min_nonempty_after=1)
                    fallback_position = device_hit is not None
                if device_hit is None:
                    quality_rows.append(
                        {
                            "file_id": file_id,
                            "source_file": fp.name,
                            "sheet": ws.title,
                            "status": "skipped",
                            "warning": "no device or position header with at least one value",
                        }
                    )
                    continue
        
                date_hit = choose_label_hit(rows, LABEL_DATE_TIME)
                if date_hit is None:
                    quality_rows.append(
                        {
                            "file_id": file_id,
                            "source_file": fp.name,
                            "sheet": ws.title,
                            "status": "skipped",
                            "warning": "no measurement datetime header",
                        }
                    )
                    continue
        
                position_hit = choose_label_hit(rows, LABEL_POSITION, min_nonempty_after=1)
                current_hit = choose_label_hit(rows, LABEL_AGING_CURRENT, min_nonempty_after=0)
                initial_voltage_hit = choose_label_hit(rows, LABEL_INITIAL_VOLTAGE, min_nonempty_after=0)
                initial_power_hit = choose_label_hit(rows, LABEL_INITIAL_POWER, min_nonempty_after=0, exclude_regex=r"80|%")
                start_hit = choose_label_hit(rows, LABEL_START_DATE, min_nonempty_after=0)
                end_hit = choose_label_hit(rows, LABEL_END_DATE, min_nonempty_after=0)
        
                batch = first_metadata_value(rows, LABEL_BATCH)
                aging_temp_raw = first_metadata_value(rows, LABEL_AGING_TEMP) or ws.title
                aging_temp_c, aging_temp_status = parse_temperature(aging_temp_raw, ws.title)
                laser_type = first_metadata_value(rows, LABEL_LASER_TYPE)
                oven = first_metadata_value(rows, LABEL_OVEN)
        
                device_cols = [col for col, _ in values_after_label(rows, device_hit)]
                sheet_events: list[dict[str, str]] = []
                for row_idx, row in enumerate(rows[date_hit.row :], start=date_hit.row + 1):
                    state, event_time, precision, raw_event = event_from_row(row)
                    if state:
                        event = {
                            "file_id": file_id,
                            "source_file": fp.name,
                            "sheet": ws.title,
                            "row": row_idx,
                            "oven_state": state,
                            "event_time": iso(event_time),
                            "time_precision": precision,
                            "raw_event": raw_event,
                        }
                        oven_rows.append(event)
                        sheet_events.append(event)
        
                off_intervals = build_off_intervals(sheet_events)
                sheet_device_uids: list[str] = []
                sheet_start_times: dict[str, datetime] = {}
                for col in device_cols:
                    raw_device_id = row_value(rows, None if fallback_position else device_hit, col)
                    position = row_value(rows, position_hit, col)
                    if fallback_position or raw_device_id in (None, ""):
                        raw_device_id = f"UNKNOWN_{norm(position) or get_column_letter(col)}"
                    current_raw = row_value(rows, current_hit, col)
                    start_time, start_precision = parse_datetime(row_value(rows, start_hit, col))
                    if start_time is None:
                        start_time, start_precision = first_measurement_time_for_col(rows, date_hit, col)
                    end_time, end_precision = parse_datetime(row_value(rows, end_hit, col))
                    initial_voltage = parse_float(row_value(rows, initial_voltage_hit, col))
                    initial_power = parse_float(row_value(rows, initial_power_hit, col))
                    current_mA = parse_first_number(current_raw)
                    device_uid = make_device_uid(file_id, ws.title, col)
                    sheet_device_uids.append(device_uid)
                    if start_time is not None:
                        sheet_start_times[device_uid] = start_time
                    device_rows.append(
                        {
                            "device_uid": device_uid,
                            "file_id": file_id,
                            "source_file": fp.name,
                            "sheet": ws.title,
                            "source_column": get_column_letter(col),
                            "device_id_raw": norm(raw_device_id),
                            "position": norm(position),
                            "batch": batch,
                            "laser_type": laser_type,
                            "aging_temperature_raw": aging_temp_raw,
                            "aging_temperature_C": aging_temp_c,
                            "aging_temperature_status": aging_temp_status,
                            "oven": oven,
                            "aging_current_raw": norm(current_raw),
                            "aging_current_mA": current_mA if current_mA is not None else "",
                            "current_is_approx": int(any(token in norm(current_raw) for token in APPROX_TOKENS)),
                            "initial_voltage_V": initial_voltage if initial_voltage is not None else "",
                            "p0_meta_mW": initial_power if initial_power is not None else "",
                            "start_time": iso(start_time),
                            "start_time_precision": start_precision,
                            "end_time": iso(end_time),
                            "end_time_precision": end_precision,
                            "device_header_row": device_hit.row,
                            "used_position_as_device_header": int(fallback_position),
                            "date_header_row": date_hit.row,
                        }
                    )
        
                for row_idx, row in enumerate(rows[date_hit.row :], start=date_hit.row + 1):
                    measurement_time, time_precision = parse_datetime(row[date_hit.col - 1] if date_hit.col - 1 < len(row) else None)
                    if measurement_time is None:
                        continue
                    values_present = False
                    for col in device_cols:
                        if col - 1 < len(row) and row[col - 1] not in (None, ""):
                            values_present = True
                            break
                    if not values_present:
                        continue
        
                    test_temp_raw = row[date_hit.col] if date_hit.col < len(row) else None
                    test_temp_c = parse_first_number(test_temp_raw)
                    for col, device_uid in zip(device_cols, sheet_device_uids):
                        power_raw = row[col - 1] if col - 1 < len(row) else None
                        if power_raw in (None, ""):
                            continue
                        power = parse_float(power_raw)
        
                        start_time = sheet_start_times.get(device_uid, measurement_time)
                        calendar_hours = (measurement_time - start_time).total_seconds() / 3600 if measurement_time >= start_time else None
                        off_hours = off_hours_between(start_time, measurement_time, off_intervals)
                        exposure_hours = None
                        if calendar_hours is not None and off_hours is not None:
                            exposure_hours = max(0.0, calendar_hours - off_hours)
        
                        measurement_rows.append(
                            {
                                "device_uid": device_uid,
                                "file_id": file_id,
                                "source_file": fp.name,
                                "sheet": ws.title,
                                "source_cell": f"{get_column_letter(col)}{row_idx}",
                                "measurement_time": iso(measurement_time),
                                "time_precision": time_precision,
                                "time_needs_review": int(time_precision in {"date_only", "datetime_midnight", "datetime_round_hour"}),
                                "test_power_temperature_raw": norm(test_temp_raw),
                                "test_power_temperature_C": test_temp_c if test_temp_c is not None else "",
                                "power_raw": norm(power_raw),
                                "power_mW": power if power is not None else "",
                                "is_zero_power": int(power == 0) if power is not None else "",
                                "calendar_hours": round(calendar_hours, 6) if calendar_hours is not None else "",
                                "off_hours_subtracted": round(off_hours, 6) if off_hours is not None else "",
                                "exposure_hours": round(exposure_hours, 6) if exposure_hours is not None else "",
                            }
                        )
        
                raw_ids = [device["device_id_raw"] for device in device_rows if device["file_id"] == file_id and device["sheet"] == ws.title]
                raw_id_counts = Counter(raw_ids)
                sheet_measurements = [row for row in measurement_rows if row["file_id"] == file_id and row["sheet"] == ws.title]
                quality_rows.append(
                    {
                        "file_id": file_id,
                        "source_file": fp.name,
                        "sheet": ws.title,
                        "status": "extracted",
                        "warning": "; ".join(
                            item
                            for item in [
                                "used position header as device id" if fallback_position else "",
                                "duplicate raw device ids" if any(count > 1 for count in raw_id_counts.values()) else "",
                                "ambiguous aging temperature" if aging_temp_status == "ambiguous" else "",
                                "no oven events" if not sheet_events else "",
                            ]
                            if item
                        ),
                        "device_count": len(device_cols),
                        "measurement_count": len(sheet_measurements),
                        "zero_power_count": sum(1 for row in sheet_measurements if row["is_zero_power"] == 1),
                        "oven_event_count": len(sheet_events),
                        "off_interval_count": len(off_intervals),
                        "date_header_row": date_hit.row,
                        "device_header_row": device_hit.row,
                        "first_measurement_time": min((row["measurement_time"] for row in sheet_measurements), default=""),
                        "last_measurement_time": max((row["measurement_time"] for row in sheet_measurements), default=""),
                    }
                )
        
            return device_rows, measurement_rows, oven_rows, quality_rows
        
        
        def add_device_measurement_summaries(device_rows: list[dict[str, Any]], measurement_rows: list[dict[str, Any]]) -> None:
            by_device: dict[str, list[dict[str, Any]]] = defaultdict(list)
            for row in measurement_rows:
                by_device[row["device_uid"]].append(row)
        
            for device in device_rows:
                rows = sorted(by_device.get(device["device_uid"], []), key=lambda row: row["measurement_time"])
                numeric_rows = [row for row in rows if row["power_mW"] != ""]
                positive = [float(row["power_mW"]) for row in numeric_rows if float(row["power_mW"]) > 0]
                first_power = float(numeric_rows[0]["power_mW"]) if numeric_rows else None
                early_positive = positive[:5]
                last_power = float(numeric_rows[-1]["power_mW"]) if numeric_rows else None
                device["measurement_count"] = len(rows)
                device["zero_power_count"] = sum(1 for row in numeric_rows if float(row["power_mW"]) == 0)
                device["first_measurement_time"] = rows[0]["measurement_time"] if rows else ""
                device["last_measurement_time"] = rows[-1]["measurement_time"] if rows else ""
                device["p0_first_mW"] = first_power if first_power is not None else ""
                device["p0_early_max5_positive_mW"] = max(early_positive) if early_positive else ""
                device["last_power_mW"] = last_power if last_power is not None else ""
                p0 = parse_float(device.get("p0_meta_mW"))
                if p0 is None or p0 <= 0:
                    p0 = max(early_positive) if early_positive else None
                device["last_power_ratio_to_best_available_p0"] = round(last_power / p0, 6) if last_power is not None and p0 else ""
        
        
        def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
            path.parent.mkdir(parents=True, exist_ok=True)
            if not rows:
                path.write_text("", encoding="utf-8-sig")
                return
            fieldnames: list[str] = []
            for row in rows:
                for key in row:
                    if key not in fieldnames:
                        fieldnames.append(key)
            with path.open("w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Extract VCSEL aging Excel workbooks into auditable long tables.")
            project_root = Path(__file__).resolve().parents[1]
            parser.add_argument("--data-dir", type=Path, default=project_root / "data")
            parser.add_argument(
                "--manifest",
                type=Path,
                default=project_root / "data" / "dataset_manifest.csv",
                help="CSV contract listing the frozen final workbooks and stable file identifiers.",
            )
            parser.add_argument("--output-dir", type=Path, default=project_root / "outputs" / "processed")
            args = parser.parse_args()
        
            all_devices: list[dict[str, Any]] = []
            all_measurements: list[dict[str, Any]] = []
            all_oven_events: list[dict[str, Any]] = []
            all_quality: list[dict[str, Any]] = []
        
            if not args.manifest.is_file():
                raise FileNotFoundError(f"Dataset manifest not found: {args.manifest.resolve()}")
            with args.manifest.open("r", encoding="utf-8-sig", newline="") as handle:
                manifest_rows = list(csv.DictReader(handle))
            required = {"file_id", "relative_path", "curation_status", "model_role"}
            if not manifest_rows or not required.issubset(manifest_rows[0]):
                raise ValueError(f"Dataset manifest must contain: {sorted(required)}")
            source_records: list[tuple[str, Path]] = []
            for record in manifest_rows:
                if record["model_role"].strip() != "main_model":
                    continue
                file_id = record["file_id"].strip()
                fp = args.data_dir / Path(record["relative_path"].strip())
                if not file_id or not fp.is_file():
                    raise FileNotFoundError(f"Manifest entry is invalid or missing: {file_id} -> {fp.resolve()}")
                source_records.append((file_id, fp))
            if len(source_records) != 9 or len({file_id for file_id, _ in source_records}) != 9:
                raise AssertionError("The frozen final-data contract must contain nine unique main-model workbooks.")
            for file_id, fp in source_records:
                devices, measurements, oven_events, quality = extract_workbook(fp, file_id)
                all_devices.extend(devices)
                all_measurements.extend(measurements)
                all_oven_events.extend(oven_events)
                all_quality.extend(quality)
        
            add_device_measurement_summaries(all_devices, all_measurements)
            write_csv(args.output_dir / "device_table_raw_extracted.csv", all_devices)
            write_csv(args.output_dir / "measurement_table_raw_extracted.csv", all_measurements)
            write_csv(args.output_dir / "oven_event_table.csv", all_oven_events)
            write_csv(args.output_dir / "extraction_quality.csv", all_quality)
            write_csv(args.output_dir / "dataset_manifest_snapshot.csv", manifest_rows)
        
            print(f"devices={len(all_devices)}")
            print(f"measurements={len(all_measurements)}")
            print(f"oven_events={len(all_oven_events)}")
            print(f"quality_rows={len(all_quality)}")
            print(f"output_dir={args.output_dir.resolve()}")
        

        main()


def run_clean(stage_args: list[str]) -> None:
    """Run the embedded clean_measurement_anomalies.py stage with an isolated command line."""
    with isolated_argv("clean", stage_args):
        import argparse
        import json
        import math
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            """Read one frozen rule's parameters without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            return dict(registry["rules"][rule_id].get("parameters", {}))
        
        QX1 = parameters("QX-1")
        QX2 = parameters("QX-2")
        P0 = parameters("P0-1")
        BI = parameters("BI-1")
        EF = parameters("EF-1")
        ABSOLUTE_IMPLAUSIBLE_MW = float(QX1["absolute_implausible_mw"])
        RATIO_IMPLAUSIBLE = float(QX1["ratio_implausible"])
        MINIMUM_POWER_FOR_RATIO_TRIGGER_MW = float(QX1["minimum_power_for_ratio_trigger_mw"])
        HIGH_RATIO_SUSPECT = float(QX1["baseline_ratio_trigger"])
        LOCAL_HIGH_RATIO_SUSPECT = float(QX1["local_ratio_trigger"])
        LOCAL_WINDOW_PRECEDING = int(QX1["local_window_preceding"])
        LOCAL_WINDOW_SUBSEQUENT = int(QX1["local_window_subsequent"])
        MINIMUM_LOCAL_NEIGHBORS = int(QX1["minimum_local_neighbors"])
        MAX_PLAUSIBLE_RATIO_AFTER_CORRECTION = float(QX1["maximum_plausible_ratio"])
        AUTO_CORRECTION_MAX_LOG_ERROR = float(QX1["automatic_score_max"])
        REVIEW_CORRECTION_MAX_LOG_ERROR = float(QX1["review_score_max"])
        COMMON_PATTERN_BONUS = float(QX1["common_pattern_bonus"])
        ARTIFACT_LOW_RATIO = float(QX2["low_ratio_max"])
        ARTIFACT_RECOVERY_RATIO = float(QX2["recovery_ratio_min"])
        ARTIFACT_STRONG_RECOVERY_RATIO = float(QX2["strong_recovery_ratio_min"])
        BURN_IN_CAP_H = float(BI["burn_in_cap_h"])
        BI_REFERENCE_POINTS = int(BI["reference_positive_points"])
        BI_WINDOW_POINTS = int(BI["stable_window_points"])
        BI_MIN_WINDOW_SPAN_H = float(BI["minimum_stable_window_span_h"])
        BI_MAX_REL_SPREAD = float(BI["maximum_stable_window_relative_p10_p90_range"])
        BI_MAX_REL_SLOPE_PER_100H = float(BI["maximum_abs_stable_window_relative_slope_per_100h"])
        BI_MIN_STABLE_RATIO = float(BI["minimum_stabilized_to_provisional_reference_ratio"])
        BI_MAX_STABLE_RATIO = float(BI["maximum_stabilized_to_provisional_reference_ratio"])
        BI_MIN_BURN_IN_STABLE_RATIO = float(BI["minimum_burn_in_like_stable_ratio_exclusive"])
        BI_MIN_DROP = float(BI["minimum_burn_in_like_drop_ratio"])
        BI_MAX_DROP = float(BI["maximum_burn_in_like_drop_ratio"])
        P0_MIN_EARLY_POINTS = int(P0["minimum_early_points"])
        P0_MAX_EARLY_POINTS = int(P0["maximum_early_points"])
        EF_CATASTROPHIC_RATIO = float(EF["catastrophic_ratio"])
        EF_SEVERE_RATIO = float(EF["severe_ratio"])
        EF_MAIN_RATIO = float(EF["main_failure_ratio"])
        EF_RAPID_HORIZON_H = float(EF["rapid_loss_horizon_h"])
        EF_RAPID_CUMULATIVE_DROP = float(EF["rapid_cumulative_drop_ratio"])
        EF_MIN_SEVERE_POINTS = int(EF["minimum_severe_points"])
        EF_MIN_RAPID_POINTS = int(EF["minimum_rapid_loss_points"])
        EF_MIN_PERSISTENT_POINTS = int(EF["minimum_persistent_below_main_points"])
        EF_STABLE_LOW_IS_EARLY_LOSS = bool(EF["stable_window_at_or_below_main_is_early_loss"])
        EF_PERSISTENT_REQUIRES_NO_ACCEPTABLE_STABLE = bool(EF["persistent_main_loss_requires_no_acceptable_stable_window"])
        EF_RECOVERY_CLEARANCE = float(EF["recovery_clearance_ratio"])
        EF_ABRUPT_DROP = float(EF["abrupt_drop_ratio"])
        
        
        def safe_float(value: Any) -> float | None:
            if value is None or value == "":
                return None
            try:
                result = float(value)
            except (TypeError, ValueError):
                return None
            if math.isnan(result) or math.isinf(result):
                return None
            return result
        
        
        def provisional_scale_from_device(device: pd.Series) -> float | None:
            provisional_order = [
                *P0["best_available_order"],
                "p0_meta_mW",
                "p0_early_max5_positive_mW",
                "p0_first_mW",
            ]
            for col in provisional_order:
                value = safe_float(device.get(col, ""))
                if value is not None and value > 0:
                    return value
            return None


        def bounded_baseline_features(
            group: pd.DataFrame,
            device: pd.Series,
            reference_strategy: str = "max_all_candidates",
            burn_in_cap_h: float = BURN_IN_CAP_H,
            rapid_horizon_h: float = EF_RAPID_HORIZON_H,
            stability_tolerance_scale: float = 1.0,
        ) -> dict[str, Any]:
            """Construct a bounded post-stabilization P0 and an independent early-failure screen."""
            work = group.copy()
            work["time_h"] = pd.to_numeric(work.get("exposure_hours", ""), errors="coerce")
            work["time_h"] = work["time_h"].fillna(pd.to_numeric(work.get("calendar_hours", ""), errors="coerce"))
            work["power_num"] = pd.to_numeric(work.get("power_mW", ""), errors="coerce")
            work = work.dropna(subset=["time_h", "power_num"]).sort_values(["time_h", "measurement_time", "source_cell"])
            early_all = work[(work["time_h"] >= 0) & (work["time_h"] <= burn_in_cap_h)].copy()
            early_positive = early_all[early_all["power_num"] > 0].copy()
            first_power = float(work["power_num"].iloc[0]) if len(work) else None
            first_positive_for_p0 = early_positive.iloc[:P0_MAX_EARLY_POINTS]
            early_median = (
                float(first_positive_for_p0["power_num"].median())
                if len(first_positive_for_p0) >= P0_MIN_EARLY_POINTS
                else None
            )
            early_median_time = (
                float(first_positive_for_p0["time_h"].iloc[-1])
                if early_median is not None
                else None
            )
            reference_values = list(early_positive["power_num"].iloc[:BI_REFERENCE_POINTS].astype(float))
            meta = safe_float(device.get("p0_meta_mW", ""))
            if meta is not None and meta > 0 and reference_strategy != "max_positive_measurements_only":
                reference_values.append(meta)
            if not reference_values:
                provisional_reference = None
            elif reference_strategy == "median_all_candidates":
                provisional_reference = float(np.median(reference_values))
            else:
                provisional_reference = max(reference_values)

            stable: dict[str, Any] | None = None
            if provisional_reference is not None and len(early_positive) >= BI_WINDOW_POINTS:
                for start in range(0, len(early_positive) - BI_WINDOW_POINTS + 1):
                    window = early_positive.iloc[start : start + BI_WINDOW_POINTS]
                    t = window["time_h"].to_numpy(dtype=float)
                    p = window["power_num"].to_numpy(dtype=float)
                    span = float(t[-1] - t[0])
                    median = float(np.median(p))
                    if span < BI_MIN_WINDOW_SPAN_H or median <= 0:
                        continue
                    rel_spread = float((np.percentile(p, 90) - np.percentile(p, 10)) / median)
                    rel_slope = float(abs(np.polyfit(t, p, 1)[0]) * 100.0 / median) if span > 0 else float("inf")
                    stable_ratio = median / provisional_reference
                    if not (BI_MIN_STABLE_RATIO <= stable_ratio <= BI_MAX_STABLE_RATIO):
                        continue
                    if (rel_spread > BI_MAX_REL_SPREAD * stability_tolerance_scale
                            or rel_slope > BI_MAX_REL_SLOPE_PER_100H * stability_tolerance_scale):
                        continue
                    stable = {
                        "p0": median,
                        "time": float(t[-1]),
                        "span": span,
                        "ratio": stable_ratio,
                        "spread": rel_spread,
                        "slope": rel_slope,
                    }
                    break

            early_failure_flag = 0
            early_failure_time: float | None = None
            early_failure_confirmation_time: float | None = None
            early_failure_subtype = ""
            early_loss_timing_certainty = ""
            early_failure_severity_evidence = "none"
            if provisional_reference is not None and len(early_all):
                ratios = early_all["power_num"].to_numpy(dtype=float) / provisional_reference
                times = early_all["time_h"].to_numpy(dtype=float)
                catastrophic = np.where(ratios <= EF_CATASTROPHIC_RATIO)[0]
                severe = np.where(ratios <= EF_SEVERE_RATIO)[0]
                below_main = np.where(ratios <= EF_MAIN_RATIO)[0]
                persistent_idx: int | None = None
                if len(below_main):
                    first = int(below_main[0])
                    tail = ratios[first:]
                    if int(np.sum(tail <= EF_MAIN_RATIO)) >= EF_MIN_PERSISTENT_POINTS and float(np.max(tail)) < EF_RECOVERY_CLEARANCE:
                        persistent_idx = first
                rapid_idx: int | None = None
                rapid_ratio = 1.0 - EF_RAPID_CUMULATIVE_DROP
                for candidate_idx in np.where((times <= rapid_horizon_h) & (ratios <= rapid_ratio))[0]:
                    tail = ratios[int(candidate_idx) :]
                    if int(np.sum(tail <= EF_MAIN_RATIO)) >= EF_MIN_RAPID_POINTS and float(np.max(tail)) < EF_RECOVERY_CLEARANCE:
                        rapid_idx = int(candidate_idx)
                        break
                abrupt_idx: int | None = None
                if len(ratios) > 1:
                    steps = np.diff(ratios)
                    candidate = int(np.argmin(steps))
                    if float(steps[candidate]) <= -EF_ABRUPT_DROP and float(np.max(ratios[candidate + 1 :])) < EF_RECOVERY_CLEARANCE:
                        abrupt_idx = candidate + 1
                stable_low_plateau = bool(
                    EF_STABLE_LOW_IS_EARLY_LOSS
                    and stable is not None
                    and float(stable["ratio"]) <= EF_MAIN_RATIO
                )
                candidates: list[tuple[float, int, str, str, float | None]] = []
                if len(catastrophic):
                    catastrophic_idx = int(catastrophic[0])
                    later_catastrophic = np.where(
                        ratios[catastrophic_idx + 1 :] <= EF_CATASTROPHIC_RATIO
                    )[0]
                    later_main = np.where(ratios[catastrophic_idx + 1 :] <= EF_MAIN_RATIO)[0]
                    confirmation_indices = []
                    if len(later_catastrophic):
                        confirmation_indices.append(catastrophic_idx + 1 + int(later_catastrophic[0]))
                    if len(later_main):
                        confirmation_indices.append(catastrophic_idx + 1 + int(later_main[0]))
                    catastrophic_confirmation_idx = min(confirmation_indices) if confirmation_indices else None
                    catastrophic_confirmed = catastrophic_confirmation_idx is not None
                    if catastrophic_confirmed:
                        early_failure_severity_evidence = "confirmed_catastrophic_or_zero"
                        catastrophic_subtype = "confirmed_catastrophic_or_zero_within_bounded_window"
                        catastrophic_certainty = (
                            "confirmed_rapid"
                            if float(times[catastrophic_idx]) <= rapid_horizon_h
                            else "interval_ambiguous_after_100h"
                        )
                    else:
                        early_failure_severity_evidence = "isolated_or_terminal_catastrophic_point"
                        catastrophic_subtype = "isolated_or_terminal_catastrophic_point_unconfirmed"
                        catastrophic_certainty = "terminal_or_isolated_point_requires_review"
                    candidates.append(
                        (
                            float(times[catastrophic_idx]),
                            0,
                            catastrophic_subtype,
                            catastrophic_certainty,
                            (
                                float(times[catastrophic_confirmation_idx])
                                if catastrophic_confirmation_idx is not None
                                else None
                            ),
                        )
                    )
                if len(severe) >= EF_MIN_SEVERE_POINTS:
                    severe_time = float(times[int(severe[0])])
                    severe_confirmation_time = float(times[int(severe[EF_MIN_SEVERE_POINTS - 1])])
                    if early_failure_severity_evidence == "none":
                        early_failure_severity_evidence = "confirmed_severe_loss"
                    candidates.append(
                        (
                            severe_time,
                            1,
                            "confirmed_severe_loss_within_bounded_window",
                            "confirmed_rapid" if severe_time <= rapid_horizon_h else "interval_ambiguous_after_100h",
                            severe_confirmation_time,
                        )
                    )
                if rapid_idx is not None:
                    rapid_support = np.where(ratios[rapid_idx:] <= EF_MAIN_RATIO)[0]
                    rapid_confirmation_idx = rapid_idx + int(rapid_support[EF_MIN_RAPID_POINTS - 1])
                    candidates.append(
                        (
                            float(times[rapid_idx]),
                            2,
                            "confirmed_rapid_cumulative_loss_within_100h",
                            "confirmed_rapid",
                            float(times[rapid_confirmation_idx]),
                        )
                    )
                if abrupt_idx is not None:
                    abrupt_time = float(times[abrupt_idx])
                    candidates.append(
                        (
                            abrupt_time,
                            3,
                            "abrupt_early_drop_without_recovery",
                            "confirmed_rapid" if abrupt_time <= rapid_horizon_h else "interval_ambiguous_after_100h",
                            float(times[-1]),
                        )
                    )
                if stable_low_plateau:
                    plateau_time = float(times[int(below_main[0])]) if len(below_main) else float(stable["time"])
                    candidates.append(
                        (
                            plateau_time,
                            4,
                            "stable_low_plateau_early_loss",
                            "confirmed_within_100h" if float(stable["time"]) <= rapid_horizon_h else "interval_ambiguous_after_100h",
                            float(stable["time"]),
                        )
                    )
                if persistent_idx is not None and (
                    stable is None or not EF_PERSISTENT_REQUIRES_NO_ACCEPTABLE_STABLE
                ):
                    persistent_support = np.where(ratios[persistent_idx:] <= EF_MAIN_RATIO)[0]
                    persistent_confirmation_idx = (
                        persistent_idx + int(persistent_support[EF_MIN_PERSISTENT_POINTS - 1])
                    )
                    candidates.append(
                        (
                            float(times[persistent_idx]),
                            5,
                            "persistent_main_threshold_loss_without_acceptable_stabilization",
                            "confirmed_early_loss",
                            float(times[persistent_confirmation_idx]),
                        )
                    )

                # Event time is the earliest supported rule time.  Later, more severe
                # evidence is retained separately and must not move a device back into
                # a landmark risk set that it had already left.
                if candidates:
                    selected = min(candidates, key=lambda item: (item[0], item[1]))
                    early_failure_flag = 1
                    early_failure_time = selected[0]
                    early_failure_subtype = selected[2]
                    early_loss_timing_certainty = selected[3]
                    early_failure_confirmation_time = selected[4]

            burn_in_like_flag = 0
            stabilization_status = "insufficient_early_data"
            stable_p0: float | None = None
            if early_failure_flag:
                stabilization_status = "early_loss_before_acceptable_stabilization"
            elif stable is not None:
                stable_p0 = float(stable["p0"])
                drop = 1.0 - float(stable["ratio"])
                if (
                    float(stable["ratio"]) > BI_MIN_BURN_IN_STABLE_RATIO
                    and BI_MIN_DROP <= drop <= BI_MAX_DROP
                ):
                    burn_in_like_flag = 1
                    stabilization_status = "bounded_burn_in_like_stabilization"
                elif drop < -BI_MIN_DROP:
                    stabilization_status = "bounded_stabilization_after_power_increase"
                else:
                    stabilization_status = "bounded_stabilization_without_material_early_loss"
            elif len(early_positive) >= P0_MIN_EARLY_POINTS:
                stabilization_status = "unresolved_within_burn_in_cap"

            best_p0 = stable_p0 if stable_p0 is not None else early_median
            best_definition = "p0_post_stabilization" if stable_p0 is not None else ("p0_early_median5" if early_median is not None else "missing")
            best_time = float(stable["time"]) if stable_p0 is not None and stable is not None else early_median_time
            early_drop = (1.0 - float(stable["ratio"])) if stable is not None else None
            return {
                "p0_first_mW": first_power if first_power is not None else "",
                "p0_early_median5_positive_mW": early_median if early_median is not None else "",
                "p0_early_median5_time_h": early_median_time if early_median_time is not None else "",
                "p0_post_stabilization_mW": stable_p0 if stable_p0 is not None else "",
                "p0_post_stabilization_time_h": float(stable["time"]) if stable_p0 is not None and stable is not None else "",
                "p0_best_available_mW": best_p0 if best_p0 is not None else "",
                "p0_best_available_definition": best_definition,
                "p0_best_reference_time_h": best_time if best_time is not None else "",
                "provisional_early_reference_mW": provisional_reference if provisional_reference is not None else "",
                "burn_in_cap_h": burn_in_cap_h,
                "burn_in_stabilization_status": stabilization_status,
                "burn_in_like_flag": burn_in_like_flag,
                "burn_in_early_drop_ratio": round(early_drop, 6) if early_drop is not None else "",
                "burn_in_stabilization_time_h": float(stable["time"]) if stable is not None else "",
                "burn_in_stable_window_point_count": BI_WINDOW_POINTS if stable is not None else 0,
                "burn_in_stable_window_span_h": round(float(stable["span"]), 6) if stable is not None else "",
                "burn_in_stable_window_relative_spread": round(float(stable["spread"]), 6) if stable is not None else "",
                "burn_in_stable_window_relative_slope_per_100h": round(float(stable["slope"]), 6) if stable is not None else "",
                "early_failure_flag": early_failure_flag,
                "early_failure_time_h": early_failure_time if early_failure_time is not None else "",
                "early_failure_confirmation_time_h": (
                    early_failure_confirmation_time if early_failure_confirmation_time is not None else ""
                ),
                "early_failure_subtype": early_failure_subtype,
                "early_loss_timing_certainty": early_loss_timing_certainty,
                "early_failure_severity_evidence": early_failure_severity_evidence,
            }
        
        
        def local_expected_power(group: pd.DataFrame, idx: int, p0: float | None) -> float | None:
            left = max(0, idx - LOCAL_WINDOW_PRECEDING)
            right = min(len(group), idx + LOCAL_WINDOW_SUBSEQUENT + 1)
            local = pd.to_numeric(group.iloc[left:right]["power_mW"], errors="coerce").reset_index(drop=True)
            center = idx - left
            if 0 <= center < len(local):
                local = local.drop(local.index[center])
            local = local[(local > 0) & (local < ABSOLUTE_IMPLAUSIBLE_MW)]
            if p0 is not None and p0 > 0:
                local = local[local / p0 <= MAX_PLAUSIBLE_RATIO_AFTER_CORRECTION]
            if len(local) >= MINIMUM_LOCAL_NEIGHBORS:
                return float(local.median())
            global_values = pd.to_numeric(group["power_mW"], errors="coerce")
            global_values = global_values[(global_values > 0) & (global_values < ABSOLUTE_IMPLAUSIBLE_MW)]
            if p0 is not None and p0 > 0:
                global_values = global_values[global_values / p0 <= MAX_PLAUSIBLE_RATIO_AFTER_CORRECTION]
            if len(global_values) >= MINIMUM_LOCAL_NEIGHBORS:
                return float(global_values.median())
            return p0
        
        
        def candidate_corrections(raw_value: float, raw_text: str = "") -> list[tuple[str, float]]:
            candidates: list[tuple[str, float]] = []
            fractional = raw_value - math.floor(raw_value)
            if fractional > 0:
                candidates.append(("fractional_part_as_decimal_entry", fractional))
            for shift in [10.0, 100.0, 1000.0, 10000.0]:
                candidates.append((f"divide_by_{int(shift)}", raw_value / shift))
            text = str(raw_text or "").strip().replace(",", "")
            text = text.replace("mW", "").replace("mw", "").strip()
            if text:
                sign = ""
                if text.startswith(("+", "-")):
                    sign, text = text[0], text[1:]
                if "." in text:
                    integer, fractional_text = text.split(".", 1)
                    integer_digits = "".join(ch for ch in integer if ch.isdigit())
                    fractional_digits = "".join(ch for ch in fractional_text if ch.isdigit())
                    if len(integer_digits) >= 2 and fractional_digits:
                        for method, new_integer in [
                            ("remove_first_leading_digit_before_decimal", integer_digits[1:]),
                            ("keep_last_digit_before_decimal", integer_digits[-1:]),
                        ]:
                            if new_integer:
                                try:
                                    candidates.append((method, float(f"{sign}{new_integer}.{fractional_digits}")))
                                except ValueError:
                                    pass
                digits = "".join(ch for ch in text if ch.isdigit())
                if digits:
                    for places in [1, 2, 3, 4]:
                        if len(digits) > places:
                            try:
                                candidates.append((f"insert_missing_decimal_{places}_places", float(f"{sign}{digits}") / (10**places)))
                            except ValueError:
                                pass
            # Remove duplicate numeric candidates while preserving order.
            out: list[tuple[str, float]] = []
            seen: set[float] = set()
            for method, value in candidates:
                rounded = round(value, 12)
                if rounded not in seen and value > 0:
                    seen.add(rounded)
                    out.append((method, value))
            return out
        
        
        def choose_correction(raw_value: float, expected: float | None, p0: float | None, raw_text: str = "") -> tuple[str, float, float] | None:
            candidates = candidate_corrections(raw_value, raw_text)
            scored: list[tuple[float, str, float]] = []
            for method, value in candidates:
                if value <= 0:
                    continue
                if p0 is not None and p0 > 0:
                    ratio = value / p0
                    if ratio <= 0 or ratio > MAX_PLAUSIBLE_RATIO_AFTER_CORRECTION:
                        continue
                elif value >= ABSOLUTE_IMPLAUSIBLE_MW:
                    continue
        
                if expected is not None and expected > 0:
                    score = abs(math.log(value / expected))
                elif p0 is not None and p0 > 0:
                    score = abs(math.log(value / p0))
                else:
                    score = value
                # Prefer common manual typos when they fit the local curve: extra leading digit,
                # missing decimal point, or extra zero before/inside the intended value.
                if method in {
                    "fractional_part_as_decimal_entry",
                    "remove_first_leading_digit_before_decimal",
                    "keep_last_digit_before_decimal",
                }:
                    score -= COMMON_PATTERN_BONUS
                scored.append((score, method, value))
            if not scored:
                return None
            score, method, value = sorted(scored, key=lambda item: item[0])[0]
            return method, value, score
        
        
        def is_implausibly_high(raw_value: float, p0: float | None) -> bool:
            if raw_value >= ABSOLUTE_IMPLAUSIBLE_MW:
                return True
            if p0 is not None and p0 > 0 and raw_value / p0 >= RATIO_IMPLAUSIBLE and raw_value >= MINIMUM_POWER_FOR_RATIO_TRIGGER_MW:
                return True
            return False
        
        
        def is_suspect_high_entry_error(raw_value: float, expected: float | None, p0: float | None) -> bool:
            if is_implausibly_high(raw_value, p0):
                return True
            if p0 is not None and p0 > 0 and raw_value / p0 <= MAX_PLAUSIBLE_RATIO_AFTER_CORRECTION and raw_value < ABSOLUTE_IMPLAUSIBLE_MW:
                return False
            if p0 is not None and p0 > 0 and raw_value >= MINIMUM_POWER_FOR_RATIO_TRIGGER_MW and raw_value / p0 >= HIGH_RATIO_SUSPECT:
                return True
            if expected is not None and expected > 0 and raw_value >= MINIMUM_POWER_FOR_RATIO_TRIGGER_MW and raw_value / expected >= LOCAL_HIGH_RATIO_SUSPECT:
                return True
            return False
        
        
        def correction_flag_from_score(score: float) -> str | None:
            if score <= AUTO_CORRECTION_MAX_LOG_ERROR:
                return "corrected"
            if score <= REVIEW_CORRECTION_MAX_LOG_ERROR:
                return "review_corrected"
            return None
        
        
        def mark_transient_low_power_artifacts(
            corrected: pd.DataFrame,
            devices: pd.DataFrame,
        ) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
            device_map = {row["device_uid"]: row for _, row in devices.iterrows()}
            corrected = corrected.copy()
            corrected["endpoint_power_mW"] = pd.to_numeric(corrected["power_mW"], errors="coerce")
            corrected["analysis_power_mW"] = pd.to_numeric(corrected["power_mW"], errors="coerce")
            corrected["power_artifact_flag"] = "none"
            corrected["power_artifact_method"] = ""
            corrected["power_artifact_reason"] = ""
            corrected["power_artifact_review"] = 0
            for col in [
                "endpoint_power_mW",
                "analysis_power_mW",
                "power_artifact_flag",
                "power_artifact_method",
                "power_artifact_reason",
            ]:
                corrected[col] = corrected[col].astype(object)
        
            logs: list[dict[str, Any]] = []
            for uid, group in corrected.groupby("device_uid", sort=False):
                group = group.sort_values(["measurement_time", "source_cell"])
                device = device_map.get(uid)
                p0 = provisional_scale_from_device(device) if device is not None else None
                if p0 is None or p0 <= 0 or len(group) < 2:
                    continue
        
                powers = pd.to_numeric(group["power_mW"], errors="coerce").to_numpy(dtype=float)
                ratios = powers / p0
                row_indices = list(group.index)
                for ordinal, row_idx in enumerate(row_indices):
                    ratio = ratios[ordinal]
                    power = powers[ordinal]
                    if not np.isfinite(ratio) or not np.isfinite(power):
                        continue
                    if power != 0 and ratio > ARTIFACT_LOW_RATIO:
                        continue
        
                    prev_ratio = ratios[ordinal - 1] if ordinal > 0 else np.nan
                    next_ratio = ratios[ordinal + 1] if ordinal + 1 < len(ratios) else np.nan
                    prev_low = np.isfinite(prev_ratio) and prev_ratio <= ARTIFACT_LOW_RATIO
                    next_low = np.isfinite(next_ratio) and next_ratio <= ARTIFACT_LOW_RATIO
                    if prev_low or next_low:
                        continue
        
                    prev_recovered = np.isfinite(prev_ratio) and prev_ratio >= ARTIFACT_RECOVERY_RATIO
                    next_recovered = np.isfinite(next_ratio) and next_ratio >= ARTIFACT_RECOVERY_RATIO
                    next_strong_recovered = np.isfinite(next_ratio) and next_ratio >= ARTIFACT_STRONG_RECOVERY_RATIO
                    if not next_recovered or not (prev_recovered or next_strong_recovered):
                        continue
        
                    neighbor_ratios = [value for value in [prev_ratio, next_ratio] if np.isfinite(value) and value > ARTIFACT_LOW_RATIO]
                    if not neighbor_ratios:
                        continue
                    corrected_power = float(np.median(neighbor_ratios) * p0)
                    row = group.loc[row_idx]
                    method = "isolated_zero_immediate_recovery" if power == 0 else "isolated_near_zero_immediate_recovery"
                    corrected.loc[row_idx, "analysis_power_mW"] = corrected_power
                    corrected.loc[row_idx, "power_artifact_flag"] = "imputed_for_analysis"
                    corrected.loc[row_idx, "power_artifact_method"] = method
                    corrected.loc[row_idx, "power_artifact_reason"] = "isolated_zero_or_near_zero_followed_by_immediate_recovery"
                    corrected.loc[row_idx, "power_artifact_review"] = 1
                    logs.append(
                        {
                            "device_uid": uid,
                            "source_file": row.get("source_file", ""),
                            "sheet": row.get("sheet", ""),
                            "source_cell": row.get("source_cell", ""),
                            "measurement_time": row.get("measurement_time", ""),
                            "power_mW": power,
                            "analysis_power_mW": corrected_power,
                            "ratio_to_p0": ratio,
                            "previous_ratio": prev_ratio if np.isfinite(prev_ratio) else "",
                            "next_ratio": next_ratio if np.isfinite(next_ratio) else "",
                            "p0_reference_mW": p0,
                            "method": method,
                            "reason": "isolated_zero_or_near_zero_followed_by_immediate_recovery",
                            "downstream_policy": "preserve_power_mW_but_impute_analysis_power_mW",
                            "requires_review": 1,
                        }
                    )
            return corrected, logs
        
        
        def recalc_device_summaries(devices: pd.DataFrame, measurements: pd.DataFrame) -> pd.DataFrame:
            devices = devices.copy().astype(object)
            bounded_columns = [
                "p0_first_mW",
                "p0_early_median5_positive_mW",
                "p0_early_median5_time_h",
                "p0_post_stabilization_mW",
                "p0_post_stabilization_time_h",
                "p0_best_available_mW",
                "p0_best_available_definition",
                "p0_best_reference_time_h",
                "provisional_early_reference_mW",
                "burn_in_cap_h",
                "burn_in_stabilization_status",
                "burn_in_like_flag",
                "burn_in_early_drop_ratio",
                "burn_in_stabilization_time_h",
                "burn_in_stable_window_point_count",
                "burn_in_stable_window_span_h",
                "burn_in_stable_window_relative_spread",
                "burn_in_stable_window_relative_slope_per_100h",
                "early_failure_flag",
                "early_failure_time_h",
                "early_failure_confirmation_time_h",
                "early_failure_subtype",
                "early_loss_timing_certainty",
                "early_failure_severity_evidence",
            ]
            sensitivity_specs = {
                "sensitivity_median_reference": ("median_all_candidates", BURN_IN_CAP_H, EF_RAPID_HORIZON_H, 1.0),
                "sensitivity_positive_only_reference": ("max_positive_measurements_only", BURN_IN_CAP_H, EF_RAPID_HORIZON_H, 1.0),
                "sensitivity_80h_200h": ("max_all_candidates", 200.0, 80.0, 1.0),
                "sensitivity_120h_300h": ("max_all_candidates", 300.0, 120.0, 1.0),
                "sensitivity_stability_tight": ("max_all_candidates", BURN_IN_CAP_H, EF_RAPID_HORIZON_H, 0.5),
                "sensitivity_stability_loose": ("max_all_candidates", BURN_IN_CAP_H, EF_RAPID_HORIZON_H, 2.0),
            }
            sensitivity_fields = [
                "provisional_early_reference_mW",
                "p0_early_median5_positive_mW",
                "p0_early_median5_time_h",
                "p0_post_stabilization_mW",
                "p0_post_stabilization_time_h",
                "p0_best_available_mW",
                "p0_best_available_definition",
                "p0_best_reference_time_h",
                "early_failure_flag",
                "early_failure_time_h",
                "early_failure_confirmation_time_h",
                "early_failure_subtype",
                "early_loss_timing_certainty",
                "early_failure_severity_evidence",
                "burn_in_like_flag",
                "burn_in_stabilization_status",
            ]
            bounded_columns.extend(
                f"{prefix}_{field}"
                for prefix in sensitivity_specs
                for field in sensitivity_fields
            )
            missing_columns = [column for column in bounded_columns if column not in devices.columns]
            if missing_columns:
                missing = pd.DataFrame("", index=devices.index, columns=missing_columns, dtype=object)
                devices = pd.concat([devices, missing], axis=1)
            devices[bounded_columns] = devices[bounded_columns].astype(object)
            by_device = {uid: group.copy() for uid, group in measurements.groupby("device_uid", sort=False)}
            for idx, device in devices.iterrows():
                uid = device["device_uid"]
                group = by_device.get(uid)
                if group is None or group.empty:
                    devices.loc[idx, "measurement_count"] = 0
                    devices.loc[idx, "zero_power_count"] = 0
                    continue
                group = group.sort_values(["measurement_time", "source_cell"])
                power_col = "analysis_power_mW" if "analysis_power_mW" in group.columns else "power_mW"
                powers = pd.to_numeric(group[power_col], errors="coerce")
                numeric = group[powers.notna()].copy()
                powers = pd.to_numeric(numeric["power_mW"], errors="coerce")
                last_power = float(powers.iloc[-1]) if len(powers) else None
                baseline = bounded_baseline_features(group, device)
                sensitivity_results = {
                    prefix: bounded_baseline_features(
                        group,
                        device,
                        reference_strategy=reference_strategy,
                        burn_in_cap_h=burn_in_cap_h,
                        rapid_horizon_h=rapid_horizon_h,
                        stability_tolerance_scale=stability_scale,
                    )
                    for prefix, (reference_strategy, burn_in_cap_h, rapid_horizon_h, stability_scale)
                    in sensitivity_specs.items()
                }
                p0_best = safe_float(baseline.get("p0_best_available_mW", ""))
        
                devices.loc[idx, "measurement_count"] = int(len(numeric))
                devices.loc[idx, "zero_power_count"] = int((powers == 0).sum())
                devices.loc[idx, "first_measurement_time"] = str(numeric["measurement_time"].iloc[0]) if len(numeric) else ""
                devices.loc[idx, "last_measurement_time"] = str(numeric["measurement_time"].iloc[-1]) if len(numeric) else ""
                for key, value in baseline.items():
                    devices.loc[idx, key] = value
                for prefix, sensitivity in sensitivity_results.items():
                    for field in sensitivity_fields:
                        devices.loc[idx, f"{prefix}_{field}"] = sensitivity.get(field, "")
                devices.loc[idx, "last_power_mW"] = last_power if last_power is not None else ""
                devices.loc[idx, "last_power_ratio_to_best_available_p0"] = round(last_power / p0_best, 6) if last_power is not None and p0_best else ""
            return devices
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Correct obvious measurement-entry anomalies before AI/reliability analysis.")
            parser.add_argument("--input-dir", type=Path, default=Path("outputs") / "processed")
            args = parser.parse_args()
        
            measurement_path = args.input_dir / "measurement_table.csv"
            device_path = args.input_dir / "device_table.csv"
            raw_measurement_path = args.input_dir / "measurement_table_raw_extracted.csv"
            raw_device_path = args.input_dir / "device_table_raw_extracted.csv"
            measurement_source = raw_measurement_path if raw_measurement_path.exists() else measurement_path
            device_source = raw_device_path if raw_device_path.exists() else device_path
            measurements = pd.read_csv(measurement_source, encoding="utf-8-sig", dtype=str).fillna("")
            devices = pd.read_csv(device_source, encoding="utf-8-sig", dtype=str).fillna("")
        
            # Preserve the direct extraction outputs for auditability.
            if not raw_measurement_path.exists():
                measurements.to_csv(raw_measurement_path, index=False, encoding="utf-8-sig")
            if not raw_device_path.exists():
                devices.to_csv(raw_device_path, index=False, encoding="utf-8-sig")
        
            device_map = {row["device_uid"]: row for _, row in devices.iterrows()}
            corrected = measurements.copy()
            corrected["power_mW_raw_extracted"] = pd.to_numeric(corrected["power_mW"], errors="coerce")
            corrected["power_mW_corrected"] = corrected["power_mW_raw_extracted"]
            corrected["power_correction_flag"] = "none"
            corrected["power_correction_method"] = ""
            corrected["power_correction_reason"] = ""
            corrected["power_correction_expected_mW"] = ""
            corrected["power_correction_review"] = 0
            for col in [
                "power_mW",
                "is_zero_power",
                "power_correction_flag",
                "power_correction_method",
                "power_correction_reason",
                "power_correction_expected_mW",
            ]:
                corrected[col] = corrected[col].astype(object)
        
            logs: list[dict[str, Any]] = []
            for uid, group in corrected.groupby("device_uid", sort=False):
                group = group.sort_values(["measurement_time", "source_cell"])
                device = device_map.get(uid)
                p0 = provisional_scale_from_device(device) if device is not None else None
                for ordinal, (row_idx, row) in enumerate(group.iterrows()):
                    raw_value = safe_float(row.get("power_mW_raw_extracted", ""))
                    if raw_value is None:
                        continue
                    expected = local_expected_power(group, ordinal, p0)
                    if not is_suspect_high_entry_error(raw_value, expected, p0):
                        continue
                    chosen = choose_correction(raw_value, expected, p0, str(row.get("power_raw", "")))
                    if chosen is None:
                        corrected.loc[row_idx, "power_correction_flag"] = "review_unfixed"
                        corrected.loc[row_idx, "power_correction_reason"] = "suspect_high_power_no_plausible_entry_correction"
                        corrected.loc[row_idx, "power_correction_expected_mW"] = expected if expected is not None else ""
                        corrected.loc[row_idx, "power_correction_review"] = 1
                        logs.append(
                            {
                                "device_uid": uid,
                                "source_file": row.get("source_file", ""),
                                "sheet": row.get("sheet", ""),
                                "source_cell": row.get("source_cell", ""),
                                "measurement_time": row.get("measurement_time", ""),
                                "raw_power_mW": raw_value,
                                "corrected_power_mW": "",
                                "method": "",
                                "expected_mW": expected if expected is not None else "",
                                "p0_reference_mW": p0 if p0 is not None else "",
                                "reason": "suspect_high_power_no_plausible_entry_correction",
                                "requires_review": 1,
                            }
                        )
                        continue
                    method, value, score = chosen
                    flag = correction_flag_from_score(score)
                    if flag is None:
                        corrected.loc[row_idx, "power_correction_flag"] = "review_unfixed"
                        corrected.loc[row_idx, "power_correction_reason"] = "suspect_high_power_candidate_not_close_enough"
                        corrected.loc[row_idx, "power_correction_expected_mW"] = expected if expected is not None else ""
                        corrected.loc[row_idx, "power_correction_review"] = 1
                        logs.append(
                            {
                                "device_uid": uid,
                                "source_file": row.get("source_file", ""),
                                "sheet": row.get("sheet", ""),
                                "source_cell": row.get("source_cell", ""),
                                "measurement_time": row.get("measurement_time", ""),
                                "raw_power_mW": raw_value,
                                "corrected_power_mW": value,
                                "method": method,
                                "expected_mW": expected if expected is not None else "",
                                "p0_reference_mW": p0 if p0 is not None else "",
                                "selection_score": score,
                                "reason": "suspect_high_power_candidate_not_close_enough",
                                "requires_review": 1,
                            }
                        )
                        continue
                    corrected.loc[row_idx, "power_mW_corrected"] = value
                    corrected.loc[row_idx, "power_mW"] = str(value)
                    corrected.loc[row_idx, "power_raw"] = row.get("power_raw", "")
                    corrected.loc[row_idx, "is_zero_power"] = str(int(value == 0))
                    corrected.loc[row_idx, "power_correction_flag"] = flag
                    corrected.loc[row_idx, "power_correction_method"] = method
                    corrected.loc[row_idx, "power_correction_reason"] = "suspect_high_power_probable_entry_error"
                    corrected.loc[row_idx, "power_correction_expected_mW"] = expected if expected is not None else ""
                    corrected.loc[row_idx, "power_correction_review"] = 1
                    logs.append(
                        {
                            "device_uid": uid,
                            "source_file": row.get("source_file", ""),
                            "sheet": row.get("sheet", ""),
                            "source_cell": row.get("source_cell", ""),
                            "measurement_time": row.get("measurement_time", ""),
                            "raw_power_mW": raw_value,
                            "corrected_power_mW": value,
                            "method": method,
                            "expected_mW": expected if expected is not None else "",
                            "p0_reference_mW": p0 if p0 is not None else "",
                            "selection_score": score,
                            "correction_flag": flag,
                            "reason": "suspect_high_power_probable_entry_error",
                            "requires_review": 1,
                        }
                    )
        
            # Keep power_mW as the downstream value and make it consistently numeric-looking.
            corrected["power_mW"] = pd.to_numeric(corrected["power_mW"], errors="coerce")
            corrected["is_zero_power"] = (corrected["power_mW"] == 0).astype(int)
        
            devices_after_qx1 = recalc_device_summaries(devices, corrected)
            corrected, artifact_logs = mark_transient_low_power_artifacts(corrected, devices_after_qx1)
            devices_corrected = recalc_device_summaries(devices, corrected)
            corrected.to_csv(measurement_path, index=False, encoding="utf-8-sig")
            devices_corrected.to_csv(device_path, index=False, encoding="utf-8-sig")
        
            correction_log_columns = [
                "device_uid", "source_file", "sheet", "source_cell", "measurement_time",
                "raw_power_mW", "corrected_power_mW", "method", "expected_mW",
                "p0_reference_mW", "selection_score", "correction_flag", "reason", "requires_review",
            ]
            log_df = pd.DataFrame(logs, columns=correction_log_columns)
            log_df.to_csv(args.input_dir / "measurement_correction_log.csv", index=False, encoding="utf-8-sig")
            artifact_log_columns = [
                "device_uid", "source_file", "sheet", "source_cell", "measurement_time",
                "power_mW", "analysis_power_mW", "ratio_to_p0", "previous_ratio", "next_ratio",
                "p0_reference_mW", "method", "reason", "downstream_policy", "requires_review",
            ]
            artifact_log_df = pd.DataFrame(artifact_logs, columns=artifact_log_columns)
            artifact_log_df.to_csv(args.input_dir / "measurement_artifact_log.csv", index=False, encoding="utf-8-sig")
            corrected_count = int(corrected["power_correction_flag"].isin(["corrected", "review_corrected"]).sum())
            summary = pd.DataFrame(
                [
                    {
                        "raw_measurements": len(measurements),
                        "corrected_measurements": corrected_count,
                        "auto_corrected_measurements": int((corrected["power_correction_flag"] == "corrected").sum()),
                        "review_corrected_measurements": int((corrected["power_correction_flag"] == "review_corrected").sum()),
                        "review_unfixed_measurements": int((corrected["power_correction_flag"] == "review_unfixed").sum()),
                        "artifact_imputed_measurements": int((corrected["power_artifact_flag"] == "imputed_for_analysis").sum()),
                        "artifact_excluded_measurements": int((corrected["power_artifact_flag"] == "excluded_from_label_features").sum()),
                        "devices_with_corrections": int(log_df["device_uid"].nunique()) if not log_df.empty else 0,
                        "devices_with_artifact_adjustments": int(artifact_log_df["device_uid"].nunique()) if not artifact_log_df.empty else 0,
                        "devices_with_artifact_exclusions": int(
                            corrected.loc[corrected["power_artifact_flag"] == "excluded_from_label_features", "device_uid"].nunique()
                        ),
                        "rule_absolute_implausible_mW": ABSOLUTE_IMPLAUSIBLE_MW,
                        "rule_ratio_implausible": RATIO_IMPLAUSIBLE,
                        "rule_high_ratio_suspect": HIGH_RATIO_SUSPECT,
                        "rule_local_high_ratio_suspect": LOCAL_HIGH_RATIO_SUSPECT,
                        "rule_max_plausible_ratio_after_correction": MAX_PLAUSIBLE_RATIO_AFTER_CORRECTION,
                        "rule_auto_correction_max_log_error": AUTO_CORRECTION_MAX_LOG_ERROR,
                        "rule_review_correction_max_log_error": REVIEW_CORRECTION_MAX_LOG_ERROR,
                        "rule_artifact_low_ratio": ARTIFACT_LOW_RATIO,
                        "rule_artifact_recovery_ratio": ARTIFACT_RECOVERY_RATIO,
                        "rule_artifact_strong_recovery_ratio": ARTIFACT_STRONG_RECOVERY_RATIO,
                    }
                ]
            )
            summary.to_csv(args.input_dir / "measurement_correction_summary.csv", index=False, encoding="utf-8-sig")
        
            print(f"raw_measurements={len(measurements)}")
            print(f"corrected_measurements={corrected_count}")
            print(f"auto_corrected_measurements={int((corrected['power_correction_flag'] == 'corrected').sum())}")
            print(f"review_corrected_measurements={int((corrected['power_correction_flag'] == 'review_corrected').sum())}")
            print(f"review_unfixed_measurements={int((corrected['power_correction_flag'] == 'review_unfixed').sum())}")
            print(f"artifact_imputed_measurements={int((corrected['power_artifact_flag'] == 'imputed_for_analysis').sum())}")
            print(f"artifact_excluded_measurements={int((corrected['power_artifact_flag'] == 'excluded_from_label_features').sum())}")
            print(f"log={(args.input_dir / 'measurement_correction_log.csv').resolve()}")
            print(f"artifact_log={(args.input_dir / 'measurement_artifact_log.csv').resolve()}")
        main()


def run_events(stage_args: list[str]) -> None:
    """Run the embedded derive_exploratory_events.py stage with an isolated command line."""
    with isolated_argv("events", stage_args):
        import argparse
        import csv
        import json
        from collections import Counter, defaultdict
        from datetime import datetime
        from pathlib import Path
        from typing import Any
        
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            """Read one frozen rule's parameters without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            return dict(registry["rules"][rule_id].get("parameters", {}))
        
        P0 = parameters("P0-1")
        EVT = parameters("EVT-1")
        EF = parameters("EF-1")
        P0_DEFINITIONS = [
            ("p0_meta", "p0_meta_mW"),
            ("p0_early_median5", "p0_early_median5_positive_mW"),
            ("p0_post_stabilization", "p0_post_stabilization_mW"),
            ("p0_best_available", ""),
        ]
        if [name for name, _ in P0_DEFINITIONS] != P0["definitions"]:
            raise ValueError("P0 definitions do not match the frozen registry.")
        THRESHOLDS = [float(value) for value in EVT["threshold_ratios"]]
        EARLY_WINDOW_HOURS = float(EVT["early_window_h"])
        CATASTROPHIC_RATIO = float(EVT["catastrophic_ratio"])
        RECOVERY_MARGIN = float(EVT["recovery_margin"])
        EARLY_FAILURE_CAP_H = float(EF["early_failure_cap_h"])
        
        
        def parse_float(value: Any) -> float | None:
            if value is None or value == "":
                return None
            try:
                return float(value)
            except (TypeError, ValueError):
                return None
        
        
        def parse_datetime(value: str) -> datetime | None:
            if not value:
                return None
            for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    pass
            return None
        
        
        def load_csv(path: Path) -> list[dict[str, str]]:
            with path.open(encoding="utf-8-sig", newline="") as handle:
                return list(csv.DictReader(handle))
        
        
        def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
            path.parent.mkdir(parents=True, exist_ok=True)
            if not rows:
                path.write_text("", encoding="utf-8-sig")
                return
            fieldnames: list[str] = []
            for row in rows:
                for key in row:
                    if key not in fieldnames:
                        fieldnames.append(key)
            with path.open("w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
        
        
        def p0_value(device: dict[str, str], p0_name: str, p0_col: str) -> float | None:
            if p0_name == "p0_best_available":
                for col in P0["best_available_order"]:
                    value = parse_float(device.get(col, ""))
                    if value is not None and value > 0:
                        return value
                return None
            value = parse_float(device.get(p0_col, ""))
            return value if value is not None and value > 0 else None

        def p0_reference_time(device: dict[str, str], p0_name: str) -> float:
            if p0_name == "p0_meta":
                return 0.0
            if p0_name == "p0_early_median5":
                return parse_float(device.get("p0_early_median5_time_h", "")) or 0.0
            if p0_name == "p0_post_stabilization":
                return parse_float(device.get("p0_post_stabilization_time_h", "")) or 0.0
            return parse_float(device.get("p0_best_reference_time_h", "")) or 0.0
        
        
        def sort_measurements(rows: list[dict[str, str]]) -> list[dict[str, str]]:
            def key(row: dict[str, str]) -> tuple[float, datetime, str]:
                exposure = time_value(row)
                dt = parse_datetime(row.get("measurement_time", "")) or datetime.max
                return float("inf") if exposure is None else exposure, dt, row.get("source_cell", "")
        
            return sorted(rows, key=key)
        
        
        def time_value(row: dict[str, str]) -> float | None:
            exposure = parse_float(row.get("exposure_hours", ""))
            if exposure is not None:
                return exposure
            return parse_float(row.get("calendar_hours", ""))
        
        
        def classify_event(
            rows: list[dict[str, str]],
            p0: float,
            threshold: float,
            time_origin_h: float,
        ) -> dict[str, Any]:
            numeric = []
            for row in rows:
                power = parse_float(row.get("endpoint_power_mW", ""))
                if power is None:
                    power = parse_float(row.get("power_mW", ""))
                t = time_value(row)
                if power is None or t is None:
                    continue
                if t + 1e-9 < time_origin_h:
                    continue
                numeric.append(
                    {
                        **row,
                        "power": power,
                        "t_abs": t,
                        "t_since_p0": max(0.0, t - time_origin_h),
                        "t": t,
                        "ratio": power / p0,
                    }
                )
        
            if not numeric:
                return {
                    "event_status": "no_numeric_measurements",
                    "failure_mode_exploratory": "not_assessed",
                    "event_source_cell": "",
                    "censor_source_cell": "",
                }
        
            first_cross_idx = None
            for idx, row in enumerate(numeric):
                if row["ratio"] <= threshold:
                    first_cross_idx = idx
                    break
        
            catastrophic = next((row for row in numeric if row["ratio"] <= CATASTROPHIC_RATIO or row["power"] == 0), None)
            last = numeric[-1]
            min_row = min(numeric, key=lambda row: row["ratio"])
        
            if first_cross_idx is None:
                return {
                    "event_status": "right_censored",
                    "failure_mode_exploratory": "progressive_or_right_censored",
                    "event_time": "",
                    "event_exposure_hours": "",
                    "event_power_mW": "",
                    "event_ratio": "",
                    "event_source_cell": "",
                    "event_confirmation_time": "",
                    "event_confirmation_exposure_hours": "",
                    "event_confirmation_source_cell": "",
                    "censor_time": last["measurement_time"],
                    "censor_exposure_hours": round(last["t"], 6),
                    "censor_source_cell": last.get("source_cell", ""),
                    "last_power_mW": last["power"],
                    "last_ratio": round(last["ratio"], 6),
                    "min_ratio": round(min_row["ratio"], 6),
                    "catastrophic_time": catastrophic["measurement_time"] if catastrophic else "",
                    "catastrophic_exposure_hours": round(catastrophic["t"], 6) if catastrophic else "",
                }
        
            event = numeric[first_cross_idx]
            after = numeric[first_cross_idx + 1 :]
            later_above = [row for row in after if row["ratio"] > threshold + RECOVERY_MARGIN]
            later_below = [row for row in after if row["ratio"] <= threshold]
            confirmation = later_below[0] if later_below else (event if event is last else None)
            confirmed = confirmation is not None
            recovered = bool(later_above)
            first_clearance_index = next(
                (idx for idx, row in enumerate(after) if row["ratio"] > threshold + RECOVERY_MARGIN),
                None,
            )
            recrossed_after_clearance = bool(
                first_clearance_index is not None
                and any(row["ratio"] <= threshold for row in after[first_clearance_index + 1 :])
            )
        
            if confirmed and not recovered:
                event_status = "failure_observed"
            elif confirmed and recovered:
                event_status = "failure_observed_with_recovery"
            else:
                event_status = "transient_or_measurement_issue"
        
            if catastrophic and catastrophic["t"] <= event["t"] + 1e-9:
                mode = "change_point_or_midlife_drop" if event["t"] > EARLY_WINDOW_HOURS else "rapid_or_catastrophic_failure"
            elif event_status == "transient_or_measurement_issue":
                mode = "other_observable_pattern"
            elif event["t"] <= EARLY_WINDOW_HOURS:
                mode = "rapid_or_catastrophic_failure"
            else:
                mode = "progressive_or_right_censored"
        
            return {
                "event_status": event_status,
                "failure_mode_exploratory": mode,
                "event_time": event["measurement_time"],
                "event_exposure_hours": round(event["t"], 6),
                "event_power_mW": event["power"],
                "event_ratio": round(event["ratio"], 6),
                "event_source_cell": event.get("source_cell", ""),
                "event_confirmation_time": confirmation["measurement_time"] if confirmation else "",
                "event_confirmation_exposure_hours": round(confirmation["t"], 6) if confirmation else "",
                "event_confirmation_source_cell": confirmation.get("source_cell", "") if confirmation else "",
                "censor_time": "",
                "censor_exposure_hours": "",
                "censor_source_cell": "",
                "last_power_mW": last["power"],
                "last_ratio": round(last["ratio"], 6),
                "min_ratio": round(min_row["ratio"], 6),
                "catastrophic_time": catastrophic["measurement_time"] if catastrophic else "",
                "catastrophic_exposure_hours": round(catastrophic["t"], 6) if catastrophic else "",
                "recovered_above_threshold_after_event": int(recovered),
                "post_event_points_below_threshold": len(later_below),
                "post_event_points_above_threshold_plus_margin": len(later_above),
                "recrossed_after_first_clearance": int(recrossed_after_clearance),
                "ended_above_threshold_plus_margin": int(last["ratio"] > threshold + RECOVERY_MARGIN),
            }


        def early_failure_event(
            rows: list[dict[str, str]],
            device: dict[str, str],
            threshold: float,
        ) -> dict[str, Any]:
            """Return an EF event only when the frozen early reference crosses this threshold."""
            if not int(parse_float(device.get("early_failure_flag", "")) or 0):
                return {}
            reference = parse_float(device.get("provisional_early_reference_mW", ""))
            if reference is None or reference <= 0:
                return {}
            numeric: list[dict[str, Any]] = []
            for row in rows:
                t = time_value(row)
                power = parse_float(row.get("endpoint_power_mW", ""))
                if power is None:
                    power = parse_float(row.get("power_mW", ""))
                if t is not None and power is not None:
                    numeric.append({**row, "t": t, "power": power, "ratio": power / reference})
            numeric.sort(key=lambda row: (row["t"], row.get("measurement_time", ""), row.get("source_cell", "")))
            pair = inherited_inspection_pair(numeric, threshold, EARLY_FAILURE_CAP_H)
            if pair is None:
                return {}
            event_index, confirmation_index = pair
            event = numeric[event_index]
            confirmation = numeric[confirmation_index]
            # Inheritance changes the reference, not the clearance obligation.
            # Inspect the complete later archive with the same early denominator
            # that established this threshold-specific event, including after 240 h.
            after = numeric[event_index + 1 :]
            later_below = [row for row in after if row["ratio"] <= threshold]
            later_above = [row for row in after if row["ratio"] > threshold + RECOVERY_MARGIN]
            first_clearance_index = next(
                (idx for idx, row in enumerate(after) if row["ratio"] > threshold + RECOVERY_MARGIN),
                None,
            )
            recrossed_after_clearance = bool(
                first_clearance_index is not None
                and any(row["ratio"] <= threshold for row in after[first_clearance_index + 1 :])
            )
            subtype = str(device.get("early_failure_subtype", ""))
            timing_certainty = (
                "confirmed_rapid"
                if event["t"] <= float(EF["rapid_loss_horizon_h"]) + 1e-9
                and confirmation_index > event_index
                else "terminal_or_isolated_point_requires_review"
                if confirmation_index == event_index
                else "interval_ambiguous_substantial_early_loss"
            )
            return {
                "event_status": "failure_observed_with_recovery" if later_above else "early_failure_observed",
                "failure_mode_exploratory": (
                    "rapid_or_catastrophic_failure"
                    if timing_certainty == "confirmed_rapid"
                    else "substantial_early_loss"
                ),
                "event_time": event.get("measurement_time", ""),
                "event_exposure_hours": round(event["t"], 6),
                "event_power_mW": event["power"],
                "event_ratio": round(event["ratio"], 6),
                "event_source_cell": event.get("source_cell", ""),
                "event_confirmation_time": confirmation.get("measurement_time", ""),
                "event_confirmation_exposure_hours": round(confirmation["t"], 6),
                "event_confirmation_source_cell": confirmation.get("source_cell", ""),
                "censor_time": "",
                "censor_exposure_hours": "",
                "censor_source_cell": "",
                "early_failure_subtype": subtype,
                "early_loss_timing_certainty": timing_certainty,
                "provisional_early_reference_mW": reference if reference is not None else "",
                "recovered_above_threshold_after_event": int(bool(later_above)),
                "post_event_points_below_threshold": len(later_below),
                "post_event_points_above_threshold_plus_margin": len(later_above),
                "recrossed_after_first_clearance": int(recrossed_after_clearance),
                "ended_above_threshold_plus_margin": int(numeric[-1]["ratio"] > threshold + RECOVERY_MARGIN),
            }
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Create exploratory event tables from extracted VCSEL long tables.")
            parser.add_argument("--input-dir", type=Path, default=Path("outputs") / "processed")
            parser.add_argument("--output-dir", type=Path, default=Path("outputs") / "processed")
            args = parser.parse_args()
        
            devices = load_csv(args.input_dir / "device_table.csv")
            measurements = load_csv(args.input_dir / "measurement_table.csv")
            by_device: dict[str, list[dict[str, str]]] = defaultdict(list)
            for row in measurements:
                by_device[row["device_uid"]].append(row)
        
            event_rows: list[dict[str, Any]] = []
            for device in devices:
                device_measurements = sort_measurements(by_device.get(device["device_uid"], []))
                for p0_name, p0_col in P0_DEFINITIONS:
                    p0 = p0_value(device, p0_name, p0_col)
                    reference_time_h = p0_reference_time(device, p0_name)
                    for threshold in THRESHOLDS:
                        early_failure = early_failure_event(device_measurements, device, threshold)
                        base = {
                            "device_uid": device["device_uid"],
                            "file_id": device["file_id"],
                            "source_file": device["source_file"],
                            "sheet": device["sheet"],
                            "source_column": device["source_column"],
                            "device_id_raw": device["device_id_raw"],
                            "position": device["position"],
                            "batch": device["batch"],
                            "laser_type": device["laser_type"],
                            "aging_temperature_raw": device["aging_temperature_raw"],
                            "aging_temperature_C": device["aging_temperature_C"],
                            "aging_current_raw": device["aging_current_raw"],
                            "p0_definition": p0_name,
                            "p0_mW": p0 if p0 is not None else "",
                            "p0_reference_time_h": reference_time_h,
                            "analysis_clock_origin_h": 0.0,
                            "failure_threshold_ratio": threshold,
                            "measurement_count": device.get("measurement_count", ""),
                            "zero_power_count": device.get("zero_power_count", ""),
                        }
                        if early_failure:
                            base.update(early_failure)
                        elif p0 is None:
                            base.update(
                                {
                                    "event_status": "p0_missing_or_nonpositive",
                                    "failure_mode_exploratory": "not_assessed",
                                }
                            )
                        else:
                            base.update(classify_event(device_measurements, p0, threshold, reference_time_h))
                        event_rows.append(base)
        
            summary_rows: list[dict[str, Any]] = []
            groups: dict[tuple[str, str, str], Counter[str]] = defaultdict(Counter)
            for row in event_rows:
                key = (row["p0_definition"], str(row["failure_threshold_ratio"]), row["aging_temperature_raw"])
                groups[key][row["event_status"]] += 1
            for (p0_definition, threshold, temperature), counts in sorted(groups.items()):
                summary = {
                    "p0_definition": p0_definition,
                    "failure_threshold_ratio": threshold,
                    "aging_temperature_raw": temperature,
                    "total_device_events": sum(counts.values()),
                }
                summary.update(dict(counts))
                summary_rows.append(summary)
        
            write_csv(args.output_dir / "event_table_exploratory.csv", event_rows)
            write_csv(args.output_dir / "p0_threshold_summary.csv", summary_rows)
        
            print(f"event_rows={len(event_rows)}")
            print(f"summary_rows={len(summary_rows)}")
            print(f"output_dir={args.output_dir.resolve()}")
        main()


def run_failure_modes(stage_args: list[str]) -> None:
    """Run the embedded ai_assisted_failure_mode.py stage with an isolated command line."""
    with isolated_argv("failure_modes", stage_args):
        import argparse
        import csv
        import json
        import math
        from collections import Counter, defaultdict
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        from sklearn.cluster import KMeans
        from sklearn.impute import SimpleImputer
        from sklearn.linear_model import TheilSenRegressor
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            """Read one frozen rule's parameters without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            return dict(registry["rules"][rule_id].get("parameters", {}))
        
        FM = parameters("FM-1")
        EARLY_WINDOW_HOURS = float(FM["early_window_h"])
        MAIN_FAILURE_THRESHOLD = float(FM["main_ratio"])
        SEVERE_FAILURE_THRESHOLD = float(FM["severe_ratio"])
        CATASTROPHIC_THRESHOLD = float(FM["catastrophic_ratio"])
        EXTREME_HIGH_RATIO = float(FM["extreme_high_ratio"])
        MIN_POINTS_FOR_PATTERN = int(FM["minimum_points_for_pattern_assignment"])
        MIN_POINTS_WITHOUT_REVIEW = int(FM["minimum_points_without_review"])
        CHANGE_POINT_SCORE_MIN = float(FM["change_point_score_min"])
        LATE_SLOPE_MAX = float(FM["late_slope_per_1000h_max"])
        NEGATIVE_SLOPE_MAX = float(FM["negative_slope_per_1000h_max"])
        EARLY_LARGE_DROP_MAX = float(FM["large_drop_max"])
        SEVERE_LARGE_DROP_MAX = float(FM["severe_large_drop_max"])
        NONMONOTONE_RECOVERY_MIN = float(FM["nonmonotone_recovery_min"])
        BI = parameters("BI-1")
        BI_CAP_H = float(BI["burn_in_cap_h"])
        RCV = parameters("RCV-1")
        RCV_MIN_POINTS = int(RCV["minimum_points"])
        RCV_MIN_RECOVERY = float(RCV["minimum_recovery_after_min_ratio"])
        RCV_MIN_FINAL_GAIN = float(RCV["minimum_final_gain_from_min_ratio"])
        RCV_MIN_POST_MIN_POINTS = int(RCV["minimum_points_after_min"])
        RCV_MIN_NET_INCREASE = float(RCV["minimum_net_increase_ratio"])
        RCV_MIN_POSITIVE_SLOPE = float(RCV["minimum_positive_slope_per_1000h"])
        RCV_CATASTROPHIC_FLOOR = float(RCV["catastrophic_floor_ratio"])
        RANDOM_STATE = 42
        
        
        def safe_float(value: Any) -> float | None:
            if value is None:
                return None
            try:
                result = float(value)
            except (TypeError, ValueError):
                return None
            if math.isnan(result) or math.isinf(result):
                return None
            return result
        
        
        def choose_p0(device: pd.Series) -> tuple[float | None, str]:
            for name, col in [
                ("p0_post_stabilization", "p0_post_stabilization_mW"),
                ("p0_early_median5", "p0_early_median5_positive_mW"),
            ]:
                value = safe_float(device.get(col))
                if value is not None and value > 0:
                    return value, name
            if int(safe_float(device.get("early_failure_flag")) or 0) == 1:
                value = safe_float(device.get("provisional_early_reference_mW"))
                if value is not None and value > 0:
                    return value, "provisional_early_failure_reference"
            return None, "missing"
        
        
        def robust_slope_per_1000h(t: np.ndarray, y: np.ndarray) -> float | None:
            mask = np.isfinite(t) & np.isfinite(y)
            t = t[mask]
            y = y[mask]
            if len(t) < 3 or float(np.nanmax(t) - np.nanmin(t)) <= 0:
                return None
            try:
                model = TheilSenRegressor(random_state=RANDOM_STATE)
                model.fit(t.reshape(-1, 1), y)
                return float(model.coef_[0] * 1000.0)
            except Exception:
                slope, _ = np.polyfit(t, y, deg=1)
                return float(slope * 1000.0)
        
        
        def segmented_change_point(t: np.ndarray, y: np.ndarray) -> dict[str, Any]:
            mask = np.isfinite(t) & np.isfinite(y)
            t = t[mask]
            y = y[mask]
            order = np.argsort(t)
            t = t[order]
            y = y[order]
            if len(t) < 8 or float(t[-1] - t[0]) <= 0:
                return {
                    "change_point_time_h": "",
                    "change_point_score": "",
                    "change_point_before_slope_per_1000h": "",
                    "change_point_after_slope_per_1000h": "",
                }
        
            def sse_line(x: np.ndarray, z: np.ndarray) -> tuple[float, float]:
                if len(x) < 2 or float(x[-1] - x[0]) <= 0:
                    return float(np.sum((z - np.mean(z)) ** 2)), 0.0
                slope, intercept = np.polyfit(x, z, deg=1)
                pred = slope * x + intercept
                return float(np.sum((z - pred) ** 2)), float(slope * 1000.0)
        
            total_sse, _ = sse_line(t, y)
            if total_sse <= 1e-12:
                return {
                    "change_point_time_h": "",
                    "change_point_score": 0.0,
                    "change_point_before_slope_per_1000h": "",
                    "change_point_after_slope_per_1000h": "",
                }
        
            best = None
            min_side = max(3, int(round(len(t) * 0.15)))
            for idx in range(min_side, len(t) - min_side):
                left_sse, left_slope = sse_line(t[:idx], y[:idx])
                right_sse, right_slope = sse_line(t[idx:], y[idx:])
                score = max(0.0, (total_sse - left_sse - right_sse) / total_sse)
                candidate = (score, idx, left_slope, right_slope)
                if best is None or candidate[0] > best[0]:
                    best = candidate
        
            if best is None:
                return {
                    "change_point_time_h": "",
                    "change_point_score": "",
                    "change_point_before_slope_per_1000h": "",
                    "change_point_after_slope_per_1000h": "",
                }
            score, idx, left_slope, right_slope = best
            return {
                "change_point_time_h": round(float(t[idx]), 6),
                "change_point_score": round(float(score), 6),
                "change_point_before_slope_per_1000h": round(float(left_slope), 6),
                "change_point_after_slope_per_1000h": round(float(right_slope), 6),
            }


        def bounded_burn_in_features_from_device(device: pd.Series, t: np.ndarray, y: np.ndarray) -> dict[str, Any]:
            """Expose the pre-P0 bounded BI/EF decisions and summarize the post-P0 trajectory."""
            stabilization_time = safe_float(device.get("burn_in_stabilization_time_h"))
            post_slope = robust_slope_per_1000h(t, y)
            return {
                "burn_in_cap_h": BI_CAP_H,
                "burn_in_stabilization_status": device.get("burn_in_stabilization_status", ""),
                "burn_in_like_flag": int(safe_float(device.get("burn_in_like_flag")) or 0),
                "burn_in_early_drop_ratio": device.get("burn_in_early_drop_ratio", ""),
                "burn_in_stabilization_time_h": stabilization_time if stabilization_time is not None else "",
                "burn_in_stable_window_point_count": int(safe_float(device.get("burn_in_stable_window_point_count")) or 0),
                "burn_in_stable_window_span_h": device.get("burn_in_stable_window_span_h", ""),
                "burn_in_stable_window_relative_spread": device.get("burn_in_stable_window_relative_spread", ""),
                "burn_in_stable_window_relative_slope_per_100h": device.get("burn_in_stable_window_relative_slope_per_100h", ""),
                "post_stabilization_point_count": int(len(y)),
                "post_stabilization_duration_h": round(float(t[-1] - t[0]), 6) if len(t) else "",
                "post_stabilization_median_ratio": round(float(np.median(y)), 6) if len(y) else "",
                "post_stabilization_slope_ratio_per_1000h": round(float(post_slope), 6) if post_slope is not None else "",
                "post_stabilization_p10_p90_range": round(float(np.percentile(y, 90) - np.percentile(y, 10)), 6) if len(y) else "",
                "early_failure_flag": int(safe_float(device.get("early_failure_flag")) or 0),
                "early_failure_time_h": device.get("early_failure_time_h", ""),
                "early_failure_confirmation_time_h": device.get("early_failure_confirmation_time_h", ""),
                "early_failure_subtype": device.get("early_failure_subtype", ""),
                "early_loss_timing_certainty": device.get("early_loss_timing_certainty", ""),
                "provisional_early_reference_mW": device.get("provisional_early_reference_mW", ""),
            }


        def recovery_power_increase_features(t: np.ndarray, y: np.ndarray, slope: float | None) -> dict[str, Any]:
            """Detect sustained recovery or net power increase without assigning a mechanism."""
            result: dict[str, Any] = {
                "recovery_or_power_increase_flag": 0,
                "recovery_pattern_kind": "",
                "minimum_ratio_time_h": "",
                "post_minimum_point_count": 0,
                "final_gain_from_min_ratio": "",
                "net_power_change_ratio": "",
            }
            if len(y) < RCV_MIN_POINTS:
                return result
            min_idx = int(np.argmin(y))
            post_min_points = int(len(y) - min_idx - 1)
            recovery = float(np.max(y[min_idx:]) - y[min_idx])
            final_gain = float(y[-1] - y[min_idx])
            net_change = float(y[-1] - y[0])
            result.update(
                {
                    "minimum_ratio_time_h": round(float(t[min_idx]), 6),
                    "post_minimum_point_count": post_min_points,
                    "final_gain_from_min_ratio": round(final_gain, 6),
                    "net_power_change_ratio": round(net_change, 6),
                }
            )
            recovered = (
                float(y[min_idx]) > RCV_CATASTROPHIC_FLOOR
                and post_min_points >= RCV_MIN_POST_MIN_POINTS
                and recovery >= RCV_MIN_RECOVERY
                and final_gain >= RCV_MIN_FINAL_GAIN
            )
            increased = (
                float(np.min(y)) > RCV_CATASTROPHIC_FLOOR
                and
                slope is not None
                and slope >= RCV_MIN_POSITIVE_SLOPE
                and net_change >= RCV_MIN_NET_INCREASE
            )
            if recovered or increased:
                result["recovery_or_power_increase_flag"] = 1
                if recovered and increased:
                    result["recovery_pattern_kind"] = "recovery_and_net_increase"
                elif recovered:
                    result["recovery_pattern_kind"] = "sustained_recovery_after_minimum"
                else:
                    result["recovery_pattern_kind"] = "sustained_net_power_increase"
            return result
        
        
        def curve_features(device: pd.Series, measurements: pd.DataFrame) -> dict[str, Any]:
            p0, p0_definition = choose_p0(device)
            early_failure_flag = int(safe_float(device.get("early_failure_flag")) or 0)
            p0_reference_time = 0.0 if early_failure_flag else (safe_float(device.get("p0_best_reference_time_h")) or 0.0)
            result: dict[str, Any] = {
                "device_uid": device["device_uid"],
                "file_id": device["file_id"],
                "source_file": device.get("source_file", ""),
                "sheet": device["sheet"],
                "source_column": device["source_column"],
                "device_id_raw": device.get("device_id_raw", ""),
                "position": device.get("position", ""),
                "batch": device.get("batch", ""),
                "laser_type": device.get("laser_type", ""),
                "aging_temperature_raw": device.get("aging_temperature_raw", ""),
                "aging_temperature_C": device.get("aging_temperature_C", ""),
                "aging_current_raw": device.get("aging_current_raw", ""),
                "aging_current_mA": device.get("aging_current_mA", ""),
                "p0_ai_mW": p0 if p0 is not None else "",
                "p0_ai_definition": p0_definition,
                "p0_reference_time_h": p0_reference_time,
                "p0_first_mW_provenance_only": device.get("p0_first_mW", ""),
            }
        
            m = measurements.copy()
            power_column = "analysis_power_mW" if "analysis_power_mW" in m.columns else "power_mW"
            m["power_mW_num"] = pd.to_numeric(m[power_column], errors="coerce")
            m["time_h"] = pd.to_numeric(m["exposure_hours"], errors="coerce")
            fallback = pd.to_numeric(m["calendar_hours"], errors="coerce")
            m["time_h"] = m["time_h"].fillna(fallback)
            if "power_artifact_flag" in m.columns:
                artifact_mask = m["power_artifact_flag"].astype(str).isin(["excluded_from_label_features", "imputed_for_analysis"])
                result["power_artifact_excluded_count"] = int(artifact_mask.sum())
                result["power_artifact_review_count"] = int(pd.to_numeric(m.get("power_artifact_review", 0), errors="coerce").fillna(0).sum())
            else:
                result["power_artifact_excluded_count"] = 0
                result["power_artifact_review_count"] = 0
            m = m.dropna(subset=["power_mW_num", "time_h"]).sort_values(["time_h", "measurement_time", "source_cell"])

            result["measurement_count_ai"] = int(len(m))
            result["time_review_count"] = int(pd.to_numeric(m.get("time_needs_review", 0), errors="coerce").fillna(0).sum())
            result["time_review_fraction"] = round(result["time_review_count"] / len(m), 6) if len(m) else ""
            if "power_correction_flag" in m.columns:
                result["power_corrected_count"] = int(m["power_correction_flag"].astype(str).isin(["corrected", "review_corrected"]).sum())
                result["power_correction_review_count"] = int(pd.to_numeric(m.get("power_correction_review", 0), errors="coerce").fillna(0).sum())
            else:
                result["power_corrected_count"] = 0
                result["power_correction_review_count"] = 0
            m = m[m["time_h"] + 1e-9 >= p0_reference_time].copy()
            m["time_h"] = m["time_h"] - p0_reference_time
        
            if p0 is None or p0 <= 0 or len(m) == 0:
                result.update(
                    {
                        "duration_h": "",
                        "first_ratio": "",
                        "last_ratio": "",
                        "min_ratio": "",
                        "max_ratio": "",
                        "slope_ratio_per_1000h": "",
                        "largest_drop_step": "",
                        "largest_rise_step": "",
                        "max_recovery_after_min": "",
                        "first_below_80_time_h": "",
                        "first_below_50_time_h": "",
                        "first_below_10_time_h": "",
                        "change_point_time_h": "",
                        "change_point_score": "",
                        "change_point_before_slope_per_1000h": "",
                        "change_point_after_slope_per_1000h": "",
                        "ai_suggested_failure_mode": "insufficient_p0_or_measurements",
                        "ai_assessability": "insufficient_or_unassessable",
                        "ai_confidence": 0.15,
                        "needs_human_review": 1,
                        "review_reasons": "missing_or_nonpositive_p0_or_no_measurements",
                    }
                )
                return result
        
            t_all = m["time_h"].to_numpy(dtype=float)
            y_all = m["power_mW_num"].to_numpy(dtype=float) / p0
            finite_all = np.isfinite(t_all) & np.isfinite(y_all)
            extreme_high_ratio_count = int(np.sum(finite_all & (y_all > EXTREME_HIGH_RATIO)))
            usable_ratio_mask = finite_all & (y_all <= EXTREME_HIGH_RATIO)
            t = t_all[usable_ratio_mask]
            y = y_all[usable_ratio_mask]
            order = np.argsort(t)
            t = t[order]
            y = y[order]
            valid = np.isfinite(t) & np.isfinite(y)
            t = t[valid]
            y = y[valid]
            if len(y) == 0:
                result.update(
                    {
                        "duration_h": "",
                        "first_ratio": "",
                        "last_ratio": "",
                        "min_ratio": "",
                        "max_ratio": "",
                        "slope_ratio_per_1000h": "",
                        "largest_drop_step": "",
                        "largest_rise_step": "",
                        "max_recovery_after_min": "",
                        "first_below_80_time_h": "",
                        "first_below_50_time_h": "",
                        "first_below_10_time_h": "",
                        "change_point_time_h": "",
                        "change_point_score": "",
                        "change_point_before_slope_per_1000h": "",
                        "change_point_after_slope_per_1000h": "",
                        "ai_suggested_failure_mode": "insufficient_p0_or_measurements",
                        "ai_assessability": "insufficient_or_unassessable",
                        "ai_confidence": 0.15,
                        "needs_human_review": 1,
                        "review_reasons": "missing_numeric_measurements",
                    }
                )
                return result
        
            diffs = np.diff(y) if len(y) > 1 else np.array([])
            min_idx = int(np.argmin(y))
            later_max = float(np.max(y[min_idx:])) if min_idx < len(y) else float(y[min_idx])
            max_recovery_after_min = max(0.0, later_max - float(y[min_idx]))
            early_mask = t <= EARLY_WINDOW_HOURS
            early_min = float(np.min(y[early_mask])) if np.any(early_mask) else ""
            slope = robust_slope_per_1000h(t, y)
            cp = segmented_change_point(t, y)
            bi = bounded_burn_in_features_from_device(device, t, y)
            recovery_increase = recovery_power_increase_features(t, y, slope)
        
            def first_time_below(threshold: float) -> float | str:
                mask = y <= threshold
                if not np.any(mask):
                    return ""
                return round(float(t[np.where(mask)[0][0]]), 6)
        
            result.update(
                {
                    "duration_h": round(float(t[-1] - t[0]), 6) if len(t) else "",
                    "first_ratio": round(float(y[0]), 6),
                    "last_ratio": round(float(y[-1]), 6),
                    "min_ratio": round(float(np.min(y)), 6),
                    "max_ratio": round(float(np.max(y)), 6),
                    "early_min_ratio_100h": round(early_min, 6) if early_min != "" else "",
                    "slope_ratio_per_1000h": round(float(slope), 6) if slope is not None else "",
                    "largest_drop_step": round(float(np.min(diffs)), 6) if len(diffs) else "",
                    "largest_rise_step": round(float(np.max(diffs)), 6) if len(diffs) else "",
                    "max_recovery_after_min": round(float(max_recovery_after_min), 6),
                    "first_below_80_time_h": first_time_below(MAIN_FAILURE_THRESHOLD),
                    "first_below_50_time_h": first_time_below(SEVERE_FAILURE_THRESHOLD),
                    "first_below_10_time_h": first_time_below(CATASTROPHIC_THRESHOLD),
                    "zero_power_count_ai": int(np.sum(y == 0)),
                    "extreme_high_ratio_count": extreme_high_ratio_count,
                    "points_below_80pct": int(np.sum(y <= MAIN_FAILURE_THRESHOLD)),
                    "points_below_50pct": int(np.sum(y <= SEVERE_FAILURE_THRESHOLD)),
                    "monotone_decrease_fraction": round(float(np.sum(diffs < 0) / len(diffs)), 6) if len(diffs) else "",
                    "step_variability_mad": round(float(np.median(np.abs(diffs - np.median(diffs)))), 6) if len(diffs) else "",
                }
            )
            result.update(cp)
            result.update(bi)
            result.update(recovery_increase)
        
            mode, confidence, reasons = weak_label(result)
            result["ai_suggested_failure_mode"] = mode
            result["ai_assessability"] = "insufficient_or_unassessable" if mode.startswith("insufficient") else "assessable"
            result["ai_confidence"] = confidence
            result["needs_human_review"] = int(should_review(device, result, reasons))
            result["review_reasons"] = ";".join(reasons)
            return result
        
        
        def weak_label(features: dict[str, Any]) -> tuple[str, float, list[str]]:
            reasons: list[str] = []
            n = safe_float(features.get("measurement_count_ai")) or 0
            duration = safe_float(features.get("duration_h")) or 0
            min_ratio = safe_float(features.get("min_ratio"))
            last_ratio = safe_float(features.get("last_ratio"))
            early_min = safe_float(features.get("early_min_ratio_100h"))
            slope = safe_float(features.get("slope_ratio_per_1000h"))
            largest_drop = safe_float(features.get("largest_drop_step"))
            largest_rise = safe_float(features.get("largest_rise_step"))
            recovery = safe_float(features.get("max_recovery_after_min")) or 0
            cp_score = safe_float(features.get("change_point_score")) or 0
            after_slope = safe_float(features.get("change_point_after_slope_per_1000h"))
            zeros = safe_float(features.get("zero_power_count_ai")) or 0
            extreme_high = safe_float(features.get("extreme_high_ratio_count")) or 0
            artifact_excluded = safe_float(features.get("power_artifact_excluded_count")) or 0
            below80 = safe_float(features.get("points_below_80pct")) or 0
            below50 = safe_float(features.get("points_below_50pct")) or 0
            first_below80 = safe_float(features.get("first_below_80_time_h"))
            first_below50 = safe_float(features.get("first_below_50_time_h"))
            first_below10 = safe_float(features.get("first_below_10_time_h"))
            early_failure = int(safe_float(features.get("early_failure_flag")) or 0) == 1
            early_failure_subtype = str(features.get("early_failure_subtype") or "")
            burn_in_like = int(safe_float(features.get("burn_in_like_flag")) or 0) == 1
            recovery_or_increase = int(safe_float(features.get("recovery_or_power_increase_flag")) or 0) == 1
            recovery_kind = str(features.get("recovery_pattern_kind") or "")
        
            if extreme_high > 0:
                reasons.append("extreme_high_power_outlier_excluded")
            if artifact_excluded > 0:
                reasons.append("transient_zero_or_near_zero_artifacts_adjusted_before_labeling")
        
            if n < MIN_POINTS_FOR_PATTERN:
                reasons.append(f"fewer_than_{MIN_POINTS_FOR_PATTERN}_measurements")
                return "insufficient_curve_length", 0.2, reasons

            if early_failure:
                reasons.extend(
                    [
                        f"bounded_early_failure:{early_failure_subtype}",
                        "early_loss_not_relabelled_as_burn_in_like",
                    ]
                )
                early_loss_timing_certainty = str(features.get("early_loss_timing_certainty") or "")
                if early_loss_timing_certainty == "confirmed_rapid":
                    return "rapid_or_catastrophic_failure_candidate", 0.82, reasons
                reasons.append("rapidity_not_confirmed_from_sparse_or_bounded_observations")
                return "substantial_early_loss_candidate", 0.68, reasons

            if burn_in_like:
                reasons.extend(
                    [
                        "early_drop_followed_by_stabilization_within_240h_cap",
                        "burn_in_like_is_observable_pattern_not_physical_diagnosis",
                    ]
                )
                return "burn_in_like_early_stabilization_candidate", 0.72, reasons

            if recovery_or_increase:
                reasons.extend(
                    [
                        f"recovery_or_power_increase:{recovery_kind}",
                        "increase_may_reflect_recovery_or_measurement_protocol",
                    ]
                )
                return "recovery_or_power_increase_candidate", 0.68, reasons
        
            nonmonotone_review = recovery >= 0.12 or (largest_rise is not None and largest_rise >= 0.1)
            if nonmonotone_review:
                reasons.append("nonmonotone_recovery_or_positive_jump_detected_after_artifact_filter")
                if below80 > 0:
                    reasons.append("crosses_80pct_but_recovers")
        
            if zeros > 0 or (min_ratio is not None and min_ratio <= CATASTROPHIC_THRESHOLD):
                reasons.append("zero_or_below_10pct_power")
                if recovery >= NONMONOTONE_RECOVERY_MIN:
                    reasons.append("nonisolated_recovery_after_near_zero")
                first_catastrophic = first_below10 if first_below10 is not None else first_below50
                if first_catastrophic is not None and first_catastrophic > EARLY_WINDOW_HOURS:
                    reasons.append("late_catastrophic_drop_after_initial_survival")
                    return "change_point_or_midlife_drop_candidate", 0.68, reasons
                return "rapid_or_catastrophic_failure_candidate", 0.75 if not nonmonotone_review else 0.62, reasons
        
            if early_min is not None and early_min <= MAIN_FAILURE_THRESHOLD:
                reasons.append("drops_below_80pct_within_100h")
                if largest_drop is not None and largest_drop <= EARLY_LARGE_DROP_MAX:
                    reasons.append("abrupt_early_drop")
                    return "rapid_or_catastrophic_failure_candidate", 0.75 if not nonmonotone_review else 0.62, reasons
                return "progressive_or_right_censored_candidate", 0.58 if nonmonotone_review else 0.65, reasons
        
            if min_ratio is not None and min_ratio <= SEVERE_FAILURE_THRESHOLD:
                reasons.append("falls_below_50pct")
                if largest_drop is not None and largest_drop <= SEVERE_LARGE_DROP_MAX:
                    reasons.append("abrupt_large_drop")
                    if first_below50 is not None and first_below50 > EARLY_WINDOW_HOURS:
                        reasons.append("midlife_drop_after_initial_survival")
                        return "change_point_or_midlife_drop_candidate", 0.72 if not nonmonotone_review else 0.62, reasons
                    return "rapid_or_catastrophic_failure_candidate", 0.70 if not nonmonotone_review else 0.58, reasons
                return "progressive_or_right_censored_candidate", 0.62 if nonmonotone_review else 0.7, reasons
        
            if below80 > 0:
                reasons.append("falls_below_80pct")
                if cp_score >= CHANGE_POINT_SCORE_MIN and after_slope is not None and after_slope < LATE_SLOPE_MAX and (first_below80 is None or first_below80 > EARLY_WINDOW_HOURS):
                    reasons.append("change_point_with_faster_late_degradation")
                    return "change_point_or_midlife_drop_candidate", 0.68 if not nonmonotone_review else 0.58, reasons
                return "progressive_or_right_censored_candidate", 0.55 if nonmonotone_review else 0.65, reasons
        
            if slope is not None and slope < NEGATIVE_SLOPE_MAX and duration >= EARLY_WINDOW_HOURS:
                reasons.append("negative_robust_slope_without_threshold_crossing")
                return "progressive_or_right_censored_candidate", 0.50 if nonmonotone_review else 0.58, reasons
        
            if min_ratio is not None and min_ratio > MAIN_FAILURE_THRESHOLD:
                reasons.append("stays_above_80pct")
                return "progressive_or_right_censored_candidate", 0.52 if nonmonotone_review else 0.62, reasons
        
            reasons.append("ambiguous_curve")
            return "ambiguous_needs_review", 0.35, reasons
        
        
        def should_review(device: pd.Series, features: dict[str, Any], reasons: list[str]) -> bool:
            if features.get("ai_suggested_failure_mode", "").startswith("insufficient"):
                return True
            if features.get("ai_suggested_failure_mode", "").startswith(("burn_in_like", "recovery_or_power_increase")):
                return True
            if int(safe_float(features.get("early_failure_flag")) or 0) == 1:
                return True
            if safe_float(features.get("measurement_count_ai")) is not None and safe_float(features.get("measurement_count_ai")) < MIN_POINTS_WITHOUT_REVIEW:
                return True
            if safe_float(features.get("time_review_fraction")) is not None and safe_float(features.get("time_review_fraction")) >= 0.4:
                return True
            if device.get("aging_temperature_status", "") == "ambiguous":
                return True
            if safe_float(features.get("power_artifact_excluded_count")) and safe_float(features.get("power_artifact_excluded_count")) > 0:
                return True
            if safe_float(features.get("zero_power_count_ai")) and safe_float(features.get("zero_power_count_ai")) > 0:
                return True
            if safe_float(features.get("extreme_high_ratio_count")) and safe_float(features.get("extreme_high_ratio_count")) > 0:
                return True
            if safe_float(features.get("power_correction_review_count")) and safe_float(features.get("power_correction_review_count")) > 0:
                return True
            if any("recovery" in reason or "recovers" in reason or "positive_jump" in reason for reason in reasons):
                return True
            return False
        
        
        def assign_clusters(features_df: pd.DataFrame) -> pd.DataFrame:
            df = features_df.copy()
            feature_cols = [
                "measurement_count_ai",
                "duration_h",
                "p0_ai_mW",
                "last_ratio",
                "min_ratio",
                "max_ratio",
                "early_min_ratio_100h",
                "slope_ratio_per_1000h",
                "largest_drop_step",
                "largest_rise_step",
                "max_recovery_after_min",
                "burn_in_like_flag",
                "burn_in_early_drop_ratio",
                "post_stabilization_slope_ratio_per_1000h",
                "post_stabilization_p10_p90_range",
                "recovery_or_power_increase_flag",
                "final_gain_from_min_ratio",
                "net_power_change_ratio",
                "zero_power_count_ai",
                "extreme_high_ratio_count",
                "power_corrected_count",
                "power_correction_review_count",
                "power_artifact_excluded_count",
                "power_artifact_review_count",
                "points_below_80pct",
                "points_below_50pct",
                "monotone_decrease_fraction",
                "step_variability_mad",
                "change_point_score",
            ]
            x = df[feature_cols].apply(pd.to_numeric, errors="coerce")
            usable = x.notna().sum(axis=1) >= 5
            cluster_labels = pd.Series(["cluster_unassigned"] * len(df), index=df.index, dtype=object)
            if usable.sum() < 10:
                df["curve_cluster"] = cluster_labels
                df["curve_cluster_profile"] = "too_few_usable_curves"
                return df
        
            n_clusters = min(6, max(3, int(round(math.sqrt(float(usable.sum()) / 2.0)))))
            model = Pipeline(
                [
                    ("impute", SimpleImputer(strategy="median")),
                    ("scale", StandardScaler()),
                    ("kmeans", KMeans(n_clusters=n_clusters, random_state=RANDOM_STATE, n_init=25)),
                ]
            )
            labels = model.fit_predict(x.loc[usable])
            cluster_labels.loc[usable] = [f"C{label + 1}" for label in labels]
            df["curve_cluster"] = cluster_labels
        
            profiles = {}
            for cluster, group in df[df["curve_cluster"] != "cluster_unassigned"].groupby("curve_cluster"):
                dominant_mode = group["ai_suggested_failure_mode"].mode().iloc[0]
                median_min = pd.to_numeric(group["min_ratio"], errors="coerce").median()
                median_recovery = pd.to_numeric(group["max_recovery_after_min"], errors="coerce").median()
                zero_share = (pd.to_numeric(group["zero_power_count_ai"], errors="coerce").fillna(0) > 0).mean()
                if zero_share >= 0.35:
                    profile = "rapid_or_catastrophic_dominated"
                elif "burn_in_like" in dominant_mode:
                    profile = "burn_in_like_early_stabilization_curves"
                elif "recovery_or_power_increase" in dominant_mode:
                    profile = "recovery_or_power_increase_curves"
                elif median_recovery >= 0.12:
                    profile = "nonmonotone_or_noisy_curves"
                elif median_min <= 0.5:
                    profile = "progressive_or_right_censored_curves"
                elif "progressive" in dominant_mode:
                    profile = "progressive_or_right_censored_curves"
                else:
                    profile = dominant_mode
                profiles[cluster] = profile
            df["curve_cluster_profile"] = df["curve_cluster"].map(profiles).fillna("cluster_unassigned")
            return df
        
        
        def add_review_priority(df: pd.DataFrame) -> pd.DataFrame:
            result = df.copy()
            mode = result["ai_suggested_failure_mode"].fillna("")
            score = pd.Series(0.0, index=result.index)
            reasons = result["review_reasons"].fillna("") if "review_reasons" in result.columns else pd.Series("", index=result.index)
            score += pd.to_numeric(result["needs_human_review"], errors="coerce").fillna(0) * 3.0
            score += mode.str.contains("rapid|catastrophic|change_point|midlife", regex=True).astype(float) * 2.0
            score += mode.str.contains("burn_in_like|recovery_or_power_increase", regex=True).astype(float) * 2.0
            score += reasons.str.contains("recovery|positive_jump|early_drop_followed_by_long_nonzero_stabilization", regex=True).astype(float) * 1.5
            score += mode.str.contains("insufficient", regex=True).astype(float) * 1.5
            score += (pd.to_numeric(result["zero_power_count_ai"], errors="coerce").fillna(0) > 0).astype(float) * 2.0
            score += (pd.to_numeric(result["extreme_high_ratio_count"], errors="coerce").fillna(0) > 0).astype(float) * 2.0
            score += (pd.to_numeric(result["power_correction_review_count"], errors="coerce").fillna(0) > 0).astype(float) * 1.5
            score += (pd.to_numeric(result["power_artifact_review_count"], errors="coerce").fillna(0) > 0).astype(float) * 1.5
            score += (pd.to_numeric(result["time_review_fraction"], errors="coerce").fillna(0) >= 0.4).astype(float) * 1.0
            score += (pd.to_numeric(result["measurement_count_ai"], errors="coerce").fillna(0) < MIN_POINTS_WITHOUT_REVIEW).astype(float) * 1.0
            score += (pd.to_numeric(result["ai_confidence"], errors="coerce").fillna(1) < 0.55).astype(float) * 1.0
            result["human_review_priority_score"] = score.round(3)
            return result
        
        
        def build_summaries(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
            mode_summary = (
                df.groupby(["ai_suggested_failure_mode"], dropna=False)
                .agg(
                    n_devices=("device_uid", "count"),
                    human_review=("needs_human_review", "sum"),
                    median_min_ratio=("min_ratio", lambda x: pd.to_numeric(x, errors="coerce").median()),
                    median_last_ratio=("last_ratio", lambda x: pd.to_numeric(x, errors="coerce").median()),
                    median_duration_h=("duration_h", lambda x: pd.to_numeric(x, errors="coerce").median()),
                )
                .reset_index()
                .sort_values(["n_devices", "ai_suggested_failure_mode"], ascending=[False, True])
            )
            cluster_summary = (
                df.groupby(["curve_cluster", "curve_cluster_profile"], dropna=False)
                .agg(
                    n_devices=("device_uid", "count"),
                    dominant_mode=("ai_suggested_failure_mode", lambda x: Counter(x).most_common(1)[0][0]),
                    human_review=("needs_human_review", "sum"),
                    median_min_ratio=("min_ratio", lambda x: pd.to_numeric(x, errors="coerce").median()),
                    median_recovery=("max_recovery_after_min", lambda x: pd.to_numeric(x, errors="coerce").median()),
                    zero_power_devices=("zero_power_count_ai", lambda x: int((pd.to_numeric(x, errors="coerce").fillna(0) > 0).sum())),
                )
                .reset_index()
                .sort_values(["curve_cluster"])
            )
            temp_summary = (
                df.groupby(["aging_temperature_C", "ai_suggested_failure_mode"], dropna=False)
                .agg(n_devices=("device_uid", "count"), human_review=("needs_human_review", "sum"))
                .reset_index()
                .sort_values(["aging_temperature_C", "n_devices"], ascending=[True, False])
            )
            return mode_summary, cluster_summary, temp_summary
        
        
        FIGURE_PATTERN_LABELS = {
            "progressive_or_right_censored_candidate": "Progressive/censored",
            "rapid_or_catastrophic_failure_candidate": "Rapid/catastrophic",
            "substantial_early_loss_candidate": "Substantial early loss",
            "change_point_or_midlife_drop_candidate": "Change-point/midlife",
            "burn_in_like_early_stabilization_candidate": "Burn-in-like/early stabilization",
            "recovery_or_power_increase_candidate": "Recovery/power increase",
            "other_observable_pattern": "Other/ambiguous",
        }
        FIGURE_FEATURES = {
            "min_ratio": "Minimum P/P0",
            "slope_ratio_per_1000h": "Slope per 1000 h",
            "largest_drop_step": "Step drop",
            "max_recovery_after_min": "Recovery",
            "change_point_score": "Change point",
        }
        
        
        def build_rule_pattern_plot_tables(features: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
            """Export the exact standardized profiles and intervals used by Fig. 12."""
            numeric = features[list(FIGURE_FEATURES)].apply(pd.to_numeric, errors="coerce")
            median = numeric.median()
            scale = numeric.quantile(0.75) - numeric.quantile(0.25)
            scale = scale.where(scale.abs() > 1e-12, numeric.std()).replace(0, 1).fillna(1)
            standardized = (numeric - median) / scale
            standardized["pattern"] = features["ai_suggested_failure_mode"].astype(str)
            order = [name for name in FIGURE_PATTERN_LABELS if name in set(standardized["pattern"])]
            matrix = standardized.groupby("pattern")[list(FIGURE_FEATURES)].median().reindex(order).clip(-2, 2)
            counts = features["ai_suggested_failure_mode"].astype(str).value_counts()
            profile_rows = []
            for pattern in order:
                for feature, display_label in FIGURE_FEATURES.items():
                    profile_rows.append(
                        {
                            "pattern": pattern,
                            "pattern_label": FIGURE_PATTERN_LABELS[pattern],
                            "n": int(counts[pattern]),
                            "feature": feature,
                            "feature_label": display_label,
                            "standardized_median": float(matrix.loc[pattern, feature]),
                        }
                    )
            interval_rows = []
            z = 1.959963984540054
            for pattern in order:
                group = features[features["ai_suggested_failure_mode"].astype(str).eq(pattern)]
                confidence = pd.to_numeric(group["ai_confidence"], errors="coerce").dropna()
                review = pd.to_numeric(group["needs_human_review"], errors="coerce").fillna(0).astype(int)
                n = len(review)
                events = int(review.sum())
                fraction = events / n
                denominator = 1 + z * z / n
                center = (fraction + z * z / (2 * n)) / denominator
                half = z * np.sqrt(fraction * (1 - fraction) / n + z * z / (4 * n * n)) / denominator
                interval_rows.append(
                    {
                        "pattern": pattern,
                        "pattern_label": FIGURE_PATTERN_LABELS[pattern],
                        "confidence": float(confidence.median()),
                        "confidence_low": float(confidence.quantile(0.25)),
                        "confidence_high": float(confidence.quantile(0.75)),
                        "review": float(review.mean()),
                        "review_low": float(center - half),
                        "review_high": float(center + half),
                        "n": n,
                    }
                )
            return pd.DataFrame(profile_rows), pd.DataFrame(interval_rows)
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Rule based weak labeling and clustering of VCSEL aging curves.")
            parser.add_argument("--input-dir", type=Path, default=Path("outputs") / "processed")
            parser.add_argument("--output-dir", type=Path, default=Path("outputs") / "processed")
            args = parser.parse_args()
        
            devices = pd.read_csv(args.input_dir / "device_table.csv", encoding="utf-8-sig", dtype=str).fillna("")
            measurements = pd.read_csv(args.input_dir / "measurement_table.csv", encoding="utf-8-sig", dtype=str).fillna("")
            by_device = {key: group.copy() for key, group in measurements.groupby("device_uid", sort=False)}
        
            feature_rows = []
            for _, device in devices.iterrows():
                feature_rows.append(curve_features(device, by_device.get(device["device_uid"], pd.DataFrame(columns=measurements.columns))))
        
            features_df = pd.DataFrame(feature_rows)
            features_df = assign_clusters(features_df)
            features_df = add_review_priority(features_df)
            mode_summary, cluster_summary, temp_summary = build_summaries(features_df)
            feature_profile, confidence_review = build_rule_pattern_plot_tables(features_df)
            review_queue = (
                features_df[features_df["needs_human_review"].astype(int) == 1]
                .sort_values(["human_review_priority_score", "ai_confidence", "device_uid"], ascending=[False, True, True])
                .loc[
                    :,
                    [
                        "human_review_priority_score",
                        "device_uid",
                        "file_id",
                        "sheet",
                        "source_column",
                        "device_id_raw",
                        "position",
                        "aging_temperature_C",
                        "aging_current_raw",
                        "p0_ai_mW",
                        "measurement_count_ai",
                        "duration_h",
                        "min_ratio",
                        "last_ratio",
                        "zero_power_count_ai",
                        "extreme_high_ratio_count",
                        "power_corrected_count",
                        "power_correction_review_count",
                        "power_artifact_excluded_count",
                        "power_artifact_review_count",
                        "max_recovery_after_min",
                        "burn_in_like_flag",
                        "burn_in_early_drop_ratio",
                        "burn_in_stabilization_time_h",
                        "post_stabilization_point_count",
                        "post_stabilization_duration_h",
                        "post_stabilization_median_ratio",
                        "post_stabilization_slope_ratio_per_1000h",
                        "post_stabilization_p10_p90_range",
                        "recovery_or_power_increase_flag",
                        "recovery_pattern_kind",
                        "minimum_ratio_time_h",
                        "post_minimum_point_count",
                        "final_gain_from_min_ratio",
                        "net_power_change_ratio",
                        "first_below_80_time_h",
                        "first_below_50_time_h",
                        "first_below_10_time_h",
                        "ai_suggested_failure_mode",
                        "ai_assessability",
                        "ai_confidence",
                        "curve_cluster",
                        "curve_cluster_profile",
                        "review_reasons",
                    ],
                ]
            )
        
            args.output_dir.mkdir(parents=True, exist_ok=True)
            features_df.to_csv(args.output_dir / "ai_device_classification.csv", index=False, encoding="utf-8-sig")
            mode_summary.to_csv(args.output_dir / "ai_failure_mode_summary.csv", index=False, encoding="utf-8-sig")
            cluster_summary.to_csv(args.output_dir / "ai_curve_cluster_summary.csv", index=False, encoding="utf-8-sig")
            temp_summary.to_csv(args.output_dir / "ai_temperature_mode_summary.csv", index=False, encoding="utf-8-sig")
            review_queue.to_csv(args.output_dir / "ai_human_review_queue.csv", index=False, encoding="utf-8-sig")
            feature_profile.to_csv(
                args.output_dir / "rule_pattern_feature_profile.csv", index=False, encoding="utf-8-sig"
            )
            confidence_review.to_csv(
                args.output_dir / "rule_pattern_confidence_review.csv", index=False, encoding="utf-8-sig"
            )
        
            print(f"devices={len(features_df)}")
            print(f"modes={features_df['ai_suggested_failure_mode'].nunique()}")
            print(f"clusters={features_df['curve_cluster'].nunique()}")
            print(f"human_review={int(pd.to_numeric(features_df['needs_human_review'], errors='coerce').fillna(0).sum())}")
            print(f"output_dir={args.output_dir.resolve()}")
        main()


def run_reliability(stage_args: list[str]) -> None:
    """Run the embedded reliability_analysis.py stage with an isolated command line."""
    with isolated_argv("reliability", stage_args):
        """Compute reliability results and export plot-ready datasets; this file never draws figures."""
        
        import argparse
        import json
        import itertools
        import math
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        from scipy.optimize import minimize
        from scipy.stats import chi2
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def load_registry() -> dict[str, Any]:
            """Load and validate the frozen registry without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            if registry.get("status") != "frozen-retrospective" or registry.get("version") != "2.2.3":
                raise ValueError("Unexpected QAES-VCSEL rule registry.")
            return registry
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            return dict(load_registry()["rules"][rule_id].get("parameters", {}))
        
        REGISTRY = load_registry()
        P0 = parameters("P0-1")
        EVT = parameters("EVT-1")
        MAIN_P0 = str(P0["main_definition"])
        MAIN_THRESHOLD = str(EVT["main_threshold_ratio"])
        FAILURE_STATUSES = {str(EVT["states"]["E"]), str(EVT["states"]["EF"]), str(EVT["states"]["R"])}
        ASSESSABLE_STATUSES = FAILURE_STATUSES | {str(EVT["states"]["C"])}
        
        
        def safe_num(series: pd.Series) -> pd.Series:
            return pd.to_numeric(series, errors="coerce")
        
        
        def norm_temp(value: Any) -> str:
            if value is None or str(value).strip() == "":
                return "unknown"
            try:
                number = float(value)
                if math.isnan(number):
                    return "unknown"
                if abs(number - round(number)) < 1e-6:
                    return str(int(round(number)))
                return f"{number:g}"
            except (TypeError, ValueError):
                return str(value)
        
        
        def build_reliability_dataset(events: pd.DataFrame, ai: pd.DataFrame) -> pd.DataFrame:
            rows = events.copy()
            rows = rows.merge(
                ai[
                    [
                        "device_uid",
                        "ai_suggested_failure_mode",
                        "curve_cluster",
                        "curve_cluster_profile",
                        "needs_human_review",
                        "human_review_priority_score",
                    ]
                ],
                on="device_uid",
                how="left",
            )
            rows["temperature_group"] = rows["aging_temperature_C"].map(norm_temp)
            rows["event_observed"] = rows["event_status"].isin(FAILURE_STATUSES).astype(int)
            event_t = safe_num(rows["event_exposure_hours"])
            censor_t = safe_num(rows["censor_exposure_hours"])
            rows["analysis_time_h"] = event_t.where(rows["event_observed"] == 1, censor_t)
            rows["analysis_time_h"] = rows["analysis_time_h"].where(rows["analysis_time_h"] > 0, np.nan)
            rows["assessable"] = rows["event_status"].isin(ASSESSABLE_STATUSES) & rows["analysis_time_h"].notna()
            rows["include_main_reliability"] = (
                rows["assessable"]
                & (rows["p0_definition"] == MAIN_P0)
                & (rows["failure_threshold_ratio"].astype(str) == MAIN_THRESHOLD)
            )
            rows["include_temperature_stratified"] = rows["include_main_reliability"] & (rows["temperature_group"] != "unknown")
            rows["needs_human_review"] = safe_num(rows["needs_human_review"]).fillna(0).astype(int)
            return rows
        
        
        def km_estimate(df: pd.DataFrame) -> pd.DataFrame:
            work = df[["analysis_time_h", "event_observed"]].dropna().copy()
            if work.empty:
                return pd.DataFrame(columns=["time_h", "survival", "lower_95", "upper_95", "n_at_risk", "events", "censored"])
            work["analysis_time_h"] = safe_num(work["analysis_time_h"])
            work = work[work["analysis_time_h"] > 0].sort_values("analysis_time_h")
            survival = 1.0
            greenwood_sum = 0.0
            out = [{"time_h": 0.0, "survival": 1.0, "lower_95": 1.0, "upper_95": 1.0, "n_at_risk": int(len(work)), "events": 0, "censored": 0}]
            for t in sorted(work.loc[work["event_observed"] == 1, "analysis_time_h"].unique()):
                at_time = work[work["analysis_time_h"] == t]
                d = int((at_time["event_observed"] == 1).sum())
                c = int((at_time["event_observed"] == 0).sum())
                n = int((work["analysis_time_h"] >= t).sum())
                if n <= 0:
                    continue
                survival *= max(0.0, 1.0 - d / n)
                if n > d:
                    greenwood_sum += d / (n * (n - d))
                if survival <= 0.0:
                    lower, upper = 0.0, 0.0
                elif survival >= 1.0 or greenwood_sum == 0.0:
                    lower, upper = survival, survival
                else:
                    se_loglog = math.sqrt(greenwood_sum) / abs(math.log(survival))
                    z = 1.959963984540054
                    lower = survival ** math.exp(z * se_loglog)
                    upper = survival ** math.exp(-z * se_loglog)
                out.append({"time_h": float(t), "survival": survival, "lower_95": lower, "upper_95": upper, "n_at_risk": n, "events": d, "censored": c})
            last_time = float(work["analysis_time_h"].max())
            if out[-1]["time_h"] < last_time:
                out.append(
                    {
                        "time_h": last_time,
                        "survival": survival,
                        "lower_95": out[-1]["lower_95"],
                        "upper_95": out[-1]["upper_95"],
                        "n_at_risk": int((work["analysis_time_h"] >= last_time).sum()),
                        "events": 0,
                        "censored": int(((work["analysis_time_h"] == last_time) & (work["event_observed"] == 0)).sum()),
                    }
                )
            return pd.DataFrame(out)
        
        
        def pairwise_logrank(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
            rows = []
            groups = [g for g in sorted(df[group_col].dropna().unique()) if g != "unknown"]
            for g1, g2 in itertools.combinations(groups, 2):
                sub = df[df[group_col].isin([g1, g2])].dropna(subset=["analysis_time_h"])
                if sub.empty or sub["event_observed"].sum() == 0:
                    continue
                times = sorted(sub.loc[sub["event_observed"] == 1, "analysis_time_h"].unique())
                observed = 0.0
                expected = 0.0
                variance = 0.0
                for t in times:
                    at_risk = sub[sub["analysis_time_h"] >= t]
                    at_time = sub[sub["analysis_time_h"] == t]
                    n = len(at_risk)
                    d = int((at_time["event_observed"] == 1).sum())
                    if n <= 1 or d <= 0:
                        continue
                    n1 = int((at_risk[group_col] == g1).sum())
                    d1 = int(((at_time[group_col] == g1) & (at_time["event_observed"] == 1)).sum())
                    observed += d1
                    expected += n1 * d / n
                    variance += (n1 / n) * (1 - n1 / n) * d * (n - d) / max(1, n - 1)
                if variance <= 0:
                    stat = np.nan
                    p_value = np.nan
                else:
                    stat = (observed - expected) ** 2 / variance
                    p_value = 1 - chi2.cdf(stat, df=1)
                rows.append(
                    {
                        "group_col": group_col,
                        "group_1": g1,
                        "group_2": g2,
                        "n_1": int((sub[group_col] == g1).sum()),
                        "n_2": int((sub[group_col] == g2).sum()),
                        "events_1": int(((sub[group_col] == g1) & (sub["event_observed"] == 1)).sum()),
                        "events_2": int(((sub[group_col] == g2) & (sub["event_observed"] == 1)).sum()),
                        "observed_minus_expected_group_1": observed - expected,
                        "chi_square": stat,
                        "p_value": p_value,
                    }
                )
            return pd.DataFrame(rows)
        
        
        def fit_weibull(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
            rows = []
            for group, sub in df.groupby(group_col):
                sub = sub.dropna(subset=["analysis_time_h"]).copy()
                if group == "unknown" or len(sub) < 5 or sub["event_observed"].sum() < 2:
                    continue
                t = safe_num(sub["analysis_time_h"]).to_numpy(dtype=float)
                e = safe_num(sub["event_observed"]).fillna(0).to_numpy(dtype=float)
                t = np.maximum(t, 1e-3)
        
                def nll(params: np.ndarray) -> float:
                    log_beta, log_eta = params
                    beta = math.exp(log_beta)
                    eta = math.exp(log_eta)
                    z = (t / eta) ** beta
                    log_surv = -z
                    log_pdf = math.log(beta) - math.log(eta) + (beta - 1.0) * (np.log(t) - math.log(eta)) - z
                    ll = e * log_pdf + (1 - e) * log_surv
                    if not np.all(np.isfinite(ll)):
                        return 1e50
                    return float(-np.sum(ll))
        
                init_eta = max(float(np.median(t)), 1.0)
                result = minimize(nll, x0=np.array([math.log(1.2), math.log(init_eta)]), method="Nelder-Mead")
                if not result.success:
                    result = minimize(nll, x0=np.array([math.log(1.0), math.log(init_eta)]), method="BFGS")
                if not result.success or not np.isfinite(result.fun) or not np.isfinite(result.x).all():
                    raise RuntimeError(
                        f"Weibull fit did not converge for {group_col}={group}: {result.message}"
                    )
                beta = math.exp(float(result.x[0]))
                eta = math.exp(float(result.x[1]))
                rows.append(
                    {
                        "group_col": group_col,
                        "group": group,
                        "n": int(len(sub)),
                        "events": int(e.sum()),
                        "censored": int(len(sub) - e.sum()),
                        "weibull_shape_beta": beta,
                        "weibull_scale_eta_h": eta,
                        "weibull_median_life_h": eta * (math.log(2.0) ** (1.0 / beta)),
                        "weibull_b10_life_h": eta * ((-math.log(0.9)) ** (1.0 / beta)),
                        "neg_log_likelihood": float(result.fun),
                        "fit_success": bool(result.success),
                    }
                )
            return pd.DataFrame(rows)
        
        
        def summarize_survival(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
            rows = []
            for group, sub in df.groupby(group_col):
                sub = sub.dropna(subset=["analysis_time_h"])
                if group == "unknown" or sub.empty:
                    continue
                km = km_estimate(sub)
                median = ""
                median_ci_lower = ""
                median_ci_upper = ""
                if not km.empty and (km["survival"] <= 0.5).any():
                    median = float(km.loc[km["survival"] <= 0.5, "time_h"].iloc[0])
                if not km.empty and (km["lower_95"] <= 0.5).any():
                    median_ci_lower = float(km.loc[km["lower_95"] <= 0.5, "time_h"].iloc[0])
                if not km.empty and (km["upper_95"] <= 0.5).any():
                    median_ci_upper = float(km.loc[km["upper_95"] <= 0.5, "time_h"].iloc[0])
                rows.append(
                    {
                        "group_col": group_col,
                        "group": group,
                        "n": int(len(sub)),
                        "events": int(sub["event_observed"].sum()),
                        "censored": int(len(sub) - sub["event_observed"].sum()),
                        "event_fraction": float(sub["event_observed"].mean()),
                        "max_followup_h": float(sub["analysis_time_h"].max()),
                        "km_survival_at_end": float(km["survival"].iloc[-1]) if not km.empty else "",
                        "km_median_life_h": median,
                        "km_median_ci_lower_h": median_ci_lower,
                        "km_median_ci_upper_h": median_ci_upper,
                    }
                )
            return pd.DataFrame(rows)
        
        
        def build_sensitivity_summary(rel: pd.DataFrame) -> pd.DataFrame:
            assess = rel[rel["assessable"] & (rel["temperature_group"] != "unknown")].copy()
            assess["failure_threshold_ratio"] = assess["failure_threshold_ratio"].astype(str)
            summary = (
                assess.groupby(["p0_definition", "failure_threshold_ratio", "temperature_group"])
                .agg(
                    n=("device_uid", "count"),
                    events=("event_observed", "sum"),
                    human_review=("needs_human_review", "sum"),
                    median_time_h=("analysis_time_h", "median"),
                )
                .reset_index()
            )
            summary["event_fraction"] = summary["events"] / summary["n"]
            return summary
        
        
        def build_km_plot_contract(
            records: pd.DataFrame, curves: pd.DataFrame
        ) -> tuple[pd.DataFrame, pd.DataFrame]:
            """Export fixed risk-table cells and censor coordinates used by Fig. 15."""
            risk_times = np.array([0, 500, 1000, 2000, 4000, 6000, 8000], dtype=float)
            risk_rows: list[dict[str, Any]] = []
            censor_rows: list[dict[str, Any]] = []
            for temperature, group in records.groupby("temperature_group"):
                if str(temperature) == "unknown":
                    continue
                analysis_time = pd.to_numeric(group["analysis_time_h"], errors="coerce")
                for time_h in risk_times:
                    risk_rows.append(
                        {
                            "temperature_group": temperature,
                            "time_h": time_h,
                            "n_at_risk": int((analysis_time >= time_h).sum()),
                        }
                    )
                km = curves[
                    curves["temperature_group"].astype(str).eq(str(temperature))
                ].sort_values("time_h")
                step_time = pd.to_numeric(km["time_h"], errors="raise").to_numpy(float)
                step_survival = pd.to_numeric(km["survival"], errors="raise").to_numpy(float)
                censored = group[pd.to_numeric(group["event_observed"], errors="coerce").eq(0)]
                for time_h in pd.to_numeric(censored["analysis_time_h"], errors="coerce").dropna():
                    index = int(np.searchsorted(step_time, float(time_h), side="right") - 1)
                    censor_rows.append(
                        {
                            "temperature_group": temperature,
                            "time_h": float(time_h),
                            "survival": float(step_survival[max(0, index)]),
                        }
                    )
            return pd.DataFrame(risk_rows), pd.DataFrame(censor_rows)


        def competing_crossing_curve(df: pd.DataFrame) -> pd.DataFrame:
            """Estimate cumulative incidence for recovered and unrecovered threshold crossings."""
            work = df.copy()
            work["analysis_time_h"] = pd.to_numeric(work["analysis_time_h"], errors="coerce")
            work = work.dropna(subset=["analysis_time_h"])
            work["cause"] = work["event_status"].astype(str).map(
                {
                    "failure_observed": "unrecovered",
                    "early_failure_observed": "unrecovered",
                    "failure_observed_with_recovery": "recovered",
                    "right_censored": "censored",
                }
            ).fillna("censored")
            survival = 1.0
            cif_unrecovered = 0.0
            cif_recovered = 0.0
            rows = [
                {
                    "time_h": 0.0,
                    "at_risk": int(len(work)),
                    "unrecovered_events": 0,
                    "recovered_events": 0,
                    "censored": 0,
                    "event_free_survival": survival,
                    "cif_unrecovered": cif_unrecovered,
                    "cif_recovered": cif_recovered,
                }
            ]
            for time_h in sorted(work["analysis_time_h"].unique()):
                at_risk = int((work["analysis_time_h"] >= time_h).sum())
                at_time = work[work["analysis_time_h"].eq(time_h)]
                d_unrecovered = int(at_time["cause"].eq("unrecovered").sum())
                d_recovered = int(at_time["cause"].eq("recovered").sum())
                censored = int(at_time["cause"].eq("censored").sum())
                if at_risk:
                    cif_unrecovered += survival * d_unrecovered / at_risk
                    cif_recovered += survival * d_recovered / at_risk
                    survival *= 1.0 - (d_unrecovered + d_recovered) / at_risk
                rows.append(
                    {
                        "time_h": float(time_h),
                        "at_risk": at_risk,
                        "unrecovered_events": d_unrecovered,
                        "recovered_events": d_recovered,
                        "censored": censored,
                        "event_free_survival": survival,
                        "cif_unrecovered": cif_unrecovered,
                        "cif_recovered": cif_recovered,
                    }
                )
            return pd.DataFrame(rows)


        def summarize_competing_crossings(curve: pd.DataFrame) -> pd.DataFrame:
            if curve.empty:
                return pd.DataFrame()
            maximum = float(curve["time_h"].max())
            rows = []
            for horizon in dict.fromkeys([1000.0, 3000.0, 6000.0, maximum]):
                row = curve[curve["time_h"] <= horizon].iloc[-1]
                rows.append(
                    {
                        "horizon_h": horizon,
                        "event_free_survival": float(row["event_free_survival"]),
                        "cif_unrecovered": float(row["cif_unrecovered"]),
                        "cif_recovered": float(row["cif_recovered"]),
                    }
                )
            return pd.DataFrame(rows)


        def summarize_recovery_clearance(df: pd.DataFrame) -> pd.DataFrame:
            recovered = df[df["event_status"].astype(str).eq("failure_observed_with_recovery")].copy()
            recrossed = pd.to_numeric(
                recovered.get("recrossed_after_first_clearance", 0), errors="coerce"
            ).fillna(0).astype(int)
            ended_above = pd.to_numeric(
                recovered.get("ended_above_threshold_plus_margin", 0), errors="coerce"
            ).fillna(0).astype(int)
            return pd.DataFrame(
                [
                    {
                        "retrospective_recovered_crossings": int(len(recovered)),
                        "recrossed_after_first_clearance": int(recrossed.sum()),
                        "ended_above_threshold_plus_margin": int(ended_above.sum()),
                        "definition": "recovery denotes at least one later observation above threshold plus 0.03",
                    }
                ]
            )
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Censored reliability analysis for extracted VCSEL aging data.")
            parser.add_argument("--input-dir", type=Path, default=Path("outputs") / "processed")
            parser.add_argument("--output-dir", type=Path, default=Path("outputs") / "analysis")
            args = parser.parse_args()
        
            events = pd.read_csv(args.input_dir / "event_table_exploratory.csv", encoding="utf-8-sig", dtype=str).fillna("")
            ai = pd.read_csv(args.input_dir / "ai_device_classification.csv", encoding="utf-8-sig", dtype=str).fillna("")
            rel = build_reliability_dataset(events, ai)
            main = rel[rel["include_main_reliability"]].copy()
            temperature_stratified = rel[rel["include_temperature_stratified"]].copy()
        
            args.output_dir.mkdir(parents=True, exist_ok=True)
            rel.to_csv(args.output_dir / "reliability_dataset_all_definitions.csv", index=False, encoding="utf-8-sig")
            main.to_csv(args.output_dir / "reliability_dataset_main.csv", index=False, encoding="utf-8-sig")
            temperature_stratified.to_csv(
                args.output_dir / "reliability_dataset_temperature_stratified.csv", index=False, encoding="utf-8-sig"
            )
        
            km_rows = []
            for group, sub in temperature_stratified.groupby("temperature_group"):
                if group == "unknown":
                    continue
                km = km_estimate(sub)
                km["temperature_group"] = group
                km_rows.append(km)
            km_all = pd.concat(km_rows, ignore_index=True) if km_rows else pd.DataFrame()
            km_all.to_csv(args.output_dir / "km_curves_by_temperature_main.csv", index=False, encoding="utf-8-sig")
            risk_table, censor_marks = build_km_plot_contract(temperature_stratified, km_all)
            risk_table.to_csv(args.output_dir / "km_plot_risk_table.csv", index=False, encoding="utf-8-sig")
            censor_marks.to_csv(args.output_dir / "km_plot_censor_marks.csv", index=False, encoding="utf-8-sig")
        
            survival_summary = summarize_survival(temperature_stratified, "temperature_group")
            survival_summary.to_csv(args.output_dir / "survival_summary_by_temperature_main.csv", index=False, encoding="utf-8-sig")

            competing_curve = competing_crossing_curve(main)
            competing_curve.to_csv(
                args.output_dir / "crossing_type_curve.csv", index=False, encoding="utf-8-sig"
            )
            competing_summary = summarize_competing_crossings(competing_curve)
            competing_summary.to_csv(
                args.output_dir / "crossing_type_summary.csv", index=False, encoding="utf-8-sig"
            )
            summarize_recovery_clearance(main).to_csv(
                args.output_dir / "recovery_clearance_summary.csv", index=False, encoding="utf-8-sig"
            )
        
            mode_summary = summarize_survival(main, "ai_suggested_failure_mode")
            mode_summary.to_csv(args.output_dir / "survival_summary_by_ai_mode_main.csv", index=False, encoding="utf-8-sig")
        
            logrank = pairwise_logrank(temperature_stratified, "temperature_group")
            logrank.to_csv(args.output_dir / "pairwise_logrank_by_temperature_main.csv", index=False, encoding="utf-8-sig")
        
            weibull_temp = fit_weibull(temperature_stratified, "temperature_group")
            weibull_temp.to_csv(args.output_dir / "weibull_fits_by_temperature_main.csv", index=False, encoding="utf-8-sig")
            weibull_mode = fit_weibull(main, "ai_suggested_failure_mode")
            weibull_mode.to_csv(args.output_dir / "weibull_fits_by_ai_mode_main.csv", index=False, encoding="utf-8-sig")
        
            sensitivity = build_sensitivity_summary(rel)
            sensitivity.to_csv(args.output_dir / "sensitivity_event_fraction_by_p0_threshold_temperature.csv", index=False, encoding="utf-8-sig")
        
            print(f"main_devices={len(main)}")
            print(f"main_events={int(main['event_observed'].sum()) if len(main) else 0}")
            print(f"temperature_stratified_devices={len(temperature_stratified)}")
            print(f"temperatures={','.join(sorted(temperature_stratified['temperature_group'].unique())) if len(temperature_stratified) else ''}")
            print(f"analysis_dir={args.output_dir.resolve()}")
        main()


def run_passport(stage_args: list[str]) -> None:
    """Run the embedded evidence_passport_analysis.py stage with an isolated command line."""
    with isolated_argv("passport", stage_args):
        import argparse
        import json
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def rule(rule_id: str) -> dict[str, Any]:
            """Read one frozen rule without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            return dict(registry["rules"][rule_id])
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            return dict(rule(rule_id).get("parameters", {}))
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            return pd.read_csv(path, encoding="utf-8-sig")
        
        
        def safe_num(series: pd.Series | None, default: float = 0.0) -> pd.Series:
            if series is None:
                return pd.Series(dtype=float)
            return pd.to_numeric(series, errors="coerce").fillna(default)
        
        
        def broad_label(label: object) -> str:
            text = str(label).lower()
            if "burn_in_like" in text or "early_stabilization" in text:
                return "burn_in_like_early_stabilization"
            if "recovery_or_power_increase" in text or "net_power_increase" in text:
                return "recovery_or_power_increase"
            if "change_point" in text or "midlife" in text:
                return "change_point_or_midlife"
            if "catastrophic" in text or "zero" in text or "rapid" in text or "early" in text:
                return "rapid_or_catastrophic"
            if "recovery" in text or "protocol" in text or "measurement_issue" in text or "artifact" in text:
                return "insufficient"
            if "insufficient" in text or "unassessable" in text:
                return "insufficient"
            if (
                "progressive" in text
                or "stable" in text
                or "right_censored" in text
                or "censored" in text
                or "degradation" in text
                or "mild" in text
                or "severe" in text
                or "gradual" in text
            ):
                return "progressive_or_censored"
            return "other"
        
        
        def event_sensitivity(all_defs: pd.DataFrame) -> pd.DataFrame:
            if all_defs.empty:
                return pd.DataFrame(columns=["device_uid"])
            work = all_defs.copy()
            evt = parameters("EVT-1")
            state_map = {
                str(evt["states"]["E"]): "E",
                str(evt["states"]["EF"]): "E",
                str(evt["states"]["R"]): "R",
                str(evt["states"]["C"]): "C",
            }
            for status in evt["states"]["NA"]:
                state_map[str(status)] = "NA"
            work["endpoint_state"] = work["event_status"].astype(str).map(state_map).fillna("NA")
            work["event_observed_num"] = pd.to_numeric(work.get("event_observed"), errors="coerce")
            rows = []
            for device_uid, group in work.groupby("device_uid", dropna=False):
                assessable = group[group["endpoint_state"].isin(["E", "R", "C"])]
                event_values = sorted(v for v in assessable["event_observed_num"].dropna().unique())
                endpoint_states = sorted(group["endpoint_state"].dropna().unique())
                observed_times = pd.to_numeric(group.get("event_exposure_hours"), errors="coerce").dropna()
                p0_defs = group.get("p0_definition", pd.Series(dtype=str)).dropna().astype(str).nunique()
                thresholds = group.get("failure_threshold_ratio", pd.Series(dtype=float)).dropna().nunique()
                rows.append(
                    {
                        "device_uid": device_uid,
                        "event_definition_count": int(len(group)),
                        "assessable_definition_count": int(len(assessable)),
                        "p0_definition_count": int(p0_defs),
                        "failure_threshold_count": int(thresholds),
                        "event_observed_values": "|".join(str(int(v)) for v in event_values if not pd.isna(v)),
                        "binary_event_flip": int(0 in event_values and 1 in event_values),
                        "endpoint_state_values": "|".join(endpoint_states),
                        "four_state_definition_change": int(len(endpoint_states) > 1),
                        "observed_event_time_range_h": float(observed_times.max() - observed_times.min()) if len(observed_times) >= 2 else 0.0,
                    }
                )
            return pd.DataFrame(rows)
        
        
        def main_reliability(main: pd.DataFrame) -> pd.DataFrame:
            if main.empty:
                return pd.DataFrame(columns=["device_uid"])
            cols = [
                "device_uid",
                "event_observed",
                "analysis_time_h",
                "event_status",
                "failure_mode_exploratory",
                "include_main_reliability",
            ]
            keep = [col for col in cols if col in main.columns]
            return main[keep].drop_duplicates("device_uid")
        
        
        def score_passport(passport: pd.DataFrame) -> pd.DataFrame:
            out = passport.copy()
            out["weak_label_broad"] = out["ai_suggested_failure_mode"].map(broad_label)
            spec = parameters("PAS-1")
            weights = rule("PAS-1")["weights"]
        
            components = {
                "four_state_definition_change": safe_num(out.get("four_state_definition_change")).clip(0, 1),
                "non_metadata_baseline": (out.get("p0_ai_definition", "").astype(str) != "p0_meta").astype(float),
                "qx1_substitution": (safe_num(out.get("power_corrected_count")) > 0).astype(float),
                "qx2_transient_handling": (
                    safe_num(out.get("power_artifact_excluded_count", pd.Series(0, index=out.index))) > 0
                ).astype(float),
                "time_review_fraction": safe_num(out.get("time_review_fraction")).clip(0, 1),
                "low_rule_confidence": (
                    safe_num(out.get("ai_confidence"), default=1.0) < float(spec["low_rule_confidence_max"])
                ).astype(float),
                "zero_power_evidence": (safe_num(out.get("zero_power_count_ai")) > 0).astype(float),
                "rule_review_flag": safe_num(out.get("needs_human_review")).clip(0, 1),
                "main_endpoint_nonassessable": out.get("event_status", pd.Series(np.nan, index=out.index)).isna().astype(float),
            }
            for name, values in components.items():
                out[f"passport_component_{name}"] = values
            out["decision_vulnerability_score"] = sum(float(weights[name]) * values for name, values in components.items()).clip(
                0, float(spec["score_max"])
            )
            out["decision_vulnerability_level"] = pd.cut(
                out["decision_vulnerability_score"],
                bins=[-np.inf, float(spec["low_medium_boundary"]), float(spec["medium_high_boundary"]), np.inf],
                labels=["low", "medium", "high"],
                right=False,
            ).astype(str)
            reasons = []
            for _, row in out.iterrows():
                tags = []
                for name in weights:
                    if float(row.get(f"passport_component_{name}", 0) or 0) > 0:
                        tags.append(name)
                reasons.append(";".join(tags))
            out["decision_vulnerability_reasons"] = reasons
            return out
        
        
        def build_passport_figure_data(passport: pd.DataFrame) -> pd.DataFrame:
            """Export the binary signals and weighted score components used by Figs. 7-10."""
            def numeric(column: str) -> pd.Series:
                return pd.to_numeric(passport.get(column, 0), errors="coerce").fillna(0)
        
            output = pd.DataFrame({"device_uid": passport["device_uid"].astype(str)})
            signal_columns = {
                "Endpoint-state change": "passport_component_four_state_definition_change",
                "Non-meta baseline": "passport_component_non_metadata_baseline",
                "QX-1 substitution": "passport_component_qx1_substitution",
                "QX-2 transient handling": "passport_component_qx2_transient_handling",
                "Time uncertainty": "passport_component_time_review_fraction",
                "Low rule confidence": "passport_component_low_rule_confidence",
                "Endpoint non-assessable": "passport_component_main_endpoint_nonassessable",
            }
            for label, column in signal_columns.items():
                output[label] = numeric(column).gt(0).astype(int)
            labels = {
                "four_state_definition_change": "State change",
                "non_metadata_baseline": "Non-meta P0",
                "qx1_substitution": "QX-1 substitution score",
                "qx2_transient_handling": "QX-2 handling",
                "time_review_fraction": "Time review",
                "low_rule_confidence": "Low confidence",
                "zero_power_evidence": "Zero power",
                "rule_review_flag": "Rule-review flag",
                "main_endpoint_nonassessable": "Endpoint NA",
            }
            for name, weight in rule("PAS-1")["weights"].items():
                output[labels[name]] = float(weight) * numeric(f"passport_component_{name}").clip(0, 1)
            return output
        
        
        def write_report(path: Path, passport: pd.DataFrame) -> None:
            n = len(passport)
            binary_flip = int(safe_num(passport.get("binary_event_flip")).sum())
            four_state = int(safe_num(passport.get("four_state_definition_change")).sum())
            high = int((passport["decision_vulnerability_level"] == "high").sum()) if "decision_vulnerability_level" in passport else 0
            medium = int((passport["decision_vulnerability_level"] == "medium").sum()) if "decision_vulnerability_level" in passport else 0
            corrected_devices = int((safe_num(passport.get("power_corrected_count")) > 0).sum())
            artifact_devices = int((safe_num(passport.get("power_artifact_excluded_count")) > 0).sum())
            p0_derived = int((passport.get("p0_ai_definition", pd.Series(dtype=str)).astype(str) != "p0_meta").sum())
            review = int(safe_num(passport.get("needs_human_review")).sum())
            mean_score = float(passport["decision_vulnerability_score"].mean()) if n else float("nan")
            top = passport.sort_values("decision_vulnerability_score", ascending=False).head(12)
            cols = [
                "device_uid",
                "file_id",
                "aging_temperature_C",
                "weak_label_broad",
                "decision_vulnerability_score",
                "decision_vulnerability_reasons",
            ]
            top_text = top.loc[:, [col for col in cols if col in top.columns]].to_string(index=False)
            text = f"""# Reliability Evidence Passport Analysis
        
        ## Purpose
        
        This analysis creates a device-level evidence passport for the QAES-VCSEL expert system. Each passport joins raw-data quality flags, measurement-entry corrections, P0 provenance, endpoint-definition sensitivity, observable trajectory-pattern labels, and rule-review priority. The score is an audit-vulnerability index, not a physical probability of failure.
        
        ## Summary
        
        - Device passports: {n}
        - Mean decision-vulnerability score: {mean_score:.2f}
        - High-vulnerability passports: {high}
        - Medium-vulnerability passports: {medium}
        - Devices with binary crossing-status flips among assessable definitions: {binary_flip}
        - Devices with any E/R/C/NA state change across all 12 definitions: {four_state}
        - Devices routed to human review by the expert system: {review}
        - Devices with corrected power entries: {corrected_devices}
        - Devices with transient power artifacts adjusted before labeling: {artifact_devices}
        - Devices using derived or non-meta P0: {p0_derived}
        
        ## Interpretation
        
        The passport layer makes uncertainty operational. Instead of treating data quality as disposable preprocessing, QAES-VCSEL exposes devices whose conclusions depend on endpoint definitions, corrected measurements, missing or derived P0, and rule-review flags. These records are prioritized for audit without asserting an unobserved review benefit.
        
        ## Highest-Priority Passports
        
        ```text
        {top_text}
        ```
        """
            path.write_text(text, encoding="utf-8")
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Build device-level reliability evidence passports.")
            parser.add_argument("--processed-dir", type=Path, default=Path("outputs") / "processed")
            parser.add_argument("--analysis-dir", type=Path, default=Path("outputs") / "analysis")
            args = parser.parse_args()
        
            devices = read_csv(args.processed_dir / "device_table.csv")
            ai = read_csv(args.processed_dir / "ai_device_classification.csv")
            all_defs = read_csv(args.analysis_dir / "reliability_dataset_all_definitions.csv")
            main = read_csv(args.analysis_dir / "reliability_dataset_main.csv")
        
            if devices.empty or ai.empty:
                raise SystemExit("Expected device_table.csv and ai_device_classification.csv before passport analysis.")
        
            base_cols = [
                "device_uid",
                "file_id",
                "source_file",
                "sheet",
                "source_column",
                "device_id_raw",
                "aging_temperature_C",
                "aging_current_mA",
                "p0_meta_mW",
                "measurement_count",
                "zero_power_count",
            ]
            passport = devices[[col for col in base_cols if col in devices.columns]].drop_duplicates("device_uid")
        
            ai_cols = [
                "device_uid",
                "p0_ai_mW",
                "p0_ai_definition",
                "measurement_count_ai",
                "time_review_fraction",
                "power_corrected_count",
                "power_correction_review_count",
                "power_artifact_excluded_count",
                "power_artifact_review_count",
                "duration_h",
                "last_ratio",
                "min_ratio",
                "max_recovery_after_min",
                "zero_power_count_ai",
                "points_below_80pct",
                "points_below_50pct",
                "change_point_score",
                "ai_suggested_failure_mode",
                "ai_confidence",
                "needs_human_review",
                "review_reasons",
                "curve_cluster",
                "curve_cluster_profile",
                "human_review_priority_score",
            ]
            passport = passport.merge(ai[[col for col in ai_cols if col in ai.columns]], on="device_uid", how="left")
            passport = passport.merge(event_sensitivity(all_defs), on="device_uid", how="left")
            passport = passport.merge(main_reliability(main), on="device_uid", how="left")
            passport = score_passport(passport)
            figure_data = build_passport_figure_data(passport)
        
            args.analysis_dir.mkdir(parents=True, exist_ok=True)
            passport_path = args.analysis_dir / "reliability_evidence_passport.csv"
            report_path = args.analysis_dir / "reliability_evidence_passport_report.md"
            passport.to_csv(passport_path, index=False, encoding="utf-8-sig")
            figure_data.to_csv(
                args.analysis_dir / "passport_figure_data.csv", index=False, encoding="utf-8-sig"
            )
            write_report(report_path, passport)
            print(f"passports={len(passport)}")
            print(f"high_vulnerability={(passport['decision_vulnerability_level'] == 'high').sum()}")
            print(f"binary_event_flips={int(passport['binary_event_flip'].fillna(0).sum())}")
            print(f"four_state_definition_changes={int(passport['four_state_definition_change'].fillna(0).sum())}")
            print(f"report={report_path.resolve()}")
        main()


def run_early_warning(stage_args: list[str]) -> None:
    """Build the landmark ranking dataset and exploratory model outputs."""
    with isolated_argv("early_warning", stage_args):
        import argparse
        import json
        import math
        import warnings
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        from sklearn.dummy import DummyClassifier
        from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
        from sklearn.impute import SimpleImputer
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import (
            average_precision_score,
            balanced_accuracy_score,
            brier_score_loss,
            f1_score,
            roc_auc_score,
        )
        from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        from sklearn.utils.class_weight import compute_sample_weight
        
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            """Read one frozen rule's parameters without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            return dict(registry["rules"][rule_id].get("parameters", {}))
        
        RANDOM_STATE = 42
        LANDMARK_HOURS = [0.0, 100.0, 500.0]
        PREDICTION_HORIZONS_HOURS = [500.0, 1000.0, 3000.0, 6000.0]
        
        FEATURE_COLS = [
            "landmark_h",
            "aging_temperature_C_num",
            "aging_current_mA_num",
            "p0_mW_num",
            "n_points_landmark",
            "span_h_landmark",
            "first_ratio_landmark",
            "last_ratio_landmark",
            "min_ratio_landmark",
            "max_ratio_landmark",
            "ratio_range_landmark",
            "last_minus_first_ratio_landmark",
            "slope_ratio_per_1000h_landmark",
            "largest_drop_step_landmark",
            "largest_rise_step_landmark",
            "max_recovery_after_min_landmark",
            "zero_power_count_landmark",
            "below_90pct_count_landmark",
            "below_80pct_count_landmark",
            "time_review_fraction_landmark",
            "power_corrected_count_landmark",
            "power_artifact_count_landmark",
        ]
        
        DESIGN_COLS = {"aging_temperature_C_num", "aging_current_mA_num", "p0_mW_num"}
        LANDMARK_PROTOCOL = parameters("LMB-1")
        LANDMARK_P0 = parameters("P0-1")
        LANDMARK_BI = parameters("BI-1")
        PROTOCOL_ONLY_COLS = list(LANDMARK_PROTOCOL["protocol_only_features"])
        FEATURE_SETS = {
            "full_design_curve_quality": FEATURE_COLS,
            "curve_quality_only": [col for col in FEATURE_COLS if col not in DESIGN_COLS],
            "design_only": ["landmark_h", "aging_temperature_C_num", "aging_current_mA_num", "p0_mW_num"],
            "protocol_only": PROTOCOL_ONLY_COLS,
        }
        
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            return pd.read_csv(path, encoding="utf-8-sig").fillna("")
        
        
        def safe_float(value: Any) -> float | None:
            try:
                result = float(value)
            except (TypeError, ValueError):
                return None
            if math.isnan(result) or math.isinf(result):
                return None
            return result
        
        
        def robust_slope(t: np.ndarray, y: np.ndarray) -> float:
            mask = np.isfinite(t) & np.isfinite(y)
            t = t[mask]
            y = y[mask]
            if len(t) < 2 or float(np.nanmax(t) - np.nanmin(t)) <= 0:
                return 0.0
            try:
                slope, _ = np.polyfit(t, y, deg=1)
            except Exception:
                return 0.0
            return float(slope * 1000.0)
        
        
        def choose_landmark_p0(
            rel_row: pd.Series,
            device_row: pd.Series | None,
            landmark_measurements: pd.DataFrame,
            landmark_h: float,
        ) -> tuple[float | None, str, float | None]:
            # Reconstruct the registered P0 hierarchy inside the truncated
            # landmark trajectory.  A final-archive P0 is never reused merely
            # because its reported support time precedes the landmark.
            cap_h = min(float(LANDMARK_BI["burn_in_cap_h"]), landmark_h)
            early = landmark_measurements[
                (pd.to_numeric(landmark_measurements["time_h"], errors="coerce") >= 0)
                & (pd.to_numeric(landmark_measurements["time_h"], errors="coerce") <= cap_h + 1e-9)
                & (pd.to_numeric(landmark_measurements["power_mW_num"], errors="coerce") > 0)
            ].copy()
            early = early.sort_values(["time_h", "measurement_time", "source_cell"])
            min_points = int(LANDMARK_P0["minimum_early_points"])
            max_points = int(LANDMARK_P0["maximum_early_points"])
            first_for_p0 = early.iloc[:max_points]
            early_median = (
                float(pd.to_numeric(first_for_p0["power_mW_num"], errors="coerce").median())
                if len(first_for_p0) >= min_points
                else None
            )
            early_median_time = float(first_for_p0["time_h"].iloc[-1]) if early_median is not None else None

            reference_values = list(
                pd.to_numeric(
                    early["power_mW_num"].iloc[: int(LANDMARK_BI["reference_positive_points"])],
                    errors="coerce",
                ).dropna()
            )
            if device_row is not None:
                p0_meta = safe_float(device_row.get("p0_meta_mW"))
                if p0_meta is not None and p0_meta > 0:
                    reference_values.append(p0_meta)
            provisional = max(reference_values) if reference_values else None

            window_n = int(LANDMARK_BI["stable_window_points"])
            if provisional is not None and len(early) >= window_n:
                for start in range(0, len(early) - window_n + 1):
                    window = early.iloc[start : start + window_n]
                    t_window = pd.to_numeric(window["time_h"], errors="coerce").to_numpy(dtype=float)
                    p_window = pd.to_numeric(window["power_mW_num"], errors="coerce").to_numpy(dtype=float)
                    span = float(t_window[-1] - t_window[0])
                    median = float(np.median(p_window))
                    if span < float(LANDMARK_BI["minimum_stable_window_span_h"]) or median <= 0:
                        continue
                    rel_spread = float((np.percentile(p_window, 90) - np.percentile(p_window, 10)) / median)
                    rel_slope = float(abs(np.polyfit(t_window, p_window, 1)[0]) * 100.0 / median)
                    stable_ratio = median / provisional
                    if not (
                        float(LANDMARK_BI["minimum_stabilized_to_provisional_reference_ratio"])
                        <= stable_ratio
                        <= float(LANDMARK_BI["maximum_stabilized_to_provisional_reference_ratio"])
                    ):
                        continue
                    if rel_spread > float(LANDMARK_BI["maximum_stable_window_relative_p10_p90_range"]):
                        continue
                    if rel_slope > float(LANDMARK_BI["maximum_abs_stable_window_relative_slope_per_100h"]):
                        continue
                    return median, "p0_post_stabilization_landmark", float(t_window[-1])

            if early_median is not None:
                return early_median, "p0_early_median5_landmark", early_median_time
            return None, "p0_unavailable_at_landmark", None
        
        
        def landmark_features(
            rel_row: pd.Series,
            measurements: pd.DataFrame,
            device_row: pd.Series | None,
            landmark_h: float,
        ) -> dict[str, Any] | None:
            sub = measurements.copy()
            sub["time_h"] = pd.to_numeric(sub["exposure_hours"], errors="coerce")
            sub["time_h"] = sub["time_h"].fillna(pd.to_numeric(sub["calendar_hours"], errors="coerce"))
            # Landmark predictors must be reconstructible from information available
            # at the landmark.  Full-trajectory QX-1/QX-2 fields can use later
            # neighbours, so they are never consumed here.  The frozen run contains
            # no runtime QX substitutions; transportable applications must recompute
            # any landmark-local quality action inside the truncated trajectory.
            sub["power_mW_num"] = pd.to_numeric(sub["power_mW"], errors="coerce")
            max_t = landmark_h if landmark_h > 0 else 1e-9
            sub = sub[(sub["time_h"] >= 0) & (sub["time_h"] <= max_t)].dropna(subset=["time_h", "power_mW_num"])
            sub = sub.sort_values(["time_h", "measurement_time", "source_cell"])
            if sub.empty:
                return None
            p0, p0_source, p0_reference_time = choose_landmark_p0(rel_row, device_row, sub, landmark_h)
            if p0 is None or p0 <= 0:
                return None
            final_p0 = safe_float(rel_row.get("p0_mW"))
            final_reference_time = safe_float(rel_row.get("p0_reference_time_h"))
            final_source = str(device_row.get("p0_best_available_definition", "")) if device_row is not None else ""
            local_source = {
                "p0_post_stabilization_landmark": "p0_post_stabilization",
                "p0_early_median5_landmark": "p0_early_median5",
            }.get(p0_source, p0_source)
            if (
                final_p0 is None
                or final_reference_time is None
                or final_reference_time > landmark_h + 1e-9
                or not np.isclose(p0, final_p0, rtol=0.0, atol=1e-12)
                or local_source != final_source
            ):
                # The final archive may select a numerically similar baseline
                # only after later observations.  Such a target was not frozen
                # at the landmark and is therefore ineligible.
                return None
        
            t = sub["time_h"].to_numpy(dtype=float)
            y = sub["power_mW_num"].to_numpy(dtype=float) / p0
            finite = np.isfinite(t) & np.isfinite(y)
            t = t[finite]
            y = y[finite]
            if len(y) == 0:
                return None
            diffs = np.diff(y) if len(y) > 1 else np.array([])
            min_idx = int(np.argmin(y))
            later_max = float(np.max(y[min_idx:])) if min_idx < len(y) else float(y[min_idx])
            current = safe_float(rel_row.get("aging_current_raw"))
        
            return {
                "device_uid": rel_row["device_uid"],
                "file_id": rel_row.get("file_id", ""),
                "aging_temperature_C": rel_row.get("aging_temperature_C", ""),
                "aging_temperature_C_num": safe_float(rel_row.get("aging_temperature_C")),
                "aging_current_mA_num": current,
                "p0_mW_num": p0,
                "p0_source_landmark": p0_source,
                "p0_reference_time_h_landmark": p0_reference_time,
                "landmark_h": landmark_h,
                "last_time_h_landmark": float(np.nanmax(t)),
                "n_points_landmark": int(len(y)),
                "span_h_landmark": float(np.nanmax(t) - np.nanmin(t)) if len(t) else 0.0,
                "first_ratio_landmark": float(y[0]),
                "last_ratio_landmark": float(y[-1]),
                "min_ratio_landmark": float(np.nanmin(y)),
                "max_ratio_landmark": float(np.nanmax(y)),
                "ratio_range_landmark": float(np.nanmax(y) - np.nanmin(y)),
                "last_minus_first_ratio_landmark": float(y[-1] - y[0]),
                "slope_ratio_per_1000h_landmark": robust_slope(t, y),
                "largest_drop_step_landmark": float(np.nanmin(diffs)) if len(diffs) else 0.0,
                "largest_rise_step_landmark": float(np.nanmax(diffs)) if len(diffs) else 0.0,
                "max_recovery_after_min_landmark": max(0.0, later_max - float(y[min_idx])),
                "zero_power_count_landmark": int(np.sum(y == 0)),
                "below_90pct_count_landmark": int(np.sum(y <= 0.9)),
                "below_80pct_count_landmark": int(np.sum(y <= 0.8)),
                "time_review_fraction_landmark": float(pd.to_numeric(sub.get("time_needs_review", 0), errors="coerce").fillna(0).mean()),
                "power_corrected_count_landmark": 0,
                "power_artifact_count_landmark": 0,
            }
        
        
        def label_for_horizon(rel_row: pd.Series, landmark_h: float, horizon_h: float) -> tuple[int | None, str]:
            analysis_time = safe_float(rel_row.get("analysis_time_h"))
            event_observed = int(safe_float(rel_row.get("event_observed")) or 0)
            confirmation_time = safe_float(rel_row.get("event_confirmation_exposure_hours"))
            if analysis_time is None or analysis_time <= landmark_h:
                return None, "not_at_risk_at_landmark"
            if (
                event_observed == 1
                and analysis_time <= horizon_h
                and confirmation_time is not None
                and confirmation_time <= horizon_h
            ):
                return 1, "failure_after_landmark_by_horizon"
            if event_observed == 1 and confirmation_time is not None and confirmation_time > horizon_h:
                return 0, "event_confirmed_after_prediction_horizon"
            if event_observed == 1 and analysis_time > horizon_h:
                return 0, "event_after_prediction_horizon"
            if event_observed == 0 and analysis_time >= horizon_h:
                return 0, "right_censored_after_horizon"
            return None, "right_censored_before_horizon"
        
        
        def build_dataset(rel: pd.DataFrame, measurements: pd.DataFrame, devices: pd.DataFrame) -> pd.DataFrame:
            by_device = {uid: group.copy() for uid, group in measurements.groupby("device_uid", sort=False)}
            device_meta = {row["device_uid"]: row for _, row in devices.iterrows()} if not devices.empty and "device_uid" in devices.columns else {}
            rows: list[dict[str, Any]] = []
            for _, rel_row in rel.iterrows():
                device_measurements = by_device.get(rel_row["device_uid"], pd.DataFrame(columns=measurements.columns))
                device_row = device_meta.get(rel_row["device_uid"])
                for landmark_h in LANDMARK_HOURS:
                    feats = landmark_features(rel_row, device_measurements, device_row, landmark_h)
                    if feats is None:
                        continue
                    for horizon_h in PREDICTION_HORIZONS_HOURS:
                        if horizon_h <= landmark_h:
                            continue
                        label, label_status = label_for_horizon(rel_row, landmark_h, horizon_h)
                        row = {
                            **feats,
                            "prediction_horizon_h": horizon_h,
                            "event_by_horizon": "" if label is None else int(label),
                            "label_status": label_status,
                            "analysis_time_h": rel_row.get("analysis_time_h", ""),
                            "event_confirmation_exposure_hours": rel_row.get("event_confirmation_exposure_hours", ""),
                            "event_observed": rel_row.get("event_observed", ""),
                            "main_p0_reference_time_h": rel_row.get("p0_reference_time_h", ""),
                        }
                        rows.append(row)
            return pd.DataFrame(rows)
        
        
        def viable_tasks(dataset: pd.DataFrame) -> list[tuple[float, float, pd.DataFrame]]:
            tasks = []
            labeled = dataset[dataset["event_by_horizon"].astype(str) != ""].copy()
            labeled["event_by_horizon"] = pd.to_numeric(labeled["event_by_horizon"], errors="coerce")
            for (landmark_h, horizon_h), group in labeled.groupby(["landmark_h", "prediction_horizon_h"]):
                counts = group["event_by_horizon"].value_counts()
                if len(group) >= 24 and set(counts.index) == {0, 1} and counts.min() >= 5:
                    tasks.append((float(landmark_h), float(horizon_h), group.reset_index(drop=True)))
            return tasks
        
        
        def model_specs() -> dict[str, Pipeline]:
            return {
                "majority_class": Pipeline(
                    [
                        ("impute", SimpleImputer(strategy="median")),
                        ("model", DummyClassifier(strategy="most_frequent")),
                    ]
                ),
                "logistic_regression": Pipeline(
                    [
                        ("impute", SimpleImputer(strategy="median")),
                        ("scale", StandardScaler()),
                        ("model", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=RANDOM_STATE)),
                    ]
                ),
                "random_forest": Pipeline(
                    [
                        ("impute", SimpleImputer(strategy="median")),
                        (
                            "model",
                            RandomForestClassifier(
                                n_estimators=500,
                                max_depth=6,
                                min_samples_leaf=3,
                                class_weight="balanced",
                                random_state=RANDOM_STATE,
                            ),
                        ),
                    ]
                ),
                "extra_trees": Pipeline(
                    [
                        ("impute", SimpleImputer(strategy="median")),
                        (
                            "model",
                            ExtraTreesClassifier(
                                n_estimators=500,
                                max_depth=6,
                                min_samples_leaf=3,
                                class_weight="balanced",
                                random_state=RANDOM_STATE,
                            ),
                        ),
                    ]
                ),
                "gradient_boosting": Pipeline(
                    [
                        ("impute", SimpleImputer(strategy="median")),
                        ("model", GradientBoostingClassifier(random_state=RANDOM_STATE)),
                    ]
                ),
            }
        
        
        def make_cv(group: pd.DataFrame) -> tuple[list[tuple[str, np.ndarray, np.ndarray]], str]:
            y = group["event_by_horizon"].astype(int)
            groups = group["file_id"].astype(str)
            min_class = int(y.value_counts().min())
            n_splits = min(5, min_class)
            if n_splits < 2:
                return [], "insufficient-class-count"
            if groups.nunique() >= n_splits:
                cv = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=RANDOM_STATE)
                splits = [(f"group_fold_{idx}", train, test) for idx, (train, test) in enumerate(cv.split(np.zeros(len(group)), y, groups), start=1)]
                return splits, "stratified-group-k-fold"
            cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=RANDOM_STATE)
            splits = [(f"stratified_fold_{idx}", train, test) for idx, (train, test) in enumerate(cv.split(group[FEATURE_COLS], y), start=1)]
            return splits, "stratified-k-fold"
        
        
        def probability_from_model(model: Pipeline, x: pd.DataFrame) -> np.ndarray:
            if hasattr(model, "predict_proba"):
                proba = model.predict_proba(x)
                if proba.shape[1] == 2:
                    return proba[:, 1]
            pred = model.predict(x)
            return np.asarray(pred, dtype=float)
        
        
        def evaluate_task(landmark_h: float, horizon_h: float, group: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
            y = group["event_by_horizon"].astype(int)
            splits, protocol = make_cv(group)
            metric_rows: list[dict[str, Any]] = []
            pred_rows: list[dict[str, Any]] = []
            importance_rows = []
        
            for feature_set, feature_cols in FEATURE_SETS.items():
                x = group[feature_cols].apply(pd.to_numeric, errors="coerce")
                for split_name, train_idx, test_idx in splits:
                    x_train, x_test = x.iloc[train_idx], x.iloc[test_idx]
                    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
                    for model_name, model in model_specs().items():
                        try:
                            with warnings.catch_warnings():
                                warnings.simplefilter("ignore")
                                if model_name == "gradient_boosting":
                                    model.fit(
                                        x_train,
                                        y_train,
                                        model__sample_weight=compute_sample_weight(
                                            class_weight="balanced", y=y_train
                                        ),
                                    )
                                else:
                                    model.fit(x_train, y_train)
                                score = probability_from_model(model, x_test)
                            pred = (score >= 0.5).astype(int)
                            row: dict[str, Any] = {
                                "landmark_h": landmark_h,
                                "prediction_horizon_h": horizon_h,
                                "feature_set": feature_set,
                                "model": model_name,
                                "split": split_name,
                                "validation_protocol": protocol,
                                "n_train": int(len(train_idx)),
                                "n_test": int(len(test_idx)),
                                "positive_fraction_test": float(y_test.mean()),
                                "balanced_accuracy": balanced_accuracy_score(y_test, pred),
                                "f1": f1_score(y_test, pred, zero_division=0),
                                "brier_score": brier_score_loss(y_test, score),
                                "status": "evaluated",
                            }
                            if y_test.nunique() == 2:
                                row["roc_auc"] = roc_auc_score(y_test, score)
                                row["average_precision"] = average_precision_score(y_test, score)
                            else:
                                row["roc_auc"] = ""
                                row["average_precision"] = ""
                            metric_rows.append(row)
                            for pos, prob, label, pred_label in zip(test_idx, score, y_test, pred):
                                pred_rows.append(
                                    {
                                        "landmark_h": landmark_h,
                                        "prediction_horizon_h": horizon_h,
                                        "feature_set": feature_set,
                                        "model": model_name,
                                        "split": split_name,
                                        "device_uid": group.loc[pos, "device_uid"],
                                        "file_id": group.loc[pos, "file_id"],
                                        "truth_event_by_horizon": int(label),
                                        "predicted_event_by_horizon": int(pred_label),
                                        "risk_score": float(prob),
                                    }
                                )
                        except Exception as exc:
                            metric_rows.append(
                                {
                                    "landmark_h": landmark_h,
                                    "prediction_horizon_h": horizon_h,
                                    "feature_set": feature_set,
                                    "model": model_name,
                                    "split": split_name,
                                    "validation_protocol": protocol,
                                    "status": f"failed: {exc}",
                                }
                            )
        
                if y.nunique() == 2 and len(group) >= 24:
                    model = Pipeline(
                        [
                            ("impute", SimpleImputer(strategy="median")),
                            (
                                "model",
                                RandomForestClassifier(
                                    n_estimators=800,
                                    max_depth=6,
                                    min_samples_leaf=3,
                                    class_weight="balanced",
                                    random_state=RANDOM_STATE,
                                ),
                            ),
                        ]
                    )
                    model.fit(x, y)
                    for feature, importance in zip(feature_cols, model.named_steps["model"].feature_importances_):
                        importance_rows.append(
                            {
                                "landmark_h": landmark_h,
                                "prediction_horizon_h": horizon_h,
                                "feature_set": feature_set,
                                "feature": feature,
                                "importance": float(importance),
                            }
                        )
        
            return pd.DataFrame(metric_rows), pd.DataFrame(pred_rows), pd.DataFrame(importance_rows)
        
        
        def summarize_metrics(metrics: pd.DataFrame) -> pd.DataFrame:
            evaluated = metrics[metrics["status"] == "evaluated"].copy() if not metrics.empty else pd.DataFrame()
            if evaluated.empty:
                return pd.DataFrame()
            for col in ["roc_auc", "average_precision"]:
                evaluated[col] = pd.to_numeric(evaluated[col], errors="coerce")
            evaluated["auc_evaluable"] = evaluated["roc_auc"].notna().astype(int)
            return (
                evaluated.groupby(["landmark_h", "prediction_horizon_h", "feature_set", "model", "validation_protocol"])
                .agg(
                    folds=("split", "nunique"),
                    auc_evaluable_folds=("auc_evaluable", "sum"),
                    total_test_records=("n_test", "sum"),
                    balanced_accuracy_mean=("balanced_accuracy", "mean"),
                    balanced_accuracy_std=("balanced_accuracy", "std"),
                    f1_mean=("f1", "mean"),
                    f1_std=("f1", "std"),
                    roc_auc_mean=("roc_auc", "mean"),
                    average_precision_mean=("average_precision", "mean"),
                    brier_score_mean=("brier_score", "mean"),
                )
                .reset_index()
                .sort_values(["landmark_h", "prediction_horizon_h", "roc_auc_mean", "balanced_accuracy_mean"], ascending=[True, True, False, False])
            )
        
        
        def write_report(path: Path, dataset: pd.DataFrame, summary: pd.DataFrame, importance: pd.DataFrame) -> None:
            labeled = dataset[dataset["event_by_horizon"].astype(str) != ""].copy()
            task_counts = (
                labeled.groupby(["landmark_h", "prediction_horizon_h", "event_by_horizon"])
                .size()
                .reset_index(name="n")
                if not labeled.empty
                else pd.DataFrame()
            )
            best = summary.sort_values(["roc_auc_mean", "balanced_accuracy_mean"], ascending=[False, False]).head(8) if not summary.empty else pd.DataFrame()
            curve_only = (
                summary[summary["feature_set"] == "curve_quality_only"]
                .sort_values(["roc_auc_mean", "balanced_accuracy_mean"], ascending=[False, False])
                .head(8)
                if not summary.empty and "feature_set" in summary.columns
                else pd.DataFrame()
            )
            text = f"""# Exploratory landmark ranking report
        
        ## Purpose
        
        This module turns the historical aging records into a censoring-filtered landmark ranking task: using only measurements available at a landmark time, predict whether a device will cross the main threshold by a later horizon. Devices censored before the horizon are excluded, so this is not a censoring-adjusted survival estimator.
        
        Feature construction is future-free with respect to measured optical-power trajectories: curve features use only rows at or before the landmark. When table-level P0 metadata are missing, the normalization baseline is estimated only from positive measurements already visible at the landmark.
        
        ## Dataset
        
        - Landmark times tested: {', '.join(str(x) for x in LANDMARK_HOURS)} h
        - Prediction horizons tested: {', '.join(str(x) for x in PREDICTION_HORIZONS_HOURS)} h
        - Landmark-horizon rows generated: {len(dataset)}
        - Labeled rows after censoring rules: {len(labeled)}
        
        Label counts by task:
        
        ```text
        {task_counts.to_string(index=False) if not task_counts.empty else '(no labeled tasks)'}
        ```
        
        ## Best exploratory landmark results
        
        ```text
        {best.to_string(index=False) if not best.empty else '(no viable benchmark tasks; too few positives/negatives after censoring)'}
        ```
        
        ## Curve and quality landmark results
        
        This table removes aging temperature, current, and P0 from the feature set. It checks whether prediction comes from early curve behavior and data-quality features rather than only design or batch variables.
        
        ```text
        {curve_only.to_string(index=False) if not curve_only.empty else '(not available)'}
        ```
        
        ## Feature Importance
        
        ```text
        {importance.sort_values('importance', ascending=False).head(20).to_string(index=False) if not importance.empty else '(not available)'}
        ```
        
        ## Manuscript Use
        
        Report this as a retrospective within-archive ranking stress test, not as a physical law, calibrated prognosis, or source-independent validation. Devices censored before the prediction horizon are excluded, while devices observed beyond the horizon are retained as negatives.
        """
            path.write_text(text, encoding="utf-8")
        
        
        def main() -> None:
            warnings.filterwarnings("ignore", message="y_pred contains classes not in y_true")
            warnings.filterwarnings("ignore", message="A single label was found in 'y_true' and 'y_pred'.*")
            parser = argparse.ArgumentParser(description="Censoring-filtered landmark ranking benchmark for VCSEL aging records.")
            parser.add_argument("--processed-dir", type=Path, default=Path("outputs") / "processed")
            parser.add_argument("--analysis-dir", type=Path, default=Path("outputs") / "analysis")
            args = parser.parse_args()
        
            rel = read_csv(args.analysis_dir / "reliability_dataset_main.csv")
            measurements = read_csv(args.processed_dir / "measurement_table.csv")
            devices = read_csv(args.processed_dir / "device_table.csv")
            if rel.empty or measurements.empty:
                raise SystemExit("Missing reliability_dataset_main.csv or measurement_table.csv.")
        
            dataset = build_dataset(rel, measurements, devices)
            tasks = viable_tasks(dataset)
            metric_tables = []
            prediction_tables = []
            importance_tables = []
            for landmark_h, horizon_h, group in tasks:
                metrics, predictions, importance = evaluate_task(landmark_h, horizon_h, group)
                metric_tables.append(metrics)
                prediction_tables.append(predictions)
                importance_tables.append(importance)
        
            metrics_all = pd.concat(metric_tables, ignore_index=True) if metric_tables else pd.DataFrame()
            predictions_all = pd.concat(prediction_tables, ignore_index=True) if prediction_tables else pd.DataFrame()
            importance_all = pd.concat(importance_tables, ignore_index=True) if importance_tables else pd.DataFrame()
            summary = summarize_metrics(metrics_all)
        
            args.analysis_dir.mkdir(parents=True, exist_ok=True)
            dataset.to_csv(args.analysis_dir / "landmark_ranking_dataset.csv", index=False, encoding="utf-8-sig")
            metrics_all.to_csv(args.analysis_dir / "landmark_exploratory_fold_metrics.csv", index=False, encoding="utf-8-sig")
            summary.to_csv(args.analysis_dir / "landmark_exploratory_model_summary.csv", index=False, encoding="utf-8-sig")
            predictions_all.to_csv(args.analysis_dir / "landmark_exploratory_predictions.csv", index=False, encoding="utf-8-sig")
            importance_all.to_csv(args.analysis_dir / "landmark_exploratory_feature_importance.csv", index=False, encoding="utf-8-sig")
            write_report(args.analysis_dir / "landmark_ranking_exploratory_report.md", dataset, summary, importance_all)
        
            print(f"landmark_horizon_rows={len(dataset)}")
            print(f"viable_tasks={len(tasks)}")
            if not summary.empty:
                top = summary.sort_values(["roc_auc_mean", "balanced_accuracy_mean"], ascending=[False, False]).iloc[0]
                print(f"best_task={top['landmark_h']}h_to_{top['prediction_horizon_h']}h")
                print(f"best_feature_set={top['feature_set']}")
                print(f"best_model={top['model']}")
                print(f"best_auc={float(top['roc_auc_mean']):.3f}")
            print(f"report={(args.analysis_dir / 'landmark_ranking_exploratory_report.md').resolve()}")
        main()


def run_validation(stage_args: list[str]) -> None:
    """Run the embedded q1_validation_stress_tests.py stage with an isolated command line."""
    with isolated_argv("validation", stage_args):
        import argparse
        import json
        import warnings
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        from sklearn.dummy import DummyClassifier
        from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
        from sklearn.impute import SimpleImputer
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import average_precision_score, balanced_accuracy_score, brier_score_loss, roc_auc_score
        from sklearn.model_selection import LeaveOneGroupOut, ParameterGrid, StratifiedGroupKFold
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        from sklearn.utils.class_weight import compute_sample_weight
        
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            """Read one frozen rule's parameters without importing sibling scripts."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            return dict(registry["rules"][rule_id].get("parameters", {}))
        
        
        LMB = parameters("LMB-1")
        RANDOM_STATE = int(LMB["random_seed"])
        N_CLUSTER_BOOTSTRAPS = int(LMB["cluster_bootstrap_draws"])
        CURVE_QUALITY_COLS = list(LMB["curve_quality_features"])
        
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            return pd.read_csv(path, encoding="utf-8-sig")
        
        
        def primary_task(dataset: pd.DataFrame) -> pd.DataFrame:
            spec = parameters("LMB-1")
            label = pd.to_numeric(dataset.get("event_by_horizon"), errors="coerce")
            work = dataset[
                pd.to_numeric(dataset.get("landmark_h"), errors="coerce").eq(float(spec["primary_landmark_h"]))
                & pd.to_numeric(dataset.get("prediction_horizon_h"), errors="coerce").eq(float(spec["primary_horizon_h"]))
                & label.notna()
            ].copy()
            work["event_by_horizon"] = pd.to_numeric(work["event_by_horizon"], errors="raise").astype(int)
            return work.reset_index(drop=True)
        
        
        def model_pipeline(model_name: str = "extra_trees") -> Pipeline:
            model = parameters("LMB-1")["model_parameters"]
            common_imputer = ("impute", SimpleImputer(strategy="median"))
            if model_name in {"majority_class", "constant_0_5"}:
                return Pipeline([common_imputer, ("model", DummyClassifier(strategy="most_frequent"))])
            if model_name == "logistic_regression":
                return Pipeline(
                    [
                        common_imputer,
                        ("scale", StandardScaler()),
                        (
                            "model",
                            LogisticRegression(
                                max_iter=2000,
                                random_state=RANDOM_STATE,
                            ),
                        ),
                    ]
                )
            if model_name == "random_forest":
                return Pipeline(
                    [
                        common_imputer,
                        (
                            "model",
                            RandomForestClassifier(
                                n_estimators=500,
                                max_depth=6,
                                min_samples_leaf=3,
                                random_state=RANDOM_STATE,
                                n_jobs=-1,
                            ),
                        ),
                    ]
                )
            if model_name == "gradient_boosting":
                return Pipeline(
                    [
                        common_imputer,
                        ("model", GradientBoostingClassifier(random_state=RANDOM_STATE)),
                    ]
                )
            if model_name != "extra_trees":
                raise KeyError(f"Unknown benchmark model: {model_name}")
            return Pipeline(
                [
                    common_imputer,
                    (
                        "model",
                        ExtraTreesClassifier(
                            n_estimators=int(model["n_estimators"]),
                            max_depth=int(model["max_depth"]),
                            min_samples_leaf=int(model["min_samples_leaf"]),
                            random_state=int(model["random_state"]),
                            n_jobs=-1,
                        ),
                    ),
                ]
            )


        def fit_pipeline(
            pipeline: Pipeline,
            x: pd.DataFrame,
            y: np.ndarray,
            model_name: str,
        ) -> Pipeline:
            """Fit with identical inverse-frequency training weights for learned classifiers."""
            if model_name in {"majority_class", "constant_0_5"}:
                return pipeline.fit(x, y)
            weights = compute_sample_weight(class_weight="balanced", y=y)
            return pipeline.fit(x, y, model__sample_weight=weights)


        def tuning_grid(model_name: str) -> list[dict[str, Any]]:
            """Small prespecified grids used only inside each outer training fold."""
            if model_name == "logistic_regression":
                grid = {"model__C": [0.1, 1.0, 10.0]}
            elif model_name in {"random_forest", "extra_trees"}:
                grid = {
                    "model__max_depth": [4, 6, None],
                    "model__min_samples_leaf": [1, 3],
                }
            elif model_name == "gradient_boosting":
                grid = {
                    "model__n_estimators": [100, 200],
                    "model__learning_rate": [0.03, 0.1],
                    "model__max_depth": [1, 2],
                }
            else:
                return [{}]
            return list(ParameterGrid(grid))


        def select_training_parameters(
            x: pd.DataFrame,
            y: np.ndarray,
            groups: np.ndarray,
            model_name: str,
        ) -> tuple[dict[str, Any], float, int]:
            """Tune without touching the outer held-out source."""
            candidates: list[tuple[float, int, str, dict[str, Any]]] = []
            inner = LeaveOneGroupOut()
            for candidate in tuning_grid(model_name):
                aucs: list[float] = []
                for inner_train, inner_valid in inner.split(x, y, groups):
                    if len(np.unique(y[inner_train])) < 2 or len(np.unique(y[inner_valid])) < 2:
                        continue
                    pipeline = model_pipeline(model_name)
                    pipeline.set_params(**candidate)
                    fitted = fit_pipeline(pipeline, x.iloc[inner_train], y[inner_train], model_name)
                    score = fitted.predict_proba(x.iloc[inner_valid])[:, 1]
                    aucs.append(float(roc_auc_score(y[inner_valid], score)))
                if aucs:
                    signature = json.dumps(candidate, sort_keys=True, separators=(",", ":"))
                    candidates.append((float(np.mean(aucs)), len(aucs), signature, candidate))
            if not candidates:
                return {}, float("nan"), 0
            candidates.sort(key=lambda item: (-item[0], -item[1], item[2]))
            score, evaluable, _, selected = candidates[0]
            return selected, score, evaluable
        
        
        def numeric_features(task: pd.DataFrame, columns: list[str], random_features: bool = False) -> pd.DataFrame:
            frame = pd.DataFrame({name: pd.to_numeric(task.get(name), errors="coerce") for name in columns}, index=task.index)
            if random_features:
                rng = np.random.default_rng(RANDOM_STATE)
                frame = pd.DataFrame(rng.normal(size=frame.shape), columns=frame.columns, index=frame.index)
            return frame
        
        
        def metric_values(y: np.ndarray, score: np.ndarray) -> dict[str, float]:
            prediction = (score >= 0.5).astype(int)
            values = {
                "balanced_accuracy": float("nan"),
                "brier_score": float(brier_score_loss(y, score)),
                "roc_auc": float("nan"),
                "average_precision": float("nan"),
            }
            if len(np.unique(y)) == 2:
                values["roc_auc"] = float(roc_auc_score(y, score))
                values["average_precision"] = float(average_precision_score(y, score))
                values["balanced_accuracy"] = float(balanced_accuracy_score(y, prediction))
            return values
        
        
        def grouped_cv(
            task: pd.DataFrame,
            columns: list[str],
            feature_set: str,
            random_features: bool = False,
            model_name: str = "extra_trees",
            tune_model: bool = False,
        ) -> tuple[pd.DataFrame, pd.DataFrame]:
            spec = parameters("LMB-1")
            y = task["event_by_horizon"].to_numpy(dtype=int)
            groups = task["file_id"].astype(str).to_numpy()
            x = numeric_features(task, columns, random_features=random_features)
            splitter = StratifiedGroupKFold(
                n_splits=int(spec["n_group_folds"]), shuffle=True, random_state=RANDOM_STATE
            )
            fold_rows: list[dict[str, Any]] = []
            prediction_rows: list[dict[str, Any]] = []
            for fold, (train_idx, test_idx) in enumerate(splitter.split(x, y, groups), start=1):
                train_y = y[train_idx]
                test_y = y[test_idx]
                train_groups = sorted(set(groups[train_idx]))
                test_groups = sorted(set(groups[test_idx]))
                if len(np.unique(train_y)) < 2:
                    raise RuntimeError(f"Fold {fold} training data contain one class.")
                selected: dict[str, Any] = {}
                inner_score = float("nan")
                inner_folds = 0
                if tune_model and model_name not in {"majority_class", "constant_0_5"}:
                    selected, inner_score, inner_folds = select_training_parameters(
                        x.iloc[train_idx].reset_index(drop=True),
                        train_y,
                        groups[train_idx],
                        model_name,
                    )
                if model_name == "constant_0_5":
                    score = np.full(len(test_idx), 0.5, dtype=float)
                else:
                    pipeline = model_pipeline(model_name)
                    pipeline.set_params(**selected)
                    fitted = fit_pipeline(pipeline, x.iloc[train_idx], train_y, model_name)
                    score = fitted.predict_proba(x.iloc[test_idx])[:, 1]
                metrics = metric_values(test_y, score)
                fold_rows.append(
                    {
                        "feature_set": feature_set,
                        "model": model_name,
                        "fold": fold,
                        "n_train": len(train_idx),
                        "n_test": len(test_idx),
                        "events_test": int(test_y.sum()),
                        "nonevents_test": int(len(test_y) - test_y.sum()),
                        "auc_evaluable": int(len(np.unique(test_y)) == 2),
                        "train_sources": "|".join(train_groups),
                        "test_sources": "|".join(test_groups),
                        "tuning_protocol": "inner_leave_one_source_out" if tune_model else "fixed_configuration",
                        "inner_evaluable_source_folds": inner_folds,
                        "inner_mean_auc": inner_score,
                        "selected_parameters": json.dumps(selected, sort_keys=True, separators=(",", ":")),
                        **metrics,
                    }
                )
                for position, score_value in zip(test_idx, score):
                    prediction_rows.append(
                        {
                            "feature_set": feature_set,
                            "model": model_name,
                            "fold": fold,
                            "device_uid": task.iloc[position]["device_uid"],
                            "file_id": task.iloc[position]["file_id"],
                            "truth": int(y[position]),
                            "risk_score": float(score_value),
                        }
                    )
            return pd.DataFrame(fold_rows), pd.DataFrame(prediction_rows)
        
        
        def source_support(task: pd.DataFrame) -> pd.DataFrame:
            rows = []
            for source, group in task.groupby("file_id", sort=True):
                events = int(group["event_by_horizon"].sum())
                rows.append(
                    {
                        "file_id": source,
                        "n": len(group),
                        "events": events,
                        "nonevents": int(len(group) - events),
                        "contains_both_classes": int(0 < events < len(group)),
                        "event_fraction": events / len(group),
                    }
                )
            return pd.DataFrame(rows)
        
        
        def summarize_cv(folds: pd.DataFrame, predictions: pd.DataFrame) -> dict[str, Any]:
            pooled = metric_values(predictions["truth"].to_numpy(dtype=int), predictions["risk_score"].to_numpy(float))
            auc = pd.to_numeric(folds["roc_auc"], errors="coerce")
            return {
                "folds": int(len(folds)),
                "auc_evaluable_folds": int(auc.notna().sum()),
                "fold_mean_auc": float(auc.mean()),
                "fold_min_auc": float(auc.min()),
                "fold_max_auc": float(auc.max()),
                "pooled_oof_auc": pooled["roc_auc"],
                "pooled_oof_average_precision": pooled["average_precision"],
                "pooled_oof_balanced_accuracy": pooled["balanced_accuracy"],
                "pooled_oof_brier_score": pooled["brier_score"],
            }


        def summarize_model_benchmark(folds: pd.DataFrame, predictions: pd.DataFrame) -> dict[str, Any]:
            summary = summarize_cv(folds, predictions)
            mixed = folds[pd.to_numeric(folds["roc_auc"], errors="coerce").notna()].copy()
            return {
                **summary,
                "mixed_fold_mean_average_precision": float(pd.to_numeric(mixed["average_precision"], errors="coerce").mean()),
                "mixed_fold_mean_balanced_accuracy": float(pd.to_numeric(mixed["balanced_accuracy"], errors="coerce").mean()),
                "mixed_fold_mean_brier_score": float(pd.to_numeric(mixed["brier_score"], errors="coerce").mean()),
                "all_fold_mean_brier_score": float(pd.to_numeric(folds["brier_score"], errors="coerce").mean()),
            }
        
        
        def cluster_bootstrap(predictions: pd.DataFrame, feature_set: str) -> pd.DataFrame:
            sources = predictions["file_id"].astype(str).drop_duplicates().to_numpy()
            rng = np.random.default_rng(RANDOM_STATE)
            draws: dict[str, list[float]] = {name: [] for name in ["roc_auc", "average_precision", "balanced_accuracy", "brier_score"]}
            for _ in range(N_CLUSTER_BOOTSTRAPS):
                sampled = rng.choice(sources, size=len(sources), replace=True)
                blocks = [predictions[predictions["file_id"].astype(str).eq(source)] for source in sampled]
                boot = pd.concat(blocks, ignore_index=True)
                values = metric_values(boot["truth"].to_numpy(dtype=int), boot["risk_score"].to_numpy(float))
                for metric, value in values.items():
                    if np.isfinite(value):
                        draws[metric].append(float(value))
            point = metric_values(predictions["truth"].to_numpy(dtype=int), predictions["risk_score"].to_numpy(float))
            rows = []
            for metric, values in draws.items():
                rows.append(
                    {
                        "feature_set": feature_set,
                        "metric": metric,
                        "point_estimate": point[metric],
                        "cluster_ci_low": float(np.quantile(values, 0.025)),
                        "cluster_ci_high": float(np.quantile(values, 0.975)),
                        "valid_bootstrap_draws": len(values),
                        "requested_bootstrap_draws": N_CLUSTER_BOOTSTRAPS,
                        "resampling_unit": "file_id",
                    }
                )
            return pd.DataFrame(rows)


        def paired_cluster_deltas(
            predictions: pd.DataFrame,
            primary_feature_set: str = "curve_quality_only",
            comparator_feature_set: str = "protocol_only",
        ) -> pd.DataFrame:
            primary = predictions[predictions["feature_set"].eq(primary_feature_set)][
                ["device_uid", "file_id", "truth", "risk_score"]
            ].rename(columns={"risk_score": "primary_score"})
            comparator = predictions[predictions["feature_set"].eq(comparator_feature_set)][
                ["device_uid", "file_id", "truth", "risk_score"]
            ].rename(columns={"risk_score": "comparator_score"})
            paired = primary.merge(
                comparator,
                on=["device_uid", "file_id", "truth"],
                how="inner",
                validate="one_to_one",
            )
            if len(paired) != len(primary) or len(paired) != len(comparator):
                raise AssertionError("Paired landmark predictions are incomplete.")
            y = paired["truth"].to_numpy(dtype=int)
            primary_values = metric_values(y, paired["primary_score"].to_numpy(float))
            comparator_values = metric_values(y, paired["comparator_score"].to_numpy(float))
            point = {
                metric: primary_values[metric] - comparator_values[metric]
                for metric in primary_values
            }
            sources = paired["file_id"].astype(str).drop_duplicates().to_numpy()
            rng = np.random.default_rng(RANDOM_STATE)
            draws: dict[str, list[float]] = {metric: [] for metric in point}
            for _ in range(N_CLUSTER_BOOTSTRAPS):
                sampled = rng.choice(sources, size=len(sources), replace=True)
                blocks = [paired[paired["file_id"].astype(str).eq(source)] for source in sampled]
                boot = pd.concat(blocks, ignore_index=True)
                boot_y = boot["truth"].to_numpy(dtype=int)
                p_values = metric_values(boot_y, boot["primary_score"].to_numpy(float))
                c_values = metric_values(boot_y, boot["comparator_score"].to_numpy(float))
                for metric in draws:
                    delta = p_values[metric] - c_values[metric]
                    if np.isfinite(delta):
                        draws[metric].append(float(delta))
            rows = []
            for metric, values in draws.items():
                rows.append(
                    {
                        "contrast": f"{primary_feature_set}_minus_{comparator_feature_set}",
                        "metric": metric,
                        "point_delta": point[metric],
                        "cluster_ci_low": float(np.quantile(values, 0.025)),
                        "cluster_ci_high": float(np.quantile(values, 0.975)),
                        "valid_bootstrap_draws": len(values),
                        "requested_bootstrap_draws": N_CLUSTER_BOOTSTRAPS,
                        "resampling_unit": "file_id",
                    }
                )
            return pd.DataFrame(rows)


        def paired_evaluable_fold_deltas(
            folds: pd.DataFrame,
            primary_feature_set: str = "curve_quality_only",
            comparator_feature_set: str = "protocol_only",
        ) -> pd.DataFrame:
            metric_names = ["roc_auc", "average_precision", "balanced_accuracy", "brier_score"]
            primary = folds[folds["feature_set"].eq(primary_feature_set)][["fold", *metric_names]].rename(
                columns={metric: f"primary_{metric}" for metric in metric_names}
            )
            comparator = folds[folds["feature_set"].eq(comparator_feature_set)][["fold", *metric_names]].rename(
                columns={metric: f"comparator_{metric}" for metric in metric_names}
            )
            paired = primary.merge(comparator, on="fold", how="inner", validate="one_to_one")
            rows: list[dict[str, Any]] = []
            for metric in metric_names:
                p = pd.to_numeric(paired[f"primary_{metric}"], errors="coerce")
                c = pd.to_numeric(paired[f"comparator_{metric}"], errors="coerce")
                valid = p.notna() & c.notna()
                deltas = p[valid] - c[valid]
                rows.append({
                    "contrast": f"{primary_feature_set}_minus_{comparator_feature_set}",
                    "metric": metric,
                    "paired_evaluable_folds": int(valid.sum()),
                    "mean_fold_delta": float(deltas.mean()) if len(deltas) else np.nan,
                    "minimum_fold_delta": float(deltas.min()) if len(deltas) else np.nan,
                    "maximum_fold_delta": float(deltas.max()) if len(deltas) else np.nan,
                    "fold_deltas": "|".join(f"{value:.6f}" for value in deltas),
                    "interpretation": "descriptive paired fold diagnostic; folds are few and not independent replications",
                })
            return pd.DataFrame(rows)
        
        
        def leave_one_source_out(task: pd.DataFrame, columns: list[str]) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, float]]:
            x = numeric_features(task, columns)
            y = task["event_by_horizon"].to_numpy(dtype=int)
            groups = task["file_id"].astype(str).to_numpy()
            rows: list[dict[str, Any]] = []
            prediction_rows: list[dict[str, Any]] = []
            for source in sorted(set(groups)):
                test_idx = np.where(groups == source)[0]
                train_idx = np.where(groups != source)[0]
                train_y, test_y = y[train_idx], y[test_idx]
                if len(np.unique(train_y)) < 2:
                    rows.append({"file_id": source, "n_test": len(test_idx), "status": "training_one_class"})
                    continue
                fitted = fit_pipeline(
                    model_pipeline("extra_trees"),
                    x.iloc[train_idx],
                    train_y,
                    "extra_trees",
                )
                score = fitted.predict_proba(x.iloc[test_idx])[:, 1]
                values = metric_values(test_y, score)
                rows.append(
                    {
                        "file_id": source,
                        "n_test": len(test_idx),
                        "events_test": int(test_y.sum()),
                        "nonevents_test": int(len(test_y) - test_y.sum()),
                        "auc_evaluable": int(len(np.unique(test_y)) == 2),
                        "status": "evaluated",
                        **values,
                    }
                )
                for position, score_value in zip(test_idx, score):
                    prediction_rows.append(
                        {
                            "file_id": source,
                            "device_uid": task.iloc[position]["device_uid"],
                            "truth": int(y[position]),
                            "risk_score": float(score_value),
                        }
                    )
            predictions = pd.DataFrame(prediction_rows)
            pooled = metric_values(predictions["truth"].to_numpy(dtype=int), predictions["risk_score"].to_numpy(float))
            return pd.DataFrame(rows), predictions, pooled
        
        
        def review_allocation(passport: pd.DataFrame) -> pd.DataFrame:
            budgets = parameters("AR-1")["budgets"]
            ranked = passport.sort_values(["decision_vulnerability_score", "device_uid"], ascending=[False, True]).reset_index(drop=True)
            rows = []
            for budget in budgets:
                selected_n = int(np.ceil(float(budget) * len(ranked)))
                selected = ranked.head(selected_n)
                rows.append(
                    {
                        "budget_fraction": float(budget),
                        "selected_devices": selected_n,
                        "source_files_represented": int(selected["file_id"].nunique()),
                        "median_score": float(pd.to_numeric(selected["decision_vulnerability_score"], errors="coerce").median()),
                        "four_state_change_records": int(pd.to_numeric(selected["four_state_definition_change"], errors="coerce").fillna(0).sum()),
                        "interpretation": "workload allocation only; no independent review-yield claim",
                    }
                )
            return pd.DataFrame(rows)
        
        
        def write_report(
            path: Path,
            task: pd.DataFrame,
            support: pd.DataFrame,
            controls: pd.DataFrame,
            bootstrap: pd.DataFrame,
            loso_summary: dict[str, float],
        ) -> None:
            events = int(task["event_by_horizon"].sum())
            nonevents = int(len(task) - events)
            negative_sources = support[support["nonevents"] > 0]
            dominant_negative_share = float(negative_sources["nonevents"].max() / nonevents)
            primary = controls[controls["feature_set"].eq("hybrid_rule_curve_quality")].iloc[0]
            protocol = controls[controls["feature_set"].eq("protocol_only")].iloc[0]
            auc_ci = bootstrap[bootstrap["metric"].eq("roc_auc")].iloc[0]
            evaluable_loso = pd.to_numeric(pd.Series([loso_summary.get("roc_auc")]), errors="coerce").notna().sum()
            text = f"""# Frozen validation stress test
        
        ## Primary estimand
        
        The frozen landmark task uses measurements available by 100 h to rank threshold crossing by 6000 h. Records censored before 6000 h are excluded; the estimand is therefore a censoring-filtered retrospective binary ranking task, not a censoring-adjusted prognosis model.
        
        The clean run contains {len(task)} horizon-observable devices: {events} have an observed threshold crossing after 100 h and by 6000 h, whereas {nonevents} have no observed crossing by 6000 h. The records come from {support['file_id'].nunique()} source files. Records without an observed crossing occur in {len(negative_sources)} source files, and the largest source contributes {dominant_negative_share:.1%} of them. This concentration is an explicit source-protocol confounding risk.
        
        ## Grouped validation
        
        Source-grouped fivefold validation produced {int(primary['auc_evaluable_folds'])} AUC-evaluable folds. Hybrid curve, quality, and context features yielded a mean fold AUC of {primary['fold_mean_auc']:.3f} (fold range {primary['fold_min_auc']:.3f}--{primary['fold_max_auc']:.3f}); protocol-only fields yielded {protocol['fold_mean_auc']:.3f}, a difference of {primary['fold_mean_auc'] - protocol['fold_mean_auc']:.3f}. The pooled out-of-fold AUC was {primary['pooled_oof_auc']:.3f}, with a descriptive 95% percentile source-file cluster-bootstrap interval of {auc_ci['cluster_ci_low']:.3f}--{auc_ci['cluster_ci_high']:.3f}. This interval resamples fixed out-of-fold predictions and is neither a refit-model confidence interval nor external validation; pooled scores are descriptive because each fold uses a separately fitted model.
        
        Leave-one-source-out predictions were also retained as a source-influence diagnostic. Most individual source files contain only one outcome class, so source-specific AUC is undefined for those files and is retained as missing rather than imputed; pooled leave-one-source-out scores are not treated as the primary performance estimate.
        
        ## Interpretation boundary
        
        These results assess internal ranking consistency under source-grouped resampling. They do not establish calibrated risk, independent external validity, a physical failure mechanism, or a benefit over source-protocol information. The evidence-passport budget table reports workload allocation only because no independent blinded adjudication outcome is available for estimating review yield.
        """
            path.write_text(text, encoding="utf-8")
        
        
        def main() -> None:
            warnings.filterwarnings("ignore", message="A single label was found in 'y_true' and 'y_pred'.*")
            warnings.filterwarnings("ignore", message="y_pred contains classes not in y_true")
            parser = argparse.ArgumentParser(description="Frozen source-grouped validation for QAES-VCSEL.")
            parser.add_argument("--analysis-dir", type=Path, default=Path("outputs") / "analysis")
            args = parser.parse_args()
            dataset = read_csv(args.analysis_dir / "landmark_ranking_dataset.csv")
            passport = read_csv(args.analysis_dir / "reliability_evidence_passport.csv")
            if dataset.empty or passport.empty:
                raise SystemExit("Missing landmark dataset or reliability evidence passport.")
            task = primary_task(dataset)
            if len(task) < 24 or task["event_by_horizon"].nunique() != 2:
                raise RuntimeError("Frozen landmark task is not evaluable.")
        
            protocol_cols = list(parameters("LMB-1")["protocol_only_features"])
            context_cols = list(parameters("LMB-1")["hybrid_context_features"])
            # Only landmark-native quality evidence is eligible.  Full-trajectory
            # QX action counts are retained in the audit outputs but excluded from
            # prediction because their original construction may inspect later
            # neighbours.
            quality_cols = ["time_review_fraction_landmark"]
            curve_cols = [column for column in CURVE_QUALITY_COLS if column not in quality_cols]
            threshold_count_cols = ["below_90pct_count_landmark", "below_80pct_count_landmark"]
            threshold_count_free_cols = [
                column for column in CURVE_QUALITY_COLS if column not in threshold_count_cols
            ]
            feature_sets = {
                "hybrid_rule_curve_quality": (list(dict.fromkeys(CURVE_QUALITY_COLS + context_cols)), False),
                "context_protocol_only": (context_cols, False),
                "curve_quality_only": (CURVE_QUALITY_COLS, False),
                "threshold_count_free": (threshold_count_free_cols, False),
                "curve_only": (curve_cols, False),
                "quality_only": (quality_cols, False),
                "protocol_only": (protocol_cols, False),
                "random_features": (CURVE_QUALITY_COLS, True),
            }
            fold_tables = []
            prediction_tables = []
            control_rows = []
            bootstrap_tables = []
            for feature_set, (columns, random_features) in feature_sets.items():
                folds, predictions = grouped_cv(task, columns, feature_set, random_features=random_features)
                summary = summarize_cv(folds, predictions)
                control_rows.append({"feature_set": feature_set, **summary})
                fold_tables.append(folds)
                prediction_tables.append(predictions)
                bootstrap_tables.append(cluster_bootstrap(predictions, feature_set))
        
            controls = pd.DataFrame(control_rows)
            bootstrap = pd.concat(bootstrap_tables, ignore_index=True)

            benchmark_models = [
                "constant_0_5",
                "majority_class",
                "logistic_regression",
                "random_forest",
                "gradient_boosting",
                "extra_trees",
            ]
            benchmark_fold_tables = []
            benchmark_prediction_tables = []
            benchmark_rows = []
            benchmark_bootstrap_tables = []
            benchmark_feature_cols = list(dict.fromkeys(CURVE_QUALITY_COLS + context_cols))
            for model_name in benchmark_models:
                model_folds, model_predictions = grouped_cv(
                    task,
                    benchmark_feature_cols,
                    model_name,
                    model_name=model_name,
                    tune_model=model_name not in {"constant_0_5", "majority_class"},
                )
                benchmark_rows.append(
                    {
                        "model": model_name,
                        **summarize_model_benchmark(model_folds, model_predictions),
                    }
                )
                benchmark_fold_tables.append(model_folds)
                benchmark_prediction_tables.append(model_predictions)
                benchmark_bootstrap_tables.append(cluster_bootstrap(model_predictions, model_name))
            benchmark_summary = pd.DataFrame(benchmark_rows)
            benchmark_folds = pd.concat(benchmark_fold_tables, ignore_index=True)
            benchmark_predictions = pd.concat(benchmark_prediction_tables, ignore_index=True)
            benchmark_bootstrap = pd.concat(benchmark_bootstrap_tables, ignore_index=True)
            benchmark_paired_deltas = pd.concat(
                [
                    paired_cluster_deltas(
                        benchmark_predictions,
                        primary_feature_set="extra_trees",
                        comparator_feature_set=comparator,
                    )
                    for comparator in benchmark_models
                    if comparator != "extra_trees"
                ],
                ignore_index=True,
            )
            benchmark_paired_folds = pd.concat(
                [
                    paired_evaluable_fold_deltas(
                        benchmark_folds,
                        primary_feature_set="extra_trees",
                        comparator_feature_set=comparator,
                    )
                    for comparator in benchmark_models
                    if comparator != "extra_trees"
                ],
                ignore_index=True,
            )
            support = source_support(task)
            loso, loso_predictions, loso_summary = leave_one_source_out(task, CURVE_QUALITY_COLS)
            allocation = review_allocation(passport)
            folds_all = pd.concat(fold_tables, ignore_index=True)
            predictions_all = pd.concat(prediction_tables, ignore_index=True)
            paired_deltas = pd.concat(
                [
                    paired_cluster_deltas(predictions_all),
                    paired_cluster_deltas(
                        predictions_all,
                        primary_feature_set="hybrid_rule_curve_quality",
                        comparator_feature_set="context_protocol_only",
                    ),
                    paired_cluster_deltas(
                        predictions_all,
                        primary_feature_set="hybrid_rule_curve_quality",
                        comparator_feature_set="curve_quality_only",
                    ),
                ],
                ignore_index=True,
            )
            paired_fold_diagnostics = pd.concat(
                [
                    paired_evaluable_fold_deltas(folds_all),
                    paired_evaluable_fold_deltas(
                        folds_all,
                        primary_feature_set="hybrid_rule_curve_quality",
                        comparator_feature_set="context_protocol_only",
                    ),
                    paired_evaluable_fold_deltas(
                        folds_all,
                        primary_feature_set="hybrid_rule_curve_quality",
                        comparator_feature_set="curve_quality_only",
                    ),
                ],
                ignore_index=True,
            )

            primary_rows = dataset[
                pd.to_numeric(dataset["landmark_h"], errors="coerce").eq(float(LMB["primary_landmark_h"]))
                & pd.to_numeric(dataset["prediction_horizon_h"], errors="coerce").eq(float(LMB["primary_horizon_h"]))
            ].copy()
            source_disjoint = all(
                set(str(row.train_sources).split("|")).isdisjoint(set(str(row.test_sources).split("|")))
                for row in benchmark_folds.itertuples()
            )
            benchmark_models_per_device = benchmark_predictions.groupby("device_uid")["model"].nunique()
            benchmark_folds_per_device = benchmark_predictions.groupby("device_uid")["fold"].nunique()
            common_outer_assignment = bool(
                benchmark_models_per_device.eq(len(benchmark_models)).all()
                and benchmark_folds_per_device.eq(1).all()
            )
            one_prediction_per_model_device = bool(
                benchmark_predictions.groupby(["model", "device_uid"]).size().eq(1).all()
            )
            feature_time_bounded = bool(
                pd.to_numeric(task["last_time_h_landmark"], errors="coerce")
                .le(float(LMB["primary_landmark_h"]) + 1e-9)
                .all()
            )
            baseline_time_bounded = bool(
                pd.to_numeric(task["p0_reference_time_h_landmark"], errors="coerce")
                .le(float(LMB["primary_landmark_h"]) + 1e-9)
                .all()
            )
            at_risk_time_valid = bool(
                pd.to_numeric(task["analysis_time_h"], errors="coerce")
                .gt(float(LMB["primary_landmark_h"]) + 1e-9)
                .all()
            )
            positive_confirmation_bounded = bool(
                pd.to_numeric(
                    task.loc[task["event_by_horizon"].eq(1), "event_confirmation_exposure_hours"],
                    errors="coerce",
                )
                .le(float(LMB["primary_horizon_h"]) + 1e-9)
                .all()
            )
            fairness_audit = pd.DataFrame(
                [
                    {
                        "check": "outer_train_test_sources_disjoint",
                        "status": "pass" if source_disjoint else "fail",
                        "value": int(source_disjoint),
                        "detail": "No outer held-out workbook source appears in its training set.",
                    },
                    {
                        "check": "common_outer_assignment_across_models",
                        "status": "pass" if common_outer_assignment else "fail",
                        "value": int(common_outer_assignment),
                        "detail": "All benchmark models use the same device-level outer fold assignment.",
                    },
                    {
                        "check": "one_outer_prediction_per_model_device",
                        "status": "pass" if one_prediction_per_model_device else "fail",
                        "value": int(one_prediction_per_model_device),
                        "detail": "Each eligible device has exactly one held-out prediction from each model.",
                    },
                    {
                        "check": "landmark_feature_time_bounded",
                        "status": "pass" if feature_time_bounded else "fail",
                        "value": int(feature_time_bounded),
                        "detail": "Every curve feature uses measurements observed no later than the 100 h landmark.",
                    },
                    {
                        "check": "baseline_support_time_bounded",
                        "status": "pass" if baseline_time_bounded else "fail",
                        "value": int(baseline_time_bounded),
                        "detail": "Every included normalization baseline is supported no later than the landmark.",
                    },
                    {
                        "check": "landmark_risk_set_event_time_valid",
                        "status": "pass" if at_risk_time_valid else "fail",
                        "value": int(at_risk_time_valid),
                        "detail": "No device with an archive-derived event time at or before the landmark enters the risk set.",
                    },
                    {
                        "check": "positive_outcomes_confirmed_by_horizon",
                        "status": "pass" if positive_confirmation_bounded else "fail",
                        "value": int(positive_confirmation_bounded),
                        "detail": "Every positive outcome completes the registered crossing-confirmation rule by 6000 h.",
                    },
                    {
                        "check": "common_primary_feature_count",
                        "status": "pass",
                        "value": len(benchmark_feature_cols),
                        "detail": "Every learned benchmark receives the same hybrid curve, quality, and context predictors.",
                    },
                    {
                        "check": "outer_sources",
                        "status": "information",
                        "value": int(task["file_id"].nunique()),
                        "detail": "Workbook source is the outer split and resampling unit.",
                    },
                    {
                        "check": "auc_evaluable_outer_sources",
                        "status": "information",
                        "value": int(support["contains_both_classes"].sum()),
                        "detail": "Only held-out sources containing both outcome classes contribute to mean fold AUC.",
                    },
                    {
                        "check": "horizon_observable_records",
                        "status": "information",
                        "value": len(task),
                        "detail": "Records enter the ranking task only when the 6000 h binary outcome is observable.",
                    },
                    {
                        "check": "right_censored_before_horizon_excluded",
                        "status": "information",
                        "value": int(primary_rows["label_status"].eq("right_censored_before_horizon").sum()),
                        "detail": "Pre-horizon censoring is excluded from binary ranking rather than relabeled as a non-event.",
                    },
                ]
            )
            if fairness_audit["status"].eq("fail").any():
                failed = fairness_audit.loc[fairness_audit["status"].eq("fail"), "check"].tolist()
                raise AssertionError(f"Landmark fairness audit failed: {failed}")
        
            support.to_csv(args.analysis_dir / "landmark_primary_source_support.csv", index=False, encoding="utf-8-sig")
            folds_all.to_csv(args.analysis_dir / "landmark_primary_group_fold_metrics.csv", index=False, encoding="utf-8-sig")
            predictions_all.to_csv(args.analysis_dir / "landmark_primary_group_predictions.csv", index=False, encoding="utf-8-sig")
            controls.to_csv(args.analysis_dir / "landmark_primary_controls.csv", index=False, encoding="utf-8-sig")
            bootstrap.to_csv(args.analysis_dir / "landmark_primary_cluster_bootstrap.csv", index=False, encoding="utf-8-sig")
            benchmark_summary.to_csv(
                args.analysis_dir / "landmark_model_benchmark.csv", index=False, encoding="utf-8-sig"
            )
            benchmark_folds.to_csv(
                args.analysis_dir / "landmark_model_benchmark_fold_metrics.csv", index=False, encoding="utf-8-sig"
            )
            benchmark_predictions.to_csv(
                args.analysis_dir / "landmark_model_benchmark_predictions.csv", index=False, encoding="utf-8-sig"
            )
            benchmark_bootstrap.to_csv(
                args.analysis_dir / "landmark_model_benchmark_cluster_bootstrap.csv", index=False, encoding="utf-8-sig"
            )
            benchmark_paired_deltas.to_csv(
                args.analysis_dir / "landmark_model_benchmark_paired_deltas.csv", index=False, encoding="utf-8-sig"
            )
            benchmark_paired_folds.to_csv(
                args.analysis_dir / "landmark_model_benchmark_paired_fold_diagnostics.csv",
                index=False,
                encoding="utf-8-sig",
            )
            paired_deltas.to_csv(args.analysis_dir / "landmark_primary_paired_deltas.csv", index=False, encoding="utf-8-sig")
            paired_fold_diagnostics.to_csv(
                args.analysis_dir / "landmark_primary_paired_fold_diagnostics.csv",
                index=False,
                encoding="utf-8-sig",
            )
            loso.to_csv(args.analysis_dir / "landmark_primary_source_influence.csv", index=False, encoding="utf-8-sig")
            loso_predictions.to_csv(args.analysis_dir / "landmark_primary_loso_predictions.csv", index=False, encoding="utf-8-sig")
            allocation.to_csv(args.analysis_dir / "passport_review_allocation.csv", index=False, encoding="utf-8-sig")
            fairness_audit.to_csv(args.analysis_dir / "landmark_fairness_audit.csv", index=False, encoding="utf-8-sig")
        
            compatibility_ci = bootstrap.rename(
                columns={"point_estimate": "observed", "cluster_ci_low": "ci_low", "cluster_ci_high": "ci_high"}
            )
            compatibility_ci.to_csv(args.analysis_dir / "q1_early_warning_bootstrap_ci.csv", index=False, encoding="utf-8-sig")
            controls.to_csv(args.analysis_dir / "q1_early_warning_negative_controls.csv", index=False, encoding="utf-8-sig")
            report = args.analysis_dir / "q1_validation_stress_tests_report.md"
            write_report(
                report,
                task,
                support,
                controls,
                bootstrap[bootstrap["feature_set"].eq("hybrid_rule_curve_quality")],
                loso_summary,
            )
            print(f"primary_records={len(task)}")
            print(f"events={int(task['event_by_horizon'].sum())}")
            print(f"nonevents={int(len(task) - task['event_by_horizon'].sum())}")
            print(controls.to_string(index=False))
            print(benchmark_summary.to_string(index=False))
            print(f"report={report.resolve()}")
        main()


def run_ablation(stage_args: list[str]) -> None:
    """Run target-governance and cohort ablation analyses."""
    with isolated_argv("ablation", stage_args):
        import argparse
        import math
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            try:
                return pd.read_csv(path, encoding="utf-8-sig").fillna("")
            except pd.errors.EmptyDataError:
                return pd.DataFrame()
        
        
        def safe_float(value: Any) -> float | None:
            try:
                result = float(value)
            except (TypeError, ValueError):
                return None
            if math.isnan(result) or math.isinf(result):
                return None
            return result
        
        
        def norm_temp(value: Any) -> str:
            number = safe_float(value)
            if number is None:
                text = str(value or "").strip()
                return text if text else "unknown"
            if abs(number - round(number)) < 1e-6:
                return str(int(round(number)))
            return f"{number:g}"
        
        
        def best_p0(row: pd.Series) -> float | None:
            for col in ["p0_post_stabilization_mW", "p0_early_median5_positive_mW"]:
                value = safe_float(row.get(col, ""))
                if value is not None and value > 0:
                    return value
            return None
        
        
        def quality_snapshot(measurements: pd.DataFrame, devices: pd.DataFrame, stage: str) -> dict[str, Any]:
            if measurements.empty:
                return {"stage": stage, "records": 0}
            device_p0 = {row["device_uid"]: best_p0(row) for _, row in devices.iterrows()} if not devices.empty else {}
            power = pd.to_numeric(measurements.get("power_mW", pd.Series(dtype=float)), errors="coerce")
            ratios = []
            for uid, value in zip(measurements["device_uid"], power):
                p0 = device_p0.get(uid)
                ratios.append(float(value) / p0 if p0 and value == value else np.nan)
            ratio = pd.Series(ratios)
            return {
                "stage": stage,
                "records": int(len(measurements)),
                "numeric_power_records": int(power.notna().sum()),
                "max_power_mW": float(power.max()) if power.notna().any() else "",
                "p99_power_mW": float(power.quantile(0.99)) if power.notna().any() else "",
                "records_power_ge_10mW": int((power >= 10).sum()),
                "records_ratio_ge_10_to_best_p0": int((ratio >= 10).sum()),
                "records_ratio_gt_3_to_best_p0": int((ratio > 3).sum()),
                "devices_with_ratio_gt_3": int(measurements.loc[ratio > 3, "device_uid"].nunique()) if "device_uid" in measurements.columns else 0,
            }
        
        
        def correction_ablation(processed_dir: Path) -> pd.DataFrame:
            raw_m = read_csv(processed_dir / "measurement_table_raw_extracted.csv")
            raw_d = read_csv(processed_dir / "device_table_raw_extracted.csv")
            clean_m = read_csv(processed_dir / "measurement_table.csv")
            clean_d = read_csv(processed_dir / "device_table.csv")
            correction_log = read_csv(processed_dir / "measurement_correction_log.csv")
            artifact_log = read_csv(processed_dir / "measurement_artifact_log.csv")
            rows = [quality_snapshot(raw_m, raw_d, "raw_extracted"), quality_snapshot(clean_m, clean_d, "after_correction")]
            out = pd.DataFrame(rows)
            out["corrected_measurement_records"] = len(correction_log)
            out["devices_with_corrections"] = correction_log["device_uid"].nunique() if not correction_log.empty else 0
            artifact_flag = clean_m.get("power_artifact_flag", pd.Series("", index=clean_m.index)).astype(str) if not clean_m.empty else pd.Series(dtype=str)
            excluded_mask = artifact_flag == "excluded_from_label_features"
            out["artifact_adjusted_measurement_records"] = len(artifact_log)
            out["devices_with_artifact_adjustments"] = artifact_log["device_uid"].nunique() if not artifact_log.empty else 0
            out["artifact_excluded_measurement_records"] = int(excluded_mask.sum())
            out["devices_with_artifact_exclusions"] = int(clean_m.loc[excluded_mask, "device_uid"].nunique()) if not clean_m.empty and "device_uid" in clean_m.columns else 0
            return out
        
        
        def device_time_quality(measurements: pd.DataFrame) -> pd.DataFrame:
            if measurements.empty:
                return pd.DataFrame(columns=["device_uid", "time_review_fraction_device", "power_corrected_count_device", "power_artifact_count_device"])
            work = measurements.copy()
            work["time_needs_review_num"] = pd.to_numeric(work.get("time_needs_review", 0), errors="coerce").fillna(0)
            work["is_corrected_num"] = work.get("power_correction_flag", "").astype(str).isin(["corrected", "review_corrected"]).astype(int)
            work["is_artifact_num"] = work.get("power_artifact_flag", "").astype(str).isin(["excluded_from_label_features", "imputed_for_analysis"]).astype(int)
            return (
                work.groupby("device_uid")
                .agg(
                    time_review_fraction_device=("time_needs_review_num", "mean"),
                    power_corrected_count_device=("is_corrected_num", "sum"),
                    power_artifact_count_device=("is_artifact_num", "sum"),
                    measurement_count_device=("device_uid", "count"),
                )
                .reset_index()
            )
        
        
        def summarize_reliability_subset(df: pd.DataFrame, scenario: str, group_value: str = "all") -> dict[str, Any]:
            if df.empty:
                return {"scenario": scenario, "temperature_group": group_value, "n": 0}
            event = pd.to_numeric(df["event_observed"], errors="coerce").fillna(0)
            time = pd.to_numeric(df["analysis_time_h"], errors="coerce")
            return {
                "scenario": scenario,
                "temperature_group": group_value,
                "n": int(len(df)),
                "events": int(event.sum()),
                "censored": int(len(df) - event.sum()),
                "event_fraction": float(event.mean()) if len(df) else "",
                "median_analysis_time_h": float(time.median()) if time.notna().any() else "",
                "human_review_records": int(pd.to_numeric(df.get("needs_human_review", 0), errors="coerce").fillna(0).sum()),
            }
        
        
        def reliability_scenarios(rel_main: pd.DataFrame, ai: pd.DataFrame, measurements: pd.DataFrame) -> pd.DataFrame:
            if rel_main.empty:
                return pd.DataFrame()
            time_quality = device_time_quality(measurements)
            ai_extra_cols = [
                col
                for col in [
                    "device_uid",
                    "review_reasons",
                    "power_corrected_count",
                    "power_correction_review_count",
                    "power_artifact_excluded_count",
                    "power_artifact_review_count",
                ]
                if col in ai.columns
            ]
            work = rel_main.merge(ai[ai_extra_cols], on="device_uid", how="left") if ai_extra_cols else rel_main.copy()
            work = work.merge(time_quality, on="device_uid", how="left")
            work["power_corrected_count_device"] = pd.to_numeric(work.get("power_corrected_count_device", 0), errors="coerce").fillna(0)
            work["power_artifact_count_device"] = pd.to_numeric(work.get("power_artifact_count_device", 0), errors="coerce").fillna(0)
            work["time_review_fraction_device"] = pd.to_numeric(work.get("time_review_fraction_device", 0), errors="coerce").fillna(0)
            mode = work["ai_suggested_failure_mode"].astype(str)
            reasons = work.get("review_reasons", pd.Series([""] * len(work), index=work.index)).astype(str)
            scenarios = {
                "all_main_records": pd.Series(True, index=work.index),
                "exclude_nonmonotone_or_artifact_review": ~reasons.str.contains("recovery|positive_jump|artifact", case=False, regex=True),
                "exclude_human_review_records": pd.to_numeric(work.get("needs_human_review", 0), errors="coerce").fillna(0) == 0,
                "exclude_rapid_or_catastrophic": ~mode.str.contains("rapid|catastrophic|zero", case=False, regex=True),
                "exclude_burn_in_like": ~mode.str.contains("burn_in_like", case=False, regex=False),
                "exclude_recovery_or_power_increase": ~mode.str.contains("recovery_or_power_increase", case=False, regex=False),
                "exclude_power_corrected_devices": work["power_corrected_count_device"] == 0,
                "exclude_power_artifact_devices": work["power_artifact_count_device"] == 0,
                "high_time_quality_only": work["time_review_fraction_device"] < 0.4,
            }
            rows: list[dict[str, Any]] = []
            for scenario, mask in scenarios.items():
                subset = work[mask].copy()
                rows.append(summarize_reliability_subset(subset, scenario, "all"))
                for temp, group in subset.groupby("temperature_group"):
                    rows.append(summarize_reliability_subset(group, scenario, str(temp)))
            return pd.DataFrame(rows)
        
        
        FIGURE_SCENARIOS = [
            "exclude_nonmonotone_or_artifact_review",
            "exclude_human_review_records",
            "exclude_rapid_or_catastrophic",
            "exclude_burn_in_like",
            "exclude_recovery_or_power_increase",
            "exclude_power_corrected_devices",
            "exclude_power_artifact_devices",
            "high_time_quality_only",
        ]
        
        
        def clustered_scenario_differences(
            rel_main: pd.DataFrame,
            ai: pd.DataFrame,
            measurements: pd.DataFrame,
            iterations: int,
            seed: int,
        ) -> pd.DataFrame:
            """Export source-cluster bootstrap results consumed directly by Fig. 16."""
            if rel_main.empty:
                return pd.DataFrame()
            quality = device_time_quality(measurements)
            cols = [column for column in ["device_uid", "review_reasons"] if column in ai.columns]
            work = rel_main.merge(ai[cols], on="device_uid", how="left") if cols else rel_main.copy()
            work = work.merge(quality, on="device_uid", how="left")
            reasons = work.get("review_reasons", pd.Series("", index=work.index)).astype(str)
            mode = work["ai_suggested_failure_mode"].fillna("").astype(str)
            corrected = pd.to_numeric(work.get("power_corrected_count_device", 0), errors="coerce").fillna(0)
            artifacts = pd.to_numeric(work.get("power_artifact_count_device", 0), errors="coerce").fillna(0)
            time_review = pd.to_numeric(work.get("time_review_fraction_device", 0), errors="coerce").fillna(0)
            masks = {
                "exclude_nonmonotone_or_artifact_review": ~reasons.str.contains("recovery|positive_jump|artifact", case=False, regex=True).to_numpy(),
                "exclude_human_review_records": pd.to_numeric(work["needs_human_review"], errors="coerce").fillna(0).eq(0).to_numpy(),
                "exclude_rapid_or_catastrophic": ~mode.str.contains("rapid|catastrophic|zero", case=False, regex=True).to_numpy(),
                "exclude_burn_in_like": ~mode.str.contains("burn_in_like", case=False, regex=False).to_numpy(),
                "exclude_recovery_or_power_increase": ~mode.str.contains("recovery_or_power_increase", case=False, regex=False).to_numpy(),
                "exclude_power_corrected_devices": corrected.eq(0).to_numpy(),
                "exclude_power_artifact_devices": artifacts.eq(0).to_numpy(),
                "high_time_quality_only": time_review.lt(0.4).to_numpy(),
            }
            sources_by_row = work["file_id"].astype(str).to_numpy()
            sources = np.array(sorted(set(sources_by_row)))
            source_indices = {source: np.flatnonzero(sources_by_row == source) for source in sources}
            events = pd.to_numeric(work["event_observed"], errors="coerce").fillna(0).to_numpy(float)
            rng = np.random.default_rng(seed)
            draws = {scenario: [] for scenario in FIGURE_SCENARIOS}
            for _ in range(iterations):
                sampled_sources = rng.choice(sources, size=len(sources), replace=True)
                indices = np.concatenate([source_indices[source] for source in sampled_sources])
                baseline = float(events[indices].mean())
                for scenario in FIGURE_SCENARIOS:
                    retained = indices[masks[scenario][indices]]
                    if len(retained):
                        draws[scenario].append(float(events[retained].mean() - baseline))
            baseline_fraction = float(events.mean())
            rows = []
            for scenario in FIGURE_SCENARIOS:
                mask = masks[scenario]
                values = np.asarray(draws[scenario])
                fraction = float(events[mask].mean())
                rows.append(
                    {
                        "scenario": scenario,
                        "n": int(mask.sum()),
                        "events": int(events[mask].sum()),
                        "difference": fraction - baseline_fraction,
                        "ci_low": float(np.quantile(values, 0.025)),
                        "ci_high": float(np.quantile(values, 0.975)),
                        "bootstrap_draws": iterations,
                        "seed": seed,
                    }
                )
            return pd.DataFrame(rows)
        
        
        def endpoint_state(status: Any) -> str:
            return {
                "failure_observed": "E",
                "early_failure_observed": "E",
                "failure_observed_with_recovery": "R",
                "right_censored": "C",
            }.get(str(status), "NA")
        
        
        def target_uncertainty_transition_counts(
            passport: pd.DataFrame, all_definitions: pd.DataFrame
        ) -> pd.DataFrame:
            """Export the exact state-transition counts used by the four Fig. 18 panels."""
            sensitive = passport[
                pd.to_numeric(passport["four_state_definition_change"], errors="coerce").fillna(0).eq(1)
            ]
            device_ids = sensitive["device_uid"].astype(str).tolist()
            subset = all_definitions[all_definitions["device_uid"].astype(str).isin(device_ids)].copy()
            subset["failure_threshold_ratio"] = pd.to_numeric(
                subset["failure_threshold_ratio"], errors="coerce"
            )
            subset["state"] = subset["event_status"].map(endpoint_state)
            state_index = subset.set_index(
                ["device_uid", "p0_definition", "failure_threshold_ratio"]
            )["state"]
            main_state = {
                uid: str(state_index.loc[(uid, "p0_best_available", 0.8)]) for uid in device_ids
            }
            rows = []
            for p0_definition in ["p0_meta", "p0_early_median5", "p0_post_stabilization", "p0_best_available"]:
                for threshold in [0.5, 0.7, 0.8]:
                    for main in ["E", "R", "C", "NA"]:
                        for alternative in ["E", "R", "C", "NA"]:
                            count = sum(
                                main_state[uid] == main
                                and str(state_index.loc[(uid, p0_definition, threshold)]) == alternative
                                for uid in device_ids
                            )
                            rows.append(
                                {
                                    "p0_definition": p0_definition,
                                    "failure_threshold_ratio": threshold,
                                    "main_state": main,
                                    "alternative_state": alternative,
                                    "device_count": int(count),
                                    "sensitive_devices": len(device_ids),
                                }
                            )
            return pd.DataFrame(rows)
        
        
        def endpoint_sensitivity_prevalence(passport: pd.DataFrame) -> pd.DataFrame:
            """Export temperature summaries and Wilson intervals used by Fig. 19."""
            work = passport.copy()
            temperature = pd.to_numeric(work["aging_temperature_C"], errors="coerce")
            work["temperature"] = temperature.map(
                lambda value: "Temperature unresolved" if pd.isna(value) else f"{int(value)} C"
            )
            work["changed"] = pd.to_numeric(
                work["four_state_definition_change"], errors="coerce"
            ).fillna(0).astype(int)
            summary = work.groupby("temperature", as_index=False).agg(
                changes=("changed", "sum"), total=("device_uid", "size")
            )
            order = ["50 C", "90 C", "100 C", "110 C", "120 C", "Temperature unresolved"]
            summary["display_order"] = summary["temperature"].map(
                {name: index for index, name in enumerate(order)}
            )
            summary = summary.sort_values("display_order").reset_index(drop=True)
            summary["fraction"] = summary["changes"] / summary["total"]
            z = 1.959963984540054
            lows, highs = [], []
            for row in summary.itertuples():
                fraction = row.changes / row.total
                denominator = 1 + z * z / row.total
                center = (fraction + z * z / (2 * row.total)) / denominator
                half = z * np.sqrt(
                    fraction * (1 - fraction) / row.total + z * z / (4 * row.total * row.total)
                ) / denominator
                lows.append(center - half)
                highs.append(center + half)
            summary["low"] = lows
            summary["high"] = highs
            summary["overall_changes"] = int(work["changed"].sum())
            summary["overall_total"] = len(work)
            return summary
        
        
        def p0_threshold_variability(sensitivity: pd.DataFrame) -> pd.DataFrame:
            if sensitivity.empty:
                return pd.DataFrame()
            work = sensitivity.copy()
            work["temperature_group"] = work["temperature_group"].map(norm_temp)
            work["event_fraction"] = pd.to_numeric(work["event_fraction"], errors="coerce")
            rows = []
            for temp, group in work.groupby("temperature_group"):
                valid = group.dropna(subset=["event_fraction"])
                if valid.empty:
                    continue
                rows.append(
                    {
                        "temperature_group": temp,
                        "settings_count": int(len(valid)),
                        "min_event_fraction": float(valid["event_fraction"].min()),
                        "max_event_fraction": float(valid["event_fraction"].max()),
                        "event_fraction_range": float(valid["event_fraction"].max() - valid["event_fraction"].min()),
                        "median_event_fraction": float(valid["event_fraction"].median()),
                    }
                )
            return pd.DataFrame(rows).sort_values("temperature_group")
        
        
        def temperature_rank_instability(sensitivity: pd.DataFrame) -> pd.DataFrame:
            if sensitivity.empty:
                return pd.DataFrame()
            work = sensitivity.copy()
            work["temperature_group"] = work["temperature_group"].map(norm_temp)
            work["event_fraction"] = pd.to_numeric(work["event_fraction"], errors="coerce")
            rows = []
            for (p0_definition, threshold), group in work.groupby(["p0_definition", "failure_threshold_ratio"]):
                valid = group.dropna(subset=["event_fraction"]).copy()
                if valid.empty:
                    continue
                valid = valid.sort_values("event_fraction", ascending=False)
                worst = valid.iloc[0]
                best = valid.iloc[-1]
                rank_map = {temp: rank + 1 for rank, temp in enumerate(valid["temperature_group"])}
                rows.append(
                    {
                        "p0_definition": p0_definition,
                        "failure_threshold_ratio": threshold,
                        "worst_temperature_by_event_fraction": worst["temperature_group"],
                        "worst_event_fraction": float(worst["event_fraction"]),
                        "best_temperature_by_event_fraction": best["temperature_group"],
                        "best_event_fraction": float(best["event_fraction"]),
                        "rank_of_120C": rank_map.get("120", ""),
                        "rank_of_90C": rank_map.get("90", ""),
                        "rank_of_100C": rank_map.get("100", ""),
                        "rank_of_50C": rank_map.get("50", ""),
                        "rank_of_110C": rank_map.get("110", ""),
                    }
                )
            return pd.DataFrame(rows)
        
        
        def write_report(
            path: Path,
            correction: pd.DataFrame,
            scenarios: pd.DataFrame,
            variability: pd.DataFrame,
            rank_instability: pd.DataFrame,
        ) -> None:
            all_scenarios = scenarios[scenarios["temperature_group"] == "all"].copy() if not scenarios.empty else pd.DataFrame()
            text = f"""# ESWA Ablation and Robustness Report
        
        ## Purpose
        
        This report adds the ablation evidence needed to support the ESWA framing. It checks whether conclusions depend on data correction, human-review-sensitive curves, nonmonotone or artifact-sensitive records, rapid or catastrophic candidates, time-quality flags, and P0/failure-threshold choices.
        
        ## Data-correction Ablation
        
        ```text
        {correction.to_string(index=False) if not correction.empty else '(not available)'}
        ```
        
        Interpretation: the correction layer should reduce implausible high-power records before the AI module sees the curves. The raw values are preserved separately, so this is auditable rather than silent cleaning.
        
        ## Reliability Scenario Ablations
        
        Overall scenario summary:
        
        ```text
        {all_scenarios.to_string(index=False) if not all_scenarios.empty else '(not available)'}
        ```
        
        Temperature-level scenario rows are written to the target-governance ablation output.
        
        ## P0 and Failure-threshold Variability
        
        ```text
        {variability.to_string(index=False) if not variability.empty else '(not available)'}
        ```
        
        ## Temperature-rank Instability
        
        ```text
        {rank_instability.to_string(index=False) if not rank_instability.empty else '(not available)'}
        ```
        
        ## Manuscript Use
        
        Use this section to argue that the proposed system is necessary because a naive temperature-only conclusion is not stable under realistic data-quality and event-definition changes. The correct claim is not that one temperature group is physically superior; the claim is that quality-aware and mode-aware reliability assessment prevents overconfident conclusions from imperfect records.
        """
            path.write_text(text, encoding="utf-8")
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Ablation and robustness analysis for ESWA-grade VCSEL expert-system evidence.")
            parser.add_argument("--processed-dir", type=Path, default=Path("outputs") / "processed")
            parser.add_argument("--analysis-dir", type=Path, default=Path("outputs") / "analysis")
            parser.add_argument("--bootstrap-draws", type=int, default=20_000)
            parser.add_argument("--bootstrap-seed", type=int, default=20260711)
            args = parser.parse_args()
            if args.bootstrap_draws < 1000:
                raise ValueError("At least 1000 source-cluster bootstrap draws are required.")
        
            rel_main = read_csv(args.analysis_dir / "reliability_dataset_main.csv")
            ai = read_csv(args.processed_dir / "ai_device_classification.csv")
            measurements = read_csv(args.processed_dir / "measurement_table.csv")
            sensitivity = read_csv(args.analysis_dir / "sensitivity_event_fraction_by_p0_threshold_temperature.csv")
            passport = read_csv(args.analysis_dir / "reliability_evidence_passport.csv")
            all_definitions = read_csv(args.analysis_dir / "reliability_dataset_all_definitions.csv")
        
            correction = correction_ablation(args.processed_dir)
            scenarios = reliability_scenarios(rel_main, ai, measurements)
            clustered = clustered_scenario_differences(
                rel_main, ai, measurements, args.bootstrap_draws, args.bootstrap_seed
            )
            variability = p0_threshold_variability(sensitivity)
            rank_instability = temperature_rank_instability(sensitivity)
            transitions = target_uncertainty_transition_counts(passport, all_definitions)
            prevalence = endpoint_sensitivity_prevalence(passport)
        
            args.analysis_dir.mkdir(parents=True, exist_ok=True)
            correction.to_csv(args.analysis_dir / "target_governance_ablation_quality_correction.csv", index=False, encoding="utf-8-sig")
            scenarios.to_csv(args.analysis_dir / "target_governance_ablation_reliability_scenarios.csv", index=False, encoding="utf-8-sig")
            clustered.to_csv(
                args.analysis_dir / "reliability_scenario_cluster_bootstrap.csv",
                index=False,
                encoding="utf-8-sig",
            )
            variability.to_csv(args.analysis_dir / "target_governance_ablation_p0_threshold_variability.csv", index=False, encoding="utf-8-sig")
            rank_instability.to_csv(args.analysis_dir / "target_governance_ablation_temperature_rank_instability.csv", index=False, encoding="utf-8-sig")
            transitions.to_csv(
                args.analysis_dir / "target_uncertainty_transition_counts.csv",
                index=False,
                encoding="utf-8-sig",
            )
            prevalence.to_csv(
                args.analysis_dir / "endpoint_sensitivity_prevalence.csv",
                index=False,
                encoding="utf-8-sig",
            )
            write_report(args.analysis_dir / "target_governance_ablation_report.md", correction, scenarios, variability, rank_instability)
        
            print(f"correction_rows={len(correction)}")
            print(f"scenario_rows={len(scenarios)}")
            print(f"clustered_scenario_rows={len(clustered)}")
            print(f"variability_rows={len(variability)}")
            print(f"rank_instability_rows={len(rank_instability)}")
            print(f"transition_rows={len(transitions)}")
            print(f"prevalence_rows={len(prevalence)}")
            print(f"report={(args.analysis_dir / 'target_governance_ablation_report.md').resolve()}")
        main()


def run_rule_trace(stage_args: list[str]) -> None:
    """Run the embedded build_device_rule_trace.py stage with an isolated command line."""
    with isolated_argv("rule_trace", stage_args):
        import argparse
        import json
        import math
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        
        ROOT = Path(__file__).resolve().parents[1]
        REGISTRY_PATH = ROOT / "data" / "qaes_vcsel_rule_registry_v2.json"
        ANALYSIS = ROOT / "outputs" / "analysis"
        PROCESSED = ROOT / "outputs" / "processed"
        REQUIRED_DEVICE_RULES = {"TR-1", "BI-1", "EF-1", "P0-1", "EVT-1", "RCV-1", "FM-1", "PAS-1", "AR-1"}
        
        
        def load_registry() -> dict[str, Any]:
            """Load and validate the frozen registry without sibling imports."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            if registry.get("status") != "frozen-retrospective" or registry.get("version") != "2.2.3":
                raise ValueError("Unexpected QAES-VCSEL rule registry.")
            return registry
        
        
        def rule(rule_id: str) -> dict[str, Any]:
            return dict(load_registry()["rules"][rule_id])
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            return dict(rule(rule_id).get("parameters", {}))
        
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            return pd.read_csv(path, encoding="utf-8-sig")
        
        
        def as_int(value: Any) -> int:
            try:
                return int(float(value))
            except (TypeError, ValueError):
                return 0
        
        
        def clean(value: Any) -> str:
            if value is None or (isinstance(value, float) and pd.isna(value)):
                return ""
            return str(value)
        
        
        def add_row(rows: list[dict[str, Any]], sequence: int, **kwargs: Any) -> int:
            registry = load_registry()
            base = {
                "trace_sequence": sequence,
                "registry_id": registry["registry_id"],
                "registry_version": registry["version"],
                "device_uid": "",
                "rule_family": "",
                "rule_id": "",
                "priority": "",
                "trigger_value": "",
                "conflict_set": "",
                "source_evidence": "",
                "action": "",
                "resulting_state": "",
                "output_artifact": "",
                "output_row_key": "",
                "review_flag": 0,
                "trace_note": "",
            }
            base.update(kwargs)
            rows.append(base)
            return sequence + 1
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Export the device-level frozen rule trace.")
            parser.parse_args()
            rows: list[dict[str, Any]] = []
            sequence = 1
            devices = read_csv(PROCESSED / "device_table.csv")
            measurements = read_csv(PROCESSED / "measurement_table.csv")
            ai = read_csv(PROCESSED / "ai_device_classification.csv")
            all_defs = read_csv(ANALYSIS / "reliability_dataset_all_definitions.csv")
            passport = read_csv(ANALYSIS / "reliability_evidence_passport.csv")
            corrections = read_csv(PROCESSED / "measurement_correction_log.csv")
            artifacts = read_csv(PROCESSED / "measurement_artifact_log.csv")
            predictions = read_csv(ANALYSIS / "landmark_primary_group_predictions.csv")
            if devices.empty or ai.empty or all_defs.empty or passport.empty:
                raise SystemExit("Trace construction requires device, rule-label, endpoint, and passport outputs.")
        
            device_index = devices.drop_duplicates("device_uid").set_index("device_uid", drop=False)
            ai_index = ai.drop_duplicates("device_uid").set_index("device_uid", drop=False)
            passport_index = passport.drop_duplicates("device_uid").set_index("device_uid", drop=False)
            measurement_groups = {uid: group for uid, group in measurements.groupby("device_uid", sort=False)}
        
            for uid, device in device_index.iterrows():
                group = measurement_groups.get(uid, pd.DataFrame())
                exposure = pd.to_numeric(group.get("exposure_hours", pd.Series(dtype=float)), errors="coerce")
                calendar = pd.to_numeric(group.get("calendar_hours", pd.Series(dtype=float)), errors="coerce")
                review = pd.to_numeric(group.get("time_needs_review", pd.Series(dtype=float)), errors="coerce").fillna(0)
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="time_reconstruction",
                    rule_id="TR-1",
                    priority=5,
                    trigger_value=(
                        f"measurements={len(group)};exposure_available={int(exposure.notna().sum())};"
                        f"calendar_available={int(calendar.notna().sum())};review_times={int(review.sum())}"
                    ),
                    conflict_set="exposure_hours|calendar_hours|missing_time",
                    source_evidence=f"{clean(device.get('source_file'))}|{clean(device.get('sheet'))}|oven_event_table.csv",
                    action="reconstruct_exposure_and_retain_time_quality",
                    resulting_state=f"max_exposure_h={clean(exposure.max() if exposure.notna().any() else '')}",
                    output_artifact="measurement_table.csv; oven_event_table.csv",
                    output_row_key=uid,
                    review_flag=int(review.sum() > 0),
                    trace_note="Exposure time subtracts closed oven-off intervals; precision flags remain visible.",
                )
        
            for uid, device in device_index.iterrows():
                ai_row = ai_index.loc[uid]
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="baseline_provenance",
                    rule_id="P0-1",
                    priority=20,
                    trigger_value=(
                        f"p0_meta={clean(device.get('p0_meta_mW'))};"
                        f"p0_early_median5={clean(device.get('p0_early_median5_positive_mW'))};"
                        f"p0_post_stabilization={clean(device.get('p0_post_stabilization_mW'))};"
                        f"p0_first_provenance_only={clean(device.get('p0_first_mW'))}"
                    ),
                    conflict_set="p0_meta|p0_early_median5|p0_post_stabilization|p0_best_available",
                    source_evidence=f"{clean(device.get('source_file'))}|{clean(device.get('sheet'))}|{clean(device.get('source_column'))}",
                    action=f"retain_all_and_select_main:{clean(ai_row.get('p0_ai_definition'))}",
                    resulting_state=f"p0_mW={clean(ai_row.get('p0_ai_mW'))}",
                    output_artifact="device_table.csv; reliability_dataset_all_definitions.csv",
                    output_row_key=uid,
                    review_flag=int(clean(device.get("burn_in_stabilization_status")) in {"unresolved_within_burn_in_cap", "insufficient_early_data"}),
                    trace_note="The first reading is provenance only; the main P0 is post-stabilization or an early-window median.",
                )
        
            for rec in corrections.itertuples(index=False):
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=rec.device_uid,
                    rule_family="measurement_quality",
                    rule_id="QX-1",
                    priority=10,
                    trigger_value=f"raw={rec.raw_power_mW};expected={rec.expected_mW};p0={rec.p0_reference_mW}",
                    conflict_set="preserve_raw|candidate_substitution|review_unfixed",
                    source_evidence=f"{rec.source_file}|{rec.sheet}|{rec.source_cell}",
                    action=f"preserve_raw_and_write_downstream:{rec.method}",
                    resulting_state=f"analysis_power_mW={rec.corrected_power_mW}",
                    output_artifact="measurement_correction_log.csv; measurement_table.csv",
                    output_row_key=f"{rec.device_uid}|{rec.source_cell}",
                    review_flag=as_int(rec.requires_review),
                    trace_note=clean(rec.reason),
                )
        
            for rec in artifacts.itertuples(index=False):
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=rec.device_uid,
                    rule_family="measurement_quality",
                    rule_id="QX-2",
                    priority=30,
                    trigger_value=f"ratio={rec.ratio_to_p0};previous={rec.previous_ratio};next={rec.next_ratio}",
                    conflict_set="preserve_raw|neighbor_supported_analysis_value|exclude_from_features",
                    source_evidence=f"{rec.source_file}|{rec.sheet}|{rec.source_cell}",
                    action=clean(rec.downstream_policy),
                    resulting_state=(
                        f"endpoint_power_mW=raw_preserved;"
                        f"analysis_power_mW={clean(getattr(rec, 'analysis_power_mW', ''))}"
                    ),
                    output_artifact="measurement_artifact_log.csv; measurement_table.csv",
                    output_row_key=f"{rec.device_uid}|{rec.source_cell}",
                    review_flag=as_int(rec.requires_review),
                    trace_note=clean(rec.reason),
                )
        
            for rec in all_defs.itertuples(index=False):
                evidence_cell = clean(getattr(rec, "event_source_cell", "")) or clean(getattr(rec, "censor_source_cell", ""))
                state = "E" if rec.event_status in {"failure_observed", "early_failure_observed"} else "R" if rec.event_status == "failure_observed_with_recovery" else "C" if rec.event_status == "right_censored" else "NA"
                pass_row = passport_index.loc[rec.device_uid]
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=rec.device_uid,
                    rule_family="endpoint_construction",
                    rule_id="EVT-1",
                    priority=40,
                    trigger_value=f"p0={rec.p0_definition};threshold={rec.failure_threshold_ratio};status={rec.event_status}",
                    conflict_set="E|R|C|NA",
                    source_evidence=f"{rec.file_id}|{rec.sheet}|{rec.source_column}|{evidence_cell}",
                    action="assign_endpoint_state",
                    resulting_state=f"state={state};inspection_time_h={clean(getattr(rec, 'analysis_time_h', ''))}",
                    output_artifact="reliability_dataset_all_definitions.csv",
                    output_row_key=f"{rec.device_uid}|{rec.p0_definition}|{rec.failure_threshold_ratio}",
                    review_flag=as_int(pass_row.get("four_state_definition_change", 0)),
                    trace_note="Raw endpoint alternatives are retained across all 12 definitions.",
                )

            for uid, rec in ai_index.iterrows():
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="early_stabilization",
                    rule_id="BI-1",
                    priority=15,
                    trigger_value=(
                        f"early_drop={clean(rec.get('burn_in_early_drop_ratio'))};"
                        f"stabilization_time_h={clean(rec.get('burn_in_stabilization_time_h'))};"
                        f"cap_h={clean(rec.get('burn_in_cap_h'))};"
                        f"stable_window_points={clean(rec.get('burn_in_stable_window_point_count'))};"
                        f"stable_window_spread={clean(rec.get('burn_in_stable_window_relative_spread'))};"
                        f"status={clean(rec.get('burn_in_stabilization_status'))}"
                    ),
                    conflict_set="burn_in_like_early_stabilization|not_detected",
                    source_evidence=f"{clean(rec.get('file_id'))}|{clean(rec.get('source_file'))}",
                    action="identify_bounded_stable_window_before_p0_selection",
                    resulting_state=(
                        f"burn_in_like_flag={clean(rec.get('burn_in_like_flag'))};"
                        f"p0_post_stabilization={clean(device_index.loc[uid].get('p0_post_stabilization_mW'))}"
                    ),
                    output_artifact="device_table.csv; ai_device_classification.csv",
                    output_row_key=uid,
                    review_flag=as_int(rec.get("burn_in_like_flag", 0)),
                    trace_note="Stabilization must be confirmed no later than the 240 h archive-specific cap; no physical burn-in diagnosis is made.",
                )

            for uid, rec in ai_index.iterrows():
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="bounded_early_failure",
                    rule_id="EF-1",
                    priority=17,
                    trigger_value=(
                        f"cap_h={clean(rec.get('burn_in_cap_h'))};"
                        f"event_time_h={clean(rec.get('early_failure_time_h'))};"
                        f"confirmation_time_h={clean(rec.get('early_failure_confirmation_time_h'))};"
                        f"subtype={clean(rec.get('early_failure_subtype'))};"
                        f"timing={clean(rec.get('early_loss_timing_certainty'))}"
                    ),
                    conflict_set="early_failure|acceptable_stabilization|unresolved",
                    source_evidence=f"{clean(rec.get('file_id'))}|{clean(rec.get('source_file'))}",
                    action="preserve_pre_p0_early_loss_and_prevent_low_p0_normalization",
                    resulting_state=f"early_failure_flag={clean(rec.get('early_failure_flag'))}",
                    output_artifact="device_table.csv; ai_device_classification.csv; reliability_dataset_all_definitions.csv",
                    output_row_key=uid,
                    review_flag=as_int(rec.get("early_failure_flag", 0)),
                    trace_note="Operational early-loss screen; not an infant-mortality mechanism diagnosis.",
                )

            for uid, rec in ai_index.iterrows():
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="recovery_and_power_increase",
                    rule_id="RCV-1",
                    priority=47,
                    trigger_value=(
                        f"recovery={clean(rec.get('max_recovery_after_min'))};"
                        f"final_gain={clean(rec.get('final_gain_from_min_ratio'))};"
                        f"net_change={clean(rec.get('net_power_change_ratio'))};"
                        f"post_min_points={clean(rec.get('post_minimum_point_count'))}"
                    ),
                    conflict_set="recovery|net_increase|not_detected",
                    source_evidence=f"{clean(rec.get('file_id'))}|{clean(rec.get('source_file'))}",
                    action="evaluate_sustained_recovery_or_power_increase",
                    resulting_state=(
                        f"flag={clean(rec.get('recovery_or_power_increase_flag'))};"
                        f"kind={clean(rec.get('recovery_pattern_kind'))}"
                    ),
                    output_artifact="ai_device_classification.csv",
                    output_row_key=uid,
                    review_flag=as_int(rec.get("recovery_or_power_increase_flag", 0)),
                    trace_note="Observable increase can reflect recovery, measurement conditions, or protocol changes.",
                )
        
            for uid, rec in ai_index.iterrows():
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="curve_pattern",
                    rule_id="FM-1",
                    priority=50,
                    trigger_value=(
                        f"min_ratio={clean(rec.get('min_ratio'))};slope={clean(rec.get('slope_ratio_per_1000h'))};"
                        f"largest_drop={clean(rec.get('largest_drop_step'))};change_point={clean(rec.get('change_point_score'))}"
                    ),
                    conflict_set="progressive_or_censored|rapid_or_catastrophic|change_point_or_midlife|burn_in_like|recovery_or_power_increase|insufficient",
                    source_evidence=f"{clean(rec.get('file_id'))}|{clean(rec.get('source_file'))}",
                    action="assign_observable_curve_pattern",
                    resulting_state=f"pattern={clean(rec.get('ai_suggested_failure_mode'))};confidence={clean(rec.get('ai_confidence'))}",
                    output_artifact="ai_device_classification.csv",
                    output_row_key=uid,
                    review_flag=as_int(rec.get("needs_human_review", 0)),
                    trace_note=clean(rec.get("review_reasons")),
                )
        
            score_weights = rule("PAS-1")["weights"]
            for uid, rec in passport_index.iterrows():
                component_text = ";".join(
                    f"{name}={clean(rec.get('passport_component_' + name, ''))}" for name in score_weights
                )
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=uid,
                    rule_family="evidence_passport",
                    rule_id="PAS-1",
                    priority=60,
                    trigger_value=component_text,
                    conflict_set="low|medium|high",
                    source_evidence=f"{clean(rec.get('file_id'))}|{clean(rec.get('sheet'))}|{clean(rec.get('source_column'))}",
                    action="compute_pre_review_audit_score",
                    resulting_state=f"score={clean(rec.get('decision_vulnerability_score'))};level={clean(rec.get('decision_vulnerability_level'))}",
                    output_artifact="reliability_evidence_passport.csv",
                    output_row_key=uid,
                    review_flag=int(clean(rec.get("decision_vulnerability_level")) == "high"),
                    trace_note=clean(rec.get("decision_vulnerability_reasons")),
                )
        
            budget = float(parameters("AR-1")["primary_budget"])
            ranked = passport.sort_values(["decision_vulnerability_score", "device_uid"], ascending=[False, True]).reset_index(drop=True)
            selected_n = int(math.ceil(budget * len(ranked)))
            for rank, rec in ranked.iterrows():
                selected = int(rank < selected_n)
                sequence = add_row(
                    rows,
                    sequence,
                    device_uid=rec.device_uid,
                    rule_family="review_allocation",
                    rule_id="AR-1",
                    priority=70,
                    trigger_value=f"score={rec.decision_vulnerability_score};rank={rank + 1};budget={budget}",
                    conflict_set="review|defer",
                    source_evidence=f"passport:{rec.device_uid}",
                    action="review" if selected else "defer",
                    resulting_state=f"selected_at_primary_budget={selected}",
                    output_artifact="device_rule_trace.csv",
                    output_row_key=rec.device_uid,
                    review_flag=selected,
                    trace_note="Allocation is an inspectable rule and not a validated efficiency model.",
                )
        
            lmb = parameters("LMB-1")
            if not predictions.empty:
                primary = predictions[predictions["feature_set"].astype(str) == str(lmb["primary_feature_set"])]
                for rec in primary.itertuples(index=False):
                    sequence = add_row(
                        rows,
                        sequence,
                        device_uid=rec.device_uid,
                        rule_family="landmark_stress_test",
                        rule_id="LMB-1",
                        priority=80,
                        trigger_value=(
                            f"landmark={lmb['primary_landmark_h']};horizon={lmb['primary_horizon_h']};"
                            f"source_grouped_fold={rec.fold}"
                        ),
                        conflict_set="cross_by_horizon|not_cross_by_horizon",
                        source_evidence=f"held_out_source={rec.file_id}",
                        action="generate_held_out_risk_score",
                        resulting_state=f"truth={rec.truth};risk={rec.risk_score}",
                        output_artifact="landmark_primary_group_predictions.csv",
                        output_row_key=f"{rec.device_uid}|fold_{rec.fold}",
                        review_flag=0,
                        trace_note="Censoring-filtered retrospective ranking stress test.",
                    )
        
            trace = pd.DataFrame(rows).sort_values(["device_uid", "priority", "output_row_key", "rule_id"]).reset_index(drop=True)
            trace["trace_sequence"] = np.arange(1, len(trace) + 1)
            ANALYSIS.mkdir(parents=True, exist_ok=True)
            trace_path = ANALYSIS / "device_rule_trace.csv"
            trace.to_csv(trace_path, index=False, encoding="utf-8-sig")
        
            present = trace.groupby("device_uid")["rule_id"].agg(lambda values: set(values))
            completeness_rows = []
            for uid in device_index.index:
                found = present.get(uid, set())
                missing = sorted(REQUIRED_DEVICE_RULES - found)
                completeness_rows.append(
                    {
                        "device_uid": uid,
                        "required_rule_families": len(REQUIRED_DEVICE_RULES),
                        "present_rule_families": len(REQUIRED_DEVICE_RULES - set(missing)),
                        "complete": int(not missing),
                        "missing_rule_ids": "|".join(missing),
                    }
                )
            completeness = pd.DataFrame(completeness_rows)
            completeness.to_csv(ANALYSIS / "device_trace_completeness.csv", index=False, encoding="utf-8-sig")
            summary = (
                trace.groupby("rule_id")
                .agg(trace_rows=("device_uid", "size"), devices=("device_uid", "nunique"), review_flags=("review_flag", "sum"))
                .reset_index()
            )
            summary.to_csv(ANALYSIS / "rule_trace_summary.csv", index=False, encoding="utf-8-sig")
            if not completeness["complete"].eq(1).all():
                raise RuntimeError("At least one device lacks a required trace family.")
            print(f"rows={len(trace)}")
            print(f"complete_devices={int(completeness['complete'].sum())}/{len(completeness)}")
            print(f"trace={trace_path.resolve()}")
        main()


def run_system_comparison(stage_args: list[str]) -> None:
    """Run the embedded system_level_comparison.py stage with an isolated command line."""
    with isolated_argv("system_comparison", stage_args):
        """Compare raw, quality-aware, ensemble, and rule-trace system layers."""
        
        import argparse
        import json
        import tempfile
        from collections import defaultdict
        from datetime import datetime
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        
        REGISTRY_PATH = Path(__file__).resolve().parents[1] / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def load_registry() -> dict[str, Any]:
            """Load and validate the frozen registry without sibling imports."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            if registry.get("status") != "frozen-retrospective" or registry.get("version") != "2.2.3":
                raise ValueError("Unexpected QAES-VCSEL rule registry.")
            return registry
        
        
        def parameters(rule_id: str) -> dict[str, Any]:
            return dict(load_registry()["rules"][rule_id].get("parameters", {}))
        
        
        P0 = parameters("P0-1")
        EVT = parameters("EVT-1")
        CATASTROPHIC_RATIO = float(EVT["catastrophic_ratio"])
        RECOVERY_MARGIN = float(EVT["recovery_margin"])
        EARLY_WINDOW_HOURS = float(EVT["early_window_h"])
        
        
        def parse_float(value: Any) -> float | None:
            if value is None or value == "":
                return None
            try:
                return float(value)
            except (TypeError, ValueError):
                return None
        
        def parse_datetime(value: str) -> datetime | None:
            if not value:
                return None
            for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    pass
            return None
        
        def p0_value(device: dict[str, str], p0_name: str, p0_col: str) -> float | None:
            if p0_name == "p0_best_available":
                for col in P0["best_available_order"]:
                    value = parse_float(device.get(col, ""))
                    if value is not None and value > 0:
                        return value
                return None
            value = parse_float(device.get(p0_col, ""))
            return value if value is not None and value > 0 else None
        
        def sort_measurements(rows: list[dict[str, str]]) -> list[dict[str, str]]:
            def key(row: dict[str, str]) -> tuple[float, datetime, str]:
                exposure = time_value(row)
                dt = parse_datetime(row.get("measurement_time", "")) or datetime.max
                return float("inf") if exposure is None else exposure, dt, row.get("source_cell", "")
        
            return sorted(rows, key=key)
        
        def time_value(row: dict[str, str]) -> float | None:
            exposure = parse_float(row.get("exposure_hours", ""))
            if exposure is not None:
                return exposure
            return parse_float(row.get("calendar_hours", ""))
        
        def classify_event(
            rows: list[dict[str, str]],
            p0: float,
            threshold: float,
            time_origin_h: float,
        ) -> dict[str, Any]:
            numeric = []
            for row in rows:
                power = parse_float(row.get("endpoint_power_mW", ""))
                if power is None:
                    power = parse_float(row.get("power_mW", ""))
                t = time_value(row)
                if power is None or t is None:
                    continue
                if t + 1e-9 < time_origin_h:
                    continue
                numeric.append(
                    {
                        **row,
                        "power": power,
                        "t": t,
                        "t_since_p0": max(0.0, t - time_origin_h),
                        "ratio": power / p0,
                    }
                )
        
            if not numeric:
                return {
                    "event_status": "no_numeric_measurements",
                    "failure_mode_exploratory": "not_assessed",
                    "event_source_cell": "",
                    "censor_source_cell": "",
                }
        
            first_cross_idx = None
            for idx, row in enumerate(numeric):
                if row["ratio"] <= threshold:
                    first_cross_idx = idx
                    break
        
            catastrophic = next((row for row in numeric if row["ratio"] <= CATASTROPHIC_RATIO or row["power"] == 0), None)
            last = numeric[-1]
            min_row = min(numeric, key=lambda row: row["ratio"])
        
            if first_cross_idx is None:
                return {
                    "event_status": "right_censored",
                    "failure_mode_exploratory": "progressive_or_right_censored",
                    "event_time": "",
                    "event_exposure_hours": "",
                    "event_power_mW": "",
                    "event_ratio": "",
                    "event_source_cell": "",
                    "event_confirmation_time": "",
                    "event_confirmation_exposure_hours": "",
                    "event_confirmation_source_cell": "",
                    "censor_time": last["measurement_time"],
                    "censor_exposure_hours": round(last["t"], 6),
                    "censor_source_cell": last.get("source_cell", ""),
                    "last_power_mW": last["power"],
                    "last_ratio": round(last["ratio"], 6),
                    "min_ratio": round(min_row["ratio"], 6),
                    "catastrophic_time": catastrophic["measurement_time"] if catastrophic else "",
                    "catastrophic_exposure_hours": round(catastrophic["t"], 6) if catastrophic else "",
                }
        
            event = numeric[first_cross_idx]
            after = numeric[first_cross_idx + 1 :]
            later_above = [row for row in after if row["ratio"] > threshold + RECOVERY_MARGIN]
            later_below = [row for row in after if row["ratio"] <= threshold]
            confirmation = later_below[0] if later_below else (event if event is last else None)
            confirmed = confirmation is not None
            recovered = bool(later_above)
            first_clearance_index = next(
                (idx for idx, row in enumerate(after) if row["ratio"] > threshold + RECOVERY_MARGIN),
                None,
            )
            recrossed_after_clearance = bool(
                first_clearance_index is not None
                and any(row["ratio"] <= threshold for row in after[first_clearance_index + 1 :])
            )
        
            if confirmed and not recovered:
                event_status = "failure_observed"
            elif confirmed and recovered:
                event_status = "failure_observed_with_recovery"
            else:
                event_status = "transient_or_measurement_issue"
        
            if catastrophic and catastrophic["t"] <= event["t"] + 1e-9:
                mode = "change_point_or_midlife_drop" if event["t"] > EARLY_WINDOW_HOURS else "rapid_or_catastrophic_failure"
            elif event_status == "transient_or_measurement_issue":
                mode = "other_observable_pattern"
            elif event["t"] <= EARLY_WINDOW_HOURS:
                mode = "rapid_or_catastrophic_failure"
            else:
                mode = "progressive_or_right_censored"
        
            return {
                "event_status": event_status,
                "failure_mode_exploratory": mode,
                "event_time": event["measurement_time"],
                "event_exposure_hours": round(event["t"], 6),
                "event_power_mW": event["power"],
                "event_ratio": round(event["ratio"], 6),
                "event_source_cell": event.get("source_cell", ""),
                "event_confirmation_time": confirmation["measurement_time"] if confirmation else "",
                "event_confirmation_exposure_hours": round(confirmation["t"], 6) if confirmation else "",
                "event_confirmation_source_cell": confirmation.get("source_cell", "") if confirmation else "",
                "censor_time": "",
                "censor_exposure_hours": "",
                "censor_source_cell": "",
                "last_power_mW": last["power"],
                "last_ratio": round(last["ratio"], 6),
                "min_ratio": round(min_row["ratio"], 6),
                "catastrophic_time": catastrophic["measurement_time"] if catastrophic else "",
                "catastrophic_exposure_hours": round(catastrophic["t"], 6) if catastrophic else "",
                "recovered_above_threshold_after_event": int(recovered),
                "post_event_points_below_threshold": len(later_below),
                "post_event_points_above_threshold_plus_margin": len(later_above),
                "recrossed_after_first_clearance": int(recrossed_after_clearance),
                "ended_above_threshold_plus_margin": int(last["ratio"] > threshold + RECOVERY_MARGIN),
            }
        
        
        
        ROOT = Path(__file__).resolve().parents[1]
        PROCESSED = ROOT / "outputs" / "processed"
        ANALYSIS = ROOT / "outputs" / "analysis"
        
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            return pd.read_csv(path, encoding="utf-8-sig")
        
        
        def p0_reference_time(device: dict[str, str], p0_name: str) -> float:
            if p0_name == "p0_meta":
                return 0.0
            if p0_name == "p0_early_median5":
                return parse_float(device.get("p0_early_median5_time_h", "")) or 0.0
            if p0_name == "p0_post_stabilization":
                return parse_float(device.get("p0_post_stabilization_time_h", "")) or 0.0
            return parse_float(device.get("p0_best_reference_time_h", "")) or 0.0


        def state_from_status(status: str) -> str:
            if status in {"failure_observed", "early_failure_observed"}:
                return "E"
            if status == "failure_observed_with_recovery":
                return "R"
            if status == "right_censored":
                return "C"
            return "NA"
        
        
        def reconstruct_main_endpoint(
            devices: pd.DataFrame,
            measurements: pd.DataFrame,
            label: str,
            scenario_prefix: str = "",
            early_cap_h: float | None = None,
        ) -> pd.DataFrame:
            grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
            for row in measurements.fillna("").to_dict(orient="records"):
                grouped[str(row["device_uid"])].append(row)
            threshold = float(parameters("EVT-1")["main_threshold_ratio"])
            if early_cap_h is None:
                early_cap_h = float(parameters("EF-1")["early_failure_cap_h"])
            rows = []
            for device in devices.fillna("").to_dict(orient="records"):
                uid = str(device["device_uid"])
                def field(name: str) -> Any:
                    return device.get(f"{scenario_prefix}_{name}" if scenario_prefix else name, "")

                p0 = parse_float(field("p0_best_available_mW"))
                p0_reference_h = parse_float(field("p0_best_reference_time_h")) or 0.0
                early_reference = parse_float(field("provisional_early_reference_mW"))
                early_failure = int(parse_float(field("early_failure_flag")) or 0) == 1
                result = None
                if early_failure and early_reference is not None and early_reference > 0:
                    numeric = []
                    for observation in grouped.get(uid, []):
                        t = time_value(observation)
                        power = parse_float(observation.get("endpoint_power_mW", ""))
                        if power is None:
                            power = parse_float(observation.get("power_mW", ""))
                        if t is not None and power is not None:
                            numeric.append({**observation, "t": t, "ratio": power / early_reference})
                    numeric.sort(key=lambda row: (row["t"], row.get("measurement_time", ""), row.get("source_cell", "")))
                    pair = inherited_inspection_pair(numeric, threshold, early_cap_h)
                    if pair is not None:
                        event_index, confirmation_index = pair
                        after = numeric[event_index + 1 :]
                        clearance = [idx for idx, row in enumerate(after) if row["ratio"] > threshold + RECOVERY_MARGIN]
                        recovered = bool(clearance)
                        result = {
                            "event_status": "failure_observed_with_recovery" if recovered else "early_failure_observed",
                            "event_exposure_hours": round(numeric[event_index]["t"], 6),
                            "event_confirmation_exposure_hours": round(numeric[confirmation_index]["t"], 6),
                            "recovered_above_threshold_after_event": int(recovered),
                            "post_event_points_below_threshold": sum(row["ratio"] <= threshold for row in after),
                            "post_event_points_above_threshold_plus_margin": len(clearance),
                            "recrossed_after_first_clearance": int(recovered and any(
                                row["ratio"] <= threshold for row in after[clearance[0] + 1 :])),
                            "ended_above_threshold_plus_margin": int(numeric[-1]["ratio"] > threshold + RECOVERY_MARGIN),
                        }
                if result is None:
                    if p0 is None:
                        result = {"event_status": "p0_missing_or_nonpositive"}
                    else:
                        result = classify_event(
                            sort_measurements(grouped.get(uid, [])), p0, threshold, p0_reference_h
                        )
                status = str(result.get("event_status", ""))
                event_time = pd.to_numeric(pd.Series([result.get("event_exposure_hours")]), errors="coerce").iloc[0]
                confirmation_time = pd.to_numeric(
                    pd.Series([result.get("event_confirmation_exposure_hours")]), errors="coerce"
                ).iloc[0]
                censor_time = pd.to_numeric(pd.Series([result.get("censor_exposure_hours")]), errors="coerce").iloc[0]
                state = state_from_status(status)
                rows.append(
                    {
                        "device_uid": uid,
                        f"{label}_status": status,
                        f"{label}_state": state,
                        f"{label}_analysis_time_h": event_time if np.isfinite(event_time) else censor_time,
                        f"{label}_event_confirmation_time_h": confirmation_time if np.isfinite(confirmation_time) else np.nan,
                        f"{label}_event_observed": int(state in {"E", "R"}),
                        f"{label}_p0_mW": p0 if p0 is not None else np.nan,
                        f"{label}_p0_reference_time_h": p0_reference_h if p0 is not None else np.nan,
                        f"{label}_p0_definition": field("p0_best_available_definition"),
                        **{f"{label}_{key}": result.get(key, "") for key in (
                            "recovered_above_threshold_after_event", "post_event_points_below_threshold",
                            "post_event_points_above_threshold_plus_margin", "recrossed_after_first_clearance",
                            "ended_above_threshold_plus_margin",
                        )},
                    }
                )
            return pd.DataFrame(rows)


        def standardize_endpoint(
            endpoint: pd.DataFrame,
            label: str,
            devices: pd.DataFrame,
            scenario: str,
        ) -> pd.DataFrame:
            rename = {
                f"{label}_status": "event_status",
                f"{label}_state": "endpoint_state",
                f"{label}_analysis_time_h": "analysis_time_h",
                f"{label}_event_confirmation_time_h": "event_confirmation_time_h",
                f"{label}_event_observed": "event_observed",
                f"{label}_p0_mW": "p0_mW",
                f"{label}_p0_reference_time_h": "p0_reference_time_h",
                f"{label}_p0_definition": "p0_definition",
            }
            out = endpoint.rename(columns=rename).copy()
            metadata = devices[["device_uid", "file_id", "aging_temperature_C"]].drop_duplicates("device_uid")
            out = out.merge(metadata, on="device_uid", how="left", validate="one_to_one")
            out.insert(0, "scenario", scenario)
            return out


        def kaplan_meier_curve(endpoint: pd.DataFrame, scenario: str, group_value: str) -> pd.DataFrame:
            work = endpoint[endpoint["endpoint_state"].isin(["E", "R", "C"])].copy()
            work["analysis_time_h"] = pd.to_numeric(work["analysis_time_h"], errors="coerce")
            work = work[work["analysis_time_h"].notna() & work["analysis_time_h"].gt(0)].copy()
            work["event_observed"] = pd.to_numeric(work["event_observed"], errors="coerce").fillna(0).astype(int)
            rows = [{
                "scenario": scenario,
                "temperature_group": group_value,
                "time_h": 0.0,
                "at_risk": len(work),
                "events": 0,
                "censored": 0,
                "survival": 1.0,
            }]
            survival = 1.0
            at_risk = len(work)
            for time_h in sorted(work["analysis_time_h"].unique()):
                at_time = work[work["analysis_time_h"].eq(time_h)]
                events = int(at_time["event_observed"].sum())
                censored = int(len(at_time) - events)
                if at_risk > 0 and events:
                    survival *= 1.0 - events / at_risk
                rows.append({
                    "scenario": scenario,
                    "temperature_group": group_value,
                    "time_h": float(time_h),
                    "at_risk": at_risk,
                    "events": events,
                    "censored": censored,
                    "survival": survival,
                })
                at_risk -= len(at_time)
            return pd.DataFrame(rows)


        def endpoint_summary(endpoint: pd.DataFrame, scenario: str, group_value: str) -> dict[str, Any]:
            assessable = endpoint[endpoint["endpoint_state"].isin(["E", "R", "C"])].copy()
            times = pd.to_numeric(assessable["analysis_time_h"], errors="coerce")
            events = pd.to_numeric(assessable["event_observed"], errors="coerce").fillna(0).astype(int)
            curve = kaplan_meier_curve(endpoint, scenario, group_value)
            below = curve[curve["survival"].le(0.5)]
            return {
                "scenario": scenario,
                "temperature_group": group_value,
                "assessable_devices": int(len(assessable)),
                "events": int(events.sum()),
                "right_censored": int(len(assessable) - events.sum()),
                "nonassessable_devices": int(len(endpoint) - len(assessable)),
                "event_fraction": float(events.mean()) if len(events) else np.nan,
                "maximum_followup_h": float(times.max()) if times.notna().any() else np.nan,
                "km_median_h": float(below.iloc[0]["time_h"]) if len(below) else np.nan,
            }


        def landmark_label_frame(endpoint: pd.DataFrame) -> pd.DataFrame:
            time_h = pd.to_numeric(endpoint["analysis_time_h"], errors="coerce")
            p0_value = pd.to_numeric(endpoint["p0_mW"], errors="coerce")
            p0_time = pd.to_numeric(endpoint["p0_reference_time_h"], errors="coerce")
            event = pd.to_numeric(endpoint["event_observed"], errors="coerce").fillna(0).astype(int)
            confirmation_h = pd.to_numeric(endpoint.get("event_confirmation_time_h"), errors="coerce")
            assessable = endpoint["endpoint_state"].astype(str).isin(["E", "R", "C"])
            p0_ready = p0_value.gt(0) & p0_time.notna() & p0_time.le(100.0)
            at_risk = time_h.notna() & time_h.gt(100.0)
            event_label = (
                assessable
                & p0_ready
                & at_risk
                & event.eq(1)
                & time_h.le(6000.0)
                & confirmation_h.le(6000.0)
            )
            nonevent_label = assessable & p0_ready & at_risk & (
                (event.eq(0) & time_h.ge(6000.0))
                | (event.eq(1) & (time_h.gt(6000.0) | confirmation_h.gt(6000.0)))
            )
            labeled = event_label | nonevent_label
            return pd.DataFrame(
                {
                    "device_uid": endpoint.loc[labeled, "device_uid"].astype(str),
                    "event_by_horizon": event_label.loc[labeled].astype(int).to_numpy(),
                }
            ).reset_index(drop=True)


        def landmark_label_counts(endpoint: pd.DataFrame) -> dict[str, int]:
            labels = landmark_label_frame(endpoint)
            return {
                "landmark_records": int(len(labels)),
                "landmark_events": int(labels["event_by_horizon"].sum()),
                "landmark_nonevents": int(len(labels) - labels["event_by_horizon"].sum()),
            }


        def previous_valid_time(measurements: pd.DataFrame, device_uid: str, event_time_h: float) -> float | None:
            sub = measurements[measurements["device_uid"].astype(str).eq(device_uid)].copy()
            sub["time_h"] = pd.to_numeric(sub.get("exposure_hours"), errors="coerce")
            sub["time_h"] = sub["time_h"].fillna(pd.to_numeric(sub.get("calendar_hours"), errors="coerce"))
            power_col = "endpoint_power_mW" if "endpoint_power_mW" in sub.columns else "power_mW"
            sub["power_num"] = pd.to_numeric(sub.get(power_col), errors="coerce")
            prior = sub[sub["time_h"].lt(event_time_h - 1e-9) & sub["power_num"].notna() & sub["power_num"].gt(0)]
            return float(prior["time_h"].max()) if len(prior) else None
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Compare the frozen QAES-VCSEL system layers.")
            parser.parse_args()
            registry = load_registry()
            devices = read_csv(PROCESSED / "device_table.csv")
            raw_measurements = read_csv(PROCESSED / "measurement_table_raw_extracted.csv")
            corrected_measurements = read_csv(PROCESSED / "measurement_table.csv")
            main_endpoint = read_csv(ANALYSIS / "reliability_dataset_main.csv")
            all_definitions = read_csv(ANALYSIS / "reliability_dataset_all_definitions.csv")
            passport = read_csv(ANALYSIS / "reliability_evidence_passport.csv")
            trace = read_csv(ANALYSIS / "device_rule_trace.csv")
            completeness = read_csv(ANALYSIS / "device_trace_completeness.csv")
            if any(frame.empty for frame in [devices, raw_measurements, corrected_measurements, main_endpoint, all_definitions, passport, trace, completeness]):
                raise SystemExit("System comparison requires the clean-run endpoint, passport, and trace outputs.")
        
            raw = reconstruct_main_endpoint(devices, raw_measurements, "raw_single")
            corrected = reconstruct_main_endpoint(devices, corrected_measurements, "corrected_single")
            paired = raw.merge(corrected, on="device_uid", validate="one_to_one")
            paired["state_changed_after_quality_rules"] = paired["raw_single_state"].ne(paired["corrected_single_state"]).astype(int)
            raw_time = pd.to_numeric(paired["raw_single_analysis_time_h"], errors="coerce")
            corrected_time = pd.to_numeric(paired["corrected_single_analysis_time_h"], errors="coerce")
            paired["inspection_time_changed_after_quality_rules"] = (
                raw_time.notna() & corrected_time.notna() & ~np.isclose(raw_time, corrected_time, equal_nan=True)
            ).astype(int)
            paired = paired.merge(
                passport[["device_uid", "binary_event_flip", "four_state_definition_change"]],
                on="device_uid",
                how="left",
                validate="one_to_one",
            )
            paired.to_csv(ANALYSIS / "system_endpoint_reconciliation.csv", index=False, encoding="utf-8-sig")

            curation = read_csv(ROOT / "data" / "qaes_vcsel_source_curation_v2.csv")
            correction_record_types = {"corrected_entry", "confirmed_typo", "expert_corrected"}
            replay_record_types = correction_record_types | {"isolated_zero_removed"}
            replay_ledger = curation[
                curation["record_type"].astype(str).isin(replay_record_types)
            ].copy()
            shadow_rows: list[dict[str, Any]] = []
            shadow_endpoint_comparison = pd.DataFrame()
            with tempfile.TemporaryDirectory(prefix="qaes_v221_shadow_") as temp_name:
                temp_dir = Path(temp_name)
                injected = raw_measurements.copy()
                for ledger_row in replay_ledger.fillna("").to_dict(orient="records"):
                    mask = (
                        injected["file_id"].astype(str).eq(str(ledger_row["file_id"]))
                        & injected["source_cell"].astype(str).eq(str(ledger_row["source_cell"]))
                        & injected["sheet"].astype(str).eq(str(ledger_row["sheet"]))
                    )
                    if int(mask.sum()) == 0 and ledger_row["record_type"] == "isolated_zero_removed":
                        source_cell = str(ledger_row["source_cell"])
                        source_column = "".join(character for character in source_cell if character.isalpha())
                        source_row = "".join(character for character in source_cell if character.isdigit())
                        same_sheet = (
                            injected["file_id"].astype(str).eq(str(ledger_row["file_id"]))
                            & injected["sheet"].astype(str).eq(str(ledger_row["sheet"]))
                        )
                        same_device = injected[
                            same_sheet & injected["device_uid"].astype(str).str.endswith(f"::{source_column}")
                        ]
                        source_rows = injected["source_cell"].astype(str).str.extract(r"(\d+)$", expand=False)
                        row_peer = injected[same_sheet & source_rows.eq(source_row)]
                        if same_device.empty or row_peer.empty:
                            raise AssertionError(f"Cannot reconstruct removed source cell {source_cell} for shadow replay.")
                        inserted = same_device.iloc[0].copy()
                        peer = row_peer.iloc[0]
                        for time_column in [
                            "measurement_time",
                            "calendar_hours",
                            "exposure_hours",
                            "source_time_cell",
                            "oven_event_id",
                            "is_stress_exposure",
                        ]:
                            if time_column in injected.columns:
                                inserted[time_column] = peer.get(time_column, inserted.get(time_column, ""))
                        inserted["source_cell"] = source_cell
                        injected = pd.concat([injected, inserted.to_frame().T], ignore_index=True)
                        mask = (
                            injected["file_id"].astype(str).eq(str(ledger_row["file_id"]))
                            & injected["source_cell"].astype(str).eq(source_cell)
                            & injected["sheet"].astype(str).eq(str(ledger_row["sheet"]))
                        )
                    if int(mask.sum()) != 1:
                        raise AssertionError(
                            f"Shadow replay expected one source cell for {ledger_row['file_id']} {ledger_row['source_cell']}."
                        )
                    original_value = parse_float(ledger_row.get("original_value", ""))
                    injected.loc[mask, "power_mW"] = original_value
                    injected.loc[mask, "power_raw"] = str(ledger_row.get("original_value", ""))
                    injected.loc[mask, "is_zero_power"] = int(original_value == 0) if original_value is not None else 0
                injected.to_csv(temp_dir / "measurement_table_raw_extracted.csv", index=False, encoding="utf-8-sig")
                raw_devices_for_shadow = read_csv(PROCESSED / "device_table_raw_extracted.csv")
                raw_devices_for_shadow.to_csv(temp_dir / "device_table_raw_extracted.csv", index=False, encoding="utf-8-sig")
                run_clean(["--input-dir", str(temp_dir)])

                qx1_log = read_csv(temp_dir / "measurement_correction_log.csv")
                qx2_log = read_csv(temp_dir / "measurement_artifact_log.csv")
                for ledger_row in replay_ledger.fillna("").to_dict(orient="records"):
                    source_cell = str(ledger_row["source_cell"])
                    if ledger_row["record_type"] in correction_record_types:
                        hit = qx1_log[
                            qx1_log["source_cell"].astype(str).eq(source_cell)
                            & qx1_log["source_file"].astype(str).eq(str(ledger_row["source_file"]))
                            & qx1_log["sheet"].astype(str).eq(str(ledger_row["sheet"]))
                        ]
                        proposed = parse_float(hit.iloc[0].get("corrected_power_mW", "")) if len(hit) else None
                        curated = parse_float(ledger_row.get("curated_value", ""))
                        matched = int(
                            proposed is not None and curated is not None and np.isclose(proposed, curated, rtol=0, atol=1e-9)
                        )
                        rule_id = "QX-1"
                        action = str(hit.iloc[0].get("correction_flag", "")) if len(hit) else "not_triggered"
                    else:
                        hit = qx2_log[
                            qx2_log["source_cell"].astype(str).eq(source_cell)
                            & qx2_log["source_file"].astype(str).eq(str(ledger_row["source_file"]))
                            & qx2_log["sheet"].astype(str).eq(str(ledger_row["sheet"]))
                        ]
                        proposed = parse_float(hit.iloc[0].get("analysis_power_mW", "")) if len(hit) else None
                        curated = None
                        matched = 0
                        rule_id = "QX-2"
                        action = str(hit.iloc[0].get("method", "")) if len(hit) else "not_triggered"
                    shadow_rows.append({
                        "file_id": ledger_row["file_id"],
                        "source_file": ledger_row["source_file"],
                        "sheet": ledger_row["sheet"],
                        "source_cell": source_cell,
                        "record_type": ledger_row["record_type"],
                        "original_value": ledger_row["original_value"],
                        "curated_value": ledger_row["curated_value"],
                        "shadow_rule_id": rule_id,
                        "shadow_rule_triggered": int(len(hit) > 0),
                        "shadow_action": action,
                        "shadow_candidate_score": hit.iloc[0].get("selection_score", "") if len(hit) else "",
                        "shadow_proposed_analysis_value_mW": proposed if proposed is not None else "",
                        "exact_curated_value_reproduced": matched,
                        "interpretation": (
                            "automatic QX-1 correction reproduced the expert value"
                            if rule_id == "QX-1" and matched
                            else "QX-1 triggered but did not reproduce the expert value"
                            if rule_id == "QX-1" and len(hit)
                            else "QX-2 detected and neutralized the isolated zero for analysis but did not reproduce source-cell deletion"
                            if rule_id == "QX-2" and len(hit)
                            else "frozen quality rule did not trigger"
                        ),
                    })

                shadow_devices = read_csv(temp_dir / "device_table.csv")
                shadow_measurements = read_csv(temp_dir / "measurement_table.csv")
                shadow_endpoint = reconstruct_main_endpoint(shadow_devices, shadow_measurements, "shadow")
                shadow_endpoint_comparison = corrected.merge(shadow_endpoint, on="device_uid", validate="one_to_one")
                shadow_endpoint_comparison["state_changed_shadow_vs_curated"] = shadow_endpoint_comparison[
                    "shadow_state"
                ].ne(shadow_endpoint_comparison["corrected_single_state"]).astype(int)
                curated_time = pd.to_numeric(
                    shadow_endpoint_comparison["corrected_single_analysis_time_h"], errors="coerce"
                )
                shadow_time = pd.to_numeric(shadow_endpoint_comparison["shadow_analysis_time_h"], errors="coerce")
                shadow_endpoint_comparison["analysis_time_changed_shadow_vs_curated"] = (
                    curated_time.notna().ne(shadow_time.notna())
                    | (curated_time.notna() & shadow_time.notna() & ~np.isclose(curated_time, shadow_time, equal_nan=True))
                ).astype(int)
            pd.DataFrame(shadow_rows).to_csv(
                ANALYSIS / "quality_rule_shadow_replay.csv", index=False, encoding="utf-8-sig"
            )
            shadow_frame = pd.DataFrame(shadow_rows)
            expert_numeric = shadow_frame[shadow_frame["record_type"].isin(correction_record_types)].copy()
            automatic_qx1_actions = int(len(qx1_log))
            qx1_reference_triggers = int(expert_numeric["shadow_rule_triggered"].sum())
            qx1_exact_matches = int(expert_numeric["exact_curated_value_reproduced"].sum())
            supervision_summary = pd.DataFrame([{
                "expert_numeric_corrections": int(len(expert_numeric)),
                "confirmed_typo_reference_cases": int((expert_numeric["record_type"] == "confirmed_typo").sum()),
                "expert_corrected_reference_cases": int((expert_numeric["record_type"] == "expert_corrected").sum()),
                "automatic_qx1_actions": automatic_qx1_actions,
                "expert_reference_cases_triggered": qx1_reference_triggers,
                "expert_values_exactly_reproduced": qx1_exact_matches,
                "exact_recall_against_all_expert_numeric_corrections": (
                    qx1_exact_matches / len(expert_numeric) if len(expert_numeric) else float("nan")
                ),
                "exact_precision_among_automatic_qx1_actions": (
                    qx1_exact_matches / automatic_qx1_actions if automatic_qx1_actions else float("nan")
                ),
                "interpretation": (
                    "QX-1 automates only high-confidence entry correction; other expert changes remain supervisory evidence"
                ),
            }])
            supervision_summary.to_csv(
                ANALYSIS / "quality_rule_expert_supervision_summary.csv", index=False, encoding="utf-8-sig"
            )
            shadow_endpoint_comparison.to_csv(
                ANALYSIS / "quality_rule_shadow_endpoint_comparison.csv", index=False, encoding="utf-8-sig"
            )
        
            raw_assessable = int(paired["raw_single_state"].isin(["E", "R", "C"]).sum())
            raw_events = int(paired["raw_single_state"].isin(["E", "R"]).sum())
            corrected_assessable = int(paired["corrected_single_state"].isin(["E", "R", "C"]).sum())
            corrected_events = int(paired["corrected_single_state"].isin(["E", "R"]).sum())
            trace_complete = int(pd.to_numeric(completeness["complete"], errors="coerce").fillna(0).sum())

            sensitivity_specs = {
                "frozen_max_reference_100h_240h": (
                    "",
                    "early_failure_flag",
                    "early_loss_timing_certainty",
                    "burn_in_like_flag",
                ),
                "median_reference_100h_240h": (
                    "sensitivity_median_reference",
                    "sensitivity_median_reference_early_failure_flag",
                    "sensitivity_median_reference_early_loss_timing_certainty",
                    "sensitivity_median_reference_burn_in_like_flag",
                ),
                "measurement_only_maximum_100h_240h": (
                    "sensitivity_positive_only_reference",
                    "sensitivity_positive_only_reference_early_failure_flag",
                    "sensitivity_positive_only_reference_early_loss_timing_certainty",
                    "sensitivity_positive_only_reference_burn_in_like_flag",
                ),
                "max_reference_80h_200h": (
                    "sensitivity_80h_200h",
                    "sensitivity_80h_200h_early_failure_flag",
                    "sensitivity_80h_200h_early_loss_timing_certainty",
                    "sensitivity_80h_200h_burn_in_like_flag",
                ),
                "max_reference_120h_300h": (
                    "sensitivity_120h_300h",
                    "sensitivity_120h_300h_early_failure_flag",
                    "sensitivity_120h_300h_early_loss_timing_certainty",
                    "sensitivity_120h_300h_burn_in_like_flag",
                ),
            }
            for name in ("tight", "loose"):
                prefix = f"sensitivity_stability_{name}"
                sensitivity_specs[f"stability_{name}_100h_240h"] = (
                    prefix, f"{prefix}_early_failure_flag", f"{prefix}_early_loss_timing_certainty",
                    f"{prefix}_burn_in_like_flag",
                )
            base_ef = pd.to_numeric(devices["early_failure_flag"], errors="coerce").fillna(0).astype(int)
            base_rapid = devices["early_loss_timing_certainty"].astype(str).eq("confirmed_rapid")
            base_burn = pd.to_numeric(devices["burn_in_like_flag"], errors="coerce").fillna(0).astype(int)
            scenario_endpoints: dict[str, pd.DataFrame] = {}
            endpoint_tables: list[pd.DataFrame] = []
            endpoint_summary_rows: list[dict[str, Any]] = []
            endpoint_km_tables: list[pd.DataFrame] = []
            frozen_endpoint: pd.DataFrame | None = None
            scenario_caps = {"sensitivity_80h_200h": 200.0, "sensitivity_120h_300h": 300.0}
            for scenario, (prefix, _, _, _) in sensitivity_specs.items():
                replay = reconstruct_main_endpoint(
                    devices,
                    corrected_measurements,
                    "scenario",
                    scenario_prefix=prefix,
                    early_cap_h=scenario_caps.get(prefix),
                )
                endpoint = standardize_endpoint(replay, "scenario", devices, scenario)
                if frozen_endpoint is None:
                    frozen_endpoint = endpoint.copy()
                frozen_compare = frozen_endpoint[[
                    "device_uid",
                    "endpoint_state",
                    "analysis_time_h",
                    "p0_mW",
                ]].rename(columns={
                    "endpoint_state": "frozen_endpoint_state",
                    "analysis_time_h": "frozen_analysis_time_h",
                    "p0_mW": "frozen_p0_mW",
                })
                endpoint = endpoint.merge(frozen_compare, on="device_uid", how="left", validate="one_to_one")
                endpoint["state_changed_vs_frozen"] = endpoint["endpoint_state"].ne(endpoint["frozen_endpoint_state"]).astype(int)
                scenario_time = pd.to_numeric(endpoint["analysis_time_h"], errors="coerce")
                frozen_time = pd.to_numeric(endpoint["frozen_analysis_time_h"], errors="coerce")
                endpoint["analysis_time_changed_vs_frozen"] = (
                    scenario_time.notna().ne(frozen_time.notna())
                    | (scenario_time.notna() & frozen_time.notna() & ~np.isclose(scenario_time, frozen_time, rtol=0, atol=1e-6, equal_nan=True))
                ).astype(int)
                scenario_p0 = pd.to_numeric(endpoint["p0_mW"], errors="coerce")
                frozen_p0 = pd.to_numeric(endpoint["frozen_p0_mW"], errors="coerce")
                endpoint["p0_changed_vs_frozen"] = (
                    scenario_p0.notna().ne(frozen_p0.notna())
                    | (scenario_p0.notna() & frozen_p0.notna() & ~np.isclose(scenario_p0, frozen_p0, rtol=0, atol=1e-6, equal_nan=True))
                ).astype(int)
                scenario_endpoints[scenario] = endpoint
                endpoint_tables.append(endpoint)

                all_summary = endpoint_summary(endpoint, scenario, "all")
                all_summary.update(landmark_label_counts(endpoint))
                all_summary.update({
                    "state_changes_vs_frozen": int(endpoint["state_changed_vs_frozen"].sum()),
                    "analysis_time_changes_vs_frozen": int(endpoint["analysis_time_changed_vs_frozen"].sum()),
                    "p0_changes_vs_frozen": int(endpoint["p0_changed_vs_frozen"].sum()),
                })
                endpoint_summary_rows.append(all_summary)
                endpoint_km_tables.append(kaplan_meier_curve(endpoint, scenario, "all"))
                for temperature, group in endpoint[endpoint["aging_temperature_C"].notna()].groupby("aging_temperature_C"):
                    group_label = f"{float(temperature):g} C"
                    endpoint_summary_rows.append(endpoint_summary(group, scenario, group_label))
                    endpoint_km_tables.append(kaplan_meier_curve(group, scenario, group_label))

            sensitivity_rows = []
            summary_by_scenario = {
                str(row["scenario"]): row
                for row in endpoint_summary_rows
                if row["temperature_group"] == "all"
            }
            for scenario, (_, ef_col, timing_col, burn_col) in sensitivity_specs.items():
                ef = pd.to_numeric(devices[ef_col], errors="coerce").fillna(0).astype(int)
                rapid = devices[timing_col].astype(str).eq("confirmed_rapid")
                burn = pd.to_numeric(devices[burn_col], errors="coerce").fillna(0).astype(int)
                endpoint_summary_all = summary_by_scenario[scenario]
                sensitivity_rows.append(
                    {
                        "scenario": scenario,
                        "early_failure_devices": int(ef.sum()),
                        "confirmed_rapid_devices": int(rapid.sum()),
                        "burn_in_like_devices": int(burn.sum()),
                        "early_failure_flag_changes_vs_frozen": int(ef.ne(base_ef).sum()),
                        "rapid_status_changes_vs_frozen": int(rapid.ne(base_rapid).sum()),
                        "burn_in_flag_changes_vs_frozen": int(burn.ne(base_burn).sum()),
                        "p0_changes_vs_frozen": endpoint_summary_all["p0_changes_vs_frozen"],
                        "endpoint_state_changes_vs_frozen": endpoint_summary_all["state_changes_vs_frozen"],
                        "analysis_time_changes_vs_frozen": endpoint_summary_all["analysis_time_changes_vs_frozen"],
                        "assessable_devices": endpoint_summary_all["assessable_devices"],
                        "events": endpoint_summary_all["events"],
                        "right_censored": endpoint_summary_all["right_censored"],
                        "km_median_h": endpoint_summary_all["km_median_h"],
                        "landmark_records": endpoint_summary_all["landmark_records"],
                        "landmark_events": endpoint_summary_all["landmark_events"],
                    }
                )
            sensitivity = pd.DataFrame(sensitivity_rows)
            sensitivity.to_csv(ANALYSIS / "early_rule_sensitivity.csv", index=False, encoding="utf-8-sig")
            pd.concat(endpoint_tables, ignore_index=True).to_csv(
                ANALYSIS / "early_rule_endpoint_transitions.csv", index=False, encoding="utf-8-sig"
            )
            pd.DataFrame(endpoint_summary_rows).to_csv(
                ANALYSIS / "early_rule_endpoint_sensitivity.csv", index=False, encoding="utf-8-sig"
            )
            pd.concat(endpoint_km_tables, ignore_index=True).to_csv(
                ANALYSIS / "early_rule_km_curves.csv", index=False, encoding="utf-8-sig"
            )

            landmark_dataset = read_csv(ANALYSIS / "landmark_ranking_dataset.csv")
            if not landmark_dataset.empty:
                landmark_dataset["landmark_h"] = pd.to_numeric(landmark_dataset["landmark_h"], errors="coerce")
                landmark_dataset["prediction_horizon_h"] = pd.to_numeric(
                    landmark_dataset["prediction_horizon_h"], errors="coerce"
                )
                landmark_dataset["event_by_horizon"] = pd.to_numeric(
                    landmark_dataset["event_by_horizon"], errors="coerce"
                )
                primary_labels = landmark_dataset[
                    landmark_dataset["landmark_h"].eq(100.0)
                    & landmark_dataset["prediction_horizon_h"].eq(6000.0)
                    & landmark_dataset["event_by_horizon"].notna()
                ][["device_uid", "event_by_horizon"]].copy()
                primary_labels["device_uid"] = primary_labels["device_uid"].astype(str)
                primary_labels["event_by_horizon"] = primary_labels["event_by_horizon"].astype(int)
                endpoint_labels = landmark_label_frame(
                    scenario_endpoints["frozen_max_reference_100h_240h"]
                )
                left = primary_labels.sort_values("device_uid").reset_index(drop=True)
                right = endpoint_labels.sort_values("device_uid").reset_index(drop=True)
                if not left.equals(right):
                    raise AssertionError(
                        "Primary landmark cohort or labels disagree with the frozen endpoint sensitivity module."
                    )

            archive_endpoint = scenario_endpoints["frozen_max_reference_100h_240h"].copy()
            archive_endpoint["scenario"] = "archive_final_crossing_as_event"
            early_unconfirmed_subtype = "isolated_or_terminal_catastrophic_point_unconfirmed"
            device_rows = {str(row["device_uid"]): row for _, row in devices.iterrows()}
            measurement_groups = {
                str(uid): group.copy() for uid, group in corrected_measurements.groupby("device_uid", sort=False)
            }
            terminal_manifest_rows: list[dict[str, Any]] = []
            for _, endpoint_row in archive_endpoint.iterrows():
                uid = str(endpoint_row["device_uid"])
                sub = measurement_groups.get(uid, pd.DataFrame()).copy()
                if sub.empty:
                    continue
                sub["trajectory_time_h"] = pd.to_numeric(sub.get("exposure_hours"), errors="coerce")
                sub["trajectory_time_h"] = sub["trajectory_time_h"].fillna(
                    pd.to_numeric(sub.get("calendar_hours"), errors="coerce")
                )
                power_col = "endpoint_power_mW" if "endpoint_power_mW" in sub.columns else "power_mW"
                sub["trajectory_power_mW"] = pd.to_numeric(sub.get(power_col), errors="coerce")
                sub = sub[sub["trajectory_time_h"].notna() & sub["trajectory_power_mW"].notna()].sort_values(
                    ["trajectory_time_h", "source_cell"], kind="mergesort"
                )
                if sub.empty:
                    continue
                device_row = device_rows.get(uid)
                early_reference = parse_float(device_row.get("provisional_early_reference_mW")) if device_row is not None else None
                catastrophic = sub["trajectory_power_mW"].le(0)
                if early_reference is not None and early_reference > 0:
                    catastrophic = catastrophic | sub["trajectory_power_mW"].div(early_reference).le(0.1 + 1e-12)
                catastrophic_rows = sub[catastrophic].copy()
                subtype = str(device_row.get("early_failure_subtype", "")) if device_row is not None else ""
                if catastrophic_rows.empty and subtype != early_unconfirmed_subtype:
                    continue
                final_row = sub.iloc[-1]
                final_is_catastrophic = bool(catastrophic.loc[final_row.name])
                event_time = parse_float(endpoint_row.get("analysis_time_h"))
                terminal_event = bool(
                    int(parse_float(endpoint_row.get("event_observed")) or 0) == 1
                    and event_time is not None
                    and np.isclose(event_time, float(final_row["trajectory_time_h"]), equal_nan=False)
                    and final_is_catastrophic
                )
                solitary_terminal = bool(terminal_event and len(catastrophic_rows) == 1)
                if solitary_terminal:
                    case_class = "terminal_solitary_catastrophic_crossing"
                    include_terminal_sensitivity = 1
                    rationale = "one catastrophic or near-zero endpoint-stream observation; it is the final observation and the main archive event time"
                elif subtype == early_unconfirmed_subtype and len(catastrophic_rows) >= 2:
                    case_class = "early_catastrophic_point_with_later_low_support"
                    include_terminal_sensitivity = 0
                    rationale = "early catastrophic support is followed by later catastrophic evidence; not a solitary terminal observation"
                elif subtype == early_unconfirmed_subtype:
                    case_class = "isolated_interior_catastrophic_point"
                    include_terminal_sensitivity = 0
                    rationale = "catastrophic support is not a solitary terminal main-endpoint crossing"
                else:
                    continue
                first_cat_time = (
                    float(catastrophic_rows["trajectory_time_h"].iloc[0]) if len(catastrophic_rows) else np.nan
                )
                last_cat_time = (
                    float(catastrophic_rows["trajectory_time_h"].iloc[-1]) if len(catastrophic_rows) else np.nan
                )
                terminal_manifest_rows.append(
                    {
                        "device_uid": uid,
                        "file_id": endpoint_row.get("file_id", ""),
                        "case_classification": case_class,
                        "included_in_terminal_sensitivity": include_terminal_sensitivity,
                        "main_archive_event_time_h": event_time,
                        "final_observation_time_h": float(final_row["trajectory_time_h"]),
                        "final_endpoint_power_mW": float(final_row["trajectory_power_mW"]),
                        "early_reference_mW": early_reference,
                        "catastrophic_observation_count": int(len(catastrophic_rows)),
                        "first_catastrophic_time_h": first_cat_time,
                        "last_catastrophic_time_h": last_cat_time,
                        "early_failure_subtype": subtype,
                        "rationale": rationale,
                    }
                )
            terminal_manifest = pd.DataFrame(terminal_manifest_rows)
            included_terminal = terminal_manifest[
                terminal_manifest["included_in_terminal_sensitivity"].eq(1)
            ].copy()
            if not included_terminal.empty:
                if not included_terminal["case_classification"].eq(
                    "terminal_solitary_catastrophic_crossing"
                ).all():
                    raise AssertionError("Terminal-zero sensitivity contains a non-terminal case")
                if not included_terminal["catastrophic_observation_count"].eq(1).all():
                    raise AssertionError("Terminal-zero sensitivity requires exactly one catastrophic observation")
                if not np.isclose(
                    pd.to_numeric(included_terminal["main_archive_event_time_h"], errors="coerce"),
                    pd.to_numeric(included_terminal["final_observation_time_h"], errors="coerce"),
                    equal_nan=False,
                ).all():
                    raise AssertionError("Terminal-zero event time must equal the final archived observation")
            later_supported = terminal_manifest[
                terminal_manifest["case_classification"].eq(
                    "early_catastrophic_point_with_later_low_support"
                )
            ]
            if not later_supported.empty and (
                later_supported["included_in_terminal_sensitivity"].ne(0).any()
                or later_supported["catastrophic_observation_count"].lt(2).any()
            ):
                raise AssertionError("Later-supported catastrophic trajectories must remain outside terminal sensitivity")
            terminal_ids = set(
                included_terminal["device_uid"].astype(str)
            )
            terminal_manifest.to_csv(
                ANALYSIS / "terminal_zero_case_manifest.csv", index=False, encoding="utf-8-sig"
            )
            nonassessable_endpoint = archive_endpoint.copy()
            nonassessable_endpoint["scenario"] = "terminal_solitary_as_nonassessable"
            nonassessable_endpoint.loc[nonassessable_endpoint["device_uid"].isin(terminal_ids), "event_status"] = "terminal_solitary_nonassessable"
            nonassessable_endpoint.loc[nonassessable_endpoint["device_uid"].isin(terminal_ids), "endpoint_state"] = "NA"
            nonassessable_endpoint.loc[nonassessable_endpoint["device_uid"].isin(terminal_ids), "analysis_time_h"] = np.nan
            nonassessable_endpoint.loc[nonassessable_endpoint["device_uid"].isin(terminal_ids), "event_observed"] = 0

            censor_endpoint = archive_endpoint.copy()
            censor_endpoint["scenario"] = "terminal_solitary_censor_at_previous_valid_point"
            previous_times: dict[str, float | None] = {}
            for uid in terminal_ids:
                event_time = pd.to_numeric(
                    archive_endpoint.loc[archive_endpoint["device_uid"].eq(uid), "analysis_time_h"], errors="coerce"
                ).dropna()
                previous_times[uid] = previous_valid_time(
                    corrected_measurements,
                    uid,
                    float(event_time.iloc[0]) if len(event_time) else float("nan"),
                )
            affected = censor_endpoint["device_uid"].isin(terminal_ids)
            censor_endpoint.loc[affected, "event_status"] = "right_censored_at_previous_valid_point"
            censor_endpoint.loc[affected, "endpoint_state"] = "C"
            censor_endpoint.loc[affected, "event_observed"] = 0
            censor_endpoint.loc[affected, "analysis_time_h"] = censor_endpoint.loc[affected, "device_uid"].map(previous_times)

            terminal_endpoint_tables = [archive_endpoint, nonassessable_endpoint, censor_endpoint]
            terminal_summary_rows: list[dict[str, Any]] = []
            terminal_km_tables: list[pd.DataFrame] = []
            for endpoint in terminal_endpoint_tables:
                scenario = str(endpoint["scenario"].iloc[0])
                all_summary = endpoint_summary(endpoint, scenario, "all")
                all_summary.update(landmark_label_counts(endpoint))
                all_summary["terminal_solitary_records_affected"] = len(terminal_ids)
                terminal_summary_rows.append(all_summary)
                terminal_km_tables.append(kaplan_meier_curve(endpoint, scenario, "all"))
                for temperature, group in endpoint[endpoint["aging_temperature_C"].notna()].groupby("aging_temperature_C"):
                    group_label = f"{float(temperature):g} C"
                    group_summary = endpoint_summary(group, scenario, group_label)
                    group_summary["terminal_solitary_records_affected"] = int(group["device_uid"].isin(terminal_ids).sum())
                    terminal_summary_rows.append(group_summary)
                    terminal_km_tables.append(kaplan_meier_curve(group, scenario, group_label))
            terminal_sensitivity = pd.DataFrame(terminal_summary_rows)
            terminal_sensitivity.to_csv(
                ANALYSIS / "terminal_unconfirmed_zero_sensitivity.csv", index=False, encoding="utf-8-sig"
            )
            pd.concat(terminal_endpoint_tables, ignore_index=True).to_csv(
                ANALYSIS / "terminal_unconfirmed_zero_endpoints.csv", index=False, encoding="utf-8-sig"
            )
            pd.concat(terminal_km_tables, ignore_index=True).to_csv(
                ANALYSIS / "terminal_unconfirmed_zero_km_curves.csv", index=False, encoding="utf-8-sig"
            )
            terminal_cases = devices[devices["device_uid"].astype(str).isin(terminal_ids)].copy()
            terminal_cases = terminal_cases.merge(
                terminal_manifest[terminal_manifest["included_in_terminal_sensitivity"].eq(1)],
                on=["device_uid", "file_id"],
                how="left",
                validate="one_to_one",
            )
            terminal_cases["previous_valid_censor_time_h"] = terminal_cases["device_uid"].astype(str).map(previous_times)
            terminal_cases.to_csv(
                ANALYSIS / "terminal_unconfirmed_zero_cases.csv", index=False, encoding="utf-8-sig"
            )
            comparison = pd.DataFrame(
                [
                    {
                        "system_layer": "raw single-definition endpoint",
                        "records": len(devices),
                        "assessable_devices": raw_assessable,
                        "events": raw_events,
                        "audit_detail": "one state per device; no definition ensemble",
                    },
                    {
                        "system_layer": "quality-aware single-definition endpoint",
                        "records": len(devices),
                        "assessable_devices": corrected_assessable,
                        "events": corrected_events,
                        "audit_detail": f"{int(paired['state_changed_after_quality_rules'].sum())} states and {int(paired['inspection_time_changed_after_quality_rules'].sum())} inspection times changed after QX rules",
                    },
                    {
                        "system_layer": "positive-follow-up main analytic cohort",
                        "records": len(devices),
                        "assessable_devices": len(main_endpoint),
                        "events": int(pd.to_numeric(main_endpoint["event_observed"], errors="coerce").sum()),
                        "audit_detail": f"{corrected_assessable - len(main_endpoint)} zero-follow-up right-censored records excluded after reconciliation",
                    },
                    {
                        "system_layer": "12-definition endpoint ensemble",
                        "records": len(all_definitions),
                        "assessable_devices": int((pd.to_numeric(passport["assessable_definition_count"], errors="coerce") > 0).sum()),
                        "events": "",
                        "audit_detail": f"{int(pd.to_numeric(passport['binary_event_flip'], errors='coerce').sum())} binary flips; {int(pd.to_numeric(passport['four_state_definition_change'], errors='coerce').sum())} four-state changes",
                    },
                    {
                        "system_layer": "frozen rule-trace system",
                        "records": len(trace),
                        "assessable_devices": trace_complete,
                        "events": "",
                        "audit_detail": f"{trace_complete}/{len(devices)} devices complete across required rule families under registry version {registry['version']}",
                    },
                ]
            )
            comparison.to_csv(ANALYSIS / "system_level_comparison.csv", index=False, encoding="utf-8-sig")
            report = f"""# System-level comparison
        
        Registry `{registry['registry_id']}` version `{registry['version']}` is frozen for the reported retrospective analysis.
        
        The comparison is functional rather than diagnostic: no independent physical-failure ground truth is available. A raw single endpoint yields {raw_assessable} assessable devices and {raw_events} observed crossings. Applying the frozen quality rules yields {corrected_assessable} assessable devices and {corrected_events} crossings, changing the endpoint state for {int(paired['state_changed_after_quality_rules'].sum())} devices and the inspection time for {int(paired['inspection_time_changed_after_quality_rules'].sum())} devices. The positive-follow-up main analytic cohort then contains {len(main_endpoint)} devices and {int(pd.to_numeric(main_endpoint['event_observed'], errors='coerce').sum())} events; the {corrected_assessable - len(main_endpoint)}-device difference is an analytic-cohort eligibility step, not a QX effect.
        
        Retaining all 12 baseline-threshold definitions exposes {int(pd.to_numeric(passport['binary_event_flip'], errors='coerce').sum())} binary crossing-status flips and {int(pd.to_numeric(passport['four_state_definition_change'], errors='coerce').sum())} E/R/C/NA state changes. The final trace contains {len(trace)} rows and is complete for {trace_complete}/{len(devices)} devices across P0-1, EVT-1, FM-1, PAS-1, and AR-1.
        
        These quantities show added audit resolution and estimand transparency; they are not estimates of diagnostic accuracy or causal benefit.
        """
            (ANALYSIS / "system_level_comparison.md").write_text(report, encoding="utf-8")
            print(comparison.to_string(index=False))
        main()


def run_system_artifacts(stage_args: list[str]) -> None:
    """Run the embedded export_system_artifacts.py stage with an isolated command line."""
    with isolated_argv("system_artifacts", stage_args):
        import argparse
        import json
        from pathlib import Path
        from typing import Any
        
        import numpy as np
        import pandas as pd
        
        ROOT = Path(__file__).resolve().parents[1]
        REGISTRY_PATH = ROOT / "data" / "qaes_vcsel_rule_registry_v2.json"
        
        
        def load_registry() -> dict[str, Any]:
            """Load and validate the frozen registry without sibling imports."""
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            if registry.get("status") != "frozen-retrospective" or registry.get("version") != "2.2.3":
                raise ValueError("Unexpected QAES-VCSEL rule registry.")
            return registry
        
        
        def export_frozen_registry(output_dir: Path) -> Path:
            """Export the frozen registry into the results directory."""
            output_dir.mkdir(parents=True, exist_ok=True)
            version = load_registry()["version"]
            json_path = output_dir / f"expert_rule_registry_v{version}.json"
            json_path.write_bytes(REGISTRY_PATH.read_bytes())
            return json_path
        
        
        def read_csv(path: Path) -> pd.DataFrame:
            if not path.exists() or path.stat().st_size == 0:
                return pd.DataFrame()
            return pd.read_csv(path, encoding="utf-8-sig")
        
        
        def file_index(root: Path) -> pd.DataFrame:
            rows: list[dict[str, Any]] = []
            folders = ["scripts", "outputs/processed", "outputs/analysis", "outputs/system_artifacts", "figures"]
            for folder in folders:
                base = root / folder
                if not base.exists():
                    continue
                for path in sorted(base.rglob("*")):
                    if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                        continue
                    rows.append(
                        {
                            "path": path.relative_to(root).as_posix(),
                            "bytes": path.stat().st_size,
                            "role": "pipeline code" if path.suffix == ".py" else "generated evidence artifact",
                        }
                    )
            return pd.DataFrame(rows)
        
        
        def rule_table(registry: dict[str, Any]) -> pd.DataFrame:
            rows = []
            for rule_id, specification in registry["rules"].items():
                rows.append(
                    {
                        "registry_id": registry["registry_id"],
                        "registry_version": registry["version"],
                        "rule_id": rule_id,
                        "module": specification.get("module", ""),
                        "purpose": specification.get("purpose", ""),
                        "required_fields_json": json.dumps(specification.get("required_fields", []), sort_keys=True),
                        "parameters_json": json.dumps(specification.get("parameters", {}), sort_keys=True),
                        "weights_json": json.dumps(specification.get("weights", {}), sort_keys=True),
                        "output_contract": specification.get("output_contract", ""),
                        "boundary": specification.get("boundary", ""),
                    }
                )
            return pd.DataFrame(rows)
        
        
        def observed_summary(root: Path) -> dict[str, Any]:
            devices = read_csv(root / "outputs" / "processed" / "device_table.csv")
            main = read_csv(root / "outputs" / "analysis" / "reliability_dataset_main.csv")
            temperature = read_csv(root / "outputs" / "analysis" / "reliability_dataset_temperature_stratified.csv")
            passport = read_csv(root / "outputs" / "analysis" / "reliability_evidence_passport.csv")
            trace_complete = read_csv(root / "outputs" / "analysis" / "device_trace_completeness.csv")
            correction = read_csv(root / "outputs" / "processed" / "measurement_correction_summary.csv")
            patterns = read_csv(root / "outputs" / "processed" / "ai_device_classification.csv")
            correction_row = correction.iloc[0].to_dict() if not correction.empty else {}
            pattern_counts = (
                patterns["ai_suggested_failure_mode"].astype(str).value_counts().sort_index().astype(int).to_dict()
                if not patterns.empty
                else {}
            )
            return {
                "devices_reconstructed": int(len(devices)),
                "main_endpoint_assessable": int(len(main)),
                "main_events": int(pd.to_numeric(main.get("event_observed"), errors="coerce").fillna(0).sum()) if not main.empty else 0,
                "temperature_stratifiable": int(len(temperature)),
                "binary_endpoint_flips": int(pd.to_numeric(passport.get("binary_event_flip"), errors="coerce").fillna(0).sum()) if not passport.empty else 0,
                "four_state_definition_changes": int(pd.to_numeric(passport.get("four_state_definition_change"), errors="coerce").fillna(0).sum()) if not passport.empty else 0,
                "trace_complete_devices": int(pd.to_numeric(trace_complete.get("complete"), errors="coerce").fillna(0).sum()) if not trace_complete.empty else 0,
                "measurement_corrections": int(float(correction_row.get("corrected_measurements", 0) or 0)),
                "transient_analysis_substitutions": int(float(correction_row.get("artifact_imputed_measurements", 0) or 0)),
                "observable_pattern_counts": pattern_counts,
            }


        def external_recovery_clearance(root: Path) -> None:
            """Recompute temporary-clearance diagnostics from included battery trajectories."""
            analysis = root / "outputs" / "analysis"
            trajectories = read_csv(analysis / "nasa_battery_external_trajectories.csv")
            devices = read_csv(analysis / "nasa_battery_external_device_summary.csv")
            if trajectories.empty or devices.empty:
                return

            def classify(ratio: np.ndarray, threshold: float) -> tuple[int, int, int]:
                below = np.flatnonzero(ratio <= threshold)
                if not len(below):
                    return 0, 0, 0
                later = ratio[int(below[0]) + 1 :]
                clearance = np.flatnonzero(later > threshold + 0.03)
                if not len(clearance):
                    return 0, 0, 0
                recrossed = int(np.any(later[int(clearance[0]) + 1 :] <= threshold))
                ended_above = int(ratio[-1] > threshold + 0.03)
                return 1, recrossed, ended_above

            curves = {
                battery: group.sort_values("discharge_cycle")["capacity_ratio"].to_numpy(float)
                for battery, group in trajectories.groupby("battery_id", sort=True)
            }
            rows: list[dict[str, Any]] = []
            for label, threshold_lookup in [
                ("fixed_0.80", {battery: 0.8 for battery in curves}),
                ("fixed_0.70", {battery: 0.7 for battery in curves}),
                (
                    "documented_threshold",
                    {
                        str(row.battery_id): float(row.documented_threshold_ratio)
                        for row in devices.itertuples()
                    },
                ),
            ]:
                classifications = [
                    classify(curves[battery], threshold)
                    for battery, threshold in threshold_lookup.items()
                    if battery in curves
                ]
                recovered = sum(value[0] for value in classifications)
                rows.append(
                    {
                        "threshold_scope": label,
                        "recovered_crossings": recovered,
                        "recrossed_after_first_clearance": sum(value[1] for value in classifications),
                        "ended_above_threshold_plus_margin": sum(value[2] for value in classifications),
                        "definition": "clearance requires a later value above threshold plus 0.03",
                    }
                )
            pd.DataFrame(rows).to_csv(
                analysis / "nasa_battery_recovery_clearance_summary.csv",
                index=False,
                encoding="utf-8-sig",
            )
        
        
        def main() -> None:
            parser = argparse.ArgumentParser(description="Build the frozen QAES-VCSEL system package.")
            parser.add_argument("--output-dir", type=Path, default=Path("outputs") / "system_artifacts")
            args = parser.parse_args()
            output_dir = (ROOT / args.output_dir).resolve() if not args.output_dir.is_absolute() else args.output_dir
            output_dir.mkdir(parents=True, exist_ok=True)
        
            registry = load_registry()
            export_frozen_registry(output_dir)
            external_recovery_clearance(ROOT)
            observed = observed_summary(ROOT)
            config = {
                "system_name": "QAES-VCSEL",
                "system_type": "auditable rule-trace reliability target-construction system",
                "registry_id": registry["registry_id"],
                "registry_version": registry["version"],
                "registry_status": registry["status"],
                "change_policy": registry["change_policy"],
                "evidence_boundary": registry["evidence_boundary"],
                "pipeline_contract": [
                    "preserve raw source evidence",
                    "write all downstream substitutions to audit logs",
                    "retain all baseline-threshold endpoint alternatives",
                    "bound the archive-specific early conditioning window at 240 h",
                    "freeze a pre-P0 early reference so later baseline selection cannot normalize away substantial early loss",
                    "select the main P0 after bounded stabilization or from an early 3-5-point median, never from the first power reading alone",
                    "route severe or persistent loss within the bounded window to early failure before burn-in-like screening",
                    "reserve rapid or catastrophic classification for records with first supporting evidence at or before 100 h; later support remains timing-ambiguous substantial early loss",
                    "separate burn-in-like early stabilization from sustained recovery or power increase",
                    "treat burn-in-like and recovery labels as observable patterns rather than mechanisms",
                    "separate endpoint assessability from temperature stratifiability",
                    "route review using only uniformly available pre-review evidence",
                    "report landmark prediction as a censoring-filtered retrospective stress test",
                ],
                "observed_result": observed,
            }
            schema = {
                "device_table.csv": "one row per reconstructed device",
                "measurement_table.csv": "raw-preserving and analysis-value measurement evidence",
                "ai_device_classification.csv": "QAES-VCSEL observable-pattern features, BI-1/EF-1/RCV-1 states, and review routing",
                "reliability_dataset_all_definitions.csv": "12 endpoint alternatives per device",
                "reliability_dataset_main.csv": "main endpoint-assessable cohort",
                "reliability_dataset_temperature_stratified.csv": "main cohort with recorded aging temperature",
                "reliability_evidence_passport.csv": "pre-review audit-vulnerability components and score",
                "device_rule_trace.csv": "rule-level decision trace keyed by device and output row",
                "device_trace_completeness.csv": "required trace-family completeness assertion",
            }
            (output_dir / "system_config.json").write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
            (output_dir / "data_schema.json").write_text(json.dumps(schema, indent=2) + "\n", encoding="utf-8")
            (output_dir / "expert_rule_base.json").write_text(json.dumps(registry["rules"], indent=2) + "\n", encoding="utf-8")
            rule_table(registry).to_csv(output_dir / "expert_rule_base.csv", index=False, encoding="utf-8-sig")
            file_index(ROOT).to_csv(output_dir / "artifact_file_index.csv", index=False, encoding="utf-8-sig")
            (output_dir / "README_system_package.md").write_text(
                "# QAES-VCSEL frozen system package\n\n"
                f"Registry `{registry['registry_id']}` version `{registry['version']}` is frozen for the reported analysis. "
                "Every parameter change requires a version increment and full regeneration.\n\n"
                "The exported rules support retrospective data-quality review, reliability target construction, observable curve-pattern description, and review routing. They do not constitute an independently validated physical failure ontology.\n\n"
                f"Observed clean-run summary: `{json.dumps(observed, sort_keys=True)}`.\n",
                encoding="utf-8",
            )
            print(f"registry_version={registry['version']}")
            print(f"system_artifacts={output_dir}")
        main()


def run_blind_review_setup(stage_args: list[str]) -> None:
    """Create one browser-based, multi-rater blinded trajectory-review instrument."""
    with isolated_argv("blind_review", stage_args):
        import argparse
        import hashlib
        import json
        from pathlib import Path

        import pandas as pd

        ROOT = Path(__file__).resolve().parents[1]
        PROCESSED = ROOT / "outputs" / "processed"
        REVIEW_ROOT = ROOT / "outputs" / "review" / "blinded_review_app"
        COORDINATOR = REVIEW_ROOT / "coordinator_only"
        CARDS = REVIEW_ROOT / "cards"
        RESPONSES = REVIEW_ROOT / "responses"

        def digest_token(*parts: object, length: int = 10) -> str:
            payload = "|".join(str(part) for part in parts).encode("utf-8")
            return hashlib.sha256(payload).hexdigest()[:length].upper()

        def numeric_text(value: object, suffix: str = "", decimals: int = 1) -> str:
            number = pd.to_numeric(pd.Series([value]), errors="coerce").iloc[0]
            if pd.isna(number):
                return "NA"
            return f"{float(number):.{decimals}f}{suffix}"

        def write_html(cases: list[dict[str, object]], version: str) -> None:
            template = r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VCSEL 领域专家客观评分</title>
<style>
:root{--paper:#fff;--ink:#000;--blue:#0063D0;--navy:#172C6F;--green:#278575;--gold:#D9A441;--red:#C83E36;--gray:#7A7A7A;--light:#D8D8D8;--wash:#F4F7FB}
*{box-sizing:border-box} body{margin:0;background:var(--wash);color:var(--ink);font-family:"Microsoft YaHei","Segoe UI",sans-serif}
button,input{font:inherit}.shell{max-width:1480px;margin:0 auto;padding:18px}.top{display:flex;gap:12px;align-items:center;justify-content:space-between;background:var(--paper);padding:14px 18px;border-bottom:3px solid var(--navy);position:sticky;top:0;z-index:5}.top h1{font-size:20px;margin:0}.badge{padding:5px 9px;background:var(--navy);color:white;border-radius:4px;font-weight:700}.progress{height:8px;background:var(--light);border-radius:8px;overflow:hidden;margin-top:7px}.progress>div{height:100%;background:var(--green);width:0}.grid{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(360px,.85fr);gap:16px;margin-top:16px}.panel{background:var(--paper);border:1px solid var(--light);border-radius:8px;padding:16px}.card-img{display:block;width:100%;height:auto;border:1px solid var(--light);background:white}.meta{display:flex;gap:16px;flex-wrap:wrap;color:#333;font-size:14px;margin:8px 0}.section{border-top:1px solid var(--light);padding-top:12px;margin-top:12px}.section h2{font-size:16px;margin:0 0 9px}.choice-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.choice{border:1px solid #AEB8C6;background:white;border-radius:6px;padding:10px;text-align:left;cursor:pointer;min-height:52px}.choice:hover{border-color:var(--blue)}.choice.selected{border:2px solid var(--blue);background:#EAF3FF}.choice small{display:block;color:#333;margin-top:3px}.confidence{display:flex;gap:7px}.confidence button{width:44px;height:40px;border:1px solid #AEB8C6;background:white;border-radius:5px}.confidence button.selected{background:var(--blue);color:white;border-color:var(--blue)}.nav{display:flex;gap:8px;margin-top:14px}.nav button,.action{border:0;background:var(--navy);color:white;border-radius:5px;padding:9px 14px;cursor:pointer}.nav button.secondary,.secondary{background:#E7ECF3;color:#111}.export{background:var(--green)}.warning{background:#FFF7DF;border-left:4px solid var(--gold);padding:10px 12px;margin:10px 0;font-size:14px}.error{color:var(--red);font-weight:700;min-height:22px}.intro{max-width:920px;margin:32px auto;background:white;padding:26px;border-radius:8px;border:1px solid var(--light)}.rater-buttons{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:18px 0}.rater-buttons button{padding:18px;border:1px solid var(--navy);background:white;color:var(--navy);border-radius:6px;font-weight:700;cursor:pointer}.rater-buttons button:hover{background:#EAF3FF}.definitions{font-size:13px;color:#333}.definitions dt{font-weight:700;margin-top:8px}.definitions dd{margin:2px 0 0 0}.hidden{display:none!important}.status-ok{color:var(--green);font-weight:700}.status-missing{color:var(--red);font-weight:700}@media(max-width:980px){.grid{grid-template-columns:1fr}.top{position:static}.choice-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div id="intro" class="intro">
  <h1>VCSEL 领域专家客观评分</h1>
  <p>输入协调者分配的匿名专家编号（例如 E01、E02）。四名专家分别使用唯一编号；相同编号会恢复该专家上次的进度，不同编号会得到不同的随机顺序。</p>
  <div class="warning"><strong>开始条件：</strong>评分时不得查看系统标签、规则输出、协调者映射或其他专家的答案。</div>
  <label><input id="consent" type="checkbox"> 我已阅读标注说明，并确认以独立专家身份完成客观评定。</label>
  <div class="rater-buttons">
    <input id="reviewerInput" type="text" maxlength="24" placeholder="匿名专家编号，如 E01" autocomplete="off" style="padding:14px;border:1px solid #AEB8C6;border-radius:6px;text-transform:uppercase">
    <button onclick="chooseRater()">开始 / 继续</button>
    <label style="padding:14px;border:1px solid #AEB8C6;border-radius:6px;text-align:center;cursor:pointer;background:#E7ECF3">导入进度备份 JSON<input type="file" accept="application/json,.json" onchange="importBackup(event)" style="display:none"></label>
  </div>
  <div id="savedProfiles" style="font-size:14px;color:#333"></div>
  <p id="introError" class="error"></p>
  <p><strong>记录：</strong>网页不记录姓名。所有进度自动保存在当前浏览器；完成后必须导出 CSV 并交给协调者。为保证独立评定，不同专家应使用各自的设备或独立浏览器配置文件。</p>
</div>

<div id="app" class="hidden">
  <div class="top">
    <div><h1>VCSEL 领域专家客观评分 <span id="raterBadge" class="badge"></span></h1><div id="progressText"></div><div class="progress"><div id="progressBar"></div></div></div>
    <div><button class="action secondary" onclick="goIncomplete()">下一条未完成</button> <button class="action secondary" onclick="exportBackup()">备份进度 JSON</button> <button class="action export" onclick="exportCsv(false)">导出当前 CSV</button> <button class="action export" onclick="exportCsv(true)">完成并导出</button></div>
  </div>
  <div class="shell">
    <div class="grid">
      <div class="panel">
        <div style="display:flex;justify-content:space-between;align-items:center"><strong id="caseTitle"></strong><span id="caseStatus"></span></div>
        <div id="caseMeta" class="meta"></div>
        <img id="curveCard" class="card-img" alt="匿名 VCSEL 原始轨迹图卡">
        <div class="nav"><button class="secondary" onclick="move(-1)">上一条</button><button onclick="move(1)">下一条</button></div>
      </div>
      <div class="panel">
        <div class="warning">只依据图中的原始功率轨迹、时间和给定工况判断。所有图统一标出 100 h 快速性边界与 0-240 h 早期观察窗口；它们不是系统结论。不要查看项目中的系统标签、P0、终点表或协调者映射。</div>
        <div class="section" style="border-top:0;margin-top:0;padding-top:0"><h2>1. 这条轨迹是否足以判断？</h2><div id="assessChoices" class="choice-grid"></div></div>
        <div id="labelSection" class="section"><h2>2. 可观察轨迹类型</h2><div id="labelChoices" class="choice-grid"></div></div>
        <div class="section"><h2>3. 判断置信度</h2><div id="confidenceChoices" class="confidence"></div><small>1＝很不确定；3＝中等；5＝非常确定</small></div>
        <div id="reasonSection" class="section hidden"><h2>4. 请选择主要原因</h2><div id="reasonChoices" class="choice-grid"></div><div id="validationError" class="error"></div></div>
        <dl class="definitions">
          <dt>持续/渐进或观察期内未突变</dt><dd>曲线较稳定、缓慢变化或逐步退化，未出现明确的早期灾变或中后期断崖。</dd>
          <dt>早期快速/灾变式下降</dt><dd>首次明确支持出现在 100 h 以内，并呈快速、严重或灾变式下降，且没有清楚恢复到接近前段水平。</dd>
          <dt>显著早期损失/低位平台</dt><dd>功率明显低于前段水平并持续或形成约不高于前段 80% 的低位平台，但首次明确支持晚于 100 h 或观测间隔不足以确认下降是否快速；不要因低位稳定而当作普通稳定化。</dd>
          <dt>中后期变化点/台阶式下降</dt><dd>前段相对稳定，随后出现明显拐点、断崖或持续的新水平。</dd>
          <dt>早期稳定化 / burn-in-like</dt><dd>在 0-240 h 早期窗口内出现约 5%-20% 的有限下降，并在高于前段约 80% 的水平形成稳定平台；严重下降、低位平台或持续下降不归入本类。这里只判断可观察形态，不认定物理 burn-in 机制。</dd>
          <dt>功率回升 / 恢复型</dt><dd>下降后持续回升，或观察期内功率整体明显增加；可能受恢复、测量条件或工况变化影响。</dd>
          <dt>其他可观察形态</dt><dd>数据可判断，但以上六类均不合适；选择一个结构化主要原因。</dd>
        </dl>
      </div>
    </div>
  </div>
</div>

<script>
const PACKAGE_VERSION = __VERSION_JSON__;
const CASES = __CASES_JSON__;
const CASE_BY_ID = Object.fromEntries(CASES.map(x => [x.blind_id, x]));
const ASSESS = [
  ['assessable','可以判断','曲线信息足以给出形态判断'],
  ['insufficient_or_unassessable','信息不足/不可判断','点数、时间或曲线质量不足']
];
const LABELS = [
  ['progressive_or_right_censored','持续/渐进或未突变','progressive / right-censored'],
  ['rapid_or_catastrophic_failure','早期快速/灾变下降','首次明确支持 ≤100 h，严重下降且无清楚恢复'],
  ['substantial_early_loss','显著早期损失/低位平台','低位损失持续，但首次支持 >100 h 或快速性无法确认'],
  ['change_point_or_midlife_drop','中后期变化点/台阶下降','change-point / midlife drop'],
  ['burn_in_like_early_stabilization','早期稳定化 / burn-in-like','0-240 h 内约 5%-20% 有限下降后在 >80% 前段水平稳定'],
  ['recovery_or_power_increase','功率回升 / 恢复型','下降后持续回升，或整体功率明显上升'],
  ['other_observable_pattern','其他可观察形态','other observable pattern']
];
const INSUFFICIENT_REASONS = [
  ['too_few_points','数据点太少','无法看出可靠趋势'],
  ['observation_too_short','观察时间太短','不足以判断长期形态'],
  ['excessive_noise_or_outliers','噪声或异常点较多','曲线形态不够可靠'],
  ['baseline_or_scale_uncertain','基线或量程不可靠','归一化参照存在问题'],
  ['other_unassessable_reason','其他不可判断原因','可在下方选填补充']
];
const OTHER_PATTERN_REASONS = [
  ['oscillatory_or_multistage','波动或多阶段型','存在多个阶段或反复波动'],
  ['isolated_outlier_dominant','孤立异常点主导','单个异常点影响整体形态'],
  ['measurement_or_protocol_shift','疑似测量或工况变化','可能存在条件切换或量程变化'],
  ['mixed_or_uncategorizable','混合或无法归类','不适合前五种形态']
];
let reviewer = null, index = 0, order = [], responses = {}, profile = {};
function storageKey(id){return `vcsel_expert_${PACKAGE_VERSION}_${id}`}
function loadProfile(id){try{return JSON.parse(localStorage.getItem(storageKey(id))||'{}')}catch(e){return {}}}
function persist(){profile.responses=responses;profile.last_index=index;profile.updated_at=new Date().toISOString();localStorage.setItem(storageKey(reviewer),JSON.stringify(profile));updateProgress()}
function hash32(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function makeOrder(id){return CASES.map(x=>x.blind_id).sort((a,b)=>{const ha=hash32(`${PACKAGE_VERSION}|${id}|${a}`),hb=hash32(`${PACKAGE_VERSION}|${id}|${b}`);return ha===hb?a.localeCompare(b):ha-hb})}
function chooseRater(forcedId=null){
  if(!document.getElementById('consent').checked){document.getElementById('introError').textContent='请先确认已阅读并同意说明。';return}
  const id=String(forcedId||document.getElementById('reviewerInput').value).trim().toUpperCase();
  if(!/^[A-Z0-9_-]{2,24}$/.test(id)){document.getElementById('introError').textContent='评审编号只能包含2–24位字母、数字、下划线或连字符。';return}
  reviewer=id;order=makeOrder(id);profile=loadProfile(id);responses=profile.responses||{};index=Math.min(profile.last_index||0,order.length-1);
  if(!profile.consent_time) profile.consent_time=new Date().toISOString();
  document.getElementById('intro').classList.add('hidden');document.getElementById('app').classList.remove('hidden');document.getElementById('raterBadge').textContent=id;persist();render();
}
function record(){const id=order[index];if(!responses[id])responses[id]={assessability:'',trajectory_label:'',confidence_1_to_5:'',reason_code:'',updated_at:''};return responses[id]}
function needsReason(r){return r&&(r.assessability==='insufficient_or_unassessable'||r.trajectory_label==='other_observable_pattern')}
function isComplete(r){if(!r||!r.assessability||!r.confidence_1_to_5)return false;if(r.assessability==='assessable'&&!r.trajectory_label)return false;if(needsReason(r)&&!r.reason_code)return false;return true}
function setValue(field,value){const r=record();r[field]=value;if(field==='assessability'){if(value==='insufficient_or_unassessable')r.trajectory_label='';r.reason_code=''}if(field==='trajectory_label')r.reason_code='';r.updated_at=new Date().toISOString();persist();render()}
function renderChoices(containerId,choices,field){const r=record();const c=document.getElementById(containerId);c.innerHTML='';choices.forEach(([value,title,detail])=>{const b=document.createElement('button');b.className='choice'+(r[field]===value?' selected':'');b.innerHTML=`<strong>${title}</strong><small>${detail}</small>`;b.onclick=()=>setValue(field,value);c.appendChild(b)})}
function render(){const id=order[index],c=CASE_BY_ID[id],r=record();document.getElementById('caseTitle').textContent=`第 ${index+1} / ${order.length} 条 · ${id}`;document.getElementById('caseMeta').innerHTML=`<span>温度：${c.temperature}</span><span>电流：${c.current}</span><span>测量点：${c.measurement_count}</span><span>时长：${c.duration}</span>`;document.getElementById('curveCard').src=c.card;renderChoices('assessChoices',ASSESS,'assessability');renderChoices('labelChoices',LABELS,'trajectory_label');document.getElementById('labelSection').classList.toggle('hidden',r.assessability==='insufficient_or_unassessable');const special=needsReason(r);const reasonSection=document.getElementById('reasonSection');reasonSection.classList.toggle('hidden',!special);if(special)renderChoices('reasonChoices',r.assessability==='insufficient_or_unassessable'?INSUFFICIENT_REASONS:OTHER_PATTERN_REASONS,'reason_code');const cc=document.getElementById('confidenceChoices');cc.innerHTML='';for(let n=1;n<=5;n++){const b=document.createElement('button');b.textContent=n;b.className=String(r.confidence_1_to_5)===String(n)?'selected':'';b.onclick=()=>setValue('confidence_1_to_5',String(n));cc.appendChild(b)}const done=isComplete(r);document.getElementById('caseStatus').textContent=done?'已完成':'未完成';document.getElementById('caseStatus').className=done?'status-ok':'status-missing';document.getElementById('validationError').textContent=needsReason(r)&&!r.reason_code?'请选择一个结构化主要原因。':'';updateProgress()}
function hasAnyAnswer(r){return Boolean(r&&(r.assessability||r.trajectory_label||r.confidence_1_to_5||r.reason_code))}
function updateProgress(){if(!reviewer)return;const answered=order.filter(id=>hasAnyAnswer(responses[id])).length;const done=order.filter(id=>isComplete(responses[id])).length;document.getElementById('progressText').textContent=answered?`已完成 ${done} / ${order.length}（自动保存于本浏览器）`:'尚未开始作答';document.getElementById('progressBar').style.width=`${100*done/order.length}%`}
function move(delta){index=Math.max(0,Math.min(order.length-1,index+delta));persist();render();window.scrollTo({top:0,behavior:'smooth'})}
function goIncomplete(){const start=index;for(let step=1;step<=order.length;step++){const j=(start+step)%order.length;if(!isComplete(responses[order[j]])){index=j;persist();render();window.scrollTo({top:0,behavior:'smooth'});return}}alert('当前评审编号的全部案例均已完成。')}
function csvCell(value){let s=String(value??'');if(/^[=+\-@]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'}
function exportCsv(requireComplete){const missing=order.filter(id=>!isComplete(responses[id]));if(requireComplete&&missing.length){alert(`仍有 ${missing.length} 条未完成，请先完成后再提交。`);return}const header=['package_version','reviewer_id','case_order','blind_id','assessability','trajectory_label','confidence_1_to_5','reason_code','consent_time','updated_at'];const rows=[header,...order.map((id,i)=>{const r=responses[id]||{};return [PACKAGE_VERSION,reviewer,i+1,id,r.assessability||'',r.trajectory_label||'',r.confidence_1_to_5||'',r.reason_code||'',profile.consent_time||'',r.updated_at||'']})];const csv='\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`${reviewer}_vcsel_blind_review_${PACKAGE_VERSION}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function exportBackup(){const payload={package_version:PACKAGE_VERSION,reviewer_id:reviewer,profile:{...profile,responses:responses,last_index:index,backup_time:new Date().toISOString()}};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`${reviewer}_vcsel_blind_review_backup_${PACKAGE_VERSION}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function importBackup(event){const file=event.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const payload=JSON.parse(reader.result);if(payload.package_version!==PACKAGE_VERSION)throw new Error('备份版本与当前网页不一致');const id=String(payload.reviewer_id||'').trim().toUpperCase();if(!/^[A-Z0-9_-]{2,24}$/.test(id)||!payload.profile)throw new Error('备份内容不完整');const allowed=new Set(CASES.map(x=>x.blind_id));for(const key of Object.keys(payload.profile.responses||{})){if(!allowed.has(key))throw new Error('备份含有未知案例编号')}localStorage.setItem(storageKey(id),JSON.stringify(payload.profile));document.getElementById('reviewerInput').value=id;document.getElementById('introError').textContent=`已导入 ${id} 的进度；勾选同意后点击“开始 / 继续”。`;showSavedProfiles()}catch(err){document.getElementById('introError').textContent=`导入失败：${err.message}`}};reader.readAsText(file,'utf-8');event.target.value=''}
function showSavedProfiles(){const prefix=`vcsel_expert_${PACKAGE_VERSION}_`;const found=[];for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key&&key.startsWith(prefix)){const id=key.slice(prefix.length),p=loadProfile(id),done=Object.values(p.responses||{}).filter(isComplete).length;found.push([id,done])}}const box=document.getElementById('savedProfiles');box.innerHTML=found.length?'本浏览器已有进度：'+found.sort().map(([id,n])=>`<button style="border:0;background:none;color:#0063D0;cursor:pointer;text-decoration:underline" onclick="document.getElementById('reviewerInput').value='${id}'">${id}（${n}/${CASES.length}）</button>`).join(''):'本浏览器尚无已保存进度。'}
window.addEventListener('DOMContentLoaded',showSavedProfiles);
window.addEventListener('beforeunload',()=>{if(reviewer)persist()});
</script>
</body>
</html>'''
            html = (
                template.replace("__VERSION_JSON__", json.dumps(version))
                .replace("__CASES_JSON__", json.dumps(cases, ensure_ascii=False))
            )
            (REVIEW_ROOT / "expert_scoring.html").write_text(html, encoding="utf-8")

        def main() -> None:
            parser = argparse.ArgumentParser(description="Create a multi-rater blinded trajectory-review web app.")
            parser.add_argument("--seed", type=int, default=20260807)
            args = parser.parse_args()

            devices = pd.read_csv(PROCESSED / "device_table_raw_extracted.csv", low_memory=False)
            measurements = pd.read_csv(PROCESSED / "measurement_table_raw_extracted.csv", low_memory=False)
            device_count = int(devices["device_uid"].nunique())
            if device_count < 1:
                raise AssertionError("Blind-review setup requires at least one reconstructed device.")

            REVIEW_ROOT.mkdir(parents=True, exist_ok=True)
            COORDINATOR.mkdir(parents=True, exist_ok=True)
            CARDS.mkdir(parents=True, exist_ok=True)
            RESPONSES.mkdir(parents=True, exist_ok=True)

            time = pd.to_numeric(measurements["exposure_hours"], errors="coerce")
            fallback = pd.to_numeric(measurements["calendar_hours"], errors="coerce")
            measurements = measurements.assign(display_time_h=time.fillna(fallback))
            summary = (
                measurements.groupby("device_uid", as_index=False)
                .agg(review_measurement_count=("power_mW", "count"), review_duration_h=("display_time_h", "max"))
            )
            work = devices.drop_duplicates("device_uid").merge(summary, on="device_uid", how="left")
            work["blind_id"] = work["device_uid"].map(lambda uid: f"B-{digest_token(args.seed, uid)}")
            if work["blind_id"].nunique() != len(work):
                raise AssertionError("Blind identifier collision detected.")

            key_columns = ["blind_id", "device_uid", "file_id", "source_file", "sheet", "source_column"]
            key = work[key_columns].sort_values("blind_id")
            key.to_csv(COORDINATOR / "blind_key.csv", index=False, encoding="utf-8-sig")

            cases: list[dict[str, object]] = []
            for row in work.sort_values("blind_id").itertuples():
                cases.append(
                    {
                        "blind_id": row.blind_id,
                        "temperature": numeric_text(row.aging_temperature_C, " °C", 0),
                        "current": numeric_text(row.aging_current_mA, " mA", 2),
                        "measurement_count": int(row.review_measurement_count) if pd.notna(row.review_measurement_count) else 0,
                        "duration": numeric_text(row.review_duration_h, " h", 1),
                        "card": f"cards/{row.blind_id}.png",
                    }
                )
            public = pd.DataFrame(cases)
            public.to_csv(REVIEW_ROOT / "public_case_manifest.csv", index=False, encoding="utf-8-sig")

            version = "2.2.2_expert_objective_v1"
            write_html(cases, version)
            (REVIEW_ROOT / "README_使用说明.txt").write_text(
                "QAES-VCSEL 轨迹模式多人盲评\n\n"
                "1. 评分由参与本研究的四名领域专家独立完成；未招募外部参与者。\n"
                "2. 使用 Chrome 或 Edge 打开 expert_scoring.html。\n"
                "3. 协调者给每名专家分配唯一匿名编号，如 E01、E02；共4名。\n"
                "4. 网页每次操作后都会自动保存；关闭后输入同一编号即可继续。\n"
                "5. 七种可观察形态均只需点选；信息不足或其他形态再选择一个结构化主要原因。\n"
                "6. 图中统一标出100 h快速性边界与0-240 h早期观察窗口；首个功率点不被当作P0，网页也不会显示系统选择的P0。\n"
                "7. 建议每完成约20条点击“备份进度JSON”；换电脑时可导入该文件继续。\n"
                "8. 每位专家完成后点击“完成并导出”，把正式CSV交给协调者。\n"
                "9. 协调员把全部CSV放入 responses 文件夹，并在全部文件锁定后才揭盲。\n"
                "10. 所有人提交前不要讨论具体曲线。\n"
                "11. 不同专家应使用各自的设备或独立浏览器配置文件；不要共用同一浏览器数据。\n\n"
                "不要把 coordinator_only 文件夹发给专家。它含匿名编号与真实器件的对应关系。\n",
                encoding="utf-8",
            )
            (RESPONSES / "README.txt").write_text(
                "Place every reviewer's completed CSV export in this folder.\n",
                encoding="utf-8",
            )
            (REVIEW_ROOT / "study_protocol.md").write_text(
                "# Multi-rater blinded observable-trajectory review protocol\n\n"
                "## Material Passport\n\n"
                "- Origin Skill: academic-research-suite / experiment-agent\n"
                "- Origin Mode: manage\n"
                "- Origin Date: 2026-08-08\n"
                "- Verification Status: UNVERIFIED\n"
                f"- Version Label: `{version}`\n\n"
                "## Design\n\n"
                f"Four domain experts involved in the study independently classified all {len(cases)} anonymized VCSEL trajectories while blinded to system outputs and the other experts' responses. Each anonymous expert ID generated a different case order. Every response was an objective selection covering assessability, one of seven observable trajectory-pattern categories, confidence on a 1--5 scale, and one structured reason when evidence was insufficient or otherwise uncategorizable. No free-text response, name, demographic field, or contact information was collected. The interface exposed unnormalized raw optical-power trajectories, time, recorded temperature, current, measurement count, duration, a neutral 100 h rapidity marker, and the same neutral 0--240 h early-window shading for every case. It did not expose the system-selected P0, rule labels, rule confidence, review reasons, endpoint states, source filenames, device identifiers, author identities, or model results. All four response files were retained and locked before rule-system concordance was calculated.\n\n"
                "## Outcomes\n\n"
                "Primary outcomes are multi-rater agreement for assessability and seven observable trajectory-pattern categories. Rapid or catastrophic loss requires first clear support at or before 100 h; later first support or a persistent low plateau is substantial early loss with uncertain rapidity. Burn-in-like early stabilization is a bounded 0--240 h, approximately 5%--20% decrease that stabilizes above about 80% of the early level. Summaries comprise Fleiss' kappa, pairwise Cohen's kappa, raw agreement, maximum-agreement counts, strict-majority coverage, and concordance between strict-majority labels and the rule system. Burn-in-like and recovery labels remain phenomenological, and the expert ratings are not treated as a battery-level or device-level physical gold standard.\n\n"
                "## Annotation provenance\n\n"
                "The exercise was an author-side technical annotation of engineering records by four domain experts involved in the study. No external research participants were recruited. The interface collected no names, free text, demographic fields, or contact information.\n",
                encoding="utf-8",
            )
            (COORDINATOR / "panel_lock_form.md").write_text(
                "# Independent blinded rating-record lock form\n\n"
                "Complete before unblinding.\n\n"
                "- Number of expert raters: 4\n"
                "- Number of completed independent ratings:\n"
                "- Confirmation that each expert worked independently and was blinded to system outputs: [ ]\n"
                "- Response lock date/time and time zone:\n"
                "- Adjudication panel and conflict declarations:\n"
                "- Unblinding authorization and date/time:\n",
                encoding="utf-8",
            )
            print(f"devices={len(cases)}")
            print("reviewers=unlimited_unique_ids")
            print(f"web_app={(REVIEW_ROOT / 'expert_scoring.html').resolve()}")
            print(f"coordinator_key={(COORDINATOR / 'blind_key.csv').resolve()}")

        main()


def run_panel_analysis(stage_args: list[str]) -> None:
    """Validate and summarize the completed four-expert blinded trajectory review."""
    with isolated_argv("panel_analysis", stage_args):
        import argparse
        import itertools
        import math
        from pathlib import Path
        from typing import Any

        import numpy as np
        import pandas as pd

        ROOT = Path(__file__).resolve().parents[1]
        REQUIRED = [
            "package_version",
            "reviewer_id",
            "case_order",
            "blind_id",
            "assessability",
            "trajectory_label",
            "confidence_1_to_5",
            "reason_code",
            "consent_time",
            "updated_at",
        ]
        RESPONSE_VERSION = "2.2.2_expert_objective_v1"
        ACCEPTED_RESPONSE_VERSIONS = {
            "2.2.1_student_objective_v1",  # Locked legacy identifier in the four completed files.
            RESPONSE_VERSION,
        }
        BOOTSTRAP_DRAWS = 2000
        PANEL_CATEGORIES = (
            "progressive_or_right_censored",
            "rapid_or_catastrophic_failure",
            "substantial_early_loss",
            "change_point_or_midlife_drop",
            "burn_in_like_early_stabilization",
            "recovery_or_power_increase",
            "other_observable_pattern",
            "insufficient_or_unassessable",
        )
        BOOTSTRAP_SEED = 20260824

        def read_response_files(fallback: Path) -> pd.DataFrame:
            frames: list[pd.DataFrame] = []
            response_root = ROOT / "data" / "blinded_panel_responses"
            paths = sorted(response_root.glob("S*_vcsel_blind_review_*.csv"))
            if not paths:
                paths = sorted(ROOT.glob("S*_vcsel_blind_review_*.csv"))
            for path in paths:
                frames.append(pd.read_csv(path, encoding="utf-8-sig"))
            xlsx_paths = sorted(response_root.glob("*.xlsx"))
            if not xlsx_paths:
                xlsx_paths = sorted(ROOT.glob("*.xlsx"))
            for path in xlsx_paths:
                workbook = pd.ExcelFile(path)
                for sheet in workbook.sheet_names:
                    frame = pd.read_excel(path, sheet_name=sheet)
                    if set(REQUIRED).issubset(frame.columns):
                        frames.append(frame)
            if frames:
                return pd.concat(frames, ignore_index=True)
            if fallback.exists():
                frame = pd.read_csv(fallback, encoding="utf-8-sig")
                if "reviewer_id" not in frame.columns and "reviewer" in frame.columns:
                    frame = frame.rename(columns={"reviewer": "reviewer_id"})
                frame["consent_time"] = "not_retained_in_anonymized_export"
                frame["updated_at"] = "not_retained_in_anonymized_export"
                return frame
            raise FileNotFoundError("No completed blinded-panel response files were found.")

        def validate_responses(responses: pd.DataFrame, key: pd.DataFrame) -> None:
            missing = [column for column in REQUIRED if column not in responses.columns]
            if missing:
                raise ValueError(f"Panel responses lack required columns: {missing}")
            versions = set(responses["package_version"].astype(str))
            if not versions or not versions.issubset(ACCEPTED_RESPONSE_VERSIONS):
                raise ValueError(f"Unexpected panel response versions: {sorted(versions)}")
            reviewer_counts = responses.groupby("reviewer_id")["blind_id"].agg(["size", "nunique"])
            if len(reviewer_counts) != 4:
                raise ValueError(f"Expected four independent response files, found {len(reviewer_counts)}.")
            if not ((reviewer_counts["size"] == len(key)) & (reviewer_counts["nunique"] == len(key))).all():
                raise ValueError("Every rater must classify every anonymized case exactly once.")
            expected = set(key["blind_id"].astype(str))
            for reviewer, group in responses.groupby("reviewer_id"):
                if set(group["blind_id"].astype(str)) != expected:
                    raise ValueError(f"Case set differs for reviewer {reviewer}.")
                order = pd.to_numeric(group["case_order"], errors="raise").astype(int)
                if set(order) != set(range(1, len(key) + 1)):
                    raise ValueError(f"Case order is incomplete for reviewer {reviewer}.")
            confidence = pd.to_numeric(responses["confidence_1_to_5"], errors="raise")
            if not confidence.between(1, 5).all():
                raise ValueError("Confidence values must lie from 1 to 5.")
            assessable = responses["assessability"].astype(str).eq("assessable")
            if responses.loc[assessable, "trajectory_label"].isna().any():
                raise ValueError("Assessable records require a trajectory label.")

        def fleiss_agreement(wide: pd.DataFrame) -> tuple[float, float]:
            values = wide.to_numpy(dtype=object)
            labels = np.unique(values)
            counts = np.stack([(values == label).sum(axis=1) for label in labels], axis=1).astype(float)
            ratings_per_case = counts.sum(axis=1)
            per_case = (
                np.square(counts).sum(axis=1) - ratings_per_case
            ) / (ratings_per_case * (ratings_per_case - 1))
            category_proportions = counts.sum(axis=0) / counts.sum()
            expected = float(np.square(category_proportions).sum())
            observed = float(per_case.mean())
            kappa = (observed - expected) / (1.0 - expected) if expected < 1.0 else np.nan
            return observed, float(kappa)

        def gwet_ac1(wide: pd.DataFrame) -> tuple[float, float]:
            """Return nominal multi-rater observed agreement and Gwet's AC1."""
            values = wide.to_numpy(dtype=object)
            observed_labels = set(np.unique(values))
            unexpected = observed_labels.difference(PANEL_CATEGORIES)
            if unexpected:
                raise ValueError(f"Unexpected panel categories: {sorted(unexpected)}")
            labels = PANEL_CATEGORIES
            counts = np.stack([(values == label).sum(axis=1) for label in labels], axis=1).astype(float)
            ratings_per_case = counts.sum(axis=1)
            per_case = (
                np.square(counts).sum(axis=1) - ratings_per_case
            ) / (ratings_per_case * (ratings_per_case - 1))
            category_proportions = counts.sum(axis=0) / counts.sum()
            expected = (
                float(np.sum(category_proportions * (1.0 - category_proportions))) / (len(PANEL_CATEGORIES) - 1)
            )
            observed = float(per_case.mean())
            ac1 = (observed - expected) / (1.0 - expected) if expected < 1.0 else np.nan
            return observed, float(ac1)

        def cohen_kappa(left: pd.Series, right: pd.Series) -> tuple[float, float]:
            pair = pd.DataFrame({"left": left, "right": right}).dropna()
            observed = float(pair["left"].eq(pair["right"]).mean())
            left_p = pair["left"].value_counts(normalize=True)
            right_p = pair["right"].value_counts(normalize=True)
            labels = set(left_p.index) | set(right_p.index)
            expected = float(sum(left_p.get(label, 0.0) * right_p.get(label, 0.0) for label in labels))
            kappa = (observed - expected) / (1.0 - expected) if expected < 1.0 else np.nan
            return observed, float(kappa)

        def strict_majority(wide: pd.DataFrame) -> pd.DataFrame:
            rows = []
            for blind_id, row in wide.iterrows():
                counts = row.value_counts()
                maximum = int(counts.iloc[0])
                tied = int((counts == maximum).sum()) > 1
                rows.append(
                    {
                        "blind_id": blind_id,
                        "strict_majority_label": counts.index[0] if maximum >= 3 else "",
                        "maximum_agreement": maximum,
                        "strict_majority": int(maximum >= 3),
                        "plurality_tie": int(tied),
                    }
                )
            return pd.DataFrame(rows).set_index("blind_id")

        def wilson(successes: int, total: int) -> tuple[float, float]:
            if total <= 0:
                return np.nan, np.nan
            z = 1.959963984540054
            proportion = successes / total
            denominator = 1 + z * z / total
            center = (proportion + z * z / (2 * total)) / denominator
            half = z * math.sqrt(
                proportion * (1 - proportion) / total + z * z / (4 * total * total)
            ) / denominator
            return float(center - half), float(center + half)

        def quantiles(values: list[float]) -> tuple[float, float]:
            finite = np.asarray([value for value in values if np.isfinite(value)], dtype=float)
            if not len(finite):
                return np.nan, np.nan
            return float(np.quantile(finite, 0.025)), float(np.quantile(finite, 0.975))

        def main() -> None:
            parser = argparse.ArgumentParser(description="Four-expert blinded trajectory agreement analysis.")
            parser.add_argument("--analysis-dir", type=Path, default=Path("outputs") / "analysis")
            parser.add_argument(
                "--key",
                type=Path,
                default=Path("outputs") / "review" / "blinded_review_app" / "coordinator_only" / "blind_key.csv",
            )
            parser.add_argument(
                "--classification",
                type=Path,
                default=Path("outputs") / "processed" / "ai_device_classification.csv",
            )
            args = parser.parse_args()
            args.analysis_dir.mkdir(parents=True, exist_ok=True)
            anonymized_path = args.analysis_dir / "blinded_panel_responses_anonymized.csv"
            key = pd.read_csv(args.key, encoding="utf-8-sig")
            responses = read_response_files(anonymized_path)
            validate_responses(responses, key)

            reviewer_map = {
                reviewer: f"R{index}"
                for index, reviewer in enumerate(sorted(responses["reviewer_id"].astype(str).unique()), start=1)
            }
            responses["reviewer"] = responses["reviewer_id"].astype(str).map(reviewer_map)
            responses["response"] = np.where(
                responses["assessability"].astype(str).eq("assessable"),
                responses["trajectory_label"].astype(str),
                "insufficient_or_unassessable",
            )
            anonymized = responses[
                [
                    "package_version",
                    "reviewer",
                    "case_order",
                    "blind_id",
                    "assessability",
                    "trajectory_label",
                    "confidence_1_to_5",
                    "reason_code",
                ]
            ].copy()
            anonymized["package_version"] = RESPONSE_VERSION
            anonymized.to_csv(anonymized_path, index=False, encoding="utf-8-sig")

            wide = responses.pivot(index="blind_id", columns="reviewer", values="response").sort_index()
            observed, fleiss = fleiss_agreement(wide)
            _, ac1 = gwet_ac1(wide)
            consensus = strict_majority(wide)
            classification = pd.read_csv(args.classification, encoding="utf-8-sig")
            rule = key[["blind_id", "device_uid", "file_id"]].merge(
                classification[["device_uid", "ai_suggested_failure_mode", "needs_human_review"]],
                on="device_uid",
                validate="one_to_one",
            )
            rule["rule_label"] = (
                rule["ai_suggested_failure_mode"]
                .astype(str)
                .str.replace("_candidate$", "", regex=True)
                .replace(
                    {
                        "ambiguous_needs_review": "other_observable_pattern",
                        "insufficient_p0_or_measurements": "insufficient_or_unassessable",
                    }
                )
            )
            consensus = consensus.merge(rule.set_index("blind_id"), left_index=True, right_index=True, validate="one_to_one")
            strict = consensus[consensus["strict_majority"].eq(1)].copy()
            strict["rule_concordant"] = strict["strict_majority_label"].eq(strict["rule_label"]).astype(int)
            concordant = int(strict["rule_concordant"].sum())
            concordance = concordant / len(strict)
            concordance_low, concordance_high = wilson(concordant, len(strict))
            system_kappa = cohen_kappa(strict["strict_majority_label"], strict["rule_label"])[1]

            pairwise_rows = []
            for left, right in itertools.combinations(wide.columns, 2):
                raw, kappa = cohen_kappa(wide[left], wide[right])
                pairwise_rows.append(
                    {"reviewer_1": left, "reviewer_2": right, "n": len(wide), "raw_agreement": raw, "cohen_kappa": kappa}
                )
            pairwise = pd.DataFrame(pairwise_rows)

            influence_rows = []
            for omitted in wide.columns:
                retained = wide.drop(columns=omitted)
                retained_observed, retained_fleiss = fleiss_agreement(retained)
                _, retained_ac1 = gwet_ac1(retained)
                retained_values = retained.to_numpy(dtype=object)
                retained_labels = np.unique(retained_values)
                retained_counts = np.stack(
                    [(retained_values == label).sum(axis=1) for label in retained_labels], axis=1
                )
                influence_rows.append(
                    {
                        "omitted_reviewer": omitted,
                        "retained_raters": retained.shape[1],
                        "multi_rater_raw_agreement": retained_observed,
                        "fleiss_kappa": retained_fleiss,
                        "gwet_ac1": retained_ac1,
                        "majority_coverage": float(np.mean(retained_counts.max(axis=1) >= 2)),
                    }
                )
            influence = pd.DataFrame(influence_rows)

            source_by_case = key.set_index("blind_id").loc[wide.index, "file_id"].astype(str)
            source_values = source_by_case.to_numpy()
            sources = np.unique(source_values)
            rule_values = consensus.loc[wide.index, "rule_label"].to_numpy(dtype=object)
            rng = np.random.default_rng(BOOTSTRAP_SEED)
            observed_draws: list[float] = []
            kappa_draws: list[float] = []
            ac1_draws: list[float] = []
            coverage_draws: list[float] = []
            concordance_draws: list[float] = []
            for _ in range(BOOTSTRAP_DRAWS):
                sampled_sources = rng.choice(sources, size=len(sources), replace=True)
                indices = np.concatenate([np.flatnonzero(source_values == source) for source in sampled_sources])
                sample = wide.iloc[indices]
                sample_observed, sample_kappa = fleiss_agreement(sample)
                _, sample_ac1 = gwet_ac1(sample)
                sample_consensus = strict_majority(sample).reset_index(drop=True)
                sample_strict = sample_consensus["strict_majority"].eq(1).to_numpy()
                sample_rule = rule_values[indices]
                observed_draws.append(sample_observed)
                kappa_draws.append(sample_kappa)
                ac1_draws.append(sample_ac1)
                coverage_draws.append(float(sample_strict.mean()))
                if sample_strict.any():
                    labels = sample_consensus.loc[sample_strict, "strict_majority_label"].to_numpy(dtype=object)
                    concordance_draws.append(float(np.mean(labels == sample_rule[sample_strict])))

            observed_ci = quantiles(observed_draws)
            kappa_ci = quantiles(kappa_draws)
            ac1_ci = quantiles(ac1_draws)
            coverage_ci = quantiles(coverage_draws)
            concordance_cluster_ci = quantiles(concordance_draws)
            summary = pd.DataFrame(
                [
                    {
                        "metric": "multi_rater_raw_agreement",
                        "estimate": observed,
                        "numerator": "",
                        "denominator": len(wide),
                        "ci_low": observed_ci[0],
                        "ci_high": observed_ci[1],
                        "interval": "source-cluster bootstrap",
                    },
                    {
                        "metric": "fleiss_kappa",
                        "estimate": fleiss,
                        "numerator": "",
                        "denominator": len(wide),
                        "ci_low": kappa_ci[0],
                        "ci_high": kappa_ci[1],
                        "interval": "source-cluster bootstrap",
                    },
                    {
                        "metric": "gwet_ac1",
                        "estimate": ac1,
                        "numerator": "",
                        "denominator": len(wide),
                        "ci_low": ac1_ci[0],
                        "ci_high": ac1_ci[1],
                        "interval": "source-cluster bootstrap",
                    },
                    {
                        "metric": "strict_majority_coverage",
                        "estimate": len(strict) / len(wide),
                        "numerator": len(strict),
                        "denominator": len(wide),
                        "ci_low": coverage_ci[0],
                        "ci_high": coverage_ci[1],
                        "interval": "source-cluster bootstrap",
                    },
                    {
                        "metric": "rule_concordance_on_strict_majority_cases",
                        "estimate": concordance,
                        "numerator": concordant,
                        "denominator": len(strict),
                        "ci_low": concordance_low,
                        "ci_high": concordance_high,
                        "interval": "Wilson",
                    },
                    {
                        "metric": "rule_concordance_source_cluster_interval",
                        "estimate": concordance,
                        "numerator": concordant,
                        "denominator": len(strict),
                        "ci_low": concordance_cluster_ci[0],
                        "ci_high": concordance_cluster_ci[1],
                        "interval": "source-cluster bootstrap",
                    },
                    {
                        "metric": "rule_vs_strict_majority_cohen_kappa",
                        "estimate": system_kappa,
                        "numerator": "",
                        "denominator": len(strict),
                        "ci_low": "",
                        "ci_high": "",
                        "interval": "not estimated",
                    },
                ]
            )

            distribution = (
                responses.groupby(["reviewer", "response"]).size().reset_index(name="n")
            )
            updated = pd.to_datetime(responses["updated_at"], errors="coerce", utc=True)
            qc = responses.assign(updated_time=updated).groupby("reviewer").agg(
                cases=("blind_id", "nunique"),
                assessable=("assessability", lambda values: int(pd.Series(values).eq("assessable").sum())),
                mean_confidence=("confidence_1_to_5", lambda values: float(pd.to_numeric(values).mean())),
                first_update=("updated_time", "min"),
                last_update=("updated_time", "max"),
            ).reset_index()
            qc["elapsed_minutes"] = (qc["last_update"] - qc["first_update"]).dt.total_seconds() / 60.0

            consensus.reset_index().to_csv(
                args.analysis_dir / "blinded_panel_case_consensus.csv", index=False, encoding="utf-8-sig"
            )
            summary.to_csv(args.analysis_dir / "blinded_panel_agreement_summary.csv", index=False, encoding="utf-8-sig")
            pairwise.to_csv(args.analysis_dir / "blinded_panel_pairwise_agreement.csv", index=False, encoding="utf-8-sig")
            influence.to_csv(args.analysis_dir / "blinded_panel_rater_influence.csv", index=False, encoding="utf-8-sig")
            distribution.to_csv(args.analysis_dir / "blinded_panel_label_distribution.csv", index=False, encoding="utf-8-sig")
            qc.to_csv(args.analysis_dir / "blinded_panel_rater_qc.csv", index=False, encoding="utf-8-sig")
            print(summary.to_string(index=False))
            print(pairwise.to_string(index=False))

        main()


def run_external_validation(stage_args: list[str]) -> None:
    """Validate the frozen endpoint-governance rules on the public NASA battery archive."""
    with isolated_argv("external_validation", stage_args):
        import argparse
        from pathlib import Path

        import numpy as np
        import pandas as pd
        from scipy.io import loadmat

        def batch_for(number: int) -> str:
            if number in {5, 6, 7, 18}:
                return "FY08Q4"
            for low, high in [(25, 28), (29, 32), (33, 36), (38, 40), (41, 44), (45, 48), (49, 52), (53, 56)]:
                if low <= number <= high:
                    return f"B{low:02d}-{high:02d}"
            raise ValueError(f"Unrecognized NASA battery number: {number}")

        def documented_threshold(number: int) -> float:
            # Study-specific operational convention from the earlier local
            # batch review. The batch READMEs are not retained in this package;
            # do not equate these ratios with NASA's rated-capacity EOL rule.
            # The exported documented_* field names are a legacy data schema.
            return 0.8 if number in {33, 34, 36, 38, 39, 40} else 0.7

        def discharge_capacity(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
            root = loadmat(path, squeeze_me=True, struct_as_record=False)[path.stem]
            capacity: list[float] = []
            temperature: list[float] = []
            cutoff: list[float] = []
            for cycle in np.atleast_1d(root.cycle):
                if str(cycle.type).strip().lower() != "discharge":
                    continue
                values = np.asarray(getattr(cycle.data, "Capacity", np.nan), dtype=float).reshape(-1)
                if not len(values) or not np.isfinite(values[0]) or values[0] <= 0:
                    continue
                voltage = np.asarray(getattr(cycle.data, "Voltage_measured", []), dtype=float).reshape(-1)
                capacity.append(float(values[0]))
                temperature.append(float(cycle.ambient_temperature))
                cutoff.append(float(np.nanmin(voltage)) if len(voltage) else np.nan)
            return np.asarray(capacity), np.asarray(temperature), np.asarray(cutoff)

        def crossing_features(ratio: np.ndarray, threshold: float) -> dict[str, object]:
            below = np.flatnonzero(ratio <= threshold)
            naive = int(below[0] + 1) if len(below) else np.nan
            recovered = False
            isolated = False
            maximum_recovery = 0.0
            recrossed_after_clearance = False
            ended_above_clearance = False
            if len(below):
                first = int(below[0])
                later = ratio[first + 1 :]
                if len(later):
                    maximum_recovery = float(np.nanmax(later) - ratio[first])
                    recovered = bool(np.any(later > threshold + 0.03))
                    isolated = bool(ratio[first + 1] > threshold + 0.03)
                    clearance = np.flatnonzero(later > threshold + 0.03)
                    if len(clearance):
                        first_clearance = int(clearance[0])
                        recrossed_after_clearance = bool(
                            np.any(later[first_clearance + 1 :] <= threshold)
                        )
                    ended_above_clearance = bool(ratio[-1] > threshold + 0.03)
            state = "C" if not len(below) else ("R" if recovered else "E")
            return {
                "naive_crossing_cycle": naive,
                "governed_state": state,
                "recovered_after_crossing": int(recovered),
                "isolated_crossing": int(isolated),
                "max_recovery_after_first_crossing": maximum_recovery,
                "recrossed_after_first_clearance": int(recrossed_after_clearance),
                "ended_above_threshold_plus_margin": int(ended_above_clearance),
            }

        parser = argparse.ArgumentParser(description="External target-governance validation on NASA PCoE batteries.")
        parser.add_argument("--external-nasa-dir", type=Path, required=True)
        parser.add_argument("--analysis-dir", type=Path, default=Path("outputs") / "analysis")
        args = parser.parse_args()
        paths = sorted(args.external_nasa_dir.glob("B*.mat"))
        if len(paths) != 34:
            raise RuntimeError(f"Expected 34 NASA battery MAT files, found {len(paths)} in {args.external_nasa_dir}")

        args.analysis_dir.mkdir(parents=True, exist_ok=True)
        rows: list[dict[str, object]] = []
        trajectories: list[dict[str, object]] = []
        for path in paths:
            number = int(path.stem[1:])
            capacity, temperature, cutoff = discharge_capacity(path)
            if len(capacity) < 4:
                raise RuntimeError(f"Too few valid discharge cycles in {path.name}")
            baseline = float(np.median(capacity[:5]))
            ratio = capacity / baseline
            documented_anomaly = int(41 <= number <= 56)
            row: dict[str, object] = {
                "battery_id": path.stem,
                "batch": batch_for(number),
                "n_discharge_cycles": len(capacity),
                "baseline_capacity_Ah": baseline,
                "first_capacity_Ah": float(capacity[0]),
                "final_capacity_ratio": float(ratio[-1]),
                "minimum_capacity_ratio": float(np.min(ratio)),
                "maximum_adjacent_rise": float(np.max(np.diff(ratio))),
                "maximum_recovery_after_minimum": float(np.max(ratio[np.argmin(ratio) :]) - np.min(ratio)),
                "ambient_temperature_C": float(np.median(temperature)),
                "median_discharge_cutoff_V": float(np.nanmedian(cutoff)),
                "documented_threshold_ratio": documented_threshold(number),
                "documented_anomaly_group": documented_anomaly,
            }
            for threshold in (0.8, 0.7):
                for key, value in crossing_features(ratio, threshold).items():
                    row[f"t{int(threshold * 100)}_{key}"] = value
            row["fixed_review_flag"] = int(
                float(row["maximum_recovery_after_minimum"]) >= 0.15
                or float(row["maximum_adjacent_rise"]) >= 0.10
                or int(row["t80_recovered_after_crossing"]) == 1
                or int(row["t70_recovered_after_crossing"]) == 1
            )
            threshold_key = int(documented_threshold(number) * 100)
            row["documented_threshold_naive_crossing_cycle"] = row[f"t{threshold_key}_naive_crossing_cycle"]
            row["documented_threshold_governed_state"] = row[f"t{threshold_key}_governed_state"]
            row["documented_threshold_recrossed_after_first_clearance"] = row[
                f"t{threshold_key}_recrossed_after_first_clearance"
            ]
            row["documented_threshold_ended_above_threshold_plus_margin"] = row[
                f"t{threshold_key}_ended_above_threshold_plus_margin"
            ]
            rows.append(row)
            for cycle, (value, normalized) in enumerate(zip(capacity, ratio), start=1):
                trajectories.append(
                    {
                        "battery_id": path.stem,
                        "batch": row["batch"],
                        "discharge_cycle": cycle,
                        "capacity_Ah": float(value),
                        "capacity_ratio": float(normalized),
                        "documented_anomaly_group": documented_anomaly,
                        "fixed_review_flag": row["fixed_review_flag"],
                    }
                )

        summary = pd.DataFrame(rows)
        trajectory = pd.DataFrame(trajectories)
        documented = summary["documented_anomaly_group"].eq(1)
        routed = summary["fixed_review_flag"].eq(1)
        captured = int((documented & routed).sum())
        documented_n = int(documented.sum())
        metrics: list[dict[str, object]] = [
            {"metric": "batteries", "estimate": len(summary), "numerator": len(summary), "denominator": len(summary), "inference": "descriptive_count"},
            {"metric": "protocol_batches", "estimate": summary["batch"].nunique(), "numerator": summary["batch"].nunique(), "denominator": summary["batch"].nunique(), "inference": "descriptive_count"},
            {"metric": "documented_anomaly_capture", "estimate": captured / documented_n, "numerator": captured, "denominator": documented_n, "inference": "descriptive_battery_fraction_with_local_batch_annotation"},
            {"metric": "non_documented_not_routed", "estimate": int((~documented & ~routed).sum()) / int((~documented).sum()), "numerator": int((~documented & ~routed).sum()), "denominator": int((~documented).sum()), "inference": "descriptive_battery_fraction_with_local_batch_annotation"},
        ]
        for threshold in (80, 70):
            crossed = summary[f"t{threshold}_naive_crossing_cycle"].notna()
            recovered = summary[f"t{threshold}_recovered_after_crossing"].eq(1)
            metrics.append(
                {
                    "metric": f"recovered_share_among_naive_t{threshold}_crossings",
                    "estimate": int((crossed & recovered).sum()) / int(crossed.sum()),
                    "numerator": int((crossed & recovered).sum()),
                    "denominator": int(crossed.sum()),
                    "inference": "descriptive_battery_fraction_clustered_within_protocol_batches",
                }
            )
            recrossed = summary[f"t{threshold}_recrossed_after_first_clearance"].eq(1)
            recovered_n = int((crossed & recovered).sum())
            metrics.append(
                {
                    "metric": f"recrossed_share_among_recovered_t{threshold}_crossings",
                    "estimate": int((crossed & recovered & recrossed).sum()) / recovered_n if recovered_n else np.nan,
                    "numerator": int((crossed & recovered & recrossed).sum()),
                    "denominator": recovered_n,
                    "inference": "descriptive_battery_fraction_clustered_within_protocol_batches",
                }
            )
        states = summary["documented_threshold_governed_state"].value_counts()
        metrics.extend(
            {
                "metric": f"documented_threshold_state_{state}",
                "estimate": int(states.get(state, 0)),
                "numerator": int(states.get(state, 0)),
                "denominator": len(summary),
                "inference": "descriptive_state_count",
            }
            for state in ["E", "R", "C"]
        )
        metric_table = pd.DataFrame(metrics)
        summary.to_csv(args.analysis_dir / "nasa_battery_external_device_summary.csv", index=False, encoding="utf-8-sig")
        trajectory.to_csv(args.analysis_dir / "nasa_battery_external_trajectories.csv", index=False, encoding="utf-8-sig")
        metric_table.to_csv(args.analysis_dir / "nasa_battery_external_metrics.csv", index=False, encoding="utf-8-sig")
        report = args.analysis_dir / "nasa_battery_external_report.md"
        report.write_text(
            "# NASA battery state-record replay\n\n"
            f"The frozen rules were replayed on {len(summary)} batteries from {summary['batch'].nunique()} protocol batches. "
            f"At each battery's assigned study-specific threshold, a single-crossing label produced {int(summary['documented_threshold_naive_crossing_cycle'].notna().sum())} events. "
            f"The governed state record separated these into {int(states.get('E', 0))} crossings without recorded clearance and {int(states.get('R', 0))} with later clearance, with {int(states.get('C', 0))} trajectories without a crossing. "
            f"The fixed conservative review rule routed {captured}/{documented_n} batteries in locally marked anomalous or incomplete batches "
            f"and {int((~documented & ~routed).sum())}/{int((~documented).sum())} batteries outside those batches were not routed. "
            "The underlying batch notes are not retained in this package. All fractions are descriptive because batteries share batch-level annotations; no battery-independent diagnostic accuracy is claimed.\n",
            encoding="utf-8",
        )
        print(metric_table.to_string(index=False))
        print(f"report={report.resolve()}")



def run_governance_audit(stage_args: list[str]) -> None:
    """Reconcile frozen target exports without modifying targets or fitting a model.

    The default input is the controlled analysis directory. An explicitly supplied
    directory can contain the same minimal columns with pseudonymous identifiers.
    These are structural consistency checks, not tests of physical label accuracy.
    """
    import json
    import hashlib
    import numpy as np
    import pandas as pd

    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Audit the frozen target and trace contract.")
    parser.add_argument("--input-dir", type=Path, default=root / "outputs" / "analysis")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs" / "analysis")
    args = parser.parse_args(stage_args)
    names = ["reliability_dataset_all_definitions.csv", "reliability_evidence_passport.csv",
             "device_rule_trace.csv", "system_endpoint_reconciliation.csv"]
    for name in names:
        if not (args.input_dir / name).is_file():
            raise FileNotFoundError(f"Required frozen audit input is missing: {args.input_dir / name}")
    endpoint, passport, trace, reconciliation = [
        pd.read_csv(args.input_dir / name, encoding="utf-8-sig", keep_default_na=False, na_values=[""]) for name in names
    ]
    required = {
        names[0]: {"device_uid", "p0_definition", "failure_threshold_ratio", "event_status", "event_observed", "analysis_time_h"},
        names[1]: {"device_uid", "binary_event_flip", "four_state_definition_change", "decision_vulnerability_score"},
        names[2]: {"device_uid", "trace_sequence", "rule_id", "registry_version"},
        names[3]: {"device_uid", "corrected_single_state", "corrected_single_event_observed", "corrected_single_analysis_time_h"},
    }
    required[names[1]].update(
        f"passport_component_{component}" for component in (
            "four_state_definition_change", "non_metadata_baseline", "qx1_substitution",
            "qx2_transient_handling", "time_review_fraction", "low_rule_confidence",
            "zero_power_evidence", "rule_review_flag", "main_endpoint_nonassessable",
        )
    )
    for name, frame in zip(names, [endpoint, passport, trace, reconciliation]):
        missing = required[name].difference(frame.columns)
        if missing:
            raise ValueError(f"{name} is missing columns: {sorted(missing)}")
    state_map = {"failure_observed": "E", "early_failure_observed": "E",
                 "failure_observed_with_recovery": "R", "right_censored": "C",
                 "p0_missing_or_nonpositive": "NA", "transient_or_measurement_issue": "NA",
                 "no_valid_measurements": "NA"}
    unknown = set(endpoint.event_status.dropna()).difference(state_map)
    if unknown or endpoint.event_status.isna().any():
        raise ValueError(f"Unrecognized endpoint statuses: {unknown}")
    endpoint = endpoint.assign(state=endpoint.event_status.map(state_map))
    ids = set(endpoint.device_uid)
    if not ids:
        raise ValueError("The endpoint contract is empty.")
    rows = []
    def check(name, passed, evaluated, violations, meaning):
        rows.append(dict(check=name, passed=bool(passed), evaluated_units=int(evaluated),
                         violations=int(violations), interpretation=meaning))
    key = ["device_uid", "p0_definition", "failure_threshold_ratio"]
    duplicate = endpoint.duplicated(key, keep=False)
    check("unique_definition_keys", not duplicate.any(), len(endpoint), duplicate.sum(), "One row per device, baseline and threshold.")
    expected = {(b, t) for b in ("p0_meta", "p0_early_median5", "p0_post_stabilization", "p0_best_available") for t in (0.5, 0.7, 0.8)}
    # The stored names are checked against the registry's actual baseline vocabulary.
    actual_baselines = set(endpoint.p0_definition)
    if actual_baselines != {b for b, _ in expected}:
        raise ValueError(f"Unexpected baseline vocabulary: {sorted(actual_baselines)}")
    bad_grids = sum(set(zip(g.p0_definition, g.failure_threshold_ratio.round(8))) != expected
                    or len(g) != 12 for _, g in endpoint.groupby("device_uid"))
    check("complete_definition_grid", bad_grids == 0, len(ids), bad_grids, "Four baselines by three thresholds for every device.")
    for label, frame in [("passport", passport), ("reconciliation", reconciliation)]:
        bad = len(ids.symmetric_difference(set(frame.device_uid))) + int(frame.device_uid.duplicated().sum())
        check(f"{label}_cohort_identity", bad == 0, len(ids), bad, "A unique record for each endpoint device.")
    binary = endpoint[endpoint.state.ne("NA")].groupby("device_uid").event_observed.nunique().gt(1).reindex(sorted(ids), fill_value=False)
    four_state = endpoint.groupby("device_uid").state.nunique().gt(1).reindex(sorted(ids))
    indexed = passport.set_index("device_uid").reindex(sorted(ids))
    for label, calculated, column in [("binary_fragility", binary, "binary_event_flip"),
                                       ("four_state_fragility", four_state, "four_state_definition_change")]:
        bad = int(calculated.astype(int).ne(indexed[column]).sum())
        check(f"{label}_reconciliation", bad == 0, len(ids), bad, "Recomputed from the complete endpoint ensemble.")
    assessable = endpoint.state.ne("NA")
    expected_binary = endpoint.state.isin(["E", "R"]).astype(int)
    bad = int(endpoint.loc[assessable, "event_observed"].ne(expected_binary[assessable]).sum())
    check("state_event_consistency", bad == 0, assessable.sum(), bad, "E and R are events; C remains censored.")
    bad = int((~np.isfinite(endpoint.loc[assessable, "analysis_time_h"]) | endpoint.loc[assessable, "analysis_time_h"].lt(0)).sum())
    check("assessable_time_validity", bad == 0, assessable.sum(), bad, "Assessable records retain finite nonnegative inspection times.")
    weights = {"four_state_definition_change": 30, "non_metadata_baseline": 0,
               "qx1_substitution": 10, "qx2_transient_handling": 5, "time_review_fraction": 10,
               "low_rule_confidence": 10, "zero_power_evidence": 5, "rule_review_flag": 10,
               "main_endpoint_nonassessable": 5}
    weighted = np.zeros(len(passport))
    for component, weight in weights.items():
        values = passport[f"passport_component_{component}"]
        if not np.isfinite(values).all() or not values.between(0, 1).all():
            raise ValueError(f"Invalid passport component: {component}")
        weighted += weight * values.to_numpy()
    bad = int((~np.isclose(weighted, passport.decision_vulnerability_score, atol=1e-8, rtol=0)).sum())
    check("passport_score_reconciliation", bad == 0, len(passport), bad, "The fixed component weights reproduce the exported score.")
    required_rules = ["TR-1", "BI-1", "EF-1", "P0-1", "EVT-1", "RCV-1", "FM-1", "PAS-1", "AR-1"]
    trace_groups = dict(tuple(trace.groupby("device_uid")))
    missing_rules = order_errors = endpoint_count_errors = 0
    for uid in ids:
        g = trace_groups.get(uid, trace.iloc[:0]).sort_values("trace_sequence")
        missing = set(required_rules).difference(g.rule_id)
        missing_rules += bool(missing)
        endpoint_count_errors += int(g.rule_id.eq("EVT-1").sum()) != 12
        if not missing:
            bounds = [(g.loc[g.rule_id.eq(rule), "trace_sequence"].min(),
                       g.loc[g.rule_id.eq(rule), "trace_sequence"].max()) for rule in required_rules]
            order_errors += any(right[0] <= left[1] for left, right in zip(bounds, bounds[1:]))
    check("mandatory_rule_coverage", missing_rules == 0, len(ids), missing_rules, "All nine mandatory rule families have a trace.")
    check("registered_trace_order", order_errors == 0, len(ids), order_errors, "Stored traces follow the registered dependency order.")
    check("endpoint_trace_cardinality", endpoint_count_errors == 0, len(ids), endpoint_count_errors, "Twelve endpoint trace rows per device.")
    trace_bad = int(trace.trace_sequence.duplicated().sum()) + len(set(trace.device_uid).difference(ids))
    check("trace_key_integrity", trace_bad == 0, len(trace), trace_bad, "Unique sequence identifiers and no extraneous device traces.")
    main = endpoint[endpoint.p0_definition.eq("p0_best_available") & endpoint.failure_threshold_ratio.eq(0.8)].set_index("device_uid")
    comparison = reconciliation.set_index("device_uid").reindex(main.index)
    bad = int(main.state.ne(comparison.corrected_single_state).sum())
    good = main.state.ne("NA")
    bad += int(main.loc[good, "event_observed"].ne(comparison.loc[good, "corrected_single_event_observed"]).sum())
    bad += int((~np.isclose(main.loc[good, "analysis_time_h"], comparison.loc[good, "corrected_single_analysis_time_h"], atol=1e-6, rtol=0, equal_nan=True)).sum())
    check("main_endpoint_reconciliation", bad == 0, len(main), bad, "The ensemble main member reproduces the separately exported endpoint.")
    report = pd.DataFrame(rows)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    report.to_csv(args.output_dir / "target_contract_audit.csv", index=False, encoding="utf-8")
    summary = {"schema_version": "1.0", "registry_versions": sorted(trace.registry_version.unique().tolist()),
               "devices": len(ids), "endpoint_definitions": len(endpoint), "trace_rows": len(trace),
               "checks": len(rows), "all_checks_passed": bool(report.passed.all()),
               "binary_fragile_devices": int(binary.sum()), "four_state_fragile_devices": int(four_state.sum()),
               "main_state_counts": main.state.value_counts().to_dict(),
               "scope": "Post hoc structural audit of frozen exports; not physical accuracy, predictive superiority or review utility.",
               "input_sha256": {name: hashlib.sha256((args.input_dir / name).read_bytes()).hexdigest() for name in names}}
    (args.output_dir / "target_contract_audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "input_sha256"}, indent=2))
    if not report.passed.all():
        raise ValueError("Target contract audit failed; inspect target_contract_audit.csv.")


STAGE_ORDER = ["extract","clean","events","failure_modes","reliability","passport","early_warning","validation","blind_review","panel_analysis","ablation","rule_trace","system_comparison","system_artifacts","governance_audit"]
STAGE_RUNNERS = {
    "extract": run_extract,
    "clean": run_clean,
    "events": run_events,
    "failure_modes": run_failure_modes,
    "reliability": run_reliability,
    "passport": run_passport,
    "early_warning": run_early_warning,
    "validation": run_validation,
    "blind_review": run_blind_review_setup,
    "panel_analysis": run_panel_analysis,
    "ablation": run_ablation,
    "rule_trace": run_rule_trace,
    "system_comparison": run_system_comparison,
    "system_artifacts": run_system_artifacts,
    "governance_audit": run_governance_audit,
}
AUXILIARY_STAGE_RUNNERS = {
    "external_validation": run_external_validation,
}


def extract_nasa_archive(archive: Path, destination: Path) -> None:
    from io import BytesIO
    import re
    import zipfile
    with zipfile.ZipFile(archive) as outer:
        for member in outer.namelist():
            if not member.lower().endswith('.zip'):
                continue
            with zipfile.ZipFile(BytesIO(outer.read(member))) as batch:
                for item in batch.namelist():
                    name = Path(item).name
                    if not re.fullmatch(r'B\d+\.mat', name, re.IGNORECASE):
                        continue
                    content = batch.read(item)
                    target = destination / name
                    if target.exists():
                        if target.read_bytes() != content:
                            raise ValueError(f'NASA archive contains conflicting versions of {name}')
                    else:
                        target.write_bytes(content)


def run_observation_simulation() -> None:
    """Synthetic observation-boundary sensitivity; see frozen simulation_protocol.md."""

    from pathlib import Path

    import json

    import hashlib

    import numpy as np

    import pandas as pd

    ROOT = Path(__file__).resolve().parents[1]

    OUT = ROOT / "outputs" / "analysis" / "ress_observation_simulation"

    PROTOCOL = ROOT / "data" / "ress_observation_simulation_protocol.md"

    PROTOCOL_SHA256 = "fd8a573aa17f55b7eefdea691ce564e8168e70662ad45d2aa689052fc2913643"

    CONFIG = {"seed": 20260911, "replications": 400, "units_per_replication": 100,
              "latent_crossing_uniform": [150, 1350], "baseline": 1.0, "threshold": 0.8,
              "inspection_spacing": [25, 100, 300], "administrative_termination": [600, 900, 1200],
              "observation_noise_sd": [0.0, 0.03], "time_unit": "arbitrary",
              "uncertainty": "Monte Carlo precision of replication means; not archive inference"}

    def run():
        protocol_sha256 = hashlib.sha256(PROTOCOL.read_bytes()).hexdigest()
        if protocol_sha256 != PROTOCOL_SHA256:
            raise ValueError("The bundled observation-simulation protocol does not match the frozen version.")
        OUT.mkdir(parents=True, exist_ok=True)
        rng = np.random.default_rng(CONFIG["seed"])
        rows, paired = [], []
        checks = {"noiseless_operator_equality": True, "common_event_time_equality": True,
                  "state_fractions_sum_to_one": True, "same_operator_inputs": True}
        master_t = np.arange(0, 1201, 25, dtype=float)
        for rep in range(CONFIG["replications"]):
            latent_t = rng.uniform(*CONFIG["latent_crossing_uniform"], CONFIG["units_per_replication"])
            latent_y = np.maximum(0, 1 - 0.2 * master_t[None, :] / latent_t[:, None])
            master_noise = rng.normal(size=latent_y.shape)
            for spacing in CONFIG["inspection_spacing"]:
                for stop in CONFIG["administrative_termination"]:
                    times = np.unique(np.append(np.arange(0, stop + 1, spacing), stop)).astype(float)
                    indices = (times / 25).astype(int)
                    truth = latent_t <= stop
                    for noise in CONFIG["observation_noise_sd"]:
                        y = latent_y[:, indices] + noise * master_noise[:, indices]
                        y[:, 0] = 1.0
                        below = y <= CONFIG["threshold"]
                        has_first = below.any(axis=1)
                        first_idx = below.argmax(axis=1)
                        first_time = times[first_idx]
                        terminal = has_first & (first_idx == len(times)-1)
                        confirmed = has_first & ((below.sum(axis=1) >= 2) | terminal)
                        unresolved = has_first & ~confirmed
                        first_registered_time = np.where(has_first, first_time, np.nan)
                        confirmed_registered_time = np.where(confirmed, first_time, np.nan)
                        common_time_differences = confirmed_registered_time[confirmed] - first_registered_time[confirmed]
                        checks["common_event_time_equality"] &= bool(np.all(common_time_differences == 0))
                        if noise == 0:
                            checks["noiseless_operator_equality"] &= bool(np.array_equal(has_first, confirmed))
                        key = {"replication": rep, "spacing": spacing, "termination": stop, "noise_sd": noise}
                        for method, event, unknown in [("first_registered", has_first, np.zeros_like(has_first)),
                                                       ("confirmed_interior_terminal", confirmed, unresolved)]:
                            censored = ~has_first
                            support = event & truth
                            err = first_time[support] - latent_t[support]
                            fractions = float(event.mean() + unknown.mean() + censored.mean())
                            checks["state_fractions_sum_to_one"] &= bool(np.isclose(fractions, 1))
                            rows.append({**key, "method": method, "n": len(truth),
                                "latent_event_fraction": float(truth.mean()),
                                "registered_event_fraction": float(event.mean()),
                                "censored_fraction": float(censored.mean()), "unresolved_fraction": float(unknown.mean()),
                                "event_fraction_difference_from_latent": float(event.mean()-truth.mean()),
                                "false_registered_fraction": float((event & ~truth).mean()),
                                "latent_without_registered_fraction": float((truth & ~event).mean()),
                                "conditional_signed_time_error": float(err.mean()) if len(err) else np.nan,
                                "conditional_timing_support": int(support.sum()),
                                "terminal_only_fraction": float(terminal.mean())})
                        paired.append({**key, "event_fraction_delta_confirmed_minus_first": float(confirmed.mean()-has_first.mean()),
                                       "unresolved_interior_fraction": float(unresolved.mean()),
                                       "common_event_time_delta": float(common_time_differences.mean()) if confirmed.any() else np.nan,
                                       "common_events": int(confirmed.sum())})
        frame = pd.DataFrame(rows)
        pairs = pd.DataFrame(paired)
        frame.to_csv(OUT / "replication_metrics.csv", index=False)
        pairs.to_csv(OUT / "paired_replication_metrics.csv", index=False)
        def summarize(df, groups, metrics):
            result = []
            for key, part in df.groupby(groups, sort=True):
                base = dict(zip(groups, key))
                for metric in metrics:
                    values = part[metric].dropna()
                    mean = float(values.mean())
                    mcse = float(values.std(ddof=1)/np.sqrt(len(values)))
                    result.append({**base, "metric": metric, "valid_replications": len(values),
                                   "mean": mean, "mcse": mcse, "mc_low": mean-1.96*mcse, "mc_high": mean+1.96*mcse})
            return pd.DataFrame(result)
        groups = ["spacing", "termination", "noise_sd", "method"]
        metrics = [x for x in frame.columns if x not in groups + ["replication", "n"]]
        summarize(frame, groups, metrics).to_csv(OUT / "scenario_summary.csv", index=False)
        summarize(pairs, groups[:-1], [x for x in pairs.columns if x not in groups[:-1]+["replication"]]).to_csv(OUT / "paired_summary.csv", index=False)
        checks["complete_factorial"] = len(frame) == 400*18*2 and len(pairs) == 400*18
        checks["replication_units_correct"] = bool(frame["n"].eq(100).all())
        CONFIG["protocol_sha256"] = protocol_sha256
        checks["bundled_protocol_hash_matches_frozen"] = protocol_sha256 == PROTOCOL_SHA256
        (OUT / "config.json").write_text(json.dumps(CONFIG, indent=2), encoding="utf-8")
        (OUT / "checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
        if not all(checks.values()):
            raise AssertionError(checks)
        print(json.dumps({"replication_rows": len(frame), "paired_rows": len(pairs), "checks": checks}))

    run()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the standalone QAES-VCSEL analysis and export all plot-ready datasets."
    )
    parser.add_argument(
        "--stage",
        choices=["all", *STAGE_ORDER, *AUXILIARY_STAGE_RUNNERS],
        default="all",
        help="Run the complete ordered workflow or one named analysis stage.",
    )
    parser.add_argument(
        "--bootstrap-draws",
        type=int,
        default=20_000,
        help="Source-cluster bootstrap draws used by the ablation stage.",
    )
    parser.add_argument(
        "--bootstrap-seed",
        type=int,
        default=20260711,
        help="Deterministic seed used by the ablation bootstrap.",
    )
    parser.add_argument(
        "--review-seed",
        type=int,
        default=20260807,
        help="Deterministic anonymization and order seed for the blind-review instrument.",
    )
    parser.add_argument(
        "--external-nasa-dir",
        type=Path,
        help="Directory containing the 34 public NASA PCoE B*.mat battery files.",
    )
    parser.add_argument(
        "--from-processed",
        action="store_true",
        help=(
            "Rebuild all numerical analyses from the included processed tables without "
            "requiring the private source workbooks."
        ),
    )
    parser.add_argument("--audit-input-dir", type=Path, help="Frozen original or sanitized inputs for --stage governance_audit.")
    parser.add_argument("--audit-output-dir", type=Path, help="Output directory for --stage governance_audit.")
    parser.add_argument("--external-nasa-archive", type=Path, help="NASA Battery Data Set ZIP, including its nested batch archives.")
    args = parser.parse_args()
    if (args.audit_input_dir or args.audit_output_dir) and args.stage != "governance_audit":
        parser.error("Audit path options require --stage governance_audit.")
    if args.from_processed and args.stage != "all":
        parser.error("--from-processed is used with the default --stage all workflow.")
    from contextlib import ExitStack
    import tempfile
    with ExitStack() as input_stack:
        if args.external_nasa_archive is not None:
            temporary = input_stack.enter_context(tempfile.TemporaryDirectory(prefix='qaes_nasa_'))
            args.external_nasa_dir = Path(temporary)
            extract_nasa_archive(args.external_nasa_archive, args.external_nasa_dir)
        selected = STAGE_ORDER[2:] if args.from_processed else (STAGE_ORDER if args.stage == "all" else [args.stage])
        if args.stage == "all" and args.external_nasa_dir is not None:
            selected = list(selected)
            selected.insert(selected.index("system_artifacts"), "external_validation")
        for stage in selected:
            stage_args: list[str] = []
            if stage == "governance_audit":
                if args.audit_input_dir:
                    stage_args.extend(["--input-dir", str(args.audit_input_dir)])
                if args.audit_output_dir:
                    stage_args.extend(["--output-dir", str(args.audit_output_dir)])
            if stage == "ablation":
                stage_args = [
                    "--bootstrap-draws", str(args.bootstrap_draws),
                    "--bootstrap-seed", str(args.bootstrap_seed),
                ]
            if stage == "blind_review":
                stage_args = ["--seed", str(args.review_seed)]
            if stage == "external_validation":
                if args.external_nasa_dir is None:
                    parser.error("--stage external_validation requires --external-nasa-dir PATH")
                stage_args = ["--external-nasa-dir", str(args.external_nasa_dir)]
            print(f"\n=== analysis stage: {stage} ===")
            runner = STAGE_RUNNERS.get(stage, AUXILIARY_STAGE_RUNNERS.get(stage))
            if runner is None:
                raise KeyError(stage)
            runner(stage_args)
    if args.stage == "all":
        import subprocess
        subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('ress_endpoint_analysis.py'))], cwd=Path(__file__).resolve().parents[1], check=True)
    if args.stage == "all":
        run_observation_simulation()
    print("\nAnalysis workflow complete.")


if __name__ == "__main__":
    main()

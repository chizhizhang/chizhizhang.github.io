"""Read the archived workbooks to check exported source cells and early references."""

from __future__ import annotations

import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUTPUT = ROOT / "outputs" / "ress_upgrade_20260925" / "raw_source_audit"


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def number(value: object) -> float | None:
    try:
        if value in (None, ""):
            return None
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def same(left: float | None, right: float | None) -> bool:
    return (left is None and right is None) or (
        left is not None
        and right is not None
        and math.isclose(left, right, rel_tol=0, abs_tol=1e-6)
    )


def main() -> None:
    manifest = {
        row["file_id"]: row
        for row in rows(DATA / "dataset_manifest.csv")
        if row["model_role"] == "main_model"
    }
    books = {}
    for file_id, entry in manifest.items():
        path = (DATA / entry["relative_path"]).resolve()
        if not path.is_relative_to(DATA.resolve()) or path.suffix.lower() != ".xlsx":
            raise ValueError(f"Unexpected source path for {file_id}")
        books[file_id] = load_workbook(path, data_only=True, read_only=False)

    measurements = rows(ROOT / "outputs" / "processed" / "measurement_table.csv")
    by_device: dict[str, list[tuple[dict[str, str], object]]] = defaultdict(list)
    numeric_matches = status_matches = 0
    for row in measurements:
        file_id = row["file_id"]
        if file_id not in books:
            raise ValueError(f"Unadmitted source: {file_id}")
        raw = books[file_id][row["sheet"]][row["source_cell"]].value
        expected_numeric = number(row["power_mW_raw_extracted"])
        if expected_numeric is not None:
            if not same(number(raw), expected_numeric):
                raise AssertionError((row["device_uid"], row["source_cell"], "numeric"))
            numeric_matches += 1
        else:
            if str(raw) != row["power_raw"]:
                raise AssertionError((row["device_uid"], row["source_cell"], "status"))
            status_matches += 1
        by_device[row["device_uid"]].append((row, raw))

    devices = {row["device_uid"]: row for row in rows(ROOT / "outputs" / "processed" / "device_table.csv")}
    if len(devices) != 104:
        raise AssertionError("Unexpected device cohort")
    references: dict[str, dict[str, object]] = {}
    metadata_matches = 0
    for uid, device in devices.items():
        eligible = []
        for row, raw in by_device[uid]:
            time = number(row["exposure_hours"])
            if time is None:
                time = number(row["calendar_hours"])
            power = number(raw)
            if time is not None and power is not None and 0 <= time <= 240 and power > 0:
                eligible.append((time, row["measurement_time"], row["source_cell"], power))
        first_three = sorted(eligible)[:3]
        values = [item[3] for item in first_three]
        metadata = number(device["p0_meta_mW"])
        metadata_cell = ""
        if metadata is not None and metadata > 0:
            header_row = int(device["device_header_row"])
            sheet = books[device["file_id"]][device["sheet"]]
            for row_number in (header_row + 3, header_row + 4):
                candidate = f"{device['source_column']}{row_number}"
                if same(number(sheet[candidate].value), metadata):
                    metadata_cell = candidate
                    break
            if not metadata_cell:
                raise AssertionError((uid, "metadata source cell"))
            metadata_matches += 1
            values.append(metadata)
        maximum = max(values) if values else None
        median = statistics.median(values) if values else None
        if not same(maximum, number(device["provisional_early_reference_mW"])):
            raise AssertionError((uid, "maximum reference"))
        if not same(median, number(device["sensitivity_median_reference_provisional_early_reference_mW"])):
            raise AssertionError((uid, "median reference"))
        references[uid] = {
            "maximum_reference_mW": maximum,
            "median_reference_mW": median,
            "support_cells": ";".join(item[2] for item in first_three),
            "metadata_mW": metadata,
            "metadata_cell": metadata_cell,
        }

    changed = [
        row
        for row in rows(ROOT / "outputs" / "analysis" / "early_rule_endpoint_transitions.csv")
        if row["scenario"] == "median_reference_100h_240h"
        and row["state_changed_vs_frozen"] == "1"
    ]
    if len(changed) != 9 or {row["file_id"] for row in changed} != {"F005", "F006"}:
        raise AssertionError("Unexpected changed-state set")
    main_event_traces = {
        row["device_uid"]: row
        for row in rows(ROOT / "outputs" / "analysis" / "device_rule_trace.csv")
        if row["rule_id"] == "EVT-1"
        and "p0=p0_best_available;threshold=0.8;" in row["trigger_value"]
    }
    paired_evidence = []
    for transition in changed:
        uid = transition["device_uid"]
        endpoints = []
        for time_key in ("frozen_analysis_time_h", "analysis_time_h"):
            endpoint_time = number(transition[time_key])
            support = [
                (row, raw)
                for row, raw in by_device[uid]
                if same(number(row["exposure_hours"]), endpoint_time)
            ]
            if len(support) != 1 or number(support[0][1]) is None:
                raise AssertionError((uid, time_key, "inspection support"))
            endpoints.append(support[0])
        event, censor = endpoints
        trace = main_event_traces.get(uid)
        if trace is None or trace["source_evidence"].split("|")[-1] != event[0]["source_cell"]:
            raise AssertionError((uid, "event trace pointer"))
        paired_evidence.append(
            {
                "device_uid": uid,
                "file_id": transition["file_id"],
                **references[uid],
                "maximum_state": transition["frozen_endpoint_state"],
                "median_state": transition["endpoint_state"],
                "maximum_event_time_h": transition["frozen_analysis_time_h"],
                "maximum_event_cell": event[0]["source_cell"],
                "maximum_event_power_mW": event[1],
                "median_censor_time_h": transition["analysis_time_h"],
                "median_censor_cell": censor[0]["source_cell"],
                "median_censor_power_mW": censor[1],
            }
        )

    OUTPUT.mkdir(parents=True, exist_ok=True)
    with (OUTPUT / "paired_evidence.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired_evidence[0]))
        writer.writeheader()
        writer.writerows(paired_evidence)
    summary = {
        "source_workbooks": len(books),
        "source_records": len(measurements),
        "numeric_cell_matches": numeric_matches,
        "nonnumeric_status_cell_matches": status_matches,
        "source_value_mismatches": 0,
        "metadata_cell_matches": metadata_matches,
        "devices_with_reconstructed_maximum_and_median_references": len(references),
        "changed_state_pairs_with_event_and_censor_inspection_cells": len(paired_evidence),
        "main_event_trace_pointer_matches": len(paired_evidence),
        "changed_state_sources": sorted({row["file_id"] for row in changed}),
        "scope": "Direct source-cell and reference-value audit using the recorded inspection clock; not an independent adjudication or a review-effort study.",
    }
    (OUTPUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

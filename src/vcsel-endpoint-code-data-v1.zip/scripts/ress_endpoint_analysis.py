"""Reproduce descriptive endpoint comparisons from frozen, paired exports.

No plotting, fitting, target rewriting, or import of the original numerical program.
Comparisons isolate representation under identical endpoint rules; no physical
accuracy or review-utility outcome is available. Run from any working directory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

STATE = {
    "failure_observed": "E", "early_failure_observed": "E",
    "failure_observed_with_recovery": "R", "right_censored": "C",
    "p0_missing_or_nonpositive": "NA", "transient_or_measurement_issue": "NA",
    "no_valid_measurements": "NA",
}
BASE = "frozen_max_reference_100h_240h"
MEDIAN = "median_reference_100h_240h"


def km(frame: pd.DataFrame, state: str = "endpoint_state",
       time: str = "analysis_time_h", event: str = "event_observed") -> dict:
    valid = frame.loc[frame[state].ne("NA")].copy()
    t = pd.to_numeric(valid[time], errors="raise").to_numpy(float)
    e = pd.to_numeric(valid[event], errors="raise").to_numpy(int)
    if not len(t):
        return dict(n=0, events=0, censored=0, median_h=None, median_status="empty", maximum_followup_h=None)
    if not np.isfinite(t).all() or (t < 0).any() or not np.isin(e, [0, 1]).all():
        raise ValueError("Invalid assessable time/event contract")
    survival, median = 1.0, None
    for current in np.unique(t):
        survival *= 1.0 - np.sum((t == current) & (e == 1)) / np.sum(t >= current)
        if median is None and survival <= .5:
            median = float(current)
    return dict(n=len(t), events=int(e.sum()), censored=int(len(t)-e.sum()),
                median_h=median, median_status="reached" if median is not None else "not_reached",
                maximum_followup_h=float(t.max()))


def changed(a: pd.Series, b: pd.Series) -> np.ndarray:
    return ~np.isclose(pd.to_numeric(a, errors="coerce"), pd.to_numeric(b, errors="coerce"),
                       rtol=0, atol=1e-6, equal_nan=True)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-dir", type=Path, default=root / "outputs/analysis")
    parser.add_argument("--output-dir", type=Path, default=root / "outputs/ress_analysis")
    parser.add_argument("--bootstrap-draws", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=20260911)
    args = parser.parse_args()
    if args.bootstrap_draws < 1000:
        parser.error("At least 1000 descriptive resampling draws are required")
    names = ["early_rule_endpoint_transitions.csv", "reliability_dataset_all_definitions.csv",
             "reliability_evidence_passport.csv", "device_rule_trace.csv"]
    frames = {name: pd.read_csv(args.analysis_dir / name, keep_default_na=False, na_values=[""])
              for name in names}
    transitions, ensemble, passport, trace = [frames[name] for name in names]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checks = []

    def check(name, passed, detail):
        checks.append(dict(check=name, passed=bool(passed), detail=str(detail)))
        if not passed:
            raise AssertionError(f"{name}: {detail}")

    def save(name, frame):
        frame.to_csv(args.output_dir / name, index=False, encoding="utf-8")

    base = transitions[transitions.scenario.eq(BASE)].copy()
    ids = set(base.device_uid)
    check("unique_base_devices", not base.device_uid.duplicated().any(), len(base))
    check("scenario_cohort_identity", all(set(g.device_uid) == ids and not g.device_uid.duplicated().any()
                                         for _, g in transitions.groupby("scenario")), "Same device identifiers in all scenarios")
    check("known_endpoint_states", set(ensemble.event_status).issubset(STATE), "All exported statuses recognized")
    ensemble["endpoint_state"] = ensemble.event_status.map(STATE)
    check("ensemble_unique_keys", not ensemble.duplicated(["device_uid", "p0_definition", "failure_threshold_ratio"]).any(), len(ensemble))
    check("ensemble_grid", ensemble.groupby("device_uid").size().eq(12).all() and set(ensemble.device_uid) == ids, "12 alternatives per device")
    ensemble_main = ensemble[ensemble.p0_definition.eq("p0_best_available") & ensemble.failure_threshold_ratio.eq(.8)]
    main_pair = base.merge(ensemble_main, on="device_uid", suffixes=("_sensitivity", "_ensemble"), validate="one_to_one")
    valid_main = main_pair.endpoint_state_sensitivity.ne("NA")
    check("independent_main_export_agreement", (main_pair.endpoint_state_sensitivity == main_pair.endpoint_state_ensemble).all()
          and not changed(main_pair.loc[valid_main, "analysis_time_h_sensitivity"],
                          main_pair.loc[valid_main, "analysis_time_h_ensemble"]).any(), "All states and assessable inspection times agree; NA has no analyzed lifetime")

    observed = valid_main & main_pair.event_observed_sensitivity.eq(1)
    check("independent_confirmation_agreement",
          not changed(main_pair.loc[observed, "event_confirmation_time_h"],
                      main_pair.loc[observed, "event_confirmation_exposure_hours"]).any(),
          "Observed events use the same threshold-specific confirmation inspection in both exports")

    paired_tables, source_rows, summary_rows, deletion_rows, bootstrap_rows = [], [], [], [], []
    rng = np.random.default_rng(args.seed)
    for scenario, alternative in transitions.groupby("scenario", sort=True):
        cols = ["device_uid", "file_id", "aging_temperature_C", "endpoint_state", "analysis_time_h", "event_observed", "p0_mW"]
        paired = base[cols].merge(alternative[cols], on=["device_uid", "file_id", "aging_temperature_C"],
                                  suffixes=("_base", "_alternative"), validate="one_to_one")
        check(f"paired_count_{scenario}", len(paired) == len(base), "Matched device/source/temperature including missing temperatures")
        paired.insert(0, "scenario", scenario)
        paired["state_changed"] = paired.endpoint_state_base.ne(paired.endpoint_state_alternative).astype(int)
        paired["time_changed"] = changed(paired.analysis_time_h_base, paired.analysis_time_h_alternative).astype(int)
        paired["baseline_changed"] = changed(paired.p0_mW_base, paired.p0_mW_alternative).astype(int)
        paired["paired_assessable"] = paired.endpoint_state_base.ne("NA") & paired.endpoint_state_alternative.ne("NA")
        paired["event_delta"] = np.where(paired.paired_assessable,
            pd.to_numeric(paired.event_observed_alternative)-pd.to_numeric(paired.event_observed_base), np.nan)
        paired_tables.append(paired)
        summary_rows.append(dict(scenario=scenario, **km(alternative), state_changes=int(paired.state_changed.sum()),
                                 time_changes=int(paired.time_changed.sum()), baseline_changes=int(paired.baseline_changed.sum())))
        for source, group in paired.groupby("file_id"):
            valid = group[group.paired_assessable]
            source_rows.append(dict(scenario=scenario, file_id=source, devices=len(group), paired_assessable=len(valid),
                                    events_base=int(pd.to_numeric(valid.event_observed_base).sum()),
                                    events_alternative=int(pd.to_numeric(valid.event_observed_alternative).sum()),
                                    state_changes=int(group.state_changed.sum()), time_changes=int(group.time_changed.sum()),
                                    baseline_changes=int(group.baseline_changed.sum()),
                                    paired_event_fraction_delta=float(valid.event_delta.mean()) if len(valid) else np.nan))
        if scenario == BASE:
            continue
        common = paired[paired.paired_assessable]
        clustered = common.groupby("file_id").event_delta.agg(["sum", "count"])
        # Same source draw weights both endpoint definitions: no independent resampling.
        draws = rng.integers(0, len(clustered), size=(args.bootstrap_draws, len(clustered)))
        denominators = clustered["count"].to_numpy()[draws].sum(axis=1)
        values = clustered["sum"].to_numpy()[draws].sum(axis=1) / denominators
        low, high = np.quantile(values, [.025, .975])
        bootstrap_rows.append(dict(scenario=scenario, paired_devices=len(common), sources=len(clustered),
                                   event_fraction_delta=float(common.event_delta.mean()), descriptive_p025=float(low),
                                   descriptive_p975=float(high), draws=args.bootstrap_draws, seed=args.seed,
                                   scope="Paired source-resampling stability interval; nine observed sources, not population inference"))
        for omitted in ["none", *sorted(base.file_id.unique())]:
            retained_base = base if omitted == "none" else base[base.file_id.ne(omitted)]
            retained_alt = alternative if omitted == "none" else alternative[alternative.file_id.ne(omitted)]
            b, a = km(retained_base), km(retained_alt)
            delta = a["median_h"]-b["median_h"] if a["median_h"] is not None and b["median_h"] is not None else None
            deletion_rows.append(dict(scenario=scenario, omitted_source=omitted,
                                      **{f"base_{k}": v for k,v in b.items()}, **{f"alternative_{k}": v for k,v in a.items()},
                                      median_delta_h=delta, delta_status="defined" if delta is not None else "at_least_one_median_not_reached"))

    binary = ensemble[ensemble.endpoint_state.ne("NA")].groupby("device_uid").event_observed.nunique().gt(1).reindex(sorted(ids), fill_value=False)
    state = ensemble.groupby("device_uid").endpoint_state.nunique().gt(1)
    pp = passport.set_index("device_uid")
    check("binary_fragility", binary.astype(int).eq(pp.binary_event_flip.reindex(binary.index)).all(), int(binary.sum()))
    check("state_fragility", state.astype(int).eq(pp.four_state_definition_change.reindex(state.index)).all(), int(state.sum()))
    numerical = km(base)
    benchmark = []
    for method, alternatives, retain_trace in [("Fixed registered main endpoint",1,False),
            ("Plain twelve-definition enumeration",12,False),("Full ordered representation",12,True)]:
        benchmark.append(dict(method=method, devices=len(base), endpoint_records=len(base)*alternatives,
                              main_assessable=numerical["n"], main_events=numerical["events"], main_km_median_h=numerical["median_h"],
                              main_state_differences=0, main_time_differences=0,
                              binary_fragility_identifiable=int(binary.sum()) if alternatives==12 else np.nan,
                              four_state_fragility_identifiable=int(state.sum()) if alternatives==12 else np.nan,
                              retained_trace_rows=len(trace) if retain_trace else 0,
                              comparison_type="Controlled export projection under identical endpoint rules; not independently implemented algorithms",
                              endpoint_accuracy="Not identifiable without independent endpoint truth",
                              review_benefit="Not measured"))
    # Honest information-removal ablation: output values unchanged by removing provenance.
    ablation = [dict(variant="Full ordered representation", retained_states="E/R/C/NA", retained_alternatives=12,
                     main_events=numerical["events"], distinct_main_clearance_records=int(base.endpoint_state.eq("R").sum()),
                     four_state_fragility=int(state.sum()), trace_rows=len(trace), claim="Reference representation"),
                dict(variant="Without trace fields",retained_states="E/R/C/NA",retained_alternatives=12,
                     main_events=numerical["events"],distinct_main_clearance_records=int(base.endpoint_state.eq("R").sum()),
                     four_state_fragility=int(state.sum()),trace_rows=0,claim="Information removal only; endpoint estimates unchanged"),
                dict(variant="Without alternatives",retained_states="E/R/C/NA",retained_alternatives=1,
                     main_events=numerical["events"],distinct_main_clearance_records=int(base.endpoint_state.eq("R").sum()),
                     four_state_fragility=np.nan,trace_rows=np.nan,claim="Across-definition fragility cannot be assessed; not zero"),
                dict(variant="Without later-clearance distinction",retained_states="event/C/NA",retained_alternatives=12,
                     main_events=numerical["events"],distinct_main_clearance_records=0,
                     four_state_fragility=np.nan,trace_rows=np.nan,claim="Five main E/R distinctions removed; binary events unchanged")]
    save("reference_paired_devices.csv", pd.concat(paired_tables, ignore_index=True))
    save("reference_source_summary.csv", pd.DataFrame(source_rows))
    save("reference_scenario_summary.csv", pd.DataFrame(summary_rows))
    save("reference_paired_source_bootstrap.csv", pd.DataFrame(bootstrap_rows))
    save("reference_source_deletion.csv", pd.DataFrame(deletion_rows))
    save("endpoint_representation_benchmark.csv", pd.DataFrame(benchmark))
    save("representation_information_ablation.csv", pd.DataFrame(ablation))
    save("numerical_checks.csv", pd.DataFrame(checks))
    manifest = dict(input_sha256={name:hashlib.sha256((args.analysis_dir/name).read_bytes()).hexdigest() for name in names},
                    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    bootstrap_draws=args.bootstrap_draws,seed=args.seed,checks_passed=all(c["passed"] for c in checks),
                    assumptions=["All comparisons use frozen endpoint rules and matched source/device identifiers.",
                                 "Numerical equality of enumeration and full representation is an intended honest result.",
                                 "Bootstrap pairs source weights across reference settings and does not refit or reconstruct targets.",
                                 "KM targets recorded threshold-crossing inspection time, not latent physical failure time.",
                                 "Source deletion is descriptive influence analysis; not external validation."])
    (args.output_dir/"analysis_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(json.dumps(dict(output_directory=str(args.output_dir), checks_passed=True, scenarios=len(summary_rows),
                         devices=len(base), sources=base.file_id.nunique()),indent=2))


if __name__ == "__main__":
    main()
